docs/branch-comparison-and-migration.md
docs/migration-checklist.md

完成 ## 十一、第 8 步：启动恢复与崩溃验证