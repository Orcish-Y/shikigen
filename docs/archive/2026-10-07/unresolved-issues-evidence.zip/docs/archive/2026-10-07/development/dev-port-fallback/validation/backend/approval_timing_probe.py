"""Diagnostic timings only; keep the original test and its deadline unchanged."""

import functools
import sys
import time
import unittest
from pathlib import Path
from unittest.mock import patch

repository_root = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(repository_root))
sys.path.insert(0, str(repository_root / "tests"))

from shikigen.runtime import run_execution
from shikigen.runtime.run_events import RunEventIngestor
from test_approval_resume import ApprovalResumeTests

probe_started_at = time.perf_counter()


def write_timing(boundary, duration=None, **fields):
  timestamp = time.perf_counter() - probe_started_at
  duration_text = "" if duration is None else f" duration={duration:.6f}s"
  print(
    f"[DEBUG-dev-port-approval] elapsed={timestamp:.6f}s "
    f"boundary={boundary}{duration_text} fields={fields}",
    file=sys.stderr,
    flush=True,
  )


def observe_async_call(boundary, invoke_original):
  @functools.wraps(invoke_original)
  async def invoke_with_timing(*arguments, **options):
    call_started_at = time.perf_counter()
    write_timing(f"{boundary}.start")
    try:
      outcome = await invoke_original(*arguments, **options)
    except BaseException as error:
      write_timing(
        f"{boundary}.error",
        time.perf_counter() - call_started_at,
        error_type=type(error).__name__,
      )
      raise
    write_timing(
      f"{boundary}.end",
      time.perf_counter() - call_started_at,
      reason=str(getattr(outcome, "reason", None)),
      status=str(getattr(outcome, "status", None)),
    )
    return outcome

  return invoke_with_timing


test_name = "test_waits_for_previous_cleanup_and_survives_caller_cancellation"
test_suite = unittest.TestSuite([ApprovalResumeTests(test_name)])
write_timing("imports.ready", has_desktop_module="app.desktop" in sys.modules)
with (
  patch.object(
    run_execution,
    "execute_agent_loop",
    observe_async_call("graph", run_execution.execute_agent_loop),
  ),
  patch.object(
    RunEventIngestor,
    "settle",
    observe_async_call("settlement", RunEventIngestor.settle),
  ),
):
  test_result = unittest.TextTestRunner(verbosity=2).run(test_suite)
write_timing("suite.end", has_desktop_module="app.desktop" in sys.modules)
sys.exit(0 if test_result.wasSuccessful() else 1)
