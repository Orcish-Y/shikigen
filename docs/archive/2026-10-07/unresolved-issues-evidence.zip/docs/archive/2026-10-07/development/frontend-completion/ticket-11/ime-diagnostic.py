"""原样执行旧 04 IME 用例，增加只读事件诊断，不补发输入事件。"""

import importlib.util
import json
import time
import unittest

from message_drafts_acceptance import MessageDraftAcceptance
from window_acceptance import REPO

spec = importlib.util.spec_from_file_location(
  "ticket10_diagnostics",
  REPO / ".scratch/frontend-completion/ticket-10/native-runner.py",
)
assert spec is not None and spec.loader is not None
diagnostics = importlib.util.module_from_spec(spec)
spec.loader.exec_module(diagnostics)
diagnostics.NATIVE_ROOT = REPO / ".scratch/frontend-completion/ticket-11/ime-diagnostic"
suite = unittest.TestSuite()
diagnostics.add_class_cases(
  suite,
  "04-ime",
  MessageDraftAcceptance,
  ["test_original_enter_composition_and_draft_survive_native_restart"],
  expected=1,
)
case = next(iter(suite))
instrument_sends = case.instrument_sends
call = case.call
quit_host = case.quit
commands = []
documents = []

TRACE = """(() => {
  window.__imeTrace = [];
  const state = () => ({draft:document.getElementById('message-draft')?.value,
    active:document.activeElement?.id, focused:document.hasFocus(),
    disabled:[...document.querySelectorAll('button')]
      .find(b=>b.textContent.trim()==='发送')?.disabled,
    run:document.querySelector('.toolbar-badge')?.textContent});
  for (const type of ['compositionstart','compositionupdate','compositionend',
      'beforeinput','input','keydown','keyup','focusin','focusout']) {
    document.addEventListener(type, event => {
      if (event.target?.id !== 'message-draft') return;
      const entry = {type, trusted:event.isTrusted, timeStamp:event.timeStamp,
        at:performance.now(), data:event.data, inputType:event.inputType,
        key:event.key, keyCode:event.keyCode, composing:event.isComposing,
        repeat:event.repeat, defaultPrevented:event.defaultPrevented,
        before:state()};
      window.__imeTrace.push(entry);
      queueMicrotask(()=>{entry.after=state();
        entry.defaultPrevented=event.defaultPrevented;});
    }, true);
  }
})()"""


def trace_install():
  case.call("Page.addScriptToEvaluateOnNewDocument", source=TRACE)
  instrument_sends()


def trace_call(method, **params):
  if method.startswith("Input."):
    commands.append({"method": method, "params": params, "at": time.monotonic()})
  return call(method, **params)


def trace_quit(host):
  documents.append(diagnostics.attempt(lambda: case.evaluate("window.__imeTrace")))
  return quit_host(host)


case.instrument_sends = trace_install
case.call = trace_call
case.quit = trace_quit
test_method = case._callTestMethod


def traced_test(method):
  try:
    return test_method(method)
  finally:
    payload = {
      "commands": commands,
      "documents_before_quit": documents,
      "events": diagnostics.attempt(lambda: case.evaluate("window.__imeTrace")),
      "draft": diagnostics.attempt(case.draft),
      "sends": diagnostics.attempt(lambda: case.evaluate("window.__sends")),
    }
    (case.artifacts / "ime-events.json").write_text(
      json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )


case._callTestMethod = traced_test
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
