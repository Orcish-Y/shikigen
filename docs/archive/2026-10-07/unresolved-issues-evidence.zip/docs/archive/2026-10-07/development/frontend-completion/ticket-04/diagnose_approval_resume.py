"""One-off diagnostic probe for the approval-resume cleanup timeout; not a test."""

import asyncio
import sys
import traceback
from pathlib import Path
from unittest import TestSuite, TextTestRunner
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT), str(ROOT / "packages/harness"), str(ROOT / "tests")]

from test_approval_resume import ApprovalResumeTests  # noqa: E402


class ApprovalResumeDiagnostic(ApprovalResumeTests):
  async def test_diagnostic_probe(self):
    settled, entered, returned, release = (
      asyncio.Event(),
      asyncio.Event(),
      asyncio.Event(),
      asyncio.Event(),
    )
    transitions = self.runtime.runs._transitions
    coordinator = self.runtime.runs._coordinator
    original = transitions.settle_execution
    wrapper_error = None
    timestamps = {}
    started = 0.0

    async def settle(**kwargs):
      nonlocal wrapper_error
      timestamps["entered"] = asyncio.get_running_loop().time()
      entered.set()
      try:
        result = await original(**kwargs)
      except BaseException as error:
        timestamps["failed"] = asyncio.get_running_loop().time()
        wrapper_error = error
        raise
      timestamps["returned"] = asyncio.get_running_loop().time()
      returned.set()
      timestamps["event"] = asyncio.get_running_loop().time()
      settled.set()
      await release.wait()
      return result

    async def snapshot(label, execution):
      row = await self.runtime.runs.read_run(self.thread, self.run_id)
      local = self.runtime.executions.get(self.thread, self.run_id)
      task = execution.task
      print(f"SNAPSHOT {label}", flush=True)
      print(f"  persisted_status={row['status']}", flush=True)
      print(f"  transitions_is_coordinator_settlement={coordinator._settlement is transitions}", flush=True)
      print(f"  registry_has_execution={local is execution}", flush=True)
      print(
        f"  settle_entered={entered.is_set()} settle_returned={returned.is_set()} "
        f"settle_error={wrapper_error!r} settle_event={settled.is_set()}",
        flush=True,
      )
      print(
        "  settle_elapsed="
        + repr({key: round(value - started, 3) for key, value in timestamps.items()}),
        flush=True,
      )
      if task is None:
        print("  execution_task=None", flush=True)
      else:
        print(
          f"  execution_task_done={task.done()} cancelled={task.cancelled()} "
          f"name={task.get_name()}",
          flush=True,
        )
        if task.done() and not task.cancelled():
          error = task.exception()
          print(f"  execution_task_exception={error!r}", flush=True)
          if error is not None:
            print("  task_exception_traceback:", flush=True)
            print("".join(traceback.format_exception(error)), flush=True)
        else:
          for frame in task.get_stack(limit=12):
            print(
              f"  execution_frame={frame.f_code.co_filename}:{frame.f_lineno} "
              f"{frame.f_code.co_name}",
              flush=True,
            )
      pending = [
        candidate
        for candidate in asyncio.all_tasks()
        if candidate is not asyncio.current_task()
      ]
      print(f"  other_tasks={len(pending)}", flush=True)
      for candidate in pending:
        print(
          f"    task={candidate.get_name()} done={candidate.done()} "
          f"cancelled={candidate.cancelled()}",
          flush=True,
        )
      events = await self.facts()
      print(
        "  recent_events="
        + repr([(item["seq"], item["event_type"]) for item in events[-8:]]),
        flush=True,
      )

    try:
      with patch.object(transitions, "settle_execution", side_effect=settle):
        started = asyncio.get_running_loop().time()
        print(
          f"IDENTITY transitions_is_coordinator_settlement={coordinator._settlement is transitions}",
          flush=True,
        )
        execution = await self.runtime.runs.resume_run(
          self.thread, self.run_id, await self.responses()
        )
        try:
          await asyncio.wait_for(settled.wait(), 3)
          elapsed = asyncio.get_running_loop().time() - started
          print(
            f"RESULT settled_within_3_seconds=True elapsed={elapsed:.3f}",
            flush=True,
          )
          await snapshot("settled-within-3-seconds", execution)
        except TimeoutError:
          print("RESULT settled_within_3_seconds=False", flush=True)
          await snapshot("3-second-timeout", execution)
          try:
            await asyncio.wait_for(settled.wait(), 5)
            print("RESULT settled_within_8_seconds=True", flush=True)
          except TimeoutError:
            print("RESULT settled_within_8_seconds=False", flush=True)
            await snapshot("8-second-timeout", execution)
        finally:
          release.set()
          if execution.task is not None and not execution.task.done():
            try:
              await asyncio.wait_for(self.runtime.runs.wait_run(execution), 5)
            except Exception as error:
              print(f"CLEANUP wait_run_error={error!r}", flush=True)
          task = execution.task
          task_error = task.exception() if task and task.done() and not task.cancelled() else None
          print(
            f"FINAL execution_task_done={task.done() if task else None} "
            f"cancelled={task.cancelled() if task else None} exception={task_error!r}",
            flush=True,
          )
    except Exception as error:
      print(f"PROBE_ERROR {error!r}", flush=True)
      raise


if __name__ == "__main__":
  suite = TestSuite([ApprovalResumeDiagnostic("test_diagnostic_probe")])
  result = TextTestRunner(verbosity=2).run(suite)
  raise SystemExit(0 if result.wasSuccessful() else 1)
