> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 07 票最终验证诊断

## 原生读取监测没有初始化

原正式两项验证 [native-run.log（原始产物已删除）](../../../README.md#已删除的材料)：2 项失败，exit 1。第一项在 `client_acceptance.py` 的 `instrument_fetch` 等待 `window.__requests` 5 秒时失败。

原方法最小复现仅跑第一项，不改产品或断言，在 teardown 前保存现场：[failure-state.json（原始产物已删除）](../../../README.md#已删除的材料)、[CDP 事件（原始产物已删除）](../../../README.md#已删除的材料)、[窗口截图（原始产物已删除）](../../../README.md#已删除的材料)。

先按三种可能核对：注入脚本词法变量冲突、页面重载未完成、注入入口没有执行。现场证明页面 complete、Tauri true、正文完整、已有 `__sends`，但缺少 `__requests`；CDP 明确记录 `SyntaxError: Identifier 'original' has already been declared`。

根因：`start_empty` 先注册 `instrument_sends`，它声明顶层 `const original`；随后 `instrument_fetch` 的另一段 Page 新文档脚本也声明同名顶层常量。后一脚本执行前报错，测试监测没有建立。

修正：共享 `instrument_fetch` 注入脚本包入 IIFE，将变量限定在自身作用域。公开 fetch 边界、请求记录、故障语义、全部原断言与 5 秒等待不变。第 03／04／05／06 正式实机回归会同时验证这处共享夹具调整。

## 原生打开失败注入没有生效

首轮第二项在等待“打开失败：系统拒绝打开”30 秒时失败。

核对三种可能：IPC 替换未生效、modified-click 没进入回调、错误没有传到组件。Tauri 2.11.6 的本机 `scripts/core.js` 用 `Object.defineProperty` 定义 `invoke`；原生只读探针 [result.json（原始产物已删除）](../../../README.md#已删除的材料) 确认 own=true、writable=false、configurable=false、无 setter。探针不打开系统浏览器，正常退出。

根因：正式测试用普通赋值尝试替换不可写的 `invoke`，不能建立预期故障边界。此时不能通过放宽断言、延长等待或增加产品测试开关处理。

修正：仅在 `http://ipc.localhost/open_web_url` 的外部 fetch 传输边界返回结构化 JSON 及 `Tauri-Response: error`，保留真实 `invoke`／`runCallback` 处理路径。其他 IPC 与后端请求照常转发；仍核对 modified-click 只产生一次受控命令、实际参数、局部错误和主窗口地址。全部原断言及 30 秒等待不变。真正 Rust 非法 URL 拒绝、权限拒绝和系统接受检查保持真实执行。

这两处修正只影响正式测试夹具，未改变产品实现。修后原生专项继续检查，初次失败不覆写。

## 完整查看关闭后焦点丢失

修后正式两项 [native-final-run.log（原始产物已删除）](../../../README.md#已删除的材料)：网页打开边界通过，正文查看在 Esc 关闭后的焦点断言失败。不能用网页用例通过抵消这一项失败。

按三个假设诊断：Markdown 子组件身份变化、原生 dialog 关闭时序、断言早于 React 清理。原方法与断言保持，在 teardown 前读取公开 DOM，保存 [focus-state.json（原始产物已删除）](../../../README.md#已删除的材料) 与[抽屉截图（原始产物已删除）](../../../README.md#已删除的材料)。同 turn、一帧、100ms、500ms 均为 BODY 焦点，页面有焦点且没有已打开 dialog；保存的原入口 `isConnected=false`，现有同类按钮均为不同节点。由此排除仅增加等待即可解决的假设。

根因：`AgentText` 每次 render 创建新的 Markdown renderer 函数；打开查看使父组件更新，React 因组件身份变化替换代码块及入口。Overlay 随后把 BODY 当作有效返回焦点，没有触发工作区回退。

修正：Markdown renderer 对象移至模块级，动态 identity／preview／onView 通过 Context 提供；Overlay 用 layout effect 管理原生 dialog，排除 BODY／HTML 返回入口，无有效入口则聚焦工作区。正式测试额外保存公开 DOM 入口，并断言关闭后原节点仍连接且 `activeElement` 是同一节点，保留全部原断言及等待。因产品变化，轻量子 agent 重新执行 Node 全套、类型／构建及增量审查；Rust／后端产品未改，不重复已完成的对应批量检查。新版构建完成后执行原生专项及旧票回归。

同一真实宿主的[脚注双向诊断（原始产物已删除）](../../../README.md#已删除的材料)确认前向和返回点击都聚焦同一消息内的准确目标；不同消息的 prefix 各自隔离。这项诊断不替代正式正文用例。

## 全数组复制的测试预期使用了 producer 键序

新版构建的 [native-focusfix-run.log（原始产物已删除）](../../../README.md#已删除的材料) 中，原文、代码复制、抽屉及新增同一入口焦点断言已通过；正文用例随后在全数组复制断言失败。实际 JSON 首个对象为 source／text／type，fixture 构造顺序为 type／text／source。原生网页用例再次通过；该次正文失败仍保留，不改算通过。

核对事实来源：用例此前已严格比较历史响应的完整内容与 fixture，所有字段、值和数组顺序相等；`EventStore._json` 原有序列化使用 `sort_keys=True`，GET 历史提供已保存的对象键序。前端复制 `JSON.stringify` 的是该公开历史内容；测试错误地使用生产 fixture 的插入顺序作为全文预期。

修正仅涉及正式验证：全文预期从真实 HTTP 历史响应构建，复制值先 `json.loads(copied) == CONTENT`，再严格比较完整字符串与预期；窄屏查看仍严格比较同一完整预期。另保存全量 copied／expected／history，以便验证所有字段和值以及数组顺序。没有改产品、删断言或延长时限；旧回归不重复，新第 07 票两项单独重新验证。

## 完整后端回归退出等待超时

首轮正式 291 项：289 通过、1 错误、1 Windows 权限跳过。空宿主环境变量分支等待子进程退出 20 秒超时；正式原用例隔离两次各 1 项通过，根因未确认。未修改后端或该测试；见[独立 needs-triage 问题](../../../../../issues/empty-host-environment-startup-exit.md)。

## 焦点修后类型检查进程受阻

新的 Node 111 项全通过，但 direct tsc 的首次修后进程长时间沉默，日志为空；只读进程快照显示 CPU 累计约 3 秒，8 个线程都处于 Wait。该次执行由测试 agent 核实任务身份后停止，仅结束本轮 node／PowerShell wrapper，记录为 248.582 秒、exit -1、受阻中止；没有类型检查结论，根因未知。

随后使用 Python subprocess 持续读取 stdout／stderr，执行完全相同的 direct tsc 命令，不改配置或产品，35.681 秒 exit 0，见 [tsc-final-focusfix-pipe.log（原始产物已删除）](../../../README.md#已删除的材料)。线程快照不能证明 PowerShell 重定向是根因；保留中止结果，不把它改算通过。前端构建随后使用同样的输出捕获方式执行。

## 原生 dialog 在 Tab 首尾边界短暂失去焦点

复制预期修正后的 [native-content-final-run.log（原始产物已删除）](../../../README.md#已删除的材料) 仍为 1 通过／1 失败：正文用例完整复制、原入口焦点、400px 抽屉及 390×780 下的 624px 面板已通过，随后 Tab 焦点断言失败。

先核对测试按键，正式用例把 `modifiers=1` 当作 Shift，但协议中 1 为 Alt、Shift 为 8，见 [Chrome DevTools 的 Input 协议源码](https://raw.githubusercontent.com/ChromeDevTools/devtools-protocol/master/pdl/domains/Input.pdl)。仅改按键不足以排除产品缺陷。

在原正式方法和断言不变的情况下，[只读诊断（原始产物已删除）](../../../README.md#已删除的材料)复现原失败；同一宿主保存[每步焦点、修饰键和截图（原始产物已删除）](../../../README.md#已删除的材料)。另明确重置起点后，正确的 0／8／0／0 短序列都在 dialog 内；连续正向 8 次的第 6 次、连续反向 8 次的第 4 次仍落到 BODY，dialog 保持 open，documentHasFocus 短暂 false。排除了“只改 Shift 值就完整满足要求”的假设。诊断本身保留原正式 1 失败；托盘退出返回 0。

产品修正：Overlay 在当前 dialog 的可见、非 disabled／inert、可 Tab 元素间处理首尾边界，正向末端返回首项，反向首项返回末端；中间仍使用浏览器导航，Alt／Ctrl／Meta 修饰不进入循环。正式测试改为正确 Shift 位并增加多轮正反方向，原焦点断言与全部内容断言保留。因公共产品改变，轻量 agent 重新验证前端全套、类型／构建及两轴审查，再用新版构建串行执行本票 2 项和旧票 10 项。Rust／后端没有新增变化，不重复对应全套。

## 完整正文的焦点圈没有继承既有样式

新版 [native-tabfix-run.log（原始产物已删除）](../../../README.md#已删除的材料) 共 12／12 通过。主 agent 目视[窄屏截图（原始产物已删除）](../../../README.md#已删除的材料)，仍发现只读 pre 的聚焦轮廓是浏览器默认黑色；`frontend/design.md` §9 要求 2px 靛蓝 outline、3px offset。既有 CSS 只为 button／input／textarea／summary／session-list 应用此规则，新 pre、表格及工作区的 tabindex 不在选择器中。

修正：把原 session-list 特例扩展为通用 `[tabindex]:focus-visible`，继续使用同一规则、颜色及尺寸。正式原生用例在多轮导航后读取 pre 的 computed style，严格断言 `rgb(79, 70, 229)`、`2px`、`3px`。只重新构建并补最新 Ruff／两轴增量审查，随后单独执行本票两项；原 10 项功能回归和前端／Rust／后端批次保持独立。所有初次截图与失败不覆写。

## 焦点间距的指定值与 WebView 解析值

[新样式专项（原始产物已删除）](../../../README.md#已删除的材料)为 1 通过／1 失败：正文用例的颜色与宽度通过，`getComputedStyle(pre).outlineOffset` 实际为 `2.66667px`，与测试要求的精确字符串 `3px` 不同。不能据此猜测补偿 CSS 或放宽容差。

按三个假设核对：存在覆盖规则、原生视口导致既有样式同样解析、仅新 pre 的样式偏差。保持原正式断言，在它之前读取公开 CSSOM、实际焦点态与视口，[最小诊断 JSON（原始产物已删除）](../../../README.md#已删除的材料)确认 pre 与现有关闭按钮都匹配同一规则，指定 `outline: 2px solid var(--accent); outline-offset: 3px`；两者聚焦时的颜色、宽度、间距精确相同，间距均解析为 `2.66667px`。切换至关闭按钮再恢复 pre 后结果不变。DPR 约 1，viewport scale 与 CSS zoom 均为 1；[截图（原始产物已删除）](../../../README.md#已删除的材料)呈现靛蓝焦点圈。底层解析原因未确认，不归因于 DPI 或 zoom。诊断保留原正式 1 项失败，没有算作验收通过。

修正仅涉及测试 oracle：在同一真实 WebView 中，pre、现有关闭按钮及恢复后的 pre 都必须为 active／focus-visible；匹配的指定 offset 严格为 `3px`，解析颜色与宽度严格为既有值，并严格比较三次完整快照相等。没有删焦点断言、放宽误差或改产品尺寸；指定值检查也防止两个控件同时偏离设计却通过比较。公开 CSSOM 不读取 React 私有状态。轻量 agent 随后只复验第 07 票两项，不重复已过的旧票 10 项或未变化的其他批次。

最终 [native-final-content-run.log（原始产物已删除）](../../../README.md#已删除的材料)：原正式两项均通过，0 失败／错误／跳过，12.323 秒、exit 0。正式[结果记录（原始产物已删除）](../../../README.md#已删除的材料)保留三个严格相等的焦点快照和完整 HTTP／复制内容；Root 核对原始日志、记录及最新截图。初次字符串断言失败与诊断仍独立保留。
