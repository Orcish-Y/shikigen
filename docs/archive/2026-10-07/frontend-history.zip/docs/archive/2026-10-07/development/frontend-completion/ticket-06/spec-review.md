> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 06 票规格审查与整改复核

基点：`c7931c2779e67d9437a2b1aec8ebfd668f33c093`。对照 PRD §6、contract §8/12、票据与 tracked/untracked 改动。

## 做得好的

- 原生事件循环读取实际窗口可见状态；前端先订阅后查询并按 revision 丢弃旧结果（`desktop.rs:46-55`、`workspace-visibility.ts:16-28`）。隐藏时撤销读取和计时器并保留投影/草稿；轮询串行且遵守 Retry-After。
- `enter()` 排队时立即清除已核实状态，避免沿用旧发送资格（`conversation-state.ts:181-185`）。

## 需修

- **原 hard finding：已解决（本次复核）。** 旧摘要 R2 的历史 GET 进行中若轮询发现 R3，旧结果曾可能抢回观察目标，违反票据 AC 3 与 PRD §6.222。现由 `summaryTarget` 保存目标身份，身份变化时中止旧探针、清空请求槽并启动新探针；回调校验捕获目标对象仍是当前目标；`stopSelection()` 清除目标，隔离切换/租约旧输入（`conversation-state.ts:83-84, 136-138, 579-605`）。新增的交错测试确认旧 signal 已中止且不观察 R2。

## 值得讨论

- 定向验证：cwd `C:/code/shikigen-agent`；`node --experimental-strip-types --test --test-name-pattern="a newer polled run invalidates an older history probe before it can take over observation" frontend/tests/visibility-polling.test.mjs`；结果 1 pass、0 fail、0 skip。本次 Spec 复核未运行完整套件或原生验收（该 agent 后续接续原生验证，另行记录）。主 agent 调度记录明确指定 `model: gpt-6-luna`、`reasoning_effort: max`、`fork_turns: none`；部署内部 SKU 未额外披露。

## 终态 Run 隐藏后恢复（只读复核）

- 符合 PRD §6.226 对正常结束、主动暂停和恢复停止的区分，以及 contract §8.136-139 的显示后重新定位要求：终态 Run 不重开 SSE；恢复时先清掉旧 paused/retry/failure，只有 snapshot GET 成功且 `verified` 后才设为 `closed`。snapshot 失败保持 `idle`/未核实并记录 `queryFailure`，不伪造 Run error 或正常结束。相关代码为 `conversation-state.ts:567-582`；新增公开测试 `visibility-polling.test.mjs:214-229` 检查成功路径。build106 正式原生场景截图也显示“观察正常结束”。

## 第 05 票等待断言（规格复核）

- 修正后的正式等待同时要求 toolbar badge 精确为“已完成”与观察“正常结束”，沿用原 20 秒时限；原断言保留，并补验已保存历史非空且所有消息 `run_status=completed`。这避免 AI 正文提前出现相同词句时误判 Run 已终态，符合 PRD §6.226 对正常结束与其他观察状态的区分、contract §8.129 对终态回放的约定。两项最终原生回归通过，详见 `native-fresh-agent-report.md`。
