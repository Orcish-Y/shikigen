> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 11 — Standards Review

固定点：`e0ea6aef1947dbb4b4a080ca993cfa05ddb99b6f`；审查 `git diff e0ea6aef1947dbb4b4a080ca993cfa05ddb99b6f` 及指定未跟踪源文件，commit list 为空。依据：`AGENTS.md`、`frontend/design.md`、Ruff/TypeScript 配置；未运行测试或 GUI。

## 做得好的

- `run_events.py` 将取消／失败正文构造收拢到 `_partial_messages`，避免两种结算各自维护序列化逻辑。
- `run_execution.py` 持有结算 Task，shutdown 取消并收集执行与结算任务；重试 sleep 位于协调锁外，取消仍可竞争。启动失败的交接和关闭路径整体有明确所有者。
- 新失败原因视图复用 `ContentBlock`，沿用完整查看与复制能力。

## 首轮发现（已关闭）

- **中｜文档规则违反，已关闭** — 首轮 [Conversation.tsx](../../../../../../frontend/src/components/Conversation.tsx#L94) 给 `error` 和 `cancelled` 共用中性的 `generation-cancelled`，违反 [frontend/design.md](../../../../../../frontend/design.md#L197) 的失败标记错误语义色要求。现改为按状态生成 `generation-error`／`generation-cancelled`；[styles.css](../../../../../../frontend/src/styles.css#L1061) 为失败状态增加 `#B91C1C`／`#FEF2F2`，取消仍为中性色；[RunFailure.tsx](../../../../../../frontend/src/components/RunFailure.tsx#L8) 的原因区也显式使用错误色。Node 断言分别检查两种 class，[native acceptance](../../../../../../frontend/src-tauri/tests/failure_partial_acceptance.py#L43) 检查失败色 RGB。该文档规则问题已关闭。

## 当前需要修

- 无（0 项硬问题）。

## 值得讨论

- **中｜异常分类建议** — [run_execution.py](../../../../../../packages/harness/shikigen/runtime/run_execution.py#L231) 对失败结算捕获所有 `Exception` 并无限重试；`InvalidRunState`、`RunNotFound` 或校验错误也会被当作暂时存储故障。建议仅重试可恢复的持久化异常，其他错误及时暴露，避免运行长期停在未结算状态。这是可维护性／错误诊断建议，不是已记录的硬规范。
- **低｜可能的 Duplicated Code（heuristic）** — [test_failure_partial_message.py](../../../../../../tests/test_failure_partial_message.py#L153) 中以下代码在 153、319、437 行重复，`fail_error` SQLite trigger 也在 163、328、445、476 行重复：

  ```python
  async def observe():
    async for frame in self.execution.stream.subscribe():
      if frame.event == "stream_failed":
        failed.set()
  ```

  可评估提取小型测试辅助方法；这是异味启发式，不是硬违规。

## 辅助脚本审阅

- [ime-diagnostic.py](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/ime-diagnostic.py#L20`） 通过旧 runner 选取既有 IME 原用例（`expected=1`）。新增脚本只记录 DOM 事件和 `Input.*` 命令，并将命令原样转发；没有新增输入事件、改断言或改变失败捕获。透明说明：原用例本身已有 `dispatchEvent(KeyboardEvent(... isComposing:true))` 和 CDP 输入命令，此诊断保留了它们。
- [failure-final.py（原始产物已删除）](../../../README.md#已删除的材料) 只选择本票唯一原生验收用例（`expected=1`）；未改测试方法或断言，也未放宽旧用例。
