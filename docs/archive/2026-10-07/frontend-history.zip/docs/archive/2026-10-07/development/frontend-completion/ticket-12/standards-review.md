> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 12 — Standards 复核（最终）

基线：a35232d461b38bdb48a8cbdad4ed6a59561dba0c；已按当前磁盘树复核 staged/unstaged 与六个新增源/测试文件。未运行测试。

## 做得好的

- `approval-decisions.ts:22-30,62-107` 使用领域名词与动作名表达身份、草稿、响应和历史事实；审批历史以服务端事件为准。
- 复用既有 `ConversationStore`、事件投影和内容查看器；审批控件遵守 `frontend/design.md:98` 的字号与触控目标规范。
- 回调名明确表达动作：`ConversationActions.rememberReadingPosition`、`BackendSession.createRunFrameReceiver`；Python 验收 helper 也使用 `read_approval_posts`、`choose_decision`、`update_rejection_reason`、`select_all_decisions`。

## 需要修的

- **当前没有未解决的硬标准违规。前版 finding 均已修复归档：** `remember` → `rememberReadingPosition`，`runReceiver` → `createRunFrameReceiver`；Node 测试实体改为 `nextApprovalRequestEvent`、`reorderedRequest`、`choicesBeforeSubmission`、`actualResponses`；HTTP 使用 `thread_id`/`actual_responses`，native acceptance 使用 `startup_snapshot`/`thread_id`。前版对应 finding 全部撤回。其余审批类型/函数、frame 回调、Store 更新方法及 fixture 命名也已按当前树核准。

## 值得讨论

- Fowler smell baseline 均为启发式，且仓库规则优先；已检查 Mysterious Name、Duplicated Code、Feature Envy、Data Clumps、Primitive Obsession、Repeated Switches、Shotgun Surgery、Divergent Change、Speculative Generality、Message Chains、Middle Man、Refused Bequest。可能的 **Data Clumps**：`identity/interruptId/index/choice` 在选择调用链重复传递，可考虑目标类型。可能的 **Primitive Obsession**：审批 `identity` 以普通 string 跨草稿与动作 API 传递，可考虑品牌类型。两者都不是当前缺陷。


## 重连窄修复复核

- `ConversationStore.canReconnect():boolean`（`conversation-state.ts:530-534`）以明确布尔谓词集中判断会话、写入与观察可用性；`reconnect()` 复用 guard。hook 只导出派生布尔值，App 传入 `activeRunId/canVerify`；Conversation 按记录 Run ID 传 `isActiveRun`，卡片仅对当前 Run 显示/启用读取动作，职责与事实归属清楚（`useConversations.ts:84`、`App.tsx:333-338`、`Conversation.tsx:96-98`、`ApprovalCard.tsx:74-76`）。
- 第 12 个 Node 测试的领域命名明确。native 测试先填写 `new_task_text`，再断言发送可用；unsupported 路径保留取消后零 POST、无工具副作用及真实 invalidated 事实断言，并在手动 GET 前验证该事实尚未显示（`approval_resume_acceptance.py:282-315,319-342`）。
- 本次窄 diff 的命名、样式与状态所有权未见新增硬标准问题；仅静态复核，未运行测试。
