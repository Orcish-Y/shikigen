> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 09 票：恢复聊天阅读位置与自动跟随

状态：已验收。票据：[第 09 票](../../../../../wayfinder/frontend-completion/implementation/09-chat-reading-position.md)。主agent已核对最后冻结构建的实际测试日志、请求、阅读几何和截图。

## 做什么、为什么、API

按会话记住正在阅读的消息/工具卡片与视口偏移，避免流式增长、重放、切换或布局变化把阅读拉走。记录保存在 App 生命周期内，Workspace 卸载不删除，应用重启首次仍定位最新。

`ChatReadingPositions` 管理跟随和锚点；`useChatReading` 通过浏览器主时间线测量、滚动意图、ResizeObserver/MutationObserver更新位置。它先采集已发生但 scroll 尚未递送的真实移动，区分布局夹紧与用户操作，保留操作行显隐时的 Home 手势。React组件呈现“有新内容/回到最新”。底部处理审批仅主动定位时间线只读状态卡片并有效焦点，正式审批写入仍为第12票。仅本次 POST 的有效接受metadata发出跟随意图，GET/用量/状态/标题查询沿用原事实而不强制到底。

视觉沿用白底、Slate细边框、现有次按钮和Phosphor图标；阅读入口独立占位，正文/输入不被悬浮按钮覆盖。

## 验收对应

| AC | 路径 | 最终证据 |
| --- | --- | --- |
| 1 首次/切回/隐藏/卸载/重启 | App内存所有者，独立会话稳定身份 | 原生switch/hide/reentry/restart通过，saved/restored均4541/-15.773，restart恢复following |
| 2 暂缺/失效/隔离 | 身份核实且读取结束后旧顺序最近邻，隐藏height0不覆盖 | 最终定向56项通过，含9项几何／门槛专项 |
| 3 上翻与动态布局 | 主时间线意图、布局锚点，内部滚动隔离 | 原生stream/replacement/layout/internal-scroll通过，代码区命中及实际内部滚动均断言 |
| 4 最新/新内容/接受 | Boolean提示、接受ID一次，GET不发信号 | 定向56项与原生有效接受／刷新重放／End恢复通过，公开POST仅2次 |
| 5 审批定位与独立滚动 | 时间线handle、focus preventScroll | 原生active approval定位、有效焦点及详情独立滚动通过，公开POST仅1次 |
| 6 切换/恢复/重复/失效 | 几何专项+真实Tauri隔离夹具 | 9项几何／门槛专项与3项本票原生通过，受影响07两项／08四项回归通过 |

## 验证与审查

最终由 `gpt-6-luna / max` 子agent执行，完整交接：[validation-context.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/validation-context.md`）。Standards与Spec两轴独立；基点 `eceb02064c0c77d18ac68e651e3dc84ffe21797d`，包含未提交新文件。

| 范围 | 已核对的实际结果 | 证据 |
| --- | --- | --- |
| 前端 | 首轮全套121通过；最终四文件定向56通过、0失败／跳过；最终类型与构建exit0。重叠批次不相加 | [前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/frontend-report.md`）、[最终56项日志（原始产物已删除）](../../../README.md#已删除的材料) |
| Rust | 25通过、0失败／忽略；fmt及backend_window构建exit0，Rust产品未变后不重复 | [前端／Rust报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/frontend-report.md`） |
| 后端 | 全套291项：290通过、0失败／错误、1 Windows symlink权限跳过；ty及两新Python最终Ruff检查exit0 | [后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/backend-report.md`） |
| 原生 | 最新修复09三项／07两项／08四项串行通过，均0失败／跳过、exit0；结合此前03–06十项共19个唯一案例，非一轮全19。旧失败保留 | [原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/native-report.md`）、[09日志（原始产物已删除）](../../../README.md#已删除的材料)、[07日志（原始产物已删除）](../../../README.md#已删除的材料)、[08日志（原始产物已删除）](../../../README.md#已删除的材料)、[失败与修复](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/diagnosis.md`） |

### Standards

独立 `gpt-6-luna / max` 审查无未解决硬规则或 smell finding；Ruff 首次排版失败已修并复验。见[审查记录](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/standards-review.md`）。

### Spec

独立 `gpt-6-luna / max` 静态核对无遗漏、超范围或相反实现。第12票接入正式审批卡片时继续沿用定位／焦点接口。见[审查记录](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/spec-review.md`）。静态通过不代表原生通过。

两轴剩余 finding：Standards 0；Spec 0。本票原生与受影响回归均已通过。

提交前暂存检查：源码、测试、文档及非原始日志文件的 `git diff --cached --check` 通过；两份早期 PowerShell 预检异常原始 stderr 含三处尾随空白，原样保留，不把这些日志内容算作源码格式通过。未调整仓库 Git 配置。

所有历史失败、额度中断和环境脚本错误保留：[diagnosis.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/diagnosis.md`）。软键盘/输入增高、物理Windows键盘/系统IME及多尺寸完整联合验收归第23票，WebView视口模拟不冒充这些证据。本地图片接口为14票，当前图片高度用例为浏览器布局边界模拟。后台两个历史 needs-triage 超时问题本轮未复现，但未确认根因，继续保留索引中的记录。
