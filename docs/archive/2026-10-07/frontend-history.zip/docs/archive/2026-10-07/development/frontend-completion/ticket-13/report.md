> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 13 票：恢复审批草稿并核实未知提交

日期：2026-10-06。规格：[实施票据](../../../../../wayfinder/frontend-completion/implementation/13-approval-draft-recovery.md)、[审批契约](../../../../../wayfinder/frontend-completion/tickets/003-approval-cancel.contract.md)。固定点 `29c3493a427e3132b76faee55dd47599dbec0c35`，本轮开始工作区干净。用户明确禁止 Git 修改；所有改动保留在工作区，不暂存、不提交、不切换分支。

## 实现

- 应用级 `ApprovalDrafts` 使用独立命名空间和 schema，完整保存会话、Run、checkpoint、Interrupt ID／namespace、动作及 review_configs、选择／原始原因和版本；Workspace 卸载不影响所有者。
- 保存本次提交 ID、捕获的 responses 和草稿版本。重开旧 pending 转 unknown；动态地址、租约、连接及运行事实不作为恢复资格持久保存。存储失败保留内存和警示。
- 全量 GET 正常结束、当前仍 interrupted、完整请求身份一致时才开放原选择；对象键顺序等价，数组顺序和省略／null 不等价。新请求默认未选，不自动提交。
- 409 重建、422 实际校验详情、503 等待和未知结果线索保留；请求与选择按 controller／租约／会话过滤旧响应。已接受只 GET 恢复，跨重启也不开放旧决策。
- 处理事实必须有完整匹配 required 身份才清对应记录，缺 required 只读保留；Run 终态按所属 Run 清理。404（包含后续快照 404）撤销操作资格而不删输入；补充快照 500 不撤销已完成全量 GET 资格。
- 沿用原稿的 `business-notice`、`ContentBlock` 和只读详情，提供本地输入核对／完整复制。它们不产生审批历史；历史只显示真实服务端 decisions。现有 POST body `{responses}` 保持契约；一次 GET 不排除先前请求稍后生效，人工重提仍可能 409。

新增产品文件：`frontend/src/approval-drafts.ts`、`frontend/src/components/ApprovalRecovery.tsx`。修改 `approval-decisions.ts`、`conversation-state.ts`、`useConversations.ts`、`App.tsx`；新增公开状态／客户端测试与真实 Tauri 验收。无后端产品、Rust、依赖或公开 API 变更。

## 验证与审查

最终验证由显式 **gpt-6-luna / max** 执行；主 agent 核对原始日志、metadata 和窗口证据。完整交接：[validation-context.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-13/validation-context.md`），完整命令与结果以[验证报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-13/validation-report.md`）为准。

已核对：

- 第一轮专项 **61 通过**；唯一完整前端回归 **164 通过，0 失败／取消／跳过**，约 99 秒。
- 完整回归期间有纯命名修正，随后规格审查补收紧身份清理，并新增缺 required 用例。完整 164 不是最终新增 13 用例版本的全套结果，不声称修复后重跑了全套；最终受影响专项 **91 通过，0 失败／取消／跳过**，含全部 **13** 项恢复测试及审批、重建、取消、会话、消息草稿、可见性回归。
- TypeScript **0 诊断**；最终构建 **exit 0**；本票原生验收文件及五个 runner，共 **6 个 Python 文件** Ruff check／format --check 通过。保留 JS 大于 500 kB 的构建警告。
- 原生首轮 **7 项：4 通过、3 失败**，三项新增均止于夹具脚本安装等待；补 `Page.enable` 后 **3 项：0 通过、3 失败**。单项诊断 **1 失败**，现场确认父夹具使用内存 checkpointer，进程重启后 checkpoint 丢失，后端按既有规则报告 `approval_state_corrupt`；重开验收夹具改用 SQLite，不改产品逻辑。
- SQLite 重试 **3 项：1 通过、1 失败、1 错误**。旧 pending 重开核实后人工提交、同一 Run 完成已通过；另外两项分别涉及旧文案断言，以及测试末尾误用尚未开放的 `/events` 接口。改为当前文案及现有 GET stream 核对，最终受影响 **2 项全部通过，0 失败／错误／跳过**。分批共覆盖 **7 个唯一原生用例**，各有最终通过证据；不声称存在一次 7／7 的全绿批次，也不改算早期失败。
- 原生最终截图和 result 已核对：[恢复原选择（原始产物已删除）](../../../README.md#已删除的材料)、[404 只读输入（原始产物已删除）](../../../README.md#已删除的材料)、[旧 pending 核实后的人工继续（原始产物已删除）](../../../README.md#已删除的材料)。选择／原因完整保留、只读 GET 无自动 POST；人工 POST 保持捕获原文，仅两项批准动作执行，历史属于原 Run。
- 真实 HTTP／SQLite／Graph 审批专项 **1 通过**。预置 5173 服务未被停止；其响应与当前 `frontend/dist` 全部 **38 个文件逐字节一致，0 不匹配**，独立只读核对补足 runner 只检查 index 直接引用两项资源的范围。

专项、完整及针对性回归重叠，不相加。开发红灯依次证实未保存选择、未恢复旧 pending、快照 404 沿用旧资格，以及缺 required 误删草稿；修复后针对性绿灯，不将预期红灯改算通过。

审查由两个独立 **gpt-6-luna / max** 子 agent 完成：[Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-13/standards-review.md`） 当前 0 剩余硬问题，初审命名问题已修；[Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-13/spec-review.md`） 当前 0 剩余硬问题，身份清理问题已修、409 文案建议已采纳。两个轴分别保留初审记录；审查未代替测试。

## 七条验收对应

| 条件 | 实现与证据 |
| --- | --- |
| 完整身份／内容／版本跨重启、独立 Workspace | 独立 `ApprovalDrafts`、全部请求 payload 和 version；公开重启恢复测试；原生实际重开保留两项已选及原始拒绝原因 |
| 全量只读核实、指纹一致、数组原序、新请求未选、零自动 POST | 13 项恢复专项中的全量 GET gate、键序与六种身份变化；91 项最终专项 |
| 旧 pending、隐藏／切换／租约、内存回退及 404 | pending 捕获／重开、旧 POST 迟到、保存失败、历史／stream／snapshot 404；原生旧 pending 先核实、人工继续，404 完整只读核对后 GET 恢复通过 |
| 409／422／503／未知结果／接受后 GET | 真实校验详情、跨重启 Retry-After、500／网络／解析异常、旧记录版本及 accepted 锁定专项；旧 12 项审批回归 |
| 实际 decisions、失效／终态锁定及人工继续警示 | `collectApprovalRecords` 服务端事实、真实 resolutions、未知重新提交 409、App 常驻核实提示；旧审批／取消回归 |
| 只清匹配记录、GET 失败保留、取消资格独立 | 完整身份集合、缺 required 不清、新 checkpoint 已编辑保留、404 禁止操作；取消与恢复专项 |
| 请求、重启及迟到竞态、无历史伪造／无自动审批 | 13 项公开测试覆盖捕获内容／版本、旧响应、无自动 POST、实际历史；原生重开无自动 POST，人工继续只执行两项批准动作且历史 Run 不变 |

## 范围与限制

本票保留上一票和索引中所有 needs-triage 历史问题，不因新一轮通过关闭。物理键盘／系统 IME、窗口边框及多尺寸联合验收仍归第 23 票。未重复无产品改动的 Rust 测试或完整后端回归；真实 HTTP/Graph 路径另行验证。前端构建的大文件警告保留，不算构建失败。

原生成功产物中的 `diagnostic-error.txt` 为宿主／WebView 退出后，cleanup 附加采集仍使用已关闭 CDP WebSocket 的错误；业务断言、result 和窗口截图已在退出前完成。验证子 agent 已按源码顺序核对，保留日志，不将退出后的附加采集误报为新一次业务验证。SQLite 夹具证明具备持久 checkpoint 的原生重开路径；内存 checkpoint 丢失后的既有服务端终态行为不在本票内改变。

审批核实只说明查询时刻事实，不新增服务端 checkpoint 条件提交或幂等键。只读备份保存的是本地输入，不是服务端历史事件；复制内容不改变运行。
