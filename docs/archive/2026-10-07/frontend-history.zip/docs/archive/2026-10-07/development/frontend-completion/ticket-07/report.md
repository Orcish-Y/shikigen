> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 07 票：安全 Markdown、网页链接与完整内容查看

实施日期：2026-10-05。状态：本票已验收；完整后端回归的一个退出超时另行追踪。

## 实现

**What**：按角色呈现完整正文、内容块、代码与 JSON；提供完整查看／复制以及受控网页打开。

**Why**：保留真实完整消息，同时让 Agent 回答可读；为后续工具、资源和运行详情提供统一只读入口。

**How**：`MessageBody` 使用 react-markdown、remark-gfm、rehype-sanitize；`markdown-policy` 在解析阶段文本化 HTML、保留 Windows／UNC／定义式引用并隔离脚注。`ContentViewer`／`ContentBlock` 直接复制源字符串或完整 JSON；`App` 复用现有 `Overlay`。Rust `open_web_url` 校验后调用 tauri-plugin-opener，关闭自动链接脚本，前端没有通用 opener 权限。

- Agent 字符串使用 Markdown；用户及工具字符串保留原文、空白和换行。内容块按原顺序展示，只识别明确的 `type=text`；额外字段与未知块可查看完整 JSON。
- 原始 HTML 显示为文字；代码和 JSON 不执行路径或链接。网页图片不自动读取，本地引用保持原始文字及复制入口，资源读取与文件确认分别留在第 14／15 票。
- 代码沿用 Slate、1px 边框、8px 圆角和单色等宽外观；表格横向滚动，代码／JSON 320px 区内滚动；完整内容使用桌面 400px 抽屉、窄屏 80dvh 底部面板。
- 查看为单一前景，关闭不改变观察、草稿或选择；入口失效时焦点回到稳定工作区。预览复制标为“复制当前片段”，失败保留可手选原文。
- 网页链接使用 button 统一调用受控命令，Ctrl／Shift 同一入口，没有原始 href／src 或新窗口链接旁路；错误局部反馈。

未修改后端产品、AGENTS 或 Git 暂存／提交。起始工作树干净，固定审查基点 `2cde5b5757e1065049fdfdc21e98d17ed6fd68ec`。新增依赖锁定兼容既有 Tauri／托盘版本，未进行整体升级。

## 开发红绿记录

- 公开 TSX 正文组件：角色呈现缺实现 → 最小组件通过；GFM／脚注测试红 → 解析与净化后通过。
- Windows 定义式链接测试红：定义的原始路径没有传到引用组件；补齐 definition／linkReference／imageReference 的受控引用传递后绿色。
- Rust 公开系统打开边界：缺模块编译红；校验与结构化错误实现后 2 项绿色。
- 主 agent 定向测试为 Node 5 项、Rust 2 项、类型和开发构建；最终批量验证由轻量子 agent 独立执行。

## 最终验收

所有最终测试及两轴审查显式调度 `gpt-6-luna / max`，完整交接见 [validation-context.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/validation-context.md`）。前端／Rust与后端验证并行；原生套件由单一 agent 串行执行。主 agent 已核对原始日志、完整复制记录、焦点快照及桌面／窄屏截图。没有重复累加同一用例的修后复验数量。

| 验证 | 工作目录／实际命令 | 最终有效结果 | 证据 |
| --- | --- | --- | --- |
| 前端全套 | `frontend`：`pnpm.exe test` | 111 通过，0 失败／跳过 | [最终前端日志（原始产物已删除）](../../../README.md#已删除的材料) |
| 独立类型检查 | `frontend`：`node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json` | exit 0 | [类型检查（原始产物已删除）](../../../README.md#已删除的材料) |
| 最新样式构建 | `frontend`：`pnpm.exe build`（包含 tsc） | exit 0；保留 >500 kB warning | [构建 stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| Rust 全套及格式 | `frontend/src-tauri`：`cargo test`；`cargo fmt --check` | 25 通过，0 失败／忽略；格式通过 | [Rust 日志（原始产物已删除）](../../../README.md#已删除的材料)、[格式（原始产物已删除）](../../../README.md#已删除的材料) |
| 原生测试宿主构建 | `frontend/src-tauri`：`cargo build --example backend_window` | exit 0 | [宿主构建（原始产物已删除）](../../../README.md#已删除的材料) |
| 本票真实 Tauri | 根目录：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-07/native-final-content-runner.py` | 2 通过，0 失败／错误／跳过，12.323 秒 | [最终专项日志（原始产物已删除）](../../../README.md#已删除的材料)、[原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/native-report.md`） |
| 旧票真实 Tauri 回归 | 根目录：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-07/native-focusfix-runner.py` | 03／04／05／06 分别 3／4／2／1 项通过，共 10 项 | [回归日志（原始产物已删除）](../../../README.md#已删除的材料) |
| Python 测试文件 lint／格式 | 根目录：`.venv/Scripts/ruff.exe check`／`format --check`，目标 `tests/desktop_markdown_fixtures.py` 及 `frontend/src-tauri/tests/{client_acceptance,markdown_content_acceptance}.py` | 三份文件均通过 | [check（原始产物已删除）](../../../README.md#已删除的材料)、[format（原始产物已删除）](../../../README.md#已删除的材料) |
| 完整后端回归 | 根目录：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` | 291 项：289 通过、1 错误、1 权限跳过，exit 1 | [完整后端日志](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/backend-unittest.log`）、[后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/backend-report.md`） |
| 后端错误原用例隔离 | 根目录：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_desktop.py -k test_environment_loaded_before_config_without_overriding_host -v` | 两次各 1 项通过；不抵消完整回归错误 | [复测一](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/backend-isolated-environment-test.log`）、[复测二（原始产物已删除）](../../../README.md#已删除的材料) |
| Python 类型 | 根目录：`.venv/Scripts/ty.exe check app packages/harness` | exit 0 | [ty（原始产物已删除）](../../../README.md#已删除的材料) |
| 收尾文档／Git 只读核对 | 根目录：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-07/check-documents.py` | exit 0；12 份文档、171 个本地目标无断链；HEAD 与固定基点相同、staged 空、diff 无空白错误 | `documents-git-final.json` |

Rust／后端产品未在焦点修复中变化，故未重复这些已完成批次。最终 CSS 变化仅补充原有焦点选择器，重新构建并运行本票专项；前端 111 项与旧票 10 项来自最后一次焦点循环产品变更后的有效批次。后续正式测试 oracle 修正不改变产品，增量运行 Ruff 与本票两项。

## 验收条件与证据

| AC | 结果与公开边界证据 |
| --- | --- |
| 1 角色与完整内容块 | Node 公开 TSX 测试核对角色、空白、额外字段与未知块；真实 HTTP 历史校对完整数组，复制值与其完整 JSON 严格一致。 |
| 2 安全 Markdown／GFM | Node 恶意及未闭合输入、任务／表格／脚注测试；真 WebView 无脚本执行或 image／iframe／form，任务只读、表格局部滚动；脚注双向目标另有[实机诊断（原始产物已删除）](../../../README.md#已删除的材料)。 |
| 3 单色代码／完整复制 | 真实文件名及语言、320px 代码区、完整代码与数组 JSON 均由正式用例核对；未闭合代码和片段标签由 Node 覆盖。 |
| 4 单前景／焦点／错误 | 桌面 400px，390×780 WebView 视口下底部 80dvh；同一入口关闭恢复、草稿不变、无新 POST／SSE、复制失败可手选；20 步双向 Tab 循环和既有焦点样式一致性通过。 |
| 5 原始引用／图片 | Windows／UNC／定义式引用保留；原路径无 href／src；工具原文、代码／JSON 不执行路径，网页图片不请求。 |
| 6 受控网页打开 | Rust 两项覆盖拒绝与系统错误；真 Tauri 拒绝非 HTTP(S)、通用 opener 权限拒绝、操作系统接受临时本机页面，修改键点击仍为一次受控调用，局部失败且主窗口不导航。 |
| 7 可复查与实机样式 | 正式结果保留 HTTP／复制／请求／焦点记录及截图；主 agent 核对[桌面抽屉（原始产物已删除）](../../../README.md#已删除的材料)与[窄屏完整正文（原始产物已删除）](../../../README.md#已删除的材料)，沿用 Slate、单色代码及靛蓝焦点。 |

两轴审查分别记录于 [Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/standards-review.md`） 和 [Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/spec-review.md`），本票直接范围均无剩余 finding；最终工作树审查范围为22份实现／测试／票据文件，另保留 scratch 证据和独立问题。实现、测试夹具、复制预期、原生焦点丢失／循环及焦点样式的初次失败和修复见 [diagnosis.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/diagnosis.md`）。最新焦点测试同时严格检查指定 `3px` 和同一 WebView 中既有按钮／正文的完整解析样式一致；底层间距解析差异原因未确认，没有反向补偿 CSS 或放宽误差。

## 保留问题与覆盖范围

- 后端完整回归在空宿主环境变量分支等待进程退出 20 秒超时；隔离两次未复现，原因未确认，[独立问题](../../../../../issues/empty-host-environment-startup-exit.md)仍为 needs-triage。Windows symlink 权限跳过单独计数。本票完成不表示完整仓库回归通过。
- 旧审批结算超时用例本轮为 `ok`，未修改路径或确认历史根因，[旧问题](../../../../../issues/approval-resume-settlement-timeout.md)仍保留。首次类型检查受阻、日志捕获与格式检查失败也保留于各分报告，不能改算通过。
- 390×780 是真实 Tauri WebView 的设备视口模拟；物理窄窗口、多尺寸、Windows 系统输入法及原生边框联合验收属于第 23 票。系统网页命令只证明操作系统接受打开，不额外声称浏览器 UI 已呈现。
- 最新入口 JS 为 523,240 bytes，构建保留 Vite >500 kB warning；没有提高阈值或隐藏提示。工具完整关联／结果卡片属于下一票 08，本轮未启动。

## 技术依据

- [react-markdown 官方说明](https://github.com/remarkjs/react-markdown)：插件与自定义组件入口。
- [rehype-sanitize 官方说明](https://github.com/rehypejs/rehype-sanitize)：允许列表净化及标识处理。
- [opener 2.5.3 Builder](https://docs.rs/tauri-plugin-opener/2.5.3/tauri_plugin_opener/struct.Builder.html)：关闭默认启用的自动链接脚本。
