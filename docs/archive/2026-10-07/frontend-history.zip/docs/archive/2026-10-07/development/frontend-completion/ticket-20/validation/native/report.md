> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 20 native validation report

最新结论：GPT-6-Luna / max 执行 `final-5` 完整四场景，4通过、0失败／错误／跳过，exit 0；最终Ruff check与format check通过。以下较早批次结果及其当时的后续安排作为历史保留，最后复验实际采用单批完整4／4，未按较早计划分批合并。物理输入、OS剪贴板及多尺寸联合检查仍未执行。

## Initial native batch: `final-1`

- **执行模型：**GPT-6-Luna，max（按验证派发指定）。
- **命令：**`uv run python .scratch/frontend-completion/ticket-20/native_runner.py --batch final-1`
- **工作目录：**`C:\code\shikigen-agent`
- **结果：**4 项真实 Windows Tauri/WebView2 验收中 1 通过、3 失败、0 跳过；进程退出码 1，运行 95.847 秒。
- **真实运行范围：**`backend_window.exe` + 临时数据库/离线 deterministic agent + 当前 `frontend/dist`，通过公开 HTTP 与 CDP 操作页面。runner 输出 `SHARED_DIST_SERVER_MODE=reused`、index 396 字节、2 个引用资源，并逐字节比较了 5173 服务的 index 与 bundle 和本地 dist。5173 是复用的现有静态服务；启动前 9238 与 45200 无监听。没有停止外部进程。
- **构建快照：**本批次 dist 的 `index.html` 最后修改时间为 2026-10-06 20:17:31；原生可执行文件为 `frontend/src-tauri/target/debug/examples/backend_window.exe`。本批次在本地时间复制控件构建之前运行；不是之后的最终产品构建。

### 验收明细

| 原生用例 | 结果 | 证据与结论 |
| --- | --- | --- |
| `test_committed_title_formal_override_filter_full_view_and_utc` | 失败 | 正文发送并保留原文、服务端正式标题覆盖、按标题过滤均已走到；键盘 Enter 激活侧栏会话“查看完整标题与时间”按钮后，30 秒内没有出现 `dialog[open]`。截图显示该按钮有焦点但抽屉未打开。失败发生在完整标题/时区/UTC 复制断言之前；不可视为这些断言通过。 |
| `test_native_restart_revalidates_cache_failed_read_and_storage_failure_keep_memory` | 失败 | 跨真实 Tauri 重启后标题缓存被公开历史重新核对，并验证读失败不是空态。最终的“存储写失败”警告等待超时，失败快照仍显示被注入的历史 HTTP 500 页面。之后定位到同一页面重复注入全局 `const` 的夹具问题，主 agent 已包 IIFE 修复；此旧批次不覆盖该修订。 |
| `test_examples_append_and_late_history_does_not_steal_input_or_modal_focus` | 失败 | 用例到达延迟历史与命令面板聚焦步骤；CDP 对 `Runtime.evaluate` 的返回值序列化失败：`Object reference chain is too long`。失败截图显示命令面板已打开、关闭按钮聚焦。原因是注入表达式末尾返回了 DOM Element；主 agent 已让表达式返回原始布尔值修复夹具。示例追加/无发送的更早断言已通过，但异步焦点结论未完成。 |
| `test_calendar_minute_and_midnight_refresh_is_display_only` | 通过 | 真实 Tauri 页面将 CDP 时区设为 `Asia/Shanghai`，通过页面虚拟时钟验证“今天/昨天/更早/日期待确认”分组、跨分钟更新成“1 分钟前”、显示刷新没有增加 HTTP 请求；真实更新时间排序也核对。该批次只用了页面虚拟时钟，未覆盖后续主 agent 新增的真实 WM_CLOSE 隐藏/托盘显示路径。 |

### 日志与截图

- 完整 unittest 输出及 traceback：`C:\code\shikigen-agent\.scratch\frontend-completion\ticket-20\validation\native\initial-final-1.stdout.log`
- 原生用例 artifacts：`C:\code\shikigen-agent\.scratch\frontend-completion\ticket-20\native\final-1\`
- 每个失败用例目录有 `failure.json`、`window.png`、`host-0.log`（重启用例另有 `host-1.log`）；日历通过用例目录有 `result.json`、`window.png`、`host-0.log`。
- `failure.json` 保留失败时页面正文、HTTP 请求路径/方法和焦点元素。首例截图显示长正式标题已显示、侧栏检查按钮聚焦、草稿仍保留。

## Ruff 初检记录

1. 首次指定的 `uv run ruff check ...` 发现新增 acceptance 文件 6 个 E501；`uv run ruff format --check ...` 通过。主 agent 随后按 lint 结果修整。
2. 主 agent后续插入 CDP 诊断 import 后，我再次执行 check，只发现 1 个 I001；format check 仍通过。主 agent 已说明该 import 排序已修正。
3. 最终 Ruff check 与 format check 待源码稳定后再跑；本报告不把以上中间 lint 结果当最终通过。

## 当时的下一批次计划 / 覆盖边界（已由后续批次完成）

当前保留 `final-1` 所有失败与截图，不覆盖或删除。主 agent 要求等双轴 review 小修及新的 frontend dist 完成后，在新 batch 中完整顺序重跑4个用例，覆盖：复制完整本地时间、脚本 IIFE、DOM primitive 返回和可见性真实关闭/恢复等修订。复测若仍有键盘激活失败，将进一步记录 `document.hasFocus`、目标按钮 `isConnected`、CDP key 事件结果；不会用编程式 click 替代键盘断言。

按票据与第23票边界，物理键盘/输入法候选、OS 原生剪贴板、系统窗口边框，以及联合尺寸/视口的实机覆盖仍未由本票完成。以上是当时的中间状态，已由下方 final-4/final-5 与最终 Ruff 记录更新。

## Final native recheck: batches `final-4` and `final-5`

### `final-4`: sandbox blocked CDP setup

- **执行模型：**GPT-6-Luna，max。
- **命令：**`$env:UV_CACHE_DIR = Join-Path $env:TEMP 'ticket20-uv-cache'; uv run python .scratch/frontend-completion/ticket-20/native_runner.py --batch final-4`
- **工作目录：**`C:\code\shikigen-agent`。
- **结果：**4 项全部在 `PaginationAcceptance.connect()` 等待本机 CDP endpoint 时失败，0 pass / 4 fail / 0 skip；运行 137.751 秒，退出码 1。四项都没有进入产品验收断言，不能据此判定产品失败。
- **证据：**[final-4.stdout.log（原始产物已删除）](../../../../../README.md#已删除的材料) 保存完整 unittest traceback；[原生 artifacts（临时产物已清理）](../../../../../README.md#已清理的临时产物) 中仅有 4 个空 `host-0.log`，没有 `result.json`、`failure.json` 或截图。失败现场 `9238` 无监听，`45200` 仅有 TIME_WAIT；没有终止任何外部进程。

### `final-5`: elevated Windows Tauri/WebView2 recheck

- **执行模型：**GPT-6-Luna，max。
- **命令：**`$env:UV_CACHE_DIR = Join-Path $env:TEMP 'ticket20-uv-cache'; uv run python .scratch/frontend-completion/ticket-20/native_runner.py --batch final-5`，通过 `require_escalated` 执行，以允许隔离测试启动本机 Tauri/WebView2 并连接 loopback CDP/fixture 服务。权限执行获准；未停止外部进程。
- **工作目录：**`C:\code\shikigen-agent`。
- **结果：**4 pass / 0 fail / 0 skip；38.118 秒，退出码 0。runner 复用了 5173 静态服务，报告 `SHARED_DIST_SERVER_MODE=reused`、index 396 bytes、2 个引用资产，并连接了真实 `backend_window.exe`。本次 dist index 修改时间为 2026-10-06 21:33:04；native 可执行文件为现有 `frontend/src-tauri/target/debug/examples/backend_window.exe`（修改时间 2026-10-06 13:30:01）。
- **精确 stdout：**[final-5.stdout.log（原始产物已删除）](../../../../../README.md#已删除的材料)。每个用例的 `result.json`、`window.png` 与 `host-0.log` 保存在 [final-5 artifacts（临时产物已清理）](../../../../../README.md#已清理的临时产物)；标题/复制用例另有 `identity.png`，重启用例另有 `host-1.log`。

| 用例 | 结果 | 实际核对范围 |
| --- | --- | --- |
| `test_committed_title_formal_override_filter_full_view_and_utc` | 通过 | 首条用户消息原文保留；正式服务端标题覆盖临时标题，完整标题过滤、键盘激活完整标题/时间抽屉、Asia/Shanghai 本地时间和 UTC 原值复制通过。正式时间复制值与公开线程 `updated_at` 一致；清除正式标题后回退至已核实临时标题，草稿保留。请求只包含该会话的已知消息读取路径（完整历史或真实 `run_id` 的终态消息）和列表读取，无 PATCH。`result.json` 保存完整标题、复制时间和最终草稿。复制通过页面 clipboard stub，非 OS 剪贴板。 |
| `test_native_restart_revalidates_cache_failed_read_and_storage_failure_keep_memory` | 通过 | 真实 native 退出/重开保留草稿；过期标题缓存由公开历史重新核对；历史读取失败保留标题且不显示空态，恢复读取后刷新；标题缓存写失败显示标题内存提示，同时草稿仍可本地持久保存且不出现“草稿仅在本次应用中保留”提示。 |
| `test_examples_append_and_late_history_does_not_steal_input_or_modal_focus` | 通过 | 三条例子逐字追加到非空草稿、保留输入焦点且不发送；迟到历史不抢命令模态焦点；会话切换期间另一会话的草稿/选择/输入焦点不被旧响应覆盖；请求记录没有 `/stream` POST。 |
| `test_calendar_minute_and_midnight_refresh_is_display_only` | 通过 | 真实 Tauri/CDP 页面验证 Asia/Shanghai 的今天/昨天/更早/日期待确认分组、跨分钟相对文案和时间身份；页面虚拟时钟推进不增加 HTTP。真实 `WM_CLOSE` 隐藏与托盘“打开主窗口”恢复通过；重新显示只发一次列表 GET 和一次所选历史 GET。时间推进采用页面虚拟时钟。 |

本票实机覆盖仍不包含物理键盘/输入法候选、OS 原生剪贴板、系统边框测量或联合视口/窗口尺寸验收。页面键盘操作由 CDP 驱动。`final-4` 的 sandbox 失败记录完整保留；`final-5` 是使用最新 dist 和最新验收夹具的完整结果。

## Final Ruff results

最终在代码稳定后分别执行以下命令，均退出码 0：

- `$env:UV_CACHE_DIR = Join-Path $env:TEMP 'ticket20-uv-cache'; uv run ruff check frontend/src-tauri/tests/conversation_presentation_acceptance.py .scratch/frontend-completion/ticket-20/native_runner.py .scratch/frontend-completion/ticket-20/prepare_review.py` — `All checks passed!`
- `$env:UV_CACHE_DIR = Join-Path $env:TEMP 'ticket20-uv-cache'; uv run ruff format --check frontend/src-tauri/tests/conversation_presentation_acceptance.py .scratch/frontend-completion/ticket-20/native_runner.py .scratch/frontend-completion/ticket-20/prepare_review.py` — `3 files already formatted`。

失败历史保留如下：既有初检先发现 acceptance 文件 6 个 E501，修整后新增诊断 import 曾有 1 个 I001；本次首次调用默认 uv cache 时被拒绝访问，改用 `%TEMP%` 缓存后发现两处 E501（`conversation_presentation_acceptance.py:104` 与 `:153`）。主 agent 修复后，最终独立 `ruff check` 与 `ruff format --check` 均通过。

## Historical native batch: `final-2` (interim run, superseded by `final-5`)

- **命令：**`uv run python .scratch/frontend-completion/ticket-20/native_runner.py --batch final-2`
- **退出码 / 耗时：**1 / 53.450 秒。结果 2 通过、2 失败、0 跳过。失败均在测试尝试按 `ClientAcceptance.click("关闭")` 搜索按钮后超时。
- **dist：**`frontend/dist/index.html` 为 396 字节，mtime 2026-10-06 20:27:48；runner 确认 `SHARED_DIST_SERVER_MODE=reused`、索引及 2 个引用资产字节完全匹配。Windows 真实 Tauri 主机仍为现有 `backend_window.exe`；启动前 9238、45200 端口空闲。未停止既有服务。

| 用例 | 结果 | 已实际断言的范围 |
| --- | --- | --- |
| `test_committed_title_formal_override_filter_full_view_and_utc` | 因夹具关闭按钮定位失败 | 首条提交正文原文在公开历史中保留；临时标题与服务端正式标题覆盖；过滤匹配正式标题；键盘 Enter 打开完整标题与时间面板；标题和 `Asia/Shanghai` 正确；UTC 复制值等于公开会话的原始 `updated_at`；本地时间复制值等于页面完整本地时间。`identity.png`/失败快照记录两个复制按钮均显示“已复制”。以上断言通过。之后测试调用按可见文字 `textContent` 查找 icon-only `aria-label="关闭"`，超时退出；清除过滤后 formal→null 回退、草稿不丢及无 PATCH 的尾部断言未执行。 |
| `test_native_restart_revalidates_cache_failed_read_and_storage_failure_keep_memory` | 通过 | 真实退出/重启恢复草稿；过期本地标题经完整公开历史重新核对；历史 500 保留标题且不伪装空态；刷新恢复；Storage 写失败时保留内存标题/草稿并提示；只读请求约束通过。`result.json` 保存首尾 cache 来源。 |
| `test_examples_append_and_late_history_does_not_steal_input_or_modal_focus` | 因相同夹具关闭按钮定位失败 | 三条例子逐字追加、焦点保留、未发送；创建第二会话后迟到的第一会话历史不打断当前输入；命令模态保持原聚焦元素；用例在命令模态的 `aria-label="关闭"` 按钮关闭步骤失败。该次结果检查到此为止，所以随后切回另一会话时保护其草稿的尾部竞态断言未执行。`failure.json` 显示路径截至此点只有创建会话 POST，没有 `/stream` 自动发送。 |
| `test_calendar_minute_and_midnight_refresh_is_display_only` | 通过 | 本地“今天/昨天/更早/日期待确认”分组、未来日期绝对分组、时区转换、分钟更新、排序身份，以及更新显示不增加请求；新增真实 `WM_CLOSE` 隐藏/恢复路径通过。整个原生页面/CDP会话是实机，显示时间部分采用页面虚拟时钟。`result.json` 记录初始四个分组、原始 UTC 微秒时间及请求/页面范围。 |

两个失败共用根因：`ClientAcceptance.click` 只匹配 `button.textContent`，但 Overlay 关闭按钮是无文字 SVG 按钮，仅有 `aria-label="关闭"`。这属于原生验收辅助器查找策略，不是组件缺少关闭按钮或焦点回归。主 agent 已加 `close_overlay` 定位 `dialog[open] button[aria-label=关闭]`、点击并确认关闭的 helper；下一批只重新跑上述两个受影响用例。最终应合并本批2个通过与新批对应2个通过，按票据说明是两个独立 batch 覆盖四项场景，不能说单一4/4批次。

- **本批 stdout 和 traceback：**`C:\code\shikigen-agent\.scratch\frontend-completion\ticket-20\validation\native\final-2.stdout.log`
- **完整本批截图、host 日志、result/failure JSON：**`C:\code\shikigen-agent\.scratch\frontend-completion\ticket-20\native\final-2\`
- 最后一次工具响应曾将 `关闭` 两字显示成替换符，归档日志按测试源码恢复该 label；页面 HTML 的真实 aria-label 可在 failure JSON 中核对。
