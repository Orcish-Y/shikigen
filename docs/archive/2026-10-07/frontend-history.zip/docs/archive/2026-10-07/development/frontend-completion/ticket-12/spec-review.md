> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 12 票 Spec 审查

固定点：`a35232d461b38bdb48a8cbdad4ed6a59561dba0c`。本轮静态复核当前工作树中的 8 条验收、003 契约及新增实现；未运行测试。

## 做得好的

- 当前审批仅在全量 GET stream 正常结束、Run 仍 interrupted 且完整请求事实一致时可编辑；responses 覆盖全部 Interrupt，decisions 按服务端动作顺序生成，body 仅含 `responses`。[conversation-state.ts](../../../../../../frontend/src/conversation-state.ts#L597)、[approval-decisions.ts](../../../../../../frontend/src/approval-decisions.ts#L75)、[backend-client.ts](../../../../../../frontend/src/backend-client.ts#L232)
- POST metadata 经同 Run 校验后才确认接收；本地选择不生成历史，resolved／invalidated 与实际 decisions 均取自服务端事件。不支持的动作组保持只读。[conversation-state.ts](../../../../../../frontend/src/conversation-state.ts#L633)、[approval-decisions.ts](../../../../../../frontend/src/approval-decisions.ts#L92)、[ApprovalCard.tsx](../../../../../../frontend/src/components/ApprovalCard.tsx#L34)
- 终态 required 缺真实 resolution 时卡片只读并说明尚未读取处理记录；只有当前 Run 提供 GET 补读入口。`canReconnect` 复用观察／查询互斥，并以在途写请求等状态阻止重连；Run snapshot 不会制造审批事件。[ApprovalCard.tsx](../../../../../../frontend/src/components/ApprovalCard.tsx#L74)、[ConversationStore](../../../../../../frontend/src/conversation-state.ts#L530)
- 旧 Run 参数抽屉按目标 `runId` 的状态标为历史，并保留真实 resolution 优先。[App.tsx](../../../../../../frontend/src/App.tsx#L445)

## 需要修的问题

当前未发现剩余 Spec 缺陷；已核对 8 条验收及 003 中的身份核对、提交互斥、事实来源、终态只读、拒绝原因、详情与定位行为。

## 值得讨论

- 终态未读事件分支由 native 用例覆盖：先等审批 GET 完整结束，再以取消快照取得 terminal 状态，断言卡片仍无审批处理记录且只读；开启新 Run 后重开旧参数，仍标为历史。[approval_resume_acceptance.py](../../../../../../frontend/src-tauri/tests/approval_resume_acceptance.py#L320)
- Node 第 12 用例覆盖终态只读、手动 GET 读取真实 invalidated、且不重发 POST。[approval-decisions.test.mjs](../../../../../../frontend/tests/approval-decisions.test.mjs#L286)
- **撤回记录：**曾疑虑身份 helper 未单独接收 `threadId`；协议要求 checkpoint.thread_id 等于所属会话，且该字段已纳入规范化请求身份，因此不构成缺陷。[run-protocol.ts](../../../../../../frontend/src/run-protocol.ts#L50)、[approval-decisions.ts](../../../../../../frontend/src/approval-decisions.ts#L28)
