> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# interaction-matrix-final-4 OSK 截图证据复验

## 执行信息

- PRD：`.scratch/frontend-completion/PRD.md`，#11 / Story 114。
- 用例：`docs/wayfinder/frontend-completion/implementation/23-native-workflow-acceptance.md`，OSK + 长内容 + TrayNotice + 四原生操作。
- 模型：`gpt-6-luna / max`；工作目录：`C:\code\shikigen-agent`。
- 命令：

  ```powershell
  .venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch interaction-matrix-final-4 --tests NativePlatformAcceptance.test_osk_long_draft_tray_notice_and_native_cancel_remain_reachable
  ```

- 结果：1 selected / 1 executed / **1 passed / 0 failed / 0 error / 0 skip**；runner exit 0，unittest 用时 23.165 秒（cases summary 单项 18.969 秒）。
- `native_platform_acceptance.py` pre/post SHA-256 `965AB30E612AC5E5E880460B5334B66EAD37210E91D77C3B4453874998274E62`；runner `4F802C6F4BD38C18190D99C774E134CC3EFFC03D0BE6C804D8322B607E4F756D`，均未变化。Ruff check/format check 均 exit 0；精确 `--list` 只选 1 项。复用的 dist 38 文件逐项哈希一致，1,049,454 bytes，manifest SHA-256 `fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f`。

## 真实 OSK 画面

我用本地图片查看器实际检查了本批 `osk-coexistence-native.png`：画面清楚显示 Windows“屏幕键盘”标题栏和完整 QWERTY 键区。`osk-coexistence-app-native.png` 是另一个独立窗口捕获，显示 Tauri 应用、缺少托盘图标提示、390×600 手机布局和多行保留草稿。因此两图分别证明 OSK 与应用窗口；不声称单一位图同时清楚显示两个窗口。图像复核证据见 [screenshot review（原始产物已删除）](../../../../../README.md#已删除的材料)。

UI Automation 观察到真实键盘 `OSKMainClass` / `ControlType.Window`，`is_offscreen=false`、`is_enabled=true`，bounds `[100,100,2183,701]`；其 `DirectUIHWND` 面板亦报告非 offscreen。键盘 PID 33876、HWND 29755782。测试中保持 OSK 存在并完成 Tauri 上四个主要动作；没有注入 OSK 键击，也没有声称使用 TabTip 或实体手指。

## 布局、动作与状态

窗口在与验收 fixture 相同的 system-aware 坐标空间中按 CSS viewport 390×600、DPR 1.5、native DPI 144 运行。primary monitor rect `[0,0,2880,1920]`，work area `[190,0,2880,1920]`；Tauri native window rect `[2257,948,2864,1904]`，完整位于 work area，右/下留白 16 px。工作区及 placement 证据见 [work-area placement（原始产物已删除）](../../../../../README.md#已删除的材料)。

阶段顺序为 `approval → send → reconnect → cancel`。第一 Run `5bebabc6ae1247808e5a79d7916060b6` 的准备消息最终 `completed`；第二 Run `e98e51bc60a5435c9c1402ef4c5d4f69` 的 390 字符原文通过发送、手动重连，并在取消后 `cancelled`。API 总体断言保持 2 次 stream POST、1 次 approval POST、1 次 cancel POST；第二 Run stream GET 恰为 4。可信原生点击目标序列包括“处理审批”“批准”“提交决策”“发送”“重新连接”“取消运行”“确认取消”。最后的取消确认点击元数据中，WindowFromPoint 命中 HWND 与预期 Tauri HWND 相同，class 为 `Tauri Window`，前景 HWND 同属该应用。

30 行草稿原文发送后，保留的下一草稿为 420 字符、30 行；result/workflow 记录阅读锚点在准备消息处、`following=false`、`newContent=false`。这些检查通过后，case 释放 stream、退出窗口并清理本例键盘。完整动作/请求/历史/草稿记录见 [result](../../../../../native-acceptance-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/native/interaction-matrix-final-4/NativePlatformAcceptance/test_osk_long_draft_tray_notice_and_native_cancel_remain_reachable/result.json`） 与 [stage workflow（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 清理与剩余边界

post-check 发现 9238/45200 空闲，本例 backend/Tauri/OSK 进程均退出；5173 PID 23344、TabTip PID 14204 保持。旧 OSK HWND 现已失效，未重新打开窗口，也未对失效 HWND 调用 `GetWindowDisplayAffinity`；只读状态记于 [OSK handle probe（原始产物已删除）](../../../../../README.md#已删除的材料)。源哈希、预检、完整 runner 输出与清理记录见 [preflight（原始产物已删除）](../../../../../README.md#已删除的材料)、[invocation（原始产物已删除）](../../../../../README.md#已删除的材料)、[stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[post hashes（原始产物已删除）](../../../../../README.md#已删除的材料)、[cleanup](../../../../../native-acceptance-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/interaction-matrix-final-4/post-batch-cleanup-observation.json`）。

本项证明 OSK 与 Tauri 同时存在时，审批、发送、重连和取消的真实 Windows 鼠标动作可达；不覆盖 OSK 字符键注入、TabTip、实体触摸硬件或物理键盘输入。

