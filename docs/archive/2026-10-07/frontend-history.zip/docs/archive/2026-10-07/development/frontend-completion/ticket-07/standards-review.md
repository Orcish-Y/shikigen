> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Standards review（Ticket 07）

固定基线：`2cde5b5757e1065049fdfdc21e98d17ed6fd68ec`；审查根 `AGENTS.md`、`frontend/design.md`、`docs/agents/issue-tracker.md`、`CONTEXT.md`，范围为本票 `files.json` 的 21 个文件（tracked diff 加新增源文件）。

## 做得好的

`MessageBody.tsx`（新增 hunk +1–101）把角色展示与完整 JSON 查看放在可复用边界；`markdown-policy.ts`（+1–82）集中管理来源保留、净化和脚注 scope。`web_open.rs`（+1–37）先校验再调用系统 opener，并用回调 seam 测错误路径。`styles.css`（约 +536 起）沿用 Slate/靛蓝语义，局部滚动与 320px 内容区及 44px 操作目标符合 `frontend/design.md` §§3–5、9。

## 需要修

未发现违反仓库硬性规范的问题。按 Mysterious Name、Duplicated Code、Feature Envy、Data Clumps、Primitive Obsession、Repeated Switches、Shotgun Surgery、Divergent Change、Speculative Generality、Message Chains、Middle Man、Refused Bequest 逐项检查，未发现值得报告的 possible smell。工具已覆盖的 Python 格式和 Ruff 规则不重复判定。

## 值得讨论

无新增规范议题。Cargo 锁文件增加 opener 依赖树；`tauri`/`tauri-utils`/`tray-icon` 现有版本未升级，新增插件固定为 `tauri-plugin-opener 2.5.3` 与 `tauri-plugin 2.5.4`，没有看到无关主版本更新。

## 增量 Standards 复核（原生首轮诊断修复）

复核 `frontend/src-tauri/tests/client_acceptance.py:124–151` 与 `frontend/src-tauri/tests/markdown_content_acceptance.py:314–351`。`instrument_fetch` 的 IIFE 只把 `const original` 和注入函数限定在局部，避免与同页 `message_drafts_acceptance.py` 的顶层词法声明重名；没有改测试断言或超时。诊断记录在 `native-diagnostic-run.log` 中指向 `instrument_fetch` 等待 `window.__requests`，`failure-state.json` 显示 requests 未初始化，符合注入脚本未执行的边界故障。

网页打开失败注入现在只拦精确 `http://ipc.localhost/open_web_url`，其他 fetch 交回原实现，并返回 Tauri IPC error envelope；真实 `invoke/runCallback` 继续处理结构化错误。后续仍断言按钮错误文案、命令/参数、URL 不变和无 href/src；未见放宽断言或延长 timeout。`native-ipc-diagnostic/.../result.json` 记录 `invoke` descriptor 为 own=true、writable=false、configurable=false，支持不应对其直接赋值的诊断。

未发现此增量违反测试/仓库规范或遮掩问题。代码中没有找到独立的 IPC helper 文件；新增的 IPC 边界拦截位于正式测试 `markdown_content_acceptance.py` 的用例中。

## 增量 Standards 复核（focusfix）

`MessageBody.tsx` 将 React-Markdown 的 `Components` 对象提升到模块级，`MarkdownContext` 向稳定组件提供 identity、preview 和最新 onView。onView 随工作区父组件 rerender 更新时，Renderer 类型保持稳定；焦点触发按钮不会因闭包函数身份变化而卸载，符合 `frontend/design.md` §9 的关闭后返回焦点要求。`Overlay.tsx` 用 `useLayoutEffect` 同步 showModal/close；只在 previous 仍连接、非 body/documentElement 且不位于 inert 下时恢复焦点，否则回到带 tabIndex 的 chat-workspace。新增正式断言保留既有可见标签检查，并验证触发按钮仍 connected 且为同一 activeElement；没有移除断言或延长等待。

共享 `instrument_fetch` IIFE 复核结论不变：解决页面顶层 const 冲突，仅封闭局部变量。未发现该增量有硬规范违例或新 possible Fowler smell。

## 增量 Standards 复核（正式测试的 JSON oracle 修正）

`markdown_content_acceptance.py` 早先红日志 `native-focusfix-run.log` 显示失败在完整复制 JSON 的 expected 字符串顺序；`EventStore._json` 会排序对象键。当前测试仍先用 `history[-1]["content"]["content"] == CONTENT` 校对公开 HTTP 事实，再以实际 history 构造 `complete_text`；复制后同时断言 `json.loads(copied) == CONTENT`（完整值及数组顺序）与 `copied == complete_text`（精确 wire serialization）。记录实际 history/copied/expected 后再断言。既有窄屏代码正文原文精确断言、焦点 same-DOM 断言及错误路径断言均保留；未删减语义断言或放宽超时。此改动修正测试 oracle 对字典插入顺序的假设，没有变更产品。

该补修没有新发现硬规范违例或 possible Fowler smell。

## 最终 Standards 复核（tabfix）

### 审查范围与依据

基于固定基线 `2cde5b5757e1065049fdfdc21e98d17ed6fd68ec`，复核 `.scratch/frontend-completion/ticket-07/files.json` 中本票 21 个文件的当前状态，包括最后一轮 `Overlay.tsx` 焦点循环、`MessageBody.tsx` 稳定 renderer、正式原生验收 20 步 Tab 序列和三份 Python 文件。依据为用户提供的根 `AGENTS.md`、`frontend/design.md`、`CONTEXT.md`、`docs/agents/issue-tracker.md` 与 `docs/agents/domain.md`；另逐项检查 Fowler 12 smells。仓库当前没有 `docs/adr/` 目录，因此无本票相关 ADR 可对照；领域文档约定对 ADR 的读取条件是文件存在时再读。

### 做得好的

- `MessageBody`、`ContentViewer`、`markdown-policy` 分别承载消息投影、完整内容查看/复制和 Markdown 策略；`Conversation` 将公共 API 的消息/工具事实映射到这些边界。这个拆分符合 `frontend/design.md` §§2–5、7–10 的工作台视觉、局部内容区与真实消息事实要求，也沿用了 `CONTEXT.md` 的“工具结果”“流式预览”“本地资源引用”等术语边界。
- 网页打开使用前端 Tauri command、Rust URL 校验和限定主窗口的 opener；自动链接脚本关闭，capability 仍为 core-only。该责任落点与本地资源引用仍只读的票据范围一致。
- `Overlay` 的新 Tab 边界逻辑只处理没有 Alt/Ctrl/Meta 的 Tab 与 Shift+Tab；首尾循环候选受 tabIndex、disabled、inert 和实际布局可见状态约束，常规中间导航仍交给原生 dialog。配合稳定 Markdown renderer，关闭后先回到仍连接且有效的触发节点，否则回工作区，满足 `frontend/design.md` §9 的 dialog 焦点约束和返回规则。正式验收保留同一入口/焦点断言，并在窄屏序列中执行多轮正反方向共 20 次按键后逐步断言焦点留在打开的 dialog。
- 最新正确路径 `ruff check` 与 `ruff format --check` 分别通过三份正式 Python 文件；误写路径的 Ruff 调用单独记录，没有记作通过或隐藏。

### 需要修

未发现仓库硬性规范违例，也没有发现需主 agent 修复的 Standards finding。Fowler 12 smells 逐项审查结果：

| Smell | 结果 |
|---|---|
| Mysterious Name | 未发现；组件、策略和受控命令名称表达职责。 |
| Duplicated Code | 未发现有维护成本的重复；代码/JSON 内容查看与复制共用 `ContentBlock`/`CopyContent`。 |
| Feature Envy | 未发现；DOM 焦点约束在 `Overlay`，消息投影在消息组件，URL 校验在 Rust 边界。 |
| Data Clumps | 未发现；`ContentView` 的标题、原文与预览标记作为一项查看请求一起传递。 |
| Primitive Obsession | 未发现值得提取的值类型；消息内容本身来自 JSON 公共边界，查看状态已有 `ContentView`。 |
| Repeated Switches | 未发现重复的大型分派；少量 role 分支分属名称投影与渲染语义。 |
| Shotgun Surgery | 未发现无关模块被牵连；映射、展示、命令和对应验收的跨层改动正是本票功能路径。 |
| Divergent Change | 未发现单一模块承载互不相关的变更理由；策略、查看器和覆盖层已有清晰边界。 |
| Speculative Generality | 未发现为未来扩展增加的通用框架或无用参数。 |
| Message Chains | 未发现需要抽取的深层对象链；DOM 查询和焦点处理保持在交互边界内。 |
| Middle Man | 未发现纯转发组件；各新增导出组件直接承担呈现或复制行为。 |
| Refused Bequest | 未发现；`RenderBoundary` 使用 React 错误边界继承，验收类复用既有桌面 harness。 |

工具已覆盖的 Python lint/format 规则只记录验证结果，不重复当成额外 Standards finding。

### 值得讨论

最新 production build 保留了 Vite 的单块 >500 kB warning；入口 JS 为 523,240 bytes。它是可见的包体积/拆分决策信号，不构成本票仓库规范违规，也没有在本次焦点修复中被隐藏或更改构建阈值。是否按后续页面/路由拆分属于产品维护者的性能取舍。

## 增量 Standards 复核（stylefix）

根 agent 对 `native-tabfix07/narrow-content.png` 的复查显示：内容抽屉内获得焦点的 `pre` 仍用浏览器默认黑色 outline。最初通用焦点规则仅覆盖按钮、输入控件、`summary` 和 `.session-list`，因此没覆盖带 `tabIndex` 的代码正文；这确实偏离 `frontend/design.md` §9 的 2px 靛蓝、3px offset 焦点样式。此前零 finding 的审查结论没有捕捉这项证据，属于不完整审查，不能作为覆盖完备的证明。

root 已把规则中的 `.session-list:focus-visible` 扩展为 `[tabindex]:focus-visible`，保留原有 `outline: 2px solid var(--accent)` 与 `outline-offset: 3px`。新 build 产物 CSS `assets/index-C37yfSMR.css`（61,653 bytes，SHA-256 `75CDA7B59E7B971ED646F8F87403C26D04D19CE0C4305F100D17B0C55964DD38`）已直接核对包含通用选择器与两项样式；对应 JS 为 `assets/index-BOOLs1PU.js`，SHA-256 `985CDECD67BF9A9D50BAA841131210F80EB7C3710955E4C6CB58FDAEC1B11E76`。stylefix 正式验收初次把 computed offset 硬断为 `3px`，产生 1 pass/1 fail；原生 CSSOM 诊断发现 WebView 实际 resolved 为 `2.66667px`。因此该次红结果暴露了 oracle 与运行时表示不一致，不能据此判定 CSS 源声明不符；精确证据和更新后的 oracle 见后续 offsetfix 段。

**状态：源代码和构建产物层面的 style finding 已修复；stylefix 原生验收的 1 fail 是旧 computed-offset oracle 失败，更新后的两项原生验收仍待 native agent 执行。** 完成票据前需核对最终原生结果。

## 增量 Standards 复核（offsetfix oracle）

只读核对最终 `markdown_content_acceptance.py`：新增 JavaScript 在公开 DOM 中取得 dialog 内的正文 `pre` 与关闭 button；通过 `document.styleSheets` 读取适用 CSSOM 规则的声明，再读取两元素的 `getComputedStyle`。严格断言 matched `outline-offset` 声明为 `3px`、颜色 `rgb(79, 70, 229)`、宽度 `2px`，active / `:focus-visible` 均为真，并精确比较 content、button、restored 三个完整快照；不依赖产品私有状态、不设置计算容差，也没有改 CSS 补偿 WebView 输出。

证据 `native-offset-diagnostic/.../focus-offset-diagnostic.json` 显示 DPR 约为 1，viewport scale/document zoom 均为 1；正文与关闭按钮在各自相同 `:focus-visible` 状态下匹配同一通用焦点规则，声明值为 `3px`、颜色和宽度符合规范，而 WebView 的 computed offset 解析字符串均为 `2.66667px`。新 oracle 的严格 CSSOM 声明断言加同 viewport 控件快照一致性，保留了对样式声明和 WebView 可见结果的严格验证，不将 computed 值字符串差异误判为 CSS 声明错误；诊断尚未确认具体解析原因。

最新三文件 Ruff `check` 和 `format --check` 均 exit 0；初次 `format --check` exit 1（仅正式 acceptance 文件需格式化），root 已格式化该文件后复检通过；完整命令、独立日志与计数见 `frontend-report.md`。本轮无新增产品改动或其他 Standards finding；更新 oracle 的最终原生两项结果仍待 agent 返回，因此保留为验收限制。

## 最终闭环

以上“待原生”记录描述该批审查时的状态。随后显式 `gpt-6-luna / max` 原生 agent 执行更新后的两项正式用例：2通过、0失败／错误／跳过，12.323秒，exit0。主agent已核对原始日志、完整复制与三个焦点快照、最新两张截图及正常宿主退出；Spec审查无本票直接范围的剩余问题。最初发现的焦点样式偏差已闭环，Standards无剩余finding。

最终 `files.json`／`change.diff` 为固定基点至工作树的22文件范围（新增实施索引收尾，没有新增产品改动）。同一轻量Standards agent执行固定只读文档检查：12份文档、171个本地目标、0断链；HEAD仍为固定基点，staged为空，`git diff --check` exit0，仅保留LF→CRLF提示。原始结果为 `documents-git-final.json`，主agent已逐项核对。未重复前端／Rust／后端／原生批量检查，未写Git状态。

该结论不消除后端完整回归的1个退出超时错误和1个权限跳过，也不覆盖第23票的物理窗口／IME／边框联合验收。由主agent根据两个测试agent已回传的独立审查和原始验证证据记录最终闭环。
