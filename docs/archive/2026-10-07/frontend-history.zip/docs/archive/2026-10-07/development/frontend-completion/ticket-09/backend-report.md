> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 09 票 Backend 验证报告

- **执行模型**：`gpt-6-luna / max`
- **工作目录**：`C:\code\shikigen-agent`（Windows PowerShell）
- **日志目录**：`.scratch/frontend-completion/ticket-09/backend/`

## 验证结果

| 检查 | 命令 | 结果 |
| --- | --- | --- |
| Backend unittest 全套（仅执行一次） | `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` | exit 0；291 项，290 通过、1 跳过、0 失败；264.383 秒 |
| 类型检查 | `.venv/Scripts/ty.exe check app packages/harness` | exit 0 |
| Ruff lint | `.venv/Scripts/ruff.exe check tests/desktop_reading_fixtures.py frontend/src-tauri/tests/chat_reading_acceptance.py` | exit 0 |
| Ruff 格式 | `.venv/Scripts/ruff.exe format --check tests/desktop_reading_fixtures.py frontend/src-tauri/tests/chat_reading_acceptance.py` | exit 0 |

unittest 摘要为 `Ran 291 tests in 264.383s`、`OK (skipped=1)`。唯一跳过是 `test_runtime_data.RuntimeDataTests.test_symlink_data_and_parent_are_rejected`，原因 `Windows symlink privilege is unavailable`；这是环境覆盖缺口，不计为通过。未复现交接提及的审批恢复结算／空 host 环境超时问题。无失败，无失败复现步骤。

日志中可见 LangChain Pregel v3 streaming beta warning、Pydantic serializer warning 和 asyncio 调试模式慢任务时序输出；另外有若干测试预期触发的恢复、查询失败日志。它们所在测试均通过，且 unittest 总结无失败。

## 证据文件

- unittest stdout：[unittest.stdout.txt（原始产物已删除）](../../../README.md#已删除的材料)（空）
- unittest stderr：[unittest.stderr.txt（原始产物已删除）](../../../README.md#已删除的材料)（完整 verbose 输出、告警/预期错误日志及最终摘要）
- unittest exit：[unittest.exit.txt（原始产物已删除）](../../../README.md#已删除的材料)（`0`）
- ty stdout/stderr/exit：`backend/ty.{stdout,stderr,exit}.txt`（exit `0`）
- Ruff check stdout/stderr/exit：`backend/ruff-check.{stdout,stderr,exit}.txt`（exit `0`）
- Ruff format stdout/stderr/exit：`backend/ruff-format.{stdout,stderr,exit}.txt`（exit `0`）
- Final Ruff check stdout/stderr/exit：`backend/final-ruff-check.{stdout,stderr,exit}.txt`（exit `0`）
- Final Ruff format stdout/stderr/exit：`backend/final-ruff-format.{stdout,stderr,exit}.txt`（exit `0`）
- Layout final Ruff check stdout/stderr/exit：`backend/layout-final-ruff-check.{stdout,stderr,exit}.txt`（exit `0`）
- Layout 首次 Ruff format stdout/stderr/exit：`backend/layout-final-ruff-format.{stdout,stderr,exit}.txt`（exit `1`，保留失败证据）
- Layout freeze Ruff check stdout/stderr/exit：`backend/layout-freeze-ruff-check.{stdout,stderr,exit}.txt`（exit `0`）
- Layout freeze Ruff format stdout/stderr/exit：`backend/layout-freeze-ruff-format.{stdout,stderr,exit}.txt`（exit `0`）
- Late scroll Ruff check stdout/stderr/exit：`backend/late-scroll-ruff-check.{stdout,stderr,exit}.txt`（exit `0`）
- Late scroll Ruff format stdout/stderr/exit：`backend/late-scroll-ruff-format.{stdout,stderr,exit}.txt`（exit `0`）
- Standards 评审：[standards-review.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/standards-review.md`）

## 最终增量复核

阅读位置增量和 native fixture 更新后，仅对两份新增 Python 文件追加执行（未重跑 backend 291 项或 ty；backend app/packages/harness 未变）：

- `.venv/Scripts/ruff.exe check tests/desktop_reading_fixtures.py frontend/src-tauri/tests/chat_reading_acceptance.py`：exit 0。
- `.venv/Scripts/ruff.exe format --check tests/desktop_reading_fixtures.py frontend/src-tauri/tests/chat_reading_acceptance.py`：exit 0。

新增末尾代码块和原生内部滚轮断言后，第一轮 `layout-final-ruff-format` exit 1：`frontend/src-tauri/tests/chat_reading_acceptance.py` 的 wheel `wait_until` lambda 需重排括号/缩进（Ruff 报 file would be reformatted，定位约第 204–211 行）。root 只修格式、未改逻辑或断言；保留上述失败日志。随后 `layout-freeze-ruff-check` 和 `layout-freeze-ruff-format` 均 exit 0。没有重跑 backend unittest 或 ty。

迟到滚动增量只更新 `useChatReading` 与 native acceptance 的可见代码块选择。对两份新增 Python 文件追加 Ruff check 与 format check，日志在 `backend/late-scroll-ruff-*`，两项 exit 0；该次未运行 backend unittest 或 ty。

## 剩余覆盖

Windows 无 symlink 权限，symlink 拒绝用例未执行。此分工未运行前端/Rust 构建或原生 WebView 专项；原生初批由 C 执行，后续由显式 `gpt-6-luna / max` 的 A 接手。新 fixture 与原生 acceptance 不由 backend unittest 自动发现，已分别纳入 Ruff 和独立原生专项验证。
