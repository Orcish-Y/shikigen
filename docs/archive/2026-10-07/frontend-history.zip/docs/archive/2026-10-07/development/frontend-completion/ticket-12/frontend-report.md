> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 12 票前端验证阶段报告

日期：2026-10-06（Asia/Shanghai）
验证模型：`gpt-6-luna`，推理强度 `max`
工作目录：`C:\code\shikigen-agent` 与 `C:\code\shikigen-agent\frontend`，PowerShell
固定点：`a35232d461b38bdb48a8cbdad4ed6a59561dba0c`

本阶段完成前端 Node、TypeScript、Vite、Ruff 和定向 Windows/Tauri 实机验证。验证子 agent 没有修改产品代码或 Git；只在 `.scratch/frontend-completion/ticket-12/` 准备验证 runner 并保存日志、metadata 和截图。主 agent 在失败定位后修正产品与验收用例，本报告区分历史结果与最终树结果，不把旧的失败或通过记录混算成最终回归。

## 命令与结果

| 范围 | 命令 | 结果 | 原始日志 / metadata |
| --- | --- | --- | --- |
| 初始前端专项 | `node --import tsx --test tests/approval-decisions.test.mjs tests/run-cancel.test.mjs tests/run-reconstruction.test.mjs tests/message-drafts.test.mjs` | 56/56 通过；失败、取消、跳过均 0。运行时审批文件还没有后来增加的两项覆盖。 | [node-specialized.log（原始产物已删除）](../../../README.md#已删除的材料) · [node-specialized.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 一次完整 Node 套件 | `node --import tsx --test tests/*.mjs` | 148/148 通过；失败、取消、跳过均 0；耗时 188.01 秒。此运行在第 11 项资格修复和新增两项专项覆盖之前开始。 | [node-full.log（原始产物已删除）](../../../README.md#已删除的材料) · [node-full.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 修正后的定向回归 | `node --import tsx --test tests/approval-decisions.test.mjs tests/run-reconstruction.test.mjs tests/run-cancel.test.mjs tests/message-drafts.test.mjs` | 59/59 通过；失败、取消、跳过均 0。包含当前审批决策 11 项及取消、Run 重建、消息草稿回归。 | [node-focused-post-review.log（原始产物已删除）](../../../README.md#已删除的材料) · [node-focused-post-review.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终完整 Node 套件 | `node --import tsx --test tests/*.mjs` | 152/152 通过；失败、取消、跳过均 0；exit 0。运行在最终产品代码变更后；后续只新增 Python 原生断言，未改 JS。 | [node-full-final-recheck.log（原始产物已删除）](../../../README.md#已删除的材料) · [node-full-final-recheck.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 中间 TypeScript / Vite | `node node_modules/typescript/bin/tsc --noEmit` / `node node_modules/vite/bin/vite.js build` | 两项 exit 0。较早 build 最大 JS chunk 为 566.21 kB（gzip 173.42 kB）。 | [typescript-post-review.log（原始产物已删除）](../../../README.md#已删除的材料) · [typescript-post-review.json（原始产物已删除）](../../../README.md#已删除的材料) · [vite-build-post-review.log（原始产物已删除）](../../../README.md#已删除的材料) · [vite-build-post-review.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终 TypeScript | `node node_modules/typescript/bin/tsc --noEmit` | exit 0，0 diagnostics。 | [typescript-final-captured.log（原始产物已删除）](../../../README.md#已删除的材料) · [typescript-final-captured.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终 Vite build | `node node_modules/vite/bin/vite.js build` | exit 0；4871 modules transformed。生成 JS chunk 567.39 kB（gzip 173.66 kB），仍有 >500 kB 非致命提示。 | [vite-final-captured.log（原始产物已删除）](../../../README.md#已删除的材料) · [vite-final-captured.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终 Python lint | `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/approval_resume_acceptance.py tests/desktop_approval_fixtures.py tests/test_frontend_approval_flow.py`；`ruff format --check` 同三文件 | 两项 exit 0；`All checks passed!`、`3 files already formatted`。 | [ruff-check-native-final-source.log（原始产物已删除）](../../../README.md#已删除的材料) · [ruff-check-native-final-source.json（原始产物已删除）](../../../README.md#已删除的材料) · [ruff-format-native-final-source.log（原始产物已删除）](../../../README.md#已删除的材料) · [ruff-format-native-final-source.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终原生定向回归 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-12/native_final_recheck_runner.py` | 7/7 通过；失败、错误、跳过均 0；70.450 秒，exit 0。选 4 个新增本地测试方法及 3 个受影响旧方法，无继承重复。 | [native-final-recheck-7.log（原始产物已删除）](../../../README.md#已删除的材料) · [native-final-recheck-7.json（原始产物已删除）](../../../README.md#已删除的材料) |

最早的 148/148、56/56 和中间 59/59 结果按各自代码快照保留，当前最终完整 Node 结果为 152/152。旧日志迁移记录保留原 `log` 路径，并以 `relocated_log` 和 `migration_note` 指向本目录中的可读文件。

## 当前 12 项审批决策测试覆盖

最终完整 Node 回归为 152/152；`approval-decisions.test.mjs` 中 12 项全部通过：

1. 多 Interrupt、多动作默认未选；提交按动作顺序生成，批准不带拒绝原因。
2. POST pending 时锁定编辑、再次提交和取消；同 Run 的本次有效 POST metadata 结束 pending，不等待 EOF。
3. 同 Run 新 checkpoint 不复用选择；POST 流暂停后，必须经过 GET 回放核实才开放新请求。
4. 错误 Run 的 POST metadata 不算接收；先 GET 核实后才允许用户手动重提。
5. **本次修复**：未知提交经正常完整 GET 核实后，后续 JSON 快照读取失败不撤销已核实的审批资格。
6. 不支持或格式不完整时整组只读，保留原始载荷，仍可取消。
7. 请求键次序不影响身份；namespace、checkpoint、动作顺序和 args 改变身份。
8. 422、500 保留选择；GET 核实后可人工重提，不凭 HTTP 结果造 resolved 历史。
9. 旧 GET metadata 不确认 POST；隐藏期间结果核实及迟到响应不会污染另一会话或新请求。
10. 503 的 Retry-After 限制 GET 核实和重提，等待期间审批／取消保持互斥。
11. resolved 采用服务端真实决策；Run 终态锁定旧卡片，迟到 running 不回退终态。
12. 终态 required 缺少真实 resolution 时保持只读；通过原 GET guard 手动读取服务端 invalidated 事实，不伪造处理结果或重发决策。

## 8 条验收条件的覆盖判断

| 验收条件 | 最终证据 | 未覆盖或限制 |
| --- | --- | --- |
| 1. 按 seq 排卡片，显示 Interrupt／动作顺序、namespace、工具名、说明和允许选项 | final native multi-Interrupt 用例核对实际 namespace 顺序、两组动作标题及 allowed choices；active-card 定位用例通过。 | DOM 顺序按返回 Interrupt 顺序验证；没有用刻意乱序的 `seq` fixture 单独证明排序器会重排。 |
| 2. 默认未选、按 allowed_decisions 显示选项、X/Y、整组只读；全部选择后一次提交 | native 首例验证默认 0/4、选择和提交；unsupported 用例验证无可用 radio、可取消并按需读取结果。截图展示真实卡片和取消终态。 | 本次没有专门断言所有响应式视口下的布局。 |
| 3. 参数折叠、完整 JSON、复制和只读抽屉；拒绝原因切换保留 | native 首例验证默认折叠、长 JSON 可滚动、首个复制文本与 args 完全相等、drawer 复制入口内容相同、drawer 无审批输入框；422 用例保留拒绝原因。 | Windows 系统剪贴板与物理输入法另属联合实机范围；用例 mock 了 clipboard 写入。 |
| 4. responses 覆盖所有 Interrupt，decisions 按动作位置排序；checkpoint 只参与客户端身份 | Node 12 项与 native 首例均通过；native 核对 POST body 只有 `responses`、两个 Interrupt、动作顺序及批准/拒绝内容。 | 当前验证覆盖 fixture 构造的两个 Interrupt；没有声称覆盖任意规模工作流。 |
| 5. pending 互斥；有效 POST metadata 接受后继续观察，不等待 EOF；GET/旧 metadata 不确认 POST | Node 12 项通过；native 首例人为暂停 POST 接受，检查按钮/选项禁用、释放后恢复观察。`pending.png` 保存了实际锁定 UI。 | 无额外缺口。 |
| 6. 按 resolved/invalidated 事实收敛，终态锁旧卡片，不伪造状态 | Node 覆盖终态 required 手动 GET；native unsupported 用例验证正常观察结束后取消、GET 前没有假 invalidated、点击“读取审批记录”后读取真实取消/失效，并且没有审批 POST 或工具副作用。旧卡片 h2 与历史参数 drawer 在新 Run 后仍保持历史身份。 | 手动 GET 失败分支由 Node 测试覆盖，native 本次验证了成功 GET 分支。 |
| 7. 底部审批定位、焦点及取消 | `ChatReadingAcceptance.test_only_active_approval_action_locates_and_focuses_timeline_card` 与受影响取消用例均在最终 native 7 项中通过；[定位截图（原始产物已删除）](../../../README.md#已删除的材料)。 | 本阶段不声称所有视口与复杂滚动高度均已覆盖；联合视口验收归第 23 票。 |
| 8. 多 Interrupt／多动作、批准拒绝、工具副作用、同 Run 继续和不支持动作 | native 四个新增用例最终全部通过；受影响取消、定位、bounded GET 三个旧用例也通过。`window.png`、`parameters.png`、`pending.png` 记录真实 WebView 状态。 | final native recheck 是 7 项定向回归，不是完整原生 12 项全套重跑；其余旧用例见失败历史段落。 |

其他明确范围：审批本地草稿跨重启属于第 13 票；物理键盘／Windows 系统 IME 与多视口联合验收属于第 23 票。本阶段没有声称覆盖它们。

## 原生实机结果与失败历史

最终 native 命令在仓库根目录运行，使用单一显式 `unittest` suite，并核对每个方法确实在其 `class.__dict__` 中，避免继承测试重复：

```powershell
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-12/native_final_recheck_runner.py
```

最终定向 7 项由 `ApprovalResumeAcceptance` 的 4 个新用例，以及旧 `CancelPartialAcceptance`、`ChatReadingAcceptance`、`StreamRecoveryAcceptance` 各 1 项组成。结果为 **7/7 通过，失败、错误、跳过均 0，70.450 秒，exit 0**。日志：[native-final-recheck-7.log（原始产物已删除）](../../../README.md#已删除的材料)，metadata：[native-final-recheck-7.json（原始产物已删除）](../../../README.md#已删除的材料)。

最终运行前 `9238` 和 `45200` 没有 Listen；5173 的既有本地静态服务仅在 index 与当前 `frontend/dist` 的两个引用 asset 均逐字节匹配后复用（index 396 bytes）。没有终止未知进程。最终 artifacts 位于 `native/final-recheck/`。

最终截图与真实 UI 状态：

- [结束状态（原始产物已删除）](../../../README.md#已删除的材料)：多 Interrupt 决策完成，Run 显示已完成，实际决策内容可见。
- [参数与只读抽屉（原始产物已删除）](../../../README.md#已删除的材料)：长 JSON 可滚动，抽屉标明只读；原始参数复制与抽屉复制内容逐字相同。
- [pending 状态（原始产物已删除）](../../../README.md#已删除的材料)：POST 接受被人为暂停时页面显示确认状态，审批选项和取消按钮禁用。
- [unsupported 取消后读取事实（原始产物已删除）](../../../README.md#已删除的材料) 与 [请求记录（原始产物已删除）](../../../README.md#已删除的材料)：正常观察结束后取消；GET 前不显示假 invalidated，用户点击“读取审批记录”后显示服务端真实结果；无审批 POST、无工具副作用。
- [旧 Run 参数 drawer（原始产物已删除）](../../../README.md#已删除的材料) 与 [页面事实记录（原始产物已删除）](../../../README.md#已删除的材料)：新 Run 开始后旧卡片仍显示“运行已结束，审批不可操作”，打开参数后出现历史内容提示并保持只读。
- [当前审批定位（原始产物已删除）](../../../README.md#已删除的材料)、[取消收敛（原始产物已删除）](../../../README.md#已删除的材料)、[bounded GET 恢复（原始产物已删除）](../../../README.md#已删除的材料) 与 [停止后的恢复状态（原始产物已删除）](../../../README.md#已删除的材料)。

失败历史按代码快照保留，不合并成最终统计：

| 阶段 | 结果与含义 | 记录 |
| --- | --- | --- |
| 初始沙箱原生 12 项 | 2 failures + 10 errors；全都卡在 WebView/CDP 连接之前，没有进入业务断言，不能算产品通过或业务失败。 | [native-approval-final-12.log（原始产物已删除）](../../../README.md#已删除的材料) · [native-approval-final-12.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 单用例 elevated 启动诊断 | 首个新增多 Interrupt 用例 1/1 通过；证明 elevated 环境可启动实机并保存 UI 截图。 | [native-bootstrap-diagnostic.log（原始产物已删除）](../../../README.md#已删除的材料) · [native-bootstrap-diagnostic.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 中间版 elevated 剩余 11 项 | 9 passed、2 failed、0 errors、0 skipped。unsupported 取消只产生终态快照；Run 观察已经结束时，前端缺少补读真实 resolution 的入口，所以“运行已取消，审批失效”无法出现。主 agent 后续添加 `canReconnect` guard 和“读取审批记录”入口；最终用例等待观察正常结束以稳定覆盖该分支。旧历史用例失败在等待“发送”按钮 enabled：草稿为空，尚未设置待发送文字，尚未执行 drawer 历史断言。 | [native-remaining-11-elevated-retry1.log（原始产物已删除）](../../../README.md#已删除的材料) · [native-remaining-11-elevated-retry1.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 中间 runner 导入尝试 | `WindowAcceptance` 名称未导入，测试前退出，Ran 0；修正 scratch runner 后才执行上述 11 项。 | [native-remaining-11-elevated.log（原始产物已删除）](../../../README.md#已删除的材料) · [native-remaining-11-elevated.json（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终当前树定向 7 项 | 新增 4 项与 3 个指定旧回归均通过，结果见本节首段；覆盖上面两项失败路径修正。 | [native-final-recheck-7.log（原始产物已删除）](../../../README.md#已删除的材料) · [native-final-recheck-7.json（原始产物已删除）](../../../README.md#已删除的材料) |

最终 unsupported 用例等待观察正常结束后再取消，先验证没有提前伪造 invalidated，再由用户手动 GET 读取处理事实；它验证新增 `canReconnect` guard 允许在终态快照后进入真实 resolution 读取。旧历史用例在等待发送前设置新草稿，同时保留取消后和新 Run 后两条 h2 断言及最终 drawer 历史断言。两条最终修正均由 7/7 实机回归覆盖。

第一次沙箱批次在 ticket-01/03/04/05/09/10 的默认 artifacts 路径留下了 8 个空 `host-0.log`；时间与 12 项启动失败批次吻合。最终证据保存在 `ticket-12/native/final-recheck/`。旧路径 manifest 位于 [bootstrap-old-paths/manifest.json（原始产物已删除）](../../../README.md#已删除的材料)；旧票据内容按主 agent 核对后的归档保留，本验证没有清理或改写。

## 未覆盖与保留的诊断

- 物理 Windows 输入、系统 IME 候选面板和多视口联合验收属于第 23 票；本阶段不声称覆盖。应用重启草稿属于第 13 票。
- `ty` 对 `tests/desktop_approval_fixtures.py` 的 `StateGraph(ApprovalState)` 保留 2 个 `invalid-argument-type` diagnostics，见 [ty-new-python-tests-final.log（原始产物已删除）](../../../README.md#已删除的材料)。主 agent 已按官方 schema 作运行时核对；该 type-check 结果仍按未通过记录保留，不计为成功。
- 本阶段没有重跑完整后端或公开 HTTP 回归；它们由独立 `gpt-6-luna` / `max` 后端验证 agent 执行，主 agent 汇总，见 [backend-report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-12/backend-report.md`）。没有修改产品代码或 Git。
