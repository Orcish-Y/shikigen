> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 09 票验证交接

## 目标、授权与环境

用户要求 `$implement docs/wayfinder/frontend-completion/implementation/index.md 完成下一票`，且再次读取并遵守 AGENTS.md。只完成第 09 票；用户确认的规格不重新访谈，不实现后续取消/审批写入/资源功能。主 agent 已重读 AGENTS.md、implement/tdd/code-review 技能。最终验证必须显式 `gpt-6-luna / max`，测试子 agent 只执行验证、定位与记录证据；产品/测试修复由主 agent 执行，不得自行放宽或删除断言。

- 仓库 `C:/code/shikigen-agent`，Windows PowerShell，Python `.venv/Scripts/python.exe -X utf8`；`pnpm.exe` 可用，`pnpm.cmd` 不可用。
- danger-full-access，approval never；不要设置 sandbox_permissions。只启动/清理自己测试资源，不停止用户浏览器/WebView/5173 服务。
- 原生测试 9238/45200 必须空闲；5173 仅复用逐字节匹配当前 dist 的已有静态服务，否则停止并报告。共享原生端口/窗口串行；前端/Rust构建完成后才开始原生。
- 本轮基点 `eceb02064c0c77d18ac68e651e3dc84ffe21797d`，开始工作树干净，master。此轮未提交：审查命令 `git diff eceb02064c0c77d18ac68e651e3dc84ffe21797d -- frontend/src frontend/tests docs/wayfinder/frontend-completion/implementation/09-chat-reading-position.md`；新文件还未 tracked，必须同时读取下面的新文件，不要把空 commit diff 当成没有实现。提交范围由主 agent 管理，子 agent 不 stage/commit/push。

## 规格与验收

- `docs/wayfinder/frontend-completion/implementation/09-chat-reading-position.md` 六条完整 AC。
- `.scratch/frontend-completion/PRD.md` §18、§21、验收表“阅读与布局”。
- `docs/wayfinder/frontend-completion/tickets/006-interaction-acceptance.contract.md` §7。
- `frontend/design.md` 原稿配色/尺寸/独立滚动，现有 Slate/白/靛蓝控件；本票只加独立底部“有新内容/回到最新”条，不覆盖正文/输入。

1. 应用本次首次最新、切回恢复锚点/偏移/跟随，隐藏/Workspace 卸载保留内存，应用重启首次最新。
2. 缺锚点等待事实核实；确认失效在上次顺序找最近存在项，不串会话。
3. 主动上翻立刻暂停，delta/完整替换/工具/图片/宽度变化保留锚点，代码/JSON区内滚动不算主时间线上翻。
4. 回到最新/主动到底恢复，有新内容不造消息数量；仅本次有效 POST 接受可恢复，GET/状态/用量/标题不能主动到底。
5. 仅主动处理审批定位卡片并焦点；列表/导航/时间线/详情独立。
6. 切换、宿主重入、重复事实、动态高度、失效目标有证据；物理键盘/系统 IME/软键盘及输入增高联合检查留第 23 票。

## 实现与改动

新增：

- `frontend/src/chat-reading-position.ts`：App 内存 Map，每会话 following/anchor/offset/order/content signatures/new-content/acceptedSendId；公开测量输入→定位结果。只存本次内存；nearest fallback 等事实 ready；重复内容与接受信息不重触发。
- `frontend/src/useChatReading.ts`：主时间线 DOM 测量，useLayoutEffect/ResizeObserver/MutationObserver；识别 wheel/keyboard/touch/scrollbar 用户意图；程序定位/布局变化不视为用户上翻；隔离局部滚动；target focus preventScroll；卸载撤销观察但保留 App records。
- `frontend/tests/chat-reading-position.test.mjs`：4 个浏览器几何边界用例。
- `tests/desktop_reading_fixtures.py`：真实 create_agent/model节点/ToolNode/middleware/checkpointer，长正文、代码、可控真实 SSE 多 delta；无供应商网络，`allow-reading-stream` 文件门；可用 bash 审批路径，normal middleware。
- `frontend/src-tauri/tests/chat_reading_acceptance.py`：3 个唯一专项测试，继承既有启动/HTTP/原生显隐入口，禁止自动发现全部继承测试。

修改：`conversation-state.ts` 增加仅本次有效POST metadata发布的 acceptedSendId；`useConversations.ts` App memory owner/factsReady/visible；`App.tsx` 注入阅读参数、审批定位委托；`components/Conversation.tsx` 稳定消息锚点、focusable timeline、独立控制条、只读审批placeholder移入timeline；`ToolCard.tsx` stable tool anchor；`styles.css` 禁原生overflow-anchor竞争、局部overscroll containment；`frontend/tests/message-drafts.test.mjs` 既有HTTP公开测试增加GET不发接受及POST标记断言；09票进度。

没有后端产品、依赖、Rust产品、AGENTS修改。审批仍只读placeholder，真正逐项审批为12票；资源接口为14/15票。data SVG 图片仅原生测试浏览器布局边界模拟异步增高，不声称本地图片功能已经实现。失效/暂缺锚点目前公开几何专项验证，原生实景按需要补充覆盖或指出缺口。

## 开发已执行（不是最终验收）

- 单测逐项 RED→GREEN：missing module、fallback null!=70、new-content false!=true、accepted 450!=900；四项最终通过。
- 接入后定向 chat-reading+tool-records 10通过，0失败；用时233047ms（首批导入检查异常慢，没据此删测试）。
- 首次 tsc发现可空anchor偏移，固定偏移在fallback前；最终 `node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json` exit0。
- Python初稿字符串闭合语法/长行问题已修，`ruff format`与`ruff check`两新文件 exit0。没有运行最终全套、原生，也没有产品修复由子 agent 实施。

## 分工与准确命令

### A：前端/Rust完整验证（唯一构建写者）

cwd frontend：`pnpm.exe test`、`node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json`、`pnpm.exe build`。
cwd frontend/src-tauri：`cargo test`、`cargo fmt --check`、`cargo build --example backend_window`。
全部stdout/stderr/exit保存 `.scratch/frontend-completion/ticket-09`；标明pass/fail/skip数量和warning。构建后写 `frontend-ready.json`（dist index+引用资源大小与sha256；backend_window构建结果）并通知主 agent/C。不要跑后端/native。若失败先通知，不修产品。

### B：后端回归 + Standards轴

cwd repo：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` 完整一次；`.venv/Scripts/ty.exe check app packages/harness`；`.venv/Scripts/ruff.exe check tests/desktop_reading_fixtures.py frontend/src-tauri/tests/chat_reading_acceptance.py`；同路径 `ruff format --check`。
旧291测试预期290pass1symlink权限skip，不能把skip算pass。历史审批恢复结算/空host环境退出超时issue仍needs-triage，若本轮复现准确保存失败，不重复盲跑。B只碰自己的reports/logs，不更改产品或票据。

Standards读取 AGENTS.md、CONTEXT.md、docs/agents/{issue-tracker,domain,triage-labels}.md、frontend/design.md；docs/adr不存在。与基点审查并完整read新文件。要求先做得好，再需要修，再讨论；<400字主报告，引用规则/位置。工具已经执行的lint/type不作为额外审查finding。

Smell baseline（只判断，有证据才报告，不是硬规则，repo规则优先）：

- Mysterious Name：名字不说明内容/行为→重命名或澄清设计。
- Duplicated Code：多处同逻辑→提取共享形状。
- Feature Envy：方法更依赖他对象数据→移到所属对象。
- Data Clumps：多字段总一起移动→定义类型。
- Primitive Obsession：领域概念应有小类型而用了原始值→定义领域类型。
- Repeated Switches：同类型重复分支→多态/统一映射。
- Shotgun Surgery：一件变化迫多文件散改→收拢变化。
- Divergent Change：一个模块因多个无关理由变化→拆模块。
- Speculative Generality：规格无需求的抽象→删除/内联。
- Message Chains：长对象链→目标提供直接方法。
- Middle Man：纯转发→删中间层。
- Refused Bequest：忽略大部分继承→组合。

### C：原生专项与必要回归 + Spec轴

等待A完成build并得到ready证据，不触发自己的并行构建；检查dist hash/ports。
Python命令需设置进程级 PYTHONPATH = repo/tests + repo/frontend/src-tauri/tests + repo/packages/harness（不要改HOME等系统变量）：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-09/native-runner.py` cwd repo。
runner串行执行03=3、04=4、05=2、06=1、07=2、08=4、09=3，预期19个唯一case。所有旧suite artifact_root必须覆盖到ticket09/native/NN，避免写旧验收目录！确认Inherited tests只按明确列表/本类__dict__。
C可以补只读诊断、截图、runner，但不能改产品/正式测试期待。发现失败立即提供当前body/geometry/history/requests/window证据，告知主 agent修复；已过批次不重复。真实WM_CLOSE/tray显隐、backend kill/retry(仅临时fixturehandles)、native restart、CDP合成键盘/wheel及WebView deviceviewport模拟准确标注，不冒充物理IME/软键盘。
Spec独立按六AC和§7，<400字报告缺失/不对/超范围，每条引用规格，保持Standards/Spec分开。不参考Standards结论后再写Spec。

## 收尾

实际模型、执行命令、数量、失败复现、日志截图、覆盖缺口必须具备。主 agent核对报告后修复、交针对性回归，再更新票据done/index/总报告并commit。B最后可核对Markdown本地链接/git diff check；子 agent不stage/commit。

## 最终修复增量（原生初批失败后）

完整证据见 [diagnosis.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-09/diagnosis.md`）。原native/Spec agent远程compact报模型capacity，已由显式gpt-6-luna/max的A兼任原生/Spec，与B的Standards独立。初次03–08=16pass、09=3fail；sameFact阶段诊断09仍3fail，不覆盖旧日志。

产品增量：内容改用RunProjection.sameFact，键序重放不算新增；remember真实几何入口用于新建/切换前与连接的卸载时，保留模式；恢复following时清除旧1s意图。新增第五/六单测都先red再green。

夹具增量：每次tool_call_id唯一避免checkpointer复用；审批测试先真实interrupted且assert_anchor，再主动刷新GET核实后保持全部原定位/焦点/1POST断言，符合已有GET核实契约。不加审批写入或自动POST恢复。root Ruff开发两文件0。

A最终只跑同四文件（chat-reading-position/message-drafts/tool-records/run-reconstruction）预计53项、tsc/build；保存新的日志/ready旧版，不重复初全套121/Rust25。然后串行09三项，失败捕获runner副本将ARTIFACT_ROOT设置09-final，接07两项/08四项受影响回归，分别07-final/08-final。03–06未受影响10项不再重跑；最终唯一原生数仍19（重复回归不累加）。B只做最终Standards复核和两新py Ruff，不重跑后端/ty。

最终冻结补充：读取结束门槛 readingHistoryReady（history ready、verified、observation idle/closed），首次GET metadata尚在open阶段只核实身份，不能确认暂缺锚点失效。新增第7红绿用例。前一53项通过保留，最终改为四文件54项/tsc/build，artifact前缀history-gate，ready旧版另存；native final此前尚未启动，故不产生一轮无效原生回归。B只读复核该门槛，已通过两新py Ruff不重跑。

布局增量：54/类型/构建成功后的09-final=2pass1fail（宽屏恢复clamp在ResizeObserver之前被Home残留资格记成用户上翻）。完整证据和根诊断见diagnosis。新增第8几何测试RED/GREEN，sameTimelineLayout忽略纯scrollTop而检查height/total/锚点内容坐标；scroll布局有变先update，不捕获成新阅读意图。产品/原生断言不再改，A执行四文件预计55项/type/build，日志frontend-layout-final-*，ready旧版pre-layout保存，38HTTP精确预检后native/09-layout-final三项→07-final二项→08-final四项。旧失败不覆盖；未受影响后台/Rust/03–06不重复。B仅追加第8项Standards只读复核。

实际最终冻结：update遇布局改变清除旧手势；无手势scroll重申锚点，覆盖ResizeObserver先/后两顺序。TAIL加末尾真实90行代码；原生内部滚动去scrollIntoView，命中最后PRE断言+向下wheel等待内部scrollTop>0后向上wheel，两次必须保持following。旧wheel命中P事实保留diagnosis，不算内部覆盖。A只计最终55/type/build+原生证据；B对两Python增量Ruff，不重跑后台suite/ty。

controls-final：上一09-layout-final0/3因自身reading-controls显隐减小height把Home清资格。根仅修hook识别自身操作行且其余布局不变，保留当前手势与未递送位置；apply不写相同scrollTop。无原生/fixture/领域tests改动，55数量不变。A日志frontend-controls-fix-*，38HTTP预检，诊断runner仅artifact改native/09-controls-final，09三项通过再07/08。Standards只读hunk；没有重复后台/Rust/Ruff的理由。所有0/3历史保留。

late-scroll冻结：09-controls-final=1pass2fail（草稿React先于scroll、选到closed details隐藏PRE）。根加movedBeyondLayoutClamp和第9 RED/GREEN；update先采集有输入资格/非clamp的移动，再reconcile新布局，scroll共用此入口。验收只修可见PRE选择，命中/内部top>0/following断言保留，fixture不变。A四文件56/type/build（frontend-late-scroll-*）、38预检、artifact native/09-scroll-final三项→通过07/08。B只读Standards及两新Py的late-scroll-ruff检查，不重跑后台/ty/Rust，旧失败全保留。
