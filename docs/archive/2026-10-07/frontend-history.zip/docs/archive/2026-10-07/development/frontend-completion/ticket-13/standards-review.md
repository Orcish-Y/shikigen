> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 13 票 Standards 审查

审查基点：`29c3493a427e3132b76faee55dd47599dbec0c35`。规范来源：`AGENTS.md`、`frontend/design.md`。仅检查本票 diff 和交接指定新增文件；未运行验证。

## 做得好的

- `ApprovalDrafts` 把本地持久化与运行时恢复资格分开，并在恢复前验证 schema、请求指纹和提交快照（`frontend/src/approval-drafts.ts`）。
- `ApprovalRecovery` 沿用 `business-notice`、`details/summary`、`ContentBlock` 展示只读输入，符合 `frontend/design.md` §9 的既有控件约定；审批模型使用 `ApprovalSubmission`、`ApprovalBackup` 等领域名词。

## 需要修

- **硬违规（初审，已修复）**：`frontend/src/approval-drafts.ts:29` 将解析后的持久化对象命名为 `saved`。`AGENTS.md`「命名规范」要求实体使用名词短语，禁止形容词／过去分词独立充当实体名；可改为 `approvalDraftStore` 等名词。
- **硬违规（初审，已修复）**：`frontend/tests/approval-draft-recovery.test.mjs:11,51,56,69,76,91,109,115,119,121,132,145,149,151,155,158,222,229,241,245,258,262,264` 多处把事件、请求、响应、提交和工作台对象命名为 `required`、`first`、`second`、`same`、`final`、`reordered`、`updated`、`next`、`actual`、`captured`。这些实体名没有明确名词，部分是形容词／过去分词；按 `AGENTS.md` 应改为如 `requiredEvent`、`initialWorkbench`、`reorderedRequest`、`actualResponses`、`capturedSubmission`。
- **硬违规（初审，已修复）**：`frontend/src-tauri/tests/approval_draft_recovery_acceptance.py:80,131` 的 `reopened` 是重启返回的状态快照实体，应使用名词短语（如 `reopenedSnapshot`）。同文件 `:39` 的 `original` 是 fetch 函数引用；`AGENTS.md` 要求 callable 使用动宾名或显式函数后缀，可改为 `originalFetchFn`。

## 值得讨论

- 初审启发式 **Mysterious Name（已采纳修复）**：`frontend/src/approval-drafts.ts:91` 的 `readApprovalBackup(value)` 中 `value` 未说明具体载荷；`approvalBackupPayload` 会更清楚。此项是命名判断，不是硬违规。



## 初审与复核结论

- 初审记录保留如上，当前均已修复：持久化实体 `saved`→`storageSnapshot`，存储文本 `raw`→`storedText`，解析参数 `value`→`backupPayload`；JS 测试的事件、请求、服务端响应、提交和工作台实例已改为领域名词；原生验收将快照／宿主／fetch callable 分别改为 `reopened_snapshot`、`reopened_host`、`sendRequest`。
- 复核当前工作树后，未发现剩余硬性规范违规。新增 `readSnapshot` 对 Run 404 的处理撤销运行、审批和写入的已核实状态，同时保留本地输入；与 `frontend/design.md:223` 未核实审批保持只读的约定一致，规范轴无问题。
- 本次复核未运行测试、lint 或构建。
