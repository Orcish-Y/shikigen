> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 05 票验证交接

主 agent：实现与修复；测试子 agent：`gpt-6-luna / max`（显式模型／强度，fork none）。任务由用户 `$implement ... 完成第5票` 授权，要求延迟 30 分钟开始，开始于 2026-10-05 02:30 Asia/Shanghai。禁止 Git 写操作，当前轮次基点 HEAD `994ac75d94f19c8b00dd3f769df7aad9196b251d`，开始工作树为空。

## 目标／规格／验收

- [票据](../../../../../wayfinder/frontend-completion/implementation/05-stream-recovery.md)的七 AC 是本票目标。
- 正确路径在仓库根 `docs/wayfinder/frontend-completion/implementation/05-stream-recovery.md`，统一规格 `.scratch/frontend-completion/PRD.md` 第观察恢复、错误、验收章节；完整定稿契约 `docs/wayfinder/frontend-completion/tickets/002-run-projection.contract.md` 第 7–11 节；视觉 `frontend/design.md`。
- 分别展示 idle/connecting/open/retry_wait/closed/paused/failed。running EOF 是观察失败，interrupted／completed／cancelled／error 正常 EOF 不自动连接，绝不把网络错误造作 Run error。
- 原失败后仅 GET 同 Run，1/2/5 秒最多三次，秒数或 HTTP-date Retry-After 延长等待；error+EOF 不重复安排，无并发流，不加游标／Last-Event-ID。
- 首 metadata 不重置计数，30 秒健康连接或正常终态／审批回放才重置；长工具无 delta 不按超时报错。三次耗尽停止，列表刷新不启动同 Run。
- 手动重连／重新选择／新有效 lease 新轮次仍遵守 Retry-After；主动 Abort、切换和租约失效只停止读取，旧回调／计时器不能污染新目标，不 cancel。
- HTTP 400/404/500、协议错误、不可恢复 SSE、未知未分类错误停止自动；TypeError 网络故障、503、可恢复 SSE 才重试；Run404 不表示 Thread404。
- 未确认 POST 结果只 GET 核实，不自动 POST；已接受 POST 断流按同 Run 恢复。保留 HTTP status/detail/Retry-After 和 SSE code/message/recoverable，未知错误保留说明；不重启宿主。新草稿不被 GET 清空，未知提交记录及结构化失败跨重开保留。
- 实际窗口显示／隐藏桥接与 5 秒列表轮询属第 06 票，不在本票新增 Rust；本票覆盖重新选中／租约恢复等同一恢复入口与 Abort 生命周期，后续桥接沿用它们。

## 实现与变更

- 新 `frontend/src/observation-recovery.ts`：唯一有限 GET 调度任务，稳定 30 秒计数重置、Abort 等待、错误分类、RetryAfter deadline；无空闲输出超时。
- `frontend/src/conversation-state.ts`：用该任务接入 GET 观察和已接受 POST；保留按会话事实。`reconnect` 唯一任务互斥；`queryStatus` 纯快照 GET，不重启观察／恢复预算。正常完成补读历史／快照；未知 POST 先等待 retryAt 再核实。按 thread/run 记内存 retry deadline，重新进入／新 lease 不绕过。
- `backend-client.ts`：HTTP detail 属性；无事件流响应为协议错误并清理 body。
- `message-drafts.ts`／`SendRecovery.tsx`：未知发送结构化错误持久保留／只读展示，原有草稿／版本规则不改。
- `useConversations.ts`、App、Sidebar 与新 `ObservationStatus.tsx`：共用中文观察摘要、故障详情、倒计时、手动重连与纯状态查询，沿用 business-notice、次按钮、靛蓝／浅色样式。没有改 CSS、Rust、后端产品代码。
- 新 `frontend/tests/stream-recovery.test.mjs`：真实 BackendClient+Store，公开 fetch 边界与 node:test 的系统时间控制。
- 旧 `message-drafts.test.mjs`／`run-reconstruction.test.mjs` 调整为验证等待，保留并增强原断言（POST503 等待／原文、已接受断流后延迟 GET）；没有删测试或放宽断言。
- 新 `frontend/src-tauri/tests/stream_recovery_acceptance.py`：真实原生 Tauri CDP，fetch 在页面脚本前安装传输包装；真实隔离后端执行 resident task，切断已接受 POST、三次 GET503／一次 GET400、手动 query／reconnect、公开 history／snapshot 核对只有一条用户消息、Run不误判error、草稿保留及正常完成。共 2 新用例。
- 文档：票据实施中，index 待验证后更新。before 文件保存于本目录；capture.py/change.diff 由主 agent 刷新，审查固定此轮快照，不能把旧票提交算入。

## 已有开发检查（不代替最终验证）

1. 首个 1/2/5 测试红：0pass/1fail（没有重连），实现后1pass。
2. 手动竞争测试红：1pass/1fail（没有 reconnect 接口），实现后2pass。
3. 18 项恢复专项曾通过；加入 POST 后与相关旧测试 61 项：60pass/1fail，旧 POST 立即 GET 假设已改为先等1秒，保留原身份／事实断言。
4. 最近 `node --experimental-strip-types --test tests/stream-recovery.test.mjs tests/run-reconstruction.test.mjs`：41pass/0fail；之后仅补了草稿503结构化持久错误断言。主直接 tsc 两次通过（之后仍有新增变更，最终需重跑）。ruff format 新native文件已执行。

## 命令／环境／权限

工作区 `C:/code/shikigen-agent`，Windows PowerShell，Node/pnpm已安装，`pnpm.exe` 可用，pnpm.cmd 不存在。

前端验证者（独占原生端口／构建）：

- cwd `frontend`：`node --experimental-strip-types --test tests/*.test.mjs`（全套一次，预期新增后约89项，以实际计数为准）。
- cwd root：`node frontend/node_modules/typescript/bin/tsc --noEmit -p frontend/tsconfig.json`。
- cwd frontend：`pnpm.exe build`。
- root：`.venv/Scripts/ruff.exe check frontend/src-tauri/tests/stream_recovery_acceptance.py` 和 `format --check`。
- 最新 dist 构建后，root：`.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/stream_recovery_acceptance.py`。
- 串行旧回归：`.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/message_drafts_acceptance.py`（4用例）、`run_reconstruction_acceptance.py`（3用例）。
- 原生 pywin32／CDP 需要 `sandbox_permissions:require_escalated`，说明启动本任务隔离实机夹具并读取窗口。自动审批拒绝请如实报告，不假冒浏览器预览。
- 5173 已有 Python http.server PID23344，源目录 frontend/dist，所有权不确定，不能杀。既有夹具逐字节比较 HTML 和所有引用JS/CSS，匹配才复用；9238/45200必须空闲，所有自有 native/backend/tool及临时 DB 按夹具清理。原生彼此串行；后端 unittest用临时路径不共享这些端口。
- Native exe 已存在 `frontend/src-tauri/target/debug/examples/backend_window.exe`，未改 Rust 无需 cargo重建；若不匹配请报告。
- 每条命令单独记录日志和 `$LASTEXITCODE`；不能以最后一个 pipeline 的 exit 代替测试 exit。不改产品代码，不删／降断言。定位失败、证据和覆盖缺口回传主 agent 修复。

后端验证者（无 native／无 pnpm／不改共享代码）：

- root `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_server.py -v`；`test_recovery.py`；`test_run_observation.py`（先rg核实名字，不存在则定位公开观察回归文件）。
- `.venv/Scripts/ty.exe check app packages/harness`。
- 最终 `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` 全套一次，必要require_escalated含子进程本地服务。
- 第04票留有正式失败 `test_approval_resume.ApprovalResumeTests.test_waits_for_previous_cleanup_and_survives_caller_cancellation`，原全套291总/289pass/1skip/1error，3秒settled超时。记录 `.scratch/approval-cleanup-test-timeout/issues/01-approval-resume-settlement-timeout.md`，本轮未改审批产品／正式测试。全套若仍失败如实记录；不反复试到绿、不改deadline、不称根因已确认。若新失败定位并通知主agent。

## 报告

分别写本目录 `frontend-report.md`、`backend-report.md`，含实际模型／强度、每条准确cwd／命令／exit和counts（父子子测试计数不相加冒充独立用例），原始日志路径、截图／result.json位置、复现、资源清理、剩余覆盖缺口。前端原生截图必须目视并报告可读性，保留失败首轮日志。主核对后关闭票据。

## 验证中补修（原始交接与日志保留）

- 第一轮 Node 实际 **91/91**、tsc/build通过。native脚本两处 E501 换行修复（仅测试文本）。
- 初次 native2 项业务断言走到正常退出，但鼠标菜单命中故障；另一项固定解释文案误命中宽泛“运行失败”否定断言，改为精确 `.toolbar-badge=运行中`，公开history=running原断言保持。
- 子 agent发现接受POST首metadata后断流、GET重放503时原文不可见；新增测试红20pass/1fail，主补修accepted断流在重连等待中补读一次真实messages，`RunProjection.mergeMessages`只补正文不盖metadata。最近恢复+重建 **42/42**，最终产品需再Node、tsc、build与native。
- 共享 `window_acceptance.py` 保留原 `tray_menu` 鼠标默认分支与断言。两种菜单键盘方案未通过：popup PostMessage 不产生菜单高亮，OS keybd_event 前置 foreground 核实失败；最终只读诊断确认 `LockScreenBackstopFrame`、foreground=0，停止所有全局输入尝试。最终 `quit` 使用 `native_command=True`：核实际 popup 菜单 labels、GetMenuItemID 和 enabled，向本宿主 `tray_icon_app` 发 WM_CANCELMODE 关闭菜单，再 WM_COMMAND 触发真实 Muda 原生菜单分发。实际源码依据为本机 tray-icon 0.24.2 的 TrackPopupMenu（未使用 TPM_RETURNCMD）与 Muda 0.19.3 的 WM_COMMAND subclass 分发。正常宿主退出 0 和后台清理断言保留；不提高超时，不直接调用产品 handler。最小真实窗口退出探针通过。锁屏下物理鼠标／键盘未验收，留给解锁后的第 23 票联合验收。
- 旧04正式首轮4项和旧03正式首轮3项失败，其中多数仅退出；04首项Enter/IME未提交也需独立诊断与正式复测，不计通过。scratch诊断不得计为正式用例通过。
- 后端已一次完整 **291 total /290pass /1skip /0error，exit0**；三个专项17/11/9和ty通过。以前审批超时本轮未复现，不据此宣称根因已解决。前端补修无后端产品改动，后端不重复验证。
- Standards review 发现秒级倒计时位于原子 aria-live，主将倒计时移出 live region，连接状态／轮次仍 polite。
- Spec review 发现正常 EOF 的空 SSE（没有 metadata）被误归类可重试，主新增公开空流测试先红（retry_wait 而非 failed）、修复 finishObservation 将此类 EOF 抛 RunProtocolError 后绿 1/1。仅已确认 running 的意外 EOF 走恢复；网络／可恢复 SSE 仍按契约处理。最终 Node 全套预期 93 项，以测试子 agent 实际结果为准。
