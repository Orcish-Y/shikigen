> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 12 票验证交接

日期：2026-10-06。代码固定点：a35232d461b38bdb48a8cbdad4ed6a59561dba0c；开始时工作区及暂存区干净。

## 目标与规格

完成 docs/wayfinder/frontend-completion/implementation/12-approval-resume.md 的全部 8 条验收条件。来源 .scratch/frontend-completion/PRD.md、docs/wayfinder/frontend-completion/tickets/003-approval-cancel.contract.md；样式 frontend/design.md；先读 AGENTS.md。仅本票，下一票审批本地持久草稿不在本次范围。

## 方案和改动

- frontend/src/approval-decisions.ts：完整请求身份（忽略对象键次序）、严格动作配置解析、默认未选草稿、按动作原顺序的全部 responses、真实审批历史。
- frontend/src/backend-client.ts：既有 approval-decisions POST，原 body，不加 checkpoint；同 run_id 验证和 SSE 统一入口。
- frontend/src/conversation-state.ts：应用内草稿、同 Run 写互斥；首次 POST 暂停后自动 GET 恢复校验；仅本次 POST metadata 结束 pending，之后继续观察；未确认失败先 GET，不重发。已接收断流只恢复观察。终态和实际处理事实锁旧卡片。
- frontend/src/useConversations.ts：公开前端动作与事实读模型。
- frontend/src/components/ApprovalCard.tsx、Conversation.tsx：按真实 seq 排卡片，原 Interrupt/action 顺序，名称、说明、namespace、允许选项、X/Y、逐项决策、可选拒绝原因、折叠完整 JSON、复制和只读抽屉；统一提交和确认取消。
- App.tsx、ContentViewer.tsx、MessageBody.tsx、styles.css：沿用外壳；处理审批定位；请求反馈；参数抽屉身份及历史标记；取消弹窗复用；终态不过时回退；关键控件 14px / 44px。
- frontend/tests/approval-decisions.test.mjs：目前 8 个公开 Store/客户端与决策模型专项；主 agent 定向全部通过。
- tests/desktop_approval_fixtures.py：真实 LangGraph root + child 并行两个 Interrupt、每个两个动作；真实 @tool 只在批准后运行；allow-approval-tools 文件控制工具结束；不访问网络模型；可经 DESKTOP_TEST_UNSUPPORTED_APPROVAL 返回 edit-only 动作。
- tests/test_frontend_approval_flow.py：临时 SQLite + HTTP +真实 Graph 完整审批；主 agent 定向 1 通过。
- frontend/src-tauri/tests/approval_resume_acceptance.py：3 个新增实机测试，多请求／多动作、参数长滚动和抽屉、拒绝原因保持、pending 后 metadata 不等 EOF、同 Run 继续、422 核实重提、unsupported 取消无工具。
- 无后端产品／Rust 产品代码／公开协议／依赖变更。

## 已有快速检查

前端新增 8 通过；既有取消/重建 28 通过；直接 node node_modules/typescript/bin/tsc --noEmit 多次通过。新后端公开流程 1 通过。3 个 Python 文件 Ruff check/format 当前通过。pnpm shim 调用曾等待很久，改用直接 node 的本地已安装可执行；不用网络下载依赖。

## 环境、限制与职责

工作目录 C:/code/shikigen-agent，PowerShell，Windows，.venv Python 已装依赖，frontend/node_modules、Rust examples 已有。模型必须显式 gpt-6-luna / max。所有子 agent 只验证和报告，禁止产品修复、删测试、放宽断言、type-ignore、git add/reset/commit。需要补覆盖只报告给主 agent。日志写本目录新日志并配 metadata，记录时间、命令、cwd、exit、数量。不能覆盖旧票据日志。暂存区保持原状。

完整后端回归与原生测试禁止同时启动：两者可能启动宿主/固定端口和争用系统资源。Node 和静态检查可与后端并行。原生 5173 / 9238 / 45200 需先核实空闲；已有静态服务只有逐字节吻合当前 dist 才复用，不杀未知进程。原生必须以一个 runner 串行，避免继承 TestCase 重复用例。

## 命令

### 后端验证（根目录）

专项：.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_frontend_approval_flow.py -v

既有审批相关：在 PYTHONPATH 包含 tests 后运行 unittest test_approval_pause test_approval_resume test_run_cancel test_message_write_transaction，保持原断言。

最终完整一次：.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v

静态：.venv/Scripts/ruff.exe check tests/desktop_approval_fixtures.py tests/test_frontend_approval_flow.py frontend/src-tauri/tests/approval_resume_acceptance.py；同范围 format --check；.venv/Scripts/ty.exe check app packages/harness；新增后端测试 ty 需 --extra-search-path tests。

### 前端验证（frontend）

专项/完整：node --import tsx --test tests/approval-decisions.test.mjs tests/run-cancel.test.mjs tests/run-reconstruction.test.mjs tests/message-drafts.test.mjs；最终完整一次 node --import tsx --test tests/*.mjs。

类型：node node_modules/typescript/bin/tsc --noEmit

构建：node node_modules/vite/bin/vite.js build（类型独立先检查）。

原生等待后端完整结束及主 agent 通知，再按独立 runner 运行新 3 个及受影响旧路径。已有 backend_window.exe，如发现 binary/源码不一致再 cargo build --example backend_window；本票无 Rust 修改，不重复 Rust 全套。

## 风险与覆盖

禁止把 GET/旧 metadata 算 POST 接收，HTTP 200 和本地选择不造历史。提交 body responses 覆盖全部 Interrupt，决定顺序不能按用户点击顺序。单次接受以后旧选择不能编辑，terminal 锁旧卡片，pending 操作不能竞争取消。核实失败保持只读，所有 POST 必须主动。Namespace 空值展示主流程但原值保留；JSON 原始不截断；未知决策整组只读；参数抽屉关闭保持草稿且不重开 SSE。

历史问题保持 needs-triage：审批结算 3 秒超时、Windows 空宿主退出超时、旧 IME Enter 偶发无 POST。旧失败不可改算为通过；隔离重试是新结果。物理输入、系统 IME、多视口联合验收归第 23 票；跨重启审批草稿归第 13 票。

报告必须实际使用模型、范围、完整命令、通过/失败/错误/跳过、日志/截图位置、可复现失败和剩余缺口。产品问题发给主 agent，修复后仅定向回归，必要时补完整。
