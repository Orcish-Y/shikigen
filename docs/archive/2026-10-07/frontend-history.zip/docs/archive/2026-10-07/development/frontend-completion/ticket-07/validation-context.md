> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 07 票验证交接

实际调度模型：所有最终验证及两轴审查使用 gpt-6-luna / max；fork none。
工作目录 C:/code/shikigen-agent，Windows PowerShell。权限在本轮接续中发生变化，按文末时间线和当前工具指令执行；不能沿用历史审批设置。不得 Git 暂存、提交、reset 或修改 AGENTS。起始 clean HEAD 2cde5b5757e1065049fdfdc21e98d17ed6fd68ec；git diff <base> 是本票 tracked 改动，新增未追踪源码也属于审查对象。没有本票 commits。

## 目标与规格

实现且仅完成 docs/wayfinder/frontend-completion/implementation/07-markdown-content-viewer.md 全部 7 AC。统一规格 .scratch/frontend-completion/PRD.md §12、§14（网页打开）、§19（单前景）；定稿 docs/wayfinder/frontend-completion/tickets/004-message-tools-export.contract.md §4、5、8；样式 frontend/design.md。01–06 已 done。本地图片读取／文件打开归14/15，本票仅保留原引用为只读文字／复制。

验收摘要：Agent Markdown，user/tool 原文与空白；type=text 角色展示且额外字段 JSON，未知块完整 JSON，数组原顺序不跨块；react-markdown10/remark-gfm4/rehype-sanitize6，HTML先文本化，无raw/MDX/执行；任务只读，表格局部滚动，脚注每消息/块隔离；代码真实语言可识别文件名，复制完整代码无围栏/行号，代码JSON320px；400px抽屉/窄屏80dvh只读面板单前景，关闭焦点/草稿/观察保留，复制失败可手选，preview片段标明；Windows/UNC/定义引用保留，无原路径href/src及远程图片请求；仅HTTP(S)经Rust受控命令+opener，自动链接脚本关闭，无plugin前端旁路授权，modifiedclick同入口，局部错误。

## 实现

MessageBody（角色、未知内容块、安全Markdown、ErrorBoundary），ContentViewer（完整text/JSON/代码、Clipboard），markdown-policy（remark HTML文本化/引用和代码信息捕获、Windows源路径、定义引用、脚注scope、sanitize schema）；displayMessage不再丢content数组，不把工具调用拼成AI Markdown，Conversation真实tool角色及原工具内容。App统一ContentView/commands/details前景，modal拦全局动作，切会话关闭。Overlay失效入口回稳定工作区。styles延续Slate/单色/原尺寸。Rust web_open公有系统打开边界验证显式http(s)://、host、拒绝controls/backslash/前后空白，结构化错误；命令只main、blocking调用opener；自动JS链接false，capabilities仍仅core。opener2.5.3为兼容既有tauri2.11.6，Cargo.lock不升级主Tauri/托盘，新增插件所需依赖；tsx用于真实TSX公开组件SSR测试，新 test script。

改动文件请 git status --short 全部核对；backend产品没有变化。新增 tests/desktop_markdown_fixtures.py 与 frontend/src-tauri/tests/markdown_content_acceptance.py 正式原生验收，前者是无网络真实Agent+middleware返回固定Markdown/块数组/工具原文，后者临时bootstrap换注入入口、不加产品钩子。公开 HTTP 历史核对持久完整事实。

## 开发验证（最终仍需子agent）

定向 Node5/5绿色（角色、blocks、Windows/UNC定义、代码/未闭合/preview、HTML/GFM/脚注），tsc通过；首次红分别缺MessageBody、无GFM、Windows定义引用丢失，最后已修。Rust web_open2/2 pass；主agent定向编译及开发build通过。Ruff新2py check/format通过。主agent最后补了脚注button id/可聚焦li与raw preview文案；最终types/build必须包含。无需主agent重复最终批量验证。

## 准确命令

根：.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v；.venv/Scripts/ty.exe check app packages/harness；.venv/Scripts/ruff.exe check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py；相同文件 ruff format --check。
frontend cwd：pnpm.exe test（node --import tsx --test tests/*.mjs）；node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json；pnpm.exe build。
frontend/src-tauri cwd：cargo fmt --check；cargo test；cargo build --example backend_window。
根 native：$env:PYTHONPATH="C:/code/shikigen-agent/tests;C:/code/shikigen-agent/frontend/src-tauri/tests;C:/code/shikigen-agent/packages/harness"；.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/markdown_content_acceptance.py。其他03/04/05/06正式脚本同路径；串行，允许通过 scratch runner改artifact_root，不能改变断言。

## 环境与风险

5173既有静态服务PID23344不归本票；必须逐字节与最新dist入口及引用资产匹配后复用，不杀已有服务。9238/45200共享原生端口必须空闲，原生suite唯一执行者，Rust build先于native。临时DB/后端每case隔离，正常托盘退出host.wait==0，不扩等待或删断言。CDP/WebView真实页面不是browser预览；桌面此前锁屏，勿解锁/绕过。物理输入/系统IME/原生边框、多尺寸真窗口归23；本票窄屏WebView Emulation要如实标明。系统浏览器成功试验打开无网络loopback临时只读页面，不终止用户浏览器。Clipboard故障在navigator外部边界注入，原生command失败在IPC外部边界注入；实际unsafe commands用真Rust拒绝，plugin无授权应deny。试验报告区分OS接受与浏览器呈现（不做额外保证）。Vite当前JS522KB会有500KB warning，不能隐藏警告；可报告。

历史后端291中symlink权限skip；第04审批cleanup旧3秒超时曾失败，05/06完整回归过，仍needs-triage，不通过改超时/删测试处理。WebView清理可能1412诊断，exit结果单独报告。

测试子agent只读产品；定位失败提供可复现命令、日志、截图、原始assert与覆盖缺口。产品/正式测试修正由主agent完成，修后定向及必要回归再交子agent。报告实际调度模型、命令cwd、pass/fail/skip、exit、证据路径。不能凭一句通过关闭票据。
# 最终验证补充：焦点修复

2026-10-05，原生专项发现并复现完整查看焦点丢失。证据、排除假设及修正详见 [diagnosis.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/diagnosis.md`）。产品变更仅 `MessageBody.tsx` 的稳定 renderer／Context 及 `Overlay.tsx` 的 layout effect／有效入口判断；正式原生第一项增加同一 DOM 节点的强断言，没有放宽断言、延长超时或加入产品测试开关。

Node 全套、类型／构建和 Standards 增量由原 frontend agent 复测；原生 agent 在新 dist 构建完成并核实 hash 后串行执行第 07 票两项及第 03／04／05／06 票 10 项。Rust／后端产品没有新增变化，不重复其批量检查。新日志与目录单独保存，不覆写首轮结果。
# 最终验证补充：Tab 边界

同一真实宿主的多轮正反 Tab 诊断证明原生 dialog 在首尾可短暂丢失焦点，详见 [diagnosis.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/diagnosis.md`）。Root 给 Overlay 添加仅普通／Shift+Tab 的首尾循环；候选来自当前 dialog 的可见、可 Tab、非 disabled／inert 控件。正式用例改为协议正确的 Shift=8，并覆盖 20 步混合及双向完整循环，不改变任何原断言或等待。

最新产品需 frontend 111 项、direct tsc、build、新 dist/hash、Ruff 和增量 Standards；随后 native 用新版构建串行执行本票 2 项及旧 03／04／05／06 票 10 项，更新 Spec。全新日志及 artifacts 使用 tabfix 后缀，早期失败与之前通过结果保持独立。Rust／backend 不变，无需重复其有效批量验证。
# 用户“继续”后的接续环境

当前工具环境改为 workspace-write／受管权限及受限网络；旧交接中的 danger-full-access 不再适用。此前测试 agent 已不在当前树中，最终 Standards／原生 Spec 接续由新建、显式 `gpt-6-luna / max` agent 完成。

最新 Tab 修复的有效日志已保存为 `frontend-test-tabfix.log`、`tsc-tabfix.log`、`frontend-build-tabfix.log`，分别 exit 0，附各自 stdout／stderr。当前 dist 为 `index-CRxAs_nQ.js` 与 `index-ab2XaoTv.css`。接续先核原始日志和资产，不重复已经完成的这批检查；补最新 Ruff／Standards，再在遵守当前原生 GUI 升权规则的前提下运行 `native-tabfix` 共 12 项正式验证。权限不足或审批未获得的检查单独记录，不计通过。

## 最终收尾：样式与指定／解析值

Tab 修后正式 12 项全部通过；主 agent 核截图发现新 pre 的焦点圈未继承原规则，补通用 `[tabindex]:focus-visible`，指定仍为 2px 靛蓝／3px offset。样式 build 通过，资产为 `index-BOOLs1PU.js`／`index-C37yfSMR.css`，完整 hash 见 [frontend-report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/frontend-report.md`）。只复验07两项，不重跑未受影响的旧10项、Rust或后端。

新的间距断言首轮为 1 通过／1 失败。只读 CSSOM 诊断确认 pre 与同 dialog 现有按钮声明均为 3px，实际焦点样式严格相同，但 offset 解析为 2.66667px；没有证据认定 DPI／zoom 根因。Root 改正式 oracle 同时严格检查 active／focus-visible、匹配声明为3px、颜色／宽度与原值、三个完整快照相等；不补偿 CSS、不放宽容差。Ruff 初次 format 检查失败，Root 格式化后，轻量 agent 三文件 check／format 均通过。

最后仅执行 `native-final-content-runner.py` 的07两项正式用例，独立保存 `native-final-content-run.log`／artifacts：2 通过、0 失败／错误／跳过，12.323秒。Root已核 raw 日志、完整复制及焦点快照、桌面和窄屏截图。测试命令已按当时 managed GUI 要求单独获得审批；随后最新工具权限切回 danger-full-access／approval never，新命令不提供 sandbox_permissions。该变化不覆写历史批准／失败记录，也不需要重复已完成验证。

最终补文档后由 Standards 轻量 agent 仅核局部链接、审查范围与只读 Git 状态。下一票为08，本轮没有实现。
