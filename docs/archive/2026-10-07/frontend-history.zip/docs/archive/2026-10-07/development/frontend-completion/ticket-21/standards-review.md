> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Standards（GPT-6-Luna/max）

审12文件，依AGENTS；未跑测试／构建／原生。

**硬3组：**

- `navigation-layout.ts:9,22,30`：`preference`布尔意图不明（最重）；函数名未显动作语义。
- `useNavigationLayout.ts:14-16`：`resize`回调裸动词；`previous/next`实体非名词。
- `responsive_navigation_acceptance.py:37,51,79,81,134,338`：`current/disabled`为形容词实体；辅助函数缺动作名。

**建议1（非硬）：**`Overlay.tsx:6-16`的`drawer/sidebar`布尔可并存，考虑`variant`；Fowler余项无明确异味，未推断运行缺陷。
