> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 10 Standards 审查

审查基准：`d7862fb50a7c5654661ca6d8967195d863c2d80e`；核对 `git diff <基准> --`、交接材料及四个新增测试/夹具文件。`HEAD` 无新增提交。本次未运行功能测试。

审查模型：`gpt-6-luna / max`。

## 做得好的

- `packages/harness/shikigen/contracts/messages.py:34,53-59` 用 `Literal` 明确生成状态，并将旧消息默认归一为 `complete`；符合 `CONTEXT.md`「中止消息」定义及 `frontend/design.md:195-199` 的正文外标因约定。
- `frontend/src/App.tsx:358-369` 复用原生 `Overlay`，取消按钮用规范危险色；初始焦点落在“继续运行”，符合 `frontend/design.md:70,225-227`。

## 需要修的问题

未发现文档硬性标准违规。Ruff、类型和格式等已由交接验证，按审查约定不重复列出。

## 值得讨论

- **启发式：可能的 Repeated Switches（非硬违规）**。`frontend/src/components/Conversation.tsx:90,95` 对同一运行状态集合重复作相反判断（`['cancelled','completed','error'].includes(...)`）；新增的 `frontend/src/run-projection.ts:18` 已有 `terminalRun`，而 `frontend/src/App.tsx:428` 与 `frontend/src/backend-client.ts:209` 也重复列举同一集合。可在组件内先算一次终态，跨调用点则放到共享低层状态谓词，避免状态扩展时列表漂移。依据：`code-review/SKILL.md` §3「Repeated Switches」基线；此项为判断性气味。
