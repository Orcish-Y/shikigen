> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 16 票 Spec Review

范围：只读审查固定副本 `.scratch/frontend-completion/ticket-16/review.diff`，对照第 16 票六项验收、PRD §15、004 契约 §9 与既有设计规范。此审查未运行 Git、测试或应用，也未修改产品／测试代码；下述测试结果来自已保存的原生验收证据，不是本次执行。

## 复核结果

1. **字段语义问题已关闭。** [`collectExportRunOutcomes`](../../../../../../frontend/src/conversation-export.ts#L15) 保留 lifecycle `message` 与 Run `error` 两个独立字段；当前 Run 摘要可与事件文案并存，审批事件不进入导出。快照、序列化及正文隔离静态实现符合第 19–23 行约束；此前发现的问题有对应专项覆盖，但本次没有重跑。

2. **取消验收有实际 WebView 证据。** 第 24 行要求实际 Tauri 下载与“保存取消／失败不改事实”，PRD §15 和契约 §9 分别要求取消保存／下载失败不改事实及 Tauri 实机验收；三处均没有要求 Windows `#32770` Save As 窗口。[正式原生用例](../../../../../../frontend/src-tauri/tests/conversation_export_acceptance.py#L250)在实际 Tauri/WebView 中记录同一下载 GUID 的 `downloadWillBegin`、成功取消响应及 `downloadProgress(state=canceled)`；结果记录 `totalBytes=69759`、`receivedBytes=0`，没有落盘文件，HTTP 历史、草稿及 Run 状态保持不变。已有日志为 **1/1 通过**（[日志（原始产物已删除）](../../../README.md#已删除的材料)，[结果（原始产物已删除）](../../../README.md#已删除的材料)）。这是真实下载生命周期取消，不是 `deny`。

   Tauri 在 Windows 使用 WebView2（[Tauri 官方文档](https://v2.tauri.app/start/prerequisites/)）。Microsoft 将 Download 与 Save As 列为不同 API／流程；下载取消可使下载进入用户取消状态，[无需特定 Save As 窗口](https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/overview-features-apis)（[取消语义](https://learn.microsoft.com/en-us/dotnet/api/microsoft.web.webview2.core.corewebview2downloadstartingeventargs.cancel?view=webview2-dotnet-1.0.3856.49)）。因此 `#32770` 不是该票的规格前置条件。

3. **默认下载 UI 仍是明确覆盖边界。** 正式成功下载与取消用例将下载目录隔离到测试产物中；它们证明实际 Blob 下载字节／取消生命周期，不证明应用默认下载目录、默认 UI 或物理用户操作。额外 `#32770` 探针两次未找到目标窗口，已保留为失败；runner 将其作为 opt-in 探针（[`native_runner.py`（临时产物已清理）](../../../README.md#已清理的临时产物)）。不得把探针记为通过，也不得把这项边界描述为已验证。可在第 23 票联合实机验收继续检查默认界面／用户操作。

## 结论

Spec 轴未发现 `#32770` 探针失败导致的第 16 票规格缺口；现有真实 WebView 取消和实际 UTF-8 文件下载证据满足票面要求，不应把策略 `deny` 当作取消证据。默认下载 UI、保存目录和物理用户取消仍未验证，需如实保留为后续覆盖边界；本结论不表示本次审查运行了测试，也不替主 agent 更新票据状态。
