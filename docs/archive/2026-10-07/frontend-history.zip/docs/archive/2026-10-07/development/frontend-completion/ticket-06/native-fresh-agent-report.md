> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 06 票原生 fresh-agent 验证报告

- 执行模型调度：`gpt-6-luna`，reasoning `max`，`fork_turns: none`（以主 agent 调度记录为准）。执行权限与 root 一致：danger-full-access / approval never；未传 `sandbox_permissions`。
- cwd：`C:/code/shikigen-agent`。未改产品/测试/Git；未解锁或绕过锁屏；未终止 PID 23344。
- 预检：9238、45200 在各轮开始前空闲。5173 的 PID 23344 服务与当前 `frontend/dist/index.html`、入口 JS、CSS 逐字节哈希相同，复用未改动。首失败 `native/host-0.log`（0 字节）已在本任务开始前复制到 `native-before-connect-fix/host-0.log`，未覆盖。

## 正式验收与旧票原生回归

| 范围 | 命令 / 结果 | 证据 |
| --- | --- | --- |
| 06 原生场景 | `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/visibility_polling_acceptance.py`；exit 0；1 pass / 0 fail；15.878 秒。Host 在隐藏时存活，托盘恢复读取成功，脚本确认正常退出（`host.wait()==0`）。 | `native-visibility-fresh-agent.log`；截图 `native/test_hidden_task_continues_and_show_recovers_facts_without_resending/window.png`；事实 `result.json` |
| 06 build106 最终原生场景 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-06/run_visibility_final.py`；exit 0；1 pass / 0 fail；15.052 秒。托盘退出及 `host.wait()==0` 断言通过。 | `native-visibility-final-106.log`；截图与事实 `native-final/test_hidden_task_continues_and_show_recovers_facts_without_resending/` |
| 03 原生回归 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-06/run_native_regression.py --ticket 03`；exit 0；3 pass / 0 fail；17.685 秒。 | `native-regression-03.log`；截图/事实位于 `native-regression/03/` |
| 04 原生回归 | 同上 `--ticket 04`；exit 0；4 pass / 0 fail；26.614 秒。 | `native-regression-04.log`；截图/事实位于 `native-regression/04/` |
| 05 原生回归（初次） | 同上 `--ticket 05`；exit 1；1 pass / 1 fail；25.538 秒。未更改原断言。 | `native-regression-05.log`；失败截图 `native-regression/05/test_bounded_get_recovery_then_manual_query_and_reconnect/window.png` |
| 05 EOF 原方法诊断（build106） | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-06/diagnose_native_eof.py`；exit 0；1 pass / 0 fail；19.110 秒。正式断言全绿，因此诊断包装器没有生成失败时间线。 | `native-eof-diagnostic-106.log`；截图/事实位于 `native-diagnostic/05-eof/test_original_bounded_recovery/` |
| 05 原生回归（最终106） | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-06/run_native_regression.py --ticket 05 --final`；exit 0；2 pass / 0 fail；26.117 秒。 | `native-regression-05-final-106.log`；截图/事实位于 `native-regression/05-final/`，未覆盖初次失败证据 |

初次 05 失败：`stream_recovery_acceptance.py:132` 期望“观察正常结束”。原始 `body()` 中会话状态为“运行中”、顶部为“观察已建立”，只有 AI 正文包含“后台任务已完成”；宽泛的 `wait_until("已完成" in self.body())` 可由正文提前满足，随后 EOF 断言失败。主 agent 保留原所有断言与 20 秒上限，将等待条件改为 toolbar badge 精确显示“已完成”且观察状态为“观察正常结束”，并补验最终历史非空且所有消息为 `run_status=completed`。build106 单项诊断与两项最终回归通过；初次 fail 日志/截图仍单独保留。

首次 06 的 1/1 使用修正前 dist105：`result.json` 记录 revision 0→1→2、隐藏期间消息 GET 与发送流 POST 被中止、恢复后只发 messages/snapshot GET、历史 Run 已完成；截图显示旧标签“观察已暂停”。build106 最终场景在相同事实下截图显示“观察正常结束”，并保留草稿；相关新公开用例与正式原生用例均通过。

每轮后检查到 9238/45200 均已释放；5173 保留原 PID 23344 服务。完整 stdout/stderr 与 exit code 分别记录在各自 `.log` 及配套 `.stdout.log` / `.stderr.log` 中。build106 由主 agent/build agent 产出；本执行 agent 未重跑 Node、TS、构建或其他验证。

最终 lint：`.venv/Scripts/ruff.exe check frontend/src-tauri/tests/visibility_polling_acceptance.py frontend/src-tauri/tests/stream_recovery_acceptance.py` exit 0（All checks passed）；`.venv/Scripts/ruff.exe format --check` 同两文件 exit 0（2 files already formatted）。命令结果见 `native-ruff-106.log`。

## 后续

初次 05 失败已由原始 stdout/stderr 和截图保留，build106 的最终两项回归单独写入 `05-final` 证据目录。
