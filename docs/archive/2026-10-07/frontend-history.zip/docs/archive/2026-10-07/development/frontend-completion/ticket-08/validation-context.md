> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 08 票验证交接

## 任务、权限与范围

用户通过 `$implement docs/wayfinder/frontend-completion/implementation/index.md 完成下一票` 授权实施第 08 票。规格：`docs/wayfinder/frontend-completion/implementation/08-complete-tool-records.md`，完整契约第 2、4、5、6 节：`docs/wayfinder/frontend-completion/tickets/004-message-tools-export.contract.md`；视觉：`frontend/design.md`。共同要求与词汇见实施 index、`CONTEXT.md`、`AGENTS.md`、`docs/agents/{issue-tracker,domain,triage-labels}.md`。无 docs/adr 目录。起始工作树干净，固定审查基点 `0c52c18060158ebe23151a66fcba88feb4273ccd`。仅第 08 票；后续第 09／10／12／14／15／16 等不在本轮范围。

cwd `C:/code/shikigen-agent`，Windows PowerShell，2026-10-05，Asia/Shanghai。当前 danger-full-access、approval never：**不要传 sandbox_permissions**。Python `.venv/Scripts/python.exe -X utf8`，Ruff／ty 同目录，pnpm 使用 `pnpm.exe`。允许本票测试、构建、启动隔离真实宿主。不要停止用户浏览器、WebView、已有 5173 服务，不编辑 AGENTS，不 stage／commit，不修改产品代码。测试若失败，保留证据、独立定位、报告主 agent 修复；不要删除／放宽断言。允许新增验证辅助文件和报告。

所有最终验证和两轴审查显式模型 **gpt-6-luna / max**。主 agent 实现与修复，子 agent 执行／诊断／审查。已有验证只在产品变化或失败后追加必要检查。未执行／跳过／阻塞不能算通过。报告须列模型、命令和目录、准确数量、实际错误、日志／截图及覆盖缺口。

## 实现

- `frontend/src/message-presentation.ts` 保留完整 `ConversationMessage` 原对象引用到 `Message.record`，稳定 ID 由 run／seq／message_id 组成，不丢其他公开字段；用户／Agent／工具角色不混淆。
- `tool-records.ts` 对同会话、同运行、tool_call_id 建立调用和结果索引。双方都唯一才将结果移动到原调用卡片，按 tool_calls 原顺序；多个调用或多个结果、跨 scope、未匹配结果独立展示。原记录不改写，结果保留 seq／ID／name／status／artifact，不按名称或到达顺序猜配。
- `ToolCard.tsx` 标题来自调用名称，结果不同名称另显示；等待／已返回／失败来自 ToolMessage／status，Error 字样不改状态；所属运行已结束且无结果依旧等待并解释。空字符串／空数组说明已返回正文为空。完整原始调用／结果可核对各自 seq 和所有字段。
- `tool-card-preferences.ts` 应用内展开偏好由 App 外层 `useConversations` 所有。正常默认折叠，首次真实失败只自动打开卡片和结果；手动收起后不会被失败／重复回放重新打开。参数、artifact、原始记录默认折叠，重启恢复默认，不写 localStorage。
- 非 null artifact（包括空字符串／0／false／[]／{}）均有只读完整区，省略／null 不造区；字符串复制原串，其余格式化完整 JSON。结果正文复用 MessageBody role=tool，长结果 320px 内滚动，查看／复制复用第 07 票 ContentBlock／ContentViewer。没有媒体／文件猜测或审批操作。
- `run-projection.ts` snapshot 附加 `runStatuses` 只读映射，用已提交历史 run_status 和已观察 metadata 解释各卡片所属运行，终态不降级；不改变当前 Run 权威／API。`conversation-state.ts`、`useConversations.ts` 传递映射。
- `Conversation.tsx` 按投影展示 ToolCard；`App.tsx` 传应用偏好；`styles.css` 继承 Slate／1px／8px／靛蓝焦点／44px 控件，并加入匹配的失败红字与图标、局部滚动。`data/{demo,tool-demo}.ts` 明确示例，会话工具演示含同名、乱序、空值、重复身份、未配对和失败。

## 验收条件与专项

1. 同会话／Run／唯一 ID 关联，调用顺序和原始两条 seq 保留；无唯一匹配独立结果，无猜测。
2. 真实 ToolMessage／status 决定状态；Run 结束无结果仍等待。中文状态，无伪 ToolMessage。
3. 空正文已返回；额外字段、结果名称不同、未知结构完整核对，无第二条 Agent 伪答。
4. 默认折叠／首次失败只展开结果；手动收起跨切换和回放保留；重启默认。
5. 非 null artifact 所有空值完整只读；null／省略区别保留，无路径／媒体执行，无另一套审批。
6. 共用完整查看／复制；长宽不撑页面；公开形状夹具覆盖同名／乱序／未匹配／空值／重复失败，真实工作台演示。

开发定向 Node 专项 **6 通过**，此前红记录：未实现 presentation 模块；随后 TypeScript flatMap 推断需明确 ToolRow；artifact 安全断言误含工作台静态 logo 的 preload，已限定工具卡片范围。不是移除受控内容断言。类型最近一次 exit 0；此后唯一产品变更为 runStatuses 空原型字典及仅 AI 读取 calls，需最终类型／全套回归。

专项正式文件：`frontend/tests/tool-records.test.mjs`；Python fixture `tests/desktop_tool_records_fixtures.py`；原生 `frontend/src-tauri/tests/tool_records_acceptance.py`（**3 项，仅选择本类 test_ 方法，避免继承父类整套重复执行**）。fixture 使用真实 create_agent、工具节点、中间件、checkpointer 和持久事实，固定 ToolModel 无网络。失败工具的 `allow-tool-results` 是临时项目目录下夹具闸门。结果 include 全空值／不同名称／未知块和明确 orphan ID；重复身份与乱序由公开 TSX 和浏览器示例覆盖，后端持久工具身份幂等，不能伪造重复保存。

## 分工与命令

### 前端／Rust agent

frontend：`pnpm.exe test`（原 111 + 新 6，预期 117）；`node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json`；`pnpm.exe build`。
frontend/src-tauri：`cargo test`（旧 25）；`cargo fmt --check`；`cargo build --example backend_window`。
将 stdout／stderr 和退出码保存在本目录。build 成功后写 `frontend-ready.json` 含 dist index／JS／CSS 路径与 hash／字节数，立即消息主 agent；只有这一 agent 构建前端／Rust。原生 agent 依赖该成功通知。

### 原生／Spec agent

等前端 build 成功后串行：沿用 ReconstructionAcceptance.setUpClass 的端口空闲与 5173 静态资源逐字节验证。9238／45200 必须空闲；若占用保留并报告。5173 没服务时共享夹具创建隐藏服务并清理；既有服务必须匹配 dist，不能杀。backend_window.exe 只用测试标识，临时项目／DB／WebView 隔离，正规退出／清理。
根目录 PowerShell 设置 `$env:PYTHONPATH = '<repo>/frontend/src-tauri/tests;<repo>/tests;<repo>/packages/harness'`，执行 `.venv/Scripts/python.exe -X utf8 <runner>`。runner 建 unittest.TestSuite，仅选本类 3 个 test_。
串行旧 03／04／05／06 的本类 3／4／2／1 项，再串行旧 07 的 2 项；不要额外发现继承测试，不累加重复数。父类有真实 Tauri 基础设施。真实 WebView 390×780 为设备视口模拟，物理窗口／IME／系统框架多尺寸验收仍归第 23 票。
Spec review 范围：`git diff 0c52c18060158ebe23151a66fcba88feb4273ccd` + 本票 untracked 源文件。未提交没有 commits list。引用上述票据／契约／design，按 missing／partial、scope creep、looks wrong 三类，逐项引用规则和代码位置，400 词内结论。不改产品代码，给主 agent 修复。

### 后端／Standards agent

根目录：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v`；`.venv/Scripts/ty.exe check app packages/harness`；`.venv/Scripts/ruff.exe check tests/desktop_tool_records_fixtures.py frontend/src-tauri/tests/tool_records_acceptance.py`；相同两文件 `ruff format --check`。
完整后端旧预期 291（1 Windows symlink 权限可能跳过）。历史问题必须保留：`.scratch/approval-cleanup-test-timeout/issues/01-approval-resume-settlement-timeout.md`；`.scratch/desktop-environment-exit-timeout/issues/01-empty-host-environment-startup-exit.md`。此前全套 289pass／1error／1skip，空环境变量分支 process.wait 超时；隔离两次通过不抵消全套。若再失败，记录本次并最多一次隔离用于诊断，绝不算全套通过。
Standards review 同一固定基点与 untracked 源文件，读 AGENTS／CONTEXT／design／本票共同行为标准。Smell baseline（都是 judgement call，repo 规则优先，工具强制的规则跳过）：Mysterious Name → rename；Duplicated Code → extract；Feature Envy → move behavior to data owner；Data Clumps → bundle fields；Primitive Obsession → domain type；Repeated Switches → one mapping/polymorphism；Shotgun Surgery → gather one change；Divergent Change → split unrelated responsibilities；Speculative Generality → delete unused abstraction；Message Chains → hide data navigation；Middle Man → remove forwarding only wrapper；Refused Bequest → composition instead of ignored inherited contract。报告明确硬规则违例／启发式，引用规则文件和代码 hunk，400 词内结论；不得因可能 smell 要求无关重构。

## 证据、收尾

最终汇总报告尚待验证；不要把票据先改 done。主 agent 核日志／截图、修复问题并交增量复验，然后更新第 08 票与实施 index。代码与测试 agent 不可自主 stage／commit。

## 后续增量交接

原定前端 117 项、Rust 25 项、原生 15 项、后端 291 项及类型／构建均已执行，详见各验证报告，不重复运行这些已通过批次。原生报告指出参数／artifact 各自的完整查看／复制没有逐个点击，因此补充第 4 个本票原生方法 `test_parameters_artifacts_and_independent_result_full_view_and_copy`，只运行这一方法，原始 runner 的历史 15 项结果保留。

两次增量失败的实际原因见 [diagnosis.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-08/diagnosis.md`）：真实 ToolNode 将未知块数组转换为公开记录中的 JSON 文本字符串，客户端复制原字符串，测试却再次序列化这个字符串。测试预期已改为字符串使用原文、其他值使用完整格式化 JSON；逐字复制／查看、历史不变和没有额外 POST 的严格断言仍保留。产品未修改，无须重建 dist 或重新运行全套。

原生／Spec agent 使用 `native-copy-final-runner.py` 做修后最终专项，证据独立保存在 `native-copy-final`。后端／Standards agent 只追加最终两文件 Ruff 与该测试 hunk 的增量核对；收到主 agent 文档就绪通知后运行 `check-documents.py` 检查文档链接、只读 Git 范围。最终验收计数由原 15 个唯一原生用例与新增 1 个组成，两次失败尝试不计作通过。
