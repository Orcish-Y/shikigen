> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第15票：每次确认后用系统程序打开工作目录文件

状态：已实现并完成本票六条核心验收。2026-10-06；用户授权实现下一票，明确禁止操作 Git。最终验证由显式 `gpt-6-luna / max` 子 agent 执行，主 agent 核对原始日志、退出码、公开命令响应、系统窗口证据及截图后关闭票据。

## 实现位置与原因

- **资源事实在 Python 后端**：复用第14票 `GET /api/workspace` 和 `GET /api/workspace/resources/resolve`，工作目录与文件工具一致。本票未改 Python 产品、数据库或 API。
- **打开意图在 Tauri 宿主**：`WorkspaceFileOpens` 使用 BackendManager 当前自管地址查询，返回 startup/workspace 身份、完整文件元数据和随机 request_id。前端无法指定后端地址、工作目录根或默认程序；opener 通用前端权限继续关闭。
- **确认在前端现有 Overlay**：Agent Markdown 明确本地文件链接、正文图片和完整图片详情进入同一流程；按会话／可见状态／租约管理生命周期，继承白色、Slate、靛蓝、小圆角和现有按钮样式。

## 打开链路

1. 点击原引用 → `prepare_workspace_file_open({startupId,path})`，宿主只进行 GET 核实和原生路径验证，不打开文件。
2. 显示“打开本地文件？”、真实名称／完整路径／大小／修改时间及默认程序说明，可复制路径。默认焦点取消；关闭、Esc、遮罩和取消发送 discard，零系统打开。
3. 用户确认 → `open_prepared_workspace_file({requestId})`，宿主先消费意图，再核实租约、目录、原引用目标、完整元数据和文件版本；通过后调用现有 `tauri-plugin-opener.open_path`。
4. 五分钟过期、重复、窗口／租约失效和文件变化均拒绝。失败保留真实原因，需要手动重新准备、新确认；成功只表示系统接受，绝不自动再次打开。

Windows 在最终资源读取至派发期间持有只读文件 handle（仅允许 FILE_SHARE_READ），阻止目标文件写入或替换。读取期间关闭确认会使 epoch 失效，阻止尚未派发的打开。最终授权后释放意图锁再调用系统边界，避免窗口主线程等待同锁时死锁；派发开始后关闭不承诺撤销系统操作。

确认还绑定原会话／消息／内容块身份与原引用：prepare、confirm 和引用观察均核对来源，其他消息中的同路径不能延续旧确认。普通文件／图片中明确尾斜线目录只读可复制。关闭等待 DOM 提交后再回焦点；入口失效时返回聊天区或可聚焦的后端状态页，不抢另一前景模态。

## 改动文件

- 新增 `frontend/src-tauri/src/workspace_file_open.rs`；`lib.rs` 注册 prepare/open/discard，绑定 main 窗口；`desktop.rs` 在隐藏、关闭、退出作废意图；后端状态发布时同步清理。
- 新增 `frontend/src/workspace-file-open.ts` 和 `components/WorkspaceFileOpen.tsx`；`App.tsx` 管理单前景确认、引用失效、会话／租约／隐藏清理；`MessageBody.tsx`、`WorkspaceImage.tsx`、`ContentViewer.tsx` 提供受控入口，`styles.css` 延续现有样式。
- 新增打开 Node 七项、正文补三项、Rust 十项和原生八项；现有图片、Markdown 用例参与回归。辅助 runner 和本轮编辑前副本用于不调用 Git 的固定审查。
- 无依赖／lock、Rust capability、Python 产品、数据库 schema 变更；未实施第16票。

## 已核对的基线与定向验证

最终测试由显式 `gpt-6-luna / max` 子 agent 执行；主 agent 已查看原始结果和退出码。

| 范围 | 当前结果 | 原始证据 |
| --- | --- | --- |
| 完整 Node 基线 | 179通过，0失败／取消／跳过；187.553秒，后续修正之前 | [stdout（原始产物已删除）](../../../README.md#已删除的材料) |
| 前端受影响专项 | 行为修正后21通过；最后纯命名及只读文案后的专项15通过，0失败／取消／跳过；两批重叠，不能相加 | [21项（原始产物已删除）](../../../README.md#已删除的材料)、[最新15项（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终 TypeScript／Vite | exit 0；主 chunk 591.51 kB、gzip 180.05 kB，保留 >500 kB 提示 | [tsc退出码（原始产物已删除）](../../../README.md#已删除的材料)、[build stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 完整 Rust 基线 | 34通过、0失败／ignored；含本票当时九项，后续锁修正之前 | [stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终 Rust 专项／check／格式 | 锁修正后10通过、0失败／ignored；check及指定格式exit 0。随后仅测试局部变量改名，no-run编译和格式exit 0，没有再次执行行为测试 | [最终10项（原始产物已删除）](../../../README.md#已删除的材料)、[Rust报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/validation/rust-backend/report.md`） |
| Python 资源 HTTP | 8通过、0失败／跳过；6.412秒 | [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终原生宿主 example | build exit 0；之后Rust产品未变 | [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终 Python 夹具／runner | 两文件Ruff check、format check exit 0 | [check（原始产物已删除）](../../../README.md#已删除的材料)、[format（原始产物已删除）](../../../README.md#已删除的材料) |
| 真实 Tauri／系统程序首批（历史） | 旧dist的11项：9通过、2失败、0跳过；118.564秒，原始结果保留，后续当前构建结果另列 | [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 真实 Tauri第二批连接失败 | 11失败、0通过／跳过，均停在WebView9238连接前；359.947秒，未进入功能断言 | [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 当前桌面环境原生探针 | 1通过、0失败／错误／跳过；11.098秒，exit 0 | [stderr（原始产物已删除）](../../../README.md#已删除的材料)、[退出码（原始产物已删除）](../../../README.md#已删除的材料) |
| 当前构建原生最终批次 | 剩余7项专项＋3项既有回归：10通过、0失败／错误／跳过；76.371秒，exit 0 | [stderr（原始产物已删除）](../../../README.md#已删除的材料)、[退出码（原始产物已删除）](../../../README.md#已删除的材料) |

各批专项与完整套件重叠，不相加为独立覆盖。全量179/34及HTTP8在后续命名／交互／锁修正之前完成；当前受影响Node、Rust、类型、构建与静态检查均有上述最终证据。当前构建的原生探针1项与最终10项互不重复，共11个唯一用例各有最终通过证据；不声称一次11／11全绿。无 Python 产品变动，仅运行受影响 HTTP8，不重复完整后端329。MSVC生成库文件 warning 与 Python asyncio slow-callback 诊断不影响上述通过；不把这些通过等同全部仓库回归全绿。

双轴审查：[Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/standards-review.md`）硬问题0、启发式结构建议1（来源引用与身份未来可封装）；[Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/spec-review.md`）无剩余硬规格缺口。来源身份、焦点恢复和目录只读问题均已修正。循环导入观察留作结构讨论，未扩大本票范围。

## 开发红绿与保留失败

- [Node红灯（原始产物已删除）](../../../README.md#已删除的材料)：模块不存在；首条 prepare/cancel 公开命令用例随后通过；开发专项7通过。
- [Rust红灯（原始产物已删除）](../../../README.md#已删除的材料)：模块不存在。
- [Rust首轮（原始产物已删除）](../../../README.md#已删除的材料)：Windows canonicalize 返回 `\\?\` 路径，默认程序传入路径与已显示普通完整路径断言不符。产品修复为继续原生校验 canonical 目标，向 opener 传已核实的普通完整路径。[第二轮（原始产物已删除）](../../../README.md#已删除的材料)1通过；[最终开发专项（原始产物已删除）](../../../README.md#已删除的材料)9通过。
- 后续原生失败如有，原批次保留，追加修复／针对性复测，不覆盖历史结果。
- Spec复核新增正文身份与目录测试先红灯：7项中5通过、2失败，随后实现来源身份与已知目录只读。
- [原生首批（原始产物已删除）](../../../README.md#已删除的材料)：11项中9通过；身份新用例使用旧dist未关闭确认而失败，无关联用例真OS接受但未捕获chooser证据而失败。已有实际默认程序成功证据是 `report.txt - Notepad` 新窗口，HTTP历史未改变。后续实际只读诊断证实该轮启动OpenWith.exe的隐藏dummy宿主，原夹具的只观测可见窗口假设不适用。修正增加真实AssocQueryStringW“无默认关联”断言、原生新窗口／进程／子文本观测及显式HANDLE关闭，仍要求本轮系统派发证据。记录is_visible，不把隐藏宿主说成选择器可见或文件显示。
- [派发锁红灯（原始产物已删除）](../../../README.md#已删除的材料)：公开边界 callback 被阻塞时 invalidate 也被锁阻塞，0通过/1失败/9过滤；查本地 tauri-runtime-wry `window_getter` 确认实际 callback 可等待主线程，已修正最终授权后不持 ledger 调用OS。
- [只读说明红灯（原始产物已删除）](../../../README.md#已删除的材料)：公开确认组件prepare失败且无intent时缺明确只读文案，8项中7通过、1失败；补文案后最终Node15项全部通过，实际HTTP原因、复制与手动prepare保留。
- [第二原生批次（原始产物已删除）](../../../README.md#已删除的材料)：11失败均为WebView调试连接9238超时，各宿主日志为空，功能路径未执行。用户期间切换到无沙箱环境；新环境测试agent的只读桌面探针与受控启动成功，9238可连接，当前用例全部通过。没有确认旧环境连接失败的具体根因，不将历史失败改算通过。

## 当前原生验收与实际系统证据

工作目录均为 `C:\code\shikigen-agent`，模型均为 `gpt-6-luna / max`。当前桌面环境先执行：

~~~powershell
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-15/native_runner.py --batch environment-probe --tests test_each_click_default_cancel_copy_escape_backdrop_and_focus_never_open
~~~

随后使用 `--batch final-current-environment --tests` 明确选择剩余七个打开专项，再加 `--regression` 的三项图片／Markdown回归；完整命令及模型交接见[原生最终报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/validation/native-current-environment/report.md`）。两批均复用现有5173静态服务，运行器核对当前dist的index与两个直接资源一致；未停止该用户服务。

- [确认截图（原始产物已删除）](../../../README.md#已删除的材料)：沿用白色、Slate、靛蓝的Overlay，真实完整路径可读、复制反馈及取消默认焦点明确。
- [真实默认程序结果（原始产物已删除）](../../../README.md#已删除的材料)：一次open返回true，新测试窗口 `report.txt - Notepad`；相同request_id重复被拒绝，已提交HTTP消息历史不变。仅证明系统接受及测试应用窗口出现，不证明应用已读完内容。
- [实际无默认关联结果（原始产物已删除）](../../../README.md#已删除的材料)：`AssocQueryStringW`返回HRESULT `-2147023741`，默认执行程序为空；一次open返回true，并产生本轮 `OpenWith.exe` PID9960、HWND9374332、标题“选取应用”、类名 `Open With Dummy Window Class For Interim Dialog`。记录 `is_visible=true`，但未据此宣称选择器位于前景或文件已显示。系统接受与打开文件成功仍明确区分；没有绑定未知后缀到默认程序或修改注册表。
- [实际后端失败及来源撤销（原始产物已删除）](../../../README.md#已删除的材料)：原消息来源替换时，同路径另一引用不能延续确认；实际终止本轮自管后端后确认关闭，旧ID失效，焦点落在可聚焦`.backend-screen`。该路径是真实后端失败，不将其表述为后端重启。
- [公开命令边界（原始产物已删除）](../../../README.md#已删除的材料)：越界403、目录422、缺失404、未知路径协议422；旧租约返回`stale_backend_lease`，通用opener仍因未授权拒绝。准备阶段无OS打开。

测试只清理明确属于本轮的临时目录、宿主及系统测试窗口；现有用户服务和旧系统窗口没有被当作测试资源关闭。历史与当前原生批次详见[前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/validation/frontend/report.md`）和[当前环境报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/validation/native-current-environment/report.md`）。

## 六条验收对应（主 agent 已核对）

1. 自管 prepare、身份／完整元数据、准备零打开：Rust prepare／window／lease／metadata专项及原生命令用例。
2. main／租约／300秒／一次性／重验／无任意路径权限：Rust虚拟时钟、并发、作废、文件变更、范围专项；原生permission和真实OS路径。
3. 每次新prepare、文件／图片入口、默认取消、copy／Esc／遮罩／close零打开：当前原生探针及图片详情用例、确认截图。
4. 切会话、隐藏、租约和引用变化，pending与错误／新确认：Node dispose／late result／变化专项，Rust查询期间关闭，原生对应路径。
5. 系统接受语义、无自动再打开／无Run变更、浏览器／未知／目录说明：当前实际默认程序及无关联结果、HTTP事实前后对比、安全Markdown回归及最终Node只读说明。
6. 实际OS成功／无关联、公开命令越界／变更／过期／重复／取消、焦点／单前景：分别记录模拟时钟／OS callback与真实系统打开证据，不能混称为实机覆盖。

## 覆盖边界

- ready→ready 租约失效用例注入公开 Tauri 桥状态帧，不代表真实 BackendManager 重启。
- 五分钟到期由 Rust外部时钟边界验证，不将其表述为原生窗口实际等待五分钟。
- 默认程序及无关联文件均有上述实际系统派发证据；成功只表示系统接受。无关联后出现OpenWith宿主不证明可见选择器或文件内容显示。Rust OS callback拒绝仅证明错误传播，不能代替实际系统打开。
- CDP WebView 输入和确认界面不代表物理键盘、系统IME或全部视口联合验收；这些继续归第23票。
- 历史审批结算超时、空宿主环境退出等待和IME问题的 needs-triage 记录继续保留。
- 本轮未执行任何 Git 命令，未暂存、提交、切分支或推送。
