> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 19 票：有限核实待结算用量

日期：2026-10-06。规格：[实施票据](../../../../../wayfinder/frontend-completion/implementation/19-usage-settlement.md)、[统一 PRD §17](../PRD.md)、[运行详情契约 §5](../../../../../wayfinder/frontend-completion/tickets/005-run-details.contract.md)。

已完成本票实现与七项核心验收。主 agent 已核对轻量测试 agent 的日志、公开请求、实际快照与原生截图，以及 Standards／Spec 复核结果后关闭票据。用户明确要求不操作 Git，本轮所有差异使用实施前文件备份生成；未执行 Git 命令。

## 实现位置与行为

- `frontend/src/usage-verification.ts`：当前目标的一个结算计时器。按后端 startup_id／base_url、会话、Run 和执行阶段保存预算；关闭详情、隐藏、切换与重新观察不删除预算。新执行阶段、新租约及用户“继续核实”允许新轮。
- `frontend/src/run-projection.ts`：`executionStage` 只随同 Run 的 interrupted→running 推进；原 `stage` 继续保护观察代次内字段适用性。重新观察不能凭空增加执行预算。
- `frontend/src/conversation-state.ts`：所有快照触发共用一个 GET 所有者，五秒任务和 1／2／5 秒错误恢复共用读取任务；最多三次重试，遵守 Retry-After。已确认 interrupted／终态 pending=true 才核实，每次完成后等五秒，最多十二次后续自动请求；失败及重试计入，成功仍 true 不重置。
- 正常观察 EOF 当场安排一次快照，与已在读请求合并；取消有效快照立即显示。取消前 GET 已开始则串行补一次确认后读取；没有旧请求时，pending=true 的后续核实等待五秒。首次边界补读不消耗十二次预算，即使它共用第十二次自动 GET 的任务。
- 适用 false 停止后续核实；数字没变化、时间到了、终态或 EOF 不推定结算。旧字段响应不能覆盖新事实；同 updated_at 的有效晚量仍可填入。错误不修改 Run 结果、正文、草稿或审批。
- 有效 false 同时终止自动 GET 的错误等待与重试；已经合并的同阶段 EOF／取消首次补读保留为一次普通快照查询，重新核对租约、会话、Run、执行阶段与可见性后发起。旧阶段的边界请求不移交新阶段。
- `RunDetails.tsx`、`App.tsx`、`useConversations.ts` 与样式：摘要和详情共用“仍在结算，自动核实已暂停”和“继续核实”入口；读取错误保留最后值并提供人工核实，404 使用重新读取会话。保留 Geist／Slate／Indigo、平面分区、400px 抽屉；重要结算提示 14px，窄屏新按钮 44px。
- 命名复核修正新增 `readySessionState`、`advanceClock`、`synchronizeVerification`、`emitVerification`、`onVerificationChange`、`lastVerificationJson` 和 `fetchFromBackend`，说明对象及动作归属。
- 没有修改后端或 Rust 产品、依赖、数据库结构；用量纯读不执行模型、工具或写入结算。

## 开发与验证中的失败记录

1. 首个受控时间测试在实现前为红灯：五秒后没有第二次 GET；添加预算协调后通过。
2. 早期新增用例曾因为初始快照期间 SSE 更新用量组而等待未完成，以及计数未及时发布而失败；夹具先完成初始查询，再验证目标竞态，产品计数发布已修。断言没有放宽。
3. 轻量 agent 唯一完整 Node 回归：224 项，223 通过、1 失败。`run-cancel.test.mjs:88` 挂起取消前 GET，再返回省略用量的旧响应；原本没有安排确认后 GET。产品修复后原断言保留，六文件定向 74／74 通过。完整套件未重跑，历史失败保留。
4. 新“第十二次自动 GET 在读时取消”先红灯，复现预算阻挡首次免费补读；主 agent 修复补读计费归属，新增用例通过证据由测试 agent 提供。
5. 命名调整后六文件回归 76 项中 75 通过、1 `ReferenceError`：测试仍解构 `ready`，引用却改为 `readySessionState`。主 agent 修正夹具标识；没有改断言。
6. Spec 静态审查发现第十二次过时用量组补读被预算拒绝后，`snapshotRead` 滞留 reading，禁用人工继续。第十七个用例先红灯复现 `'reading' !== 'ready'`，再修复预算拒绝时结束读取状态并保留暂停／错误。
7. Spec 审查发现旧阶段的自动请求／重试可能在审批继续后污染新轮，主 agent 改为阶段变化立即 Abort 并撤销其所有者，旧 finally 不结算新轮。新增第十八个用例；第十个用例收紧为旧请求已 Abort 且 running 无额外 GET，而非要求额外读取。
8. 同类手动查询允许继续读取，但旧阶段失败原先仍会写新轮 error。第十九个用例先红灯复现 `'error' !== null`，主 agent 将 completion 和恢复计费归属请求启动阶段；第二十个用例验证旧手动三次恢复不扣新预算，结束后等待五秒再启动新轮。
9. 原生夹具函数改名使两个 JS 原文行触发 Ruff E501，已拆行并格式化。测试 agent 一次临时 Ruff 命令路径错误保留，其后须用准确三路径核对；不将错误批次算通过。
10. 第二十一个用例先红灯：适用 false 清除五秒计时器后，旧自动错误等待仍活跃。主 agent 修复为确认结算时立即 Abort 自动请求，保留明确的手动刷新能力。
11. 第二十二个用例先红灯：EOF 已合并到自动在读 GET，而该 GET 返回 false 时，首次边界补读被一起取消。主 agent 将这一次普通补读保留并在目标仍适用时发起；定向红→绿，轻量 agent 最终六文件 82／82 通过。
12. 原生 `native-final-1` 四项均止于 CDP 连接阶段，2 失败、2 错误，90.785 秒；尚无产品验收证据。该失败批次保留，后续按权限流程在新目录重跑。
13. 两次升权尝试在父回合中断时分别返回 971.3 秒／274.3 秒的 aborted，无 session、退出码或新 artifact，不算执行或通过。主会话随后取得脚本前缀权限，`--help` 退出 0；它只是权限与参数检查，原生产品验证仍交轻量子 agent 执行。
14. 主 agent 核对原生 JSON 时发现夹具采集对象别名：`actualSnapshot` 引用与注入响应同一对象，后续 pending=true 会改写该证据字段。只将采集改为 `structuredClone`，产品与断言未变；先保留当前原生四项行为通过批次，再对两项注入场景重新采集核验，实际取消与事件用例无需重复。
15. `native-final-1-escalated` 四项全部通过，117.573 秒、退出 0。采集修正后 `native-evidence-final-2` 两项均止于 CDP bridge 握手，19.934 秒、2 错误、0 通过；无产品断言或原始快照证据。定位到已有通用握手会接入瞬态页面，改为复用仓库分页验收的稳定 Tauri URL／三次稳定目标／完整加载与 bridge 条件，并保存 page_target；不吞异常或修改产品断言。
16. 上述测试采集改动曾触发混合 LF／CRLF 的 Ruff format 未通过；稳定握手注释曾触发 E501。主 agent 统一格式并缩短注释，子 agent 重新核对三个 Python 文件；原失败日志保留。
17. `native-evidence-final-3` 两项仍止于 endpoint 等待，66.472 秒、2 失败、0 通过。旧测试 agent 创建于受限环境，其 default 启动是否仍沿用原权限未确认。停止旧 agent 的窗口任务后，以当前权限创建新的 `gpt-6-luna / max` agent 执行 `native-evidence-final-4`，两项均通过，91.236 秒、退出 0。不将这次通过改算为旧失败通过，也不把执行环境推断当成已确认根因。

## 验证分工与现有证据

最终执行模型均显式选择 `gpt-6-luna / max`，主 agent 实现与修复，测试 agent 执行 Node／类型／构建／Python 专项／真实 Tauri。Standards 与 Spec 分轴轻量审查，固定点为 [`before/`（临时产物已清理）](../../../README.md#已清理的临时产物)，差异为 [`review.diff`（原始产物已删除）](../../../README.md#已删除的材料)，没有使用 Git。

- [前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-19/validation/frontend/report.md`）：完整回归及逐次定向、tsc、Vite 日志／机器结果。
- [原生与补充检查](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-19/validation/native/report.md`）：后端用量专项 9／9 通过，三个新 Python 文件 Ruff lint／format 通过；原生首次行为批次 4／4 通过及全部历史连接失败保留。
- [最终原生采集复验](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-19/validation/native-final/report.md`）：采集深拷贝与稳定页面握手修正后，两项注入场景 2／2 通过，原始快照与页面注入分开记录。与首次四项重叠，合计仍为四个唯一场景，不累加为六个。
- [Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-19/standards-review.md`）：前次三个硬命名问题和一个建议均已修复，当前无遗留。
- [Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-19/spec-review.md`）：预算拒绝读取状态、旧自动／手动阶段归属、false 终止与 EOF 首次补读竞争均已修复并复核，当前无遗留硬性缺口。

主 agent 已读取实际后端用量九项日志、前端完整／定向日志与构建输出，不仅采纳 agent 简短结论。

最终冻结产品源的六文件专项为 **82 项，82 通过、0 失败、0 跳过**，含 22 项本票新增用例，日志为 `validation/frontend/final82.stdout.log`，命令、模型、时间与退出码见 `final82.result.json`。较早 74／77／78／80 批次覆盖相同用例，不叠加计数；75／76 的失败批次和完整 223／224 批次仍保留。修复后未重复完整 Node 套件。

最终 TypeScript 和 Vite 构建均退出 0，证据为 `validation/frontend/final82-tsc.*` 和 `final82-build.*`；当前主产物 `index-CrN32XvU.js` 为 622.80kB／gzip 189.04kB。

## 最终原生事实核对

- 首次完整行为批次 `native-final-1-escalated --regression` 为 **4／4 通过**，117.573 秒、退出 0；实际取消与事件回归使用该批次最终证据。
- 采集修正后的 `native-evidence-final-4` 为 **2／2 通过**，91.236 秒、退出 0。真实页面目标为 `http://127.0.0.1:5173/`；截图和 JSON 位于 `native/native-evidence-final-4/UsageSettlementAcceptance/`。
- 12 次场景共有 16 次 GET：2 次初始／EOF 查询、12 次后续自动查询、详情的一次普通刷新、一次人工继续；自动部分逐项核对五秒完成后等待。14 条 `isPendingInjected=true` 记录中的原始 `actualSnapshot.usage_pending=false` 保持独立，注入不再反向修改原始快照。最终真实后端为 completed、pending=false、15 输入＋12 输出＝27 Token、2 次模型完成回调。
- 503 场景共有 7 次 GET，含 4 次 503（首次失败＋三次恢复），遵守 1／2／5 秒，最后一次人工 GET 返回真实 27 Token 和 pending=false。
- 真实取消的 POST 为 cancelled／pending=true；后续纯 GET 仍 cancelled／pending=false／0 Token，与 POST 的 updated_at 同为 `2026-10-06T19:29:13.519932+08:00`。详情关闭，摘要仍确认晚量，正文保留。
- 既有事件回归中，完整事件子视图返回仍保留位置 250；随后手动设为 180，EOF 事件补读前后均保持 180。不是从 180 自动跳到 250。
- 两个原生通过批次覆盖四个唯一场景；不将重叠复验相加，也不声称最后一次单批重新执行四项。主 agent 已读取实际 stderr／result.json 并目视暂停摘要、继续后摘要与取消正文截图。

## 验收证据对照

| 条件 | 公开边界证据 |
| --- | --- |
| EOF／取消首次补读、共享读取 | Node 用例 2、13、15、22；保留的 run-cancel 取消前在读 GET 断言；run-events 独立补读回归 |
| 当前目标可见／ready／pending 资格，running 不轮询 | Node 用例 2、5、9、10、14、18；visibility-polling 与 stream-recovery 既有回归 |
| 五秒／十二次／false 停止 | Node 用例 1、3、12、16、17、21、22；原生真实时钟十二次与人工继续 |
| 三次重试／Retry-After／硬错误 | Node 用例 3–8、12；原生公开传输 503 与人工核实 |
| 暂停文案／继续／关闭详情／预算保留 | Node 用例 1、5、9、11、14、17；原生摘要和详情 |
| 旧组／旧阶段／取消晚量／独立事实 | Node 用例 9、10、13、15、16、17、18–20；后端九项用量回归；原生真实取消晚量 |
| 可控查询与实机证据 | 二十二项 Node 用量专项，三个新原生用例和一个已提交事件回归 |

## 证据范围

新原生取消用例使用真实 HTTP／SQLite／Graph 和真实 cancellation／usage_pending，查询载荷未修改；模型取消后的实际已记录用量为零，不伪造非零回调。

持续 pending 与 503 原生用例在公开 fetch 响应边界注入，真实请求、数据库和离线模型累计 27 Token 保留；这证明 UI／请求协调，不声称后端真实持续待结算六十秒或真实数据库忙。五秒与十二次在原生使用真实时钟，Node 精确边界使用可控时间。

截图来自实际 Tauri WebView 的 CDP 捕获。物理 OS 剪贴板、系统 IME、原生边框和四档视口联合验收仍归第 23 票。本票不重复没有改变的完整后端／Rust 回归；前端没有 lint 脚本，TypeScript 与构建检查另行执行。

Vite 主 chunk 超过 500kB 的既有提示保留；最终产物 622.80kB／gzip 189.04kB，较早构建 621.72kB／gzip 188.81kB。
