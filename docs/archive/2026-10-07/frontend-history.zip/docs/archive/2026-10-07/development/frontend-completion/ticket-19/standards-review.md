> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 19 Standards 最终审查

## 范围与固定点

以 `.scratch/frontend-completion/ticket-19/before/` 中的本轮实施前完整源备份为固定点，逐项审查 `.scratch/frontend-completion/ticket-19/review.diff` 中的全部 11 个文件：

- `frontend/src/conversation-state.ts`
- `frontend/src/run-projection.ts`
- `frontend/src/useConversations.ts`
- `frontend/src/App.tsx`
- `frontend/src/components/RunDetails.tsx`
- `frontend/src/styles.css`
- `frontend/src/usage-verification.ts`
- `frontend/tests/usage-settlement.test.mjs`
- `frontend/src-tauri/tests/usage_settlement_acceptance.py`
- `.scratch/frontend-completion/ticket-19/native_runner.py`
- `docs/wayfinder/frontend-completion/implementation/19-usage-settlement.md`

按仓库 `AGENTS.md` 命名规则和 Fowler 异味基线审查；后者仅作为判断建议。未运行 Git、测试或构建。此后索引新增的第 19 票验收摘要及第 20 票入口为纯文档收尾，由主 agent 核对结果、链接与状态；没有改变已审查的产品或测试行为。

## 结果

- **硬违规：0。** 初审指出的三项命名违规已修复：`synchronize`／`publish` 改为 `synchronizeVerification`／`emitVerification`，测试状态实体改为 `readySessionState`，时钟辅助函数改为 `advanceClock`。
- **判断建议：0。** 初审的 Mysterious Name 建议已修复：`lastPublished`／`serialized` 改为 `lastVerificationJson`／`verificationJson`。
- 后续差异复核确认阶段判断名 `isSameExecutionStage`、状态名 `hasSettledUsage`、调用计费判断 `shouldChargeInitial`／`shouldChargeSupplement` 与回调 `onVerificationChange`、`fetchFromBackend` 均符合词性及领域语义约定。
- 已审查 EOF 队列守卫：旧自动读取 owner 被中止并撤销；排队边界读取有会话、可见性、暂停状态、线程／运行身份及执行阶段检查，并复用 `refreshRunDetails()` 的共享读取路径。
- 已审查最终证据夹具：`actualSnapshot` 使用 `structuredClone(envelope.data)` 保留原始后端快照，`isPendingInjected` 单独表示测试注入状态。

## 最终原生采集握手增量

- `UsageEvidence.connect()` 复用现有 [`PaginationAcceptance.connect()`](C:/code/shikigen-agent/frontend/src-tauri/tests/pagination_acceptance.py#L27)：筛选稳定的 `127.0.0.1:5173` 页面目标，连续确认三次目标一致，并等待文档完成及 Tauri 桥接可用。该 override 将验收生命周期的 `connect` 调度到稳定握手；调用本身不吞掉新异常，也未删减产品断言。
- 证据记录增加 `page_target`，明确记录所连接的页面目标；命名符合实体名词约定。

全量差异及所有后续增量审查结论仍为 **0 项硬违规、0 项判断建议**。格式工具覆盖的内容未重复列为问题。
