> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 04 票实现与验证交接

日期：2026-10-05；cwd C:/code/shikigen-agent；Windows PowerShell。

## 任务、来源与固定点

用户 `$implement docs/wayfinder/frontend-completion/implementation/index.md 完成 4`，只推进第 04 票。
票据 `docs/wayfinder/frontend-completion/implementation/04-message-drafts-send.md`；完整规格 `.scratch/frontend-completion/PRD.md` 第 7 节及错误矩阵；契约 `docs/wayfinder/frontend-completion/tickets/002-run-projection.contract.md` 第 9 节和 `006-interaction-acceptance.contract.md` 第 2/3 节；`frontend/design.md`。
必须读 AGENTS.md、CONTEXT.md。禁止 Git 写操作；主 agent 从未执行 stage/commit，当前一些本轮文件已出现在暂存区，原状保留，不推定归属或调整。
本轮开始时 `git status --short` 无输出；固定 HEAD 051a7409c62b2f0581c24968683025ce0f73ae98。未新增提交。
审查基准是 before/ 的本轮开始文件副本；新文件 before 不存在。`change.diff` 由 `capture.py` 对 files.txt 生成，包含 staged/unstaged/new 文件的完整本轮差异，不能只读 git diff。

## 方案与文件

files.txt 列出产品、正式测试和票据文件。
MessageDrafts 是输入持久所有者：固定应用命名空间 shikigen.message-drafts.v1，只保存文字、单调版本、选中会话与提交线索。默认 localStorage，可注入存储；失败保留内存并提示。恢复 pending=>unknown，accepted runId 只作 GET 线索。不保存地址、连接、controller、timer、delta 或 Run 当前状态。
ConversationStore 仍由 App 所有，管理按会话草稿/提交 pending/unknown/accepted。POST 原文；仅本次 POST 新 Run metadata 接受，清 text+version 都对应的草稿。新版本即使正文相同也保留；GET/旧 Run/同文历史不证明接受。
接受前解析/网络/500/EOF/主动关闭保留 unknown，仅 GET；400/409/422 明确拒绝，保留草稿，GET 核实后再手动发；503 保存 Retry-After 限制主动新任务。
接受后 EOF 或断流沿用既有 GET 恢复；重开时历史尚无接受 Run，用 persisted runId GET snapshot，再按当前状态只读恢复。无自动 POST/队列。
unknown UI 完整原文、当前状态、已提交 human 消息选择，显式确认才清对应版本；“作为新任务发送”有同风格对话说明潜在重复，主动创建新 Run，保留请求期间新草稿；按捕获记录 id 和当前资格核对。404 保留文字并可复制/复制到新会话，源不删；创建结果晚到不抢切换。
Composer 原文共享动作；普通 Enter 发送/不可发时 preventDefault，ShiftEnter 正常；isComposing/keyCode229/短暂 compositionEnd guard 优先输入法，repeat 不提交。运行/审批/pending 可编辑。
取消与审批写流程本身属于票据 10/12。本轮底部保留 running“取消运行”（禁用，说明暂不可用）/interrupted“处理审批”（定位目前已有审批提示），普通 Enter 不触发它们；完整可操作取消/审批不算本轮已实现。
CSS、Rust、后端产品均未改；新增 SendRecovery 复用 business-notice/现有按钮/Overlay，本地高度受限滚动。

## 开发检查，非最终证据

TDD 通过公开 HTTP/SSE + Store：首个跨重启测试先失败 activeId，原文/接受测试先失败缺 submissions，500测试先失败丢失原始错误；每片实现后通过。最后定向 Node 18/18。
TypeScript direct tsc 多次 exit0。
新增公开后端测试原文与 surrogate：初次 import 命令缺 tests path；用 discover 修正。httpx json 默认无法编码孤 surrogate，改 ensure_ascii 转义 JSON（与浏览器 JSON.stringify 一致），单用例最终通过、含两个 subtests。
Ruff check 新 native + test_server 通过，format 已整理，最终由子 agent 核实。

## 测试命令与职责

最终所有执行者明确 gpt-6-luna / max / fork none。仅验证、定位、记录，不改产品代码/正式测试，不放宽断言。失败发主 agent 修复，再定向回归，必要时完整回归。
日志、exitcodes、报告放 `.scratch/frontend-completion/ticket-04/`，命令/真实模型/pass/fail/skip/证据/缺口都必须记录。

前端 cwd frontend：

- `node --experimental-strip-types --test tests/*.test.mjs`（最终全套一次，测试有 parent/subtest，记录 Node 计数）。
- root `node frontend/node_modules/typescript/bin/tsc --noEmit -p frontend/tsconfig.json`。
- cwd frontend `pnpm.exe build`。
- root `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/message_drafts_acceptance.py tests/test_server.py`；同文件 `ruff format --check`。
- root `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/message_drafts_acceptance.py`，脚本仅执行本票新增 4 项。复用 backend_window.exe，Rust 无变化。
- 必要回归 root `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/run_reconstruction_acceptance.py` 3 项，仅在同一个 native 验证者串行执行。

后端 cwd root：

- `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_server.py -v`、`-p test_text_safety.py -v`。
- `.venv/Scripts/ty.exe check app packages/harness`。
- 如完整回归 `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v`，预期旧 Windows symlink privilege 可能 skip，不能算通过。

## 环境、权限与实机证据边界

依赖已安装；pnpm.exe 有，pnpm.cmd 没有。venv Python -X utf8；用本地 exe，避免 uv cache 权限阻碍。不启动网络模型，用实际隔离 Agent/临时 SQLite、model/tool boundary 确定性夹具。
原生脚本使用 pywin32 + WebView CDP，实际 Windows Tauri。须先构建 dist，继承现有入口校验 5173 HTML/全部 assets 与 dist 字节一致：既有 5173 服务不归验证者所有，不停它；未监听才可用夹具自管服务。9238/45200 必须空闲，不杀占用进程。
GUI/沙箱 CDP WinError10054 等可能需 require_escalated，直接通过工具 justification 申请；保持业务断言不变，不换浏览器冒充 Tauri。原生串行，后端非原生回归不占这些固定端口；清理自己建立的窗口/后端/server，保留既有服务。
4 native 用例验证原文/单次 Enter/WebView composition、真实窗口关闭再启动草稿恢复、迟到接受保留新文字、真实 POST 已接受但传输层返回500后人工确认、显式作为新任务另一次 POST、running 草稿编辑/Enter拦截/页面刷新零重发。
WebView CDP Input.imeSetComposition + 候选保护验证不等于系统中文候选面板/物理键盘/所有 IME，后者与多尺寸/边框/窄屏/触控等完整联合验收留票据 23，必须据实报告。
检视 actual result.json / screenshots，主 agent 最后核对。不得把未执行、环境阻塞、跳过算通过。
