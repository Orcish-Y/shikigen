> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# interaction-matrix-final-2 验证记录

## 执行信息

- 模型：`gpt-6-luna / max`
- 工作目录：`C:\code\shikigen-agent`
- 执行时间：2026-10-07 01:59:51–02:01:08 UTC
- 命令：

  ```powershell
  .venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch interaction-matrix-final-2 --tests NativePlatformAcceptance.test_1024_native_send_approve_cancel_and_reconnect NativePlatformAcceptance.test_390_native_send_approve_cancel_and_reconnect NativePlatformAcceptance.test_osk_long_draft_tray_notice_and_native_cancel_remain_reachable
  ```

- 结果：3 selected / 3 executed / **1 passed / 2 failed / 0 error / 0 skip**；runner exit 1。
- 运行前后源码哈希一致：`native_platform_acceptance.py`（platform）`b7571f2b31dcc5ef0b25d244557f99d6917de17914785b699110638649f59d55`；`native_runner.py` `4f802c6f4bd38c18190d99c774e134cc3effc03d0be6c804d8322b607e4f756d`。
- Ruff check 与 `ruff format --check` 均 exit 0；精确 `--list` 列出上述 3 项。复用的 `frontend/dist` 38 个文件全部匹配 manifest `fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f`，共 1,049,454 bytes。
- 5173 仅由预存 PID 23344 提供，TabTip PID 14204 保留；运行前 9238/45200 空闲，未发现已有 OSK。

## 单项结果

### 1024×768 四操作：通过

用例完成审批、发送、手动重连和取消四阶段。第一 Run `512e0d40180042998d561fb5b7880717` 的 history 状态为 `completed`；第二 Run `f34750653aa84bfe89b96b08294fadf4` 最终为 `cancelled`，长草稿 420 字符仍在结果中。API 记录含 2 次 stream POST、1 次 approval POST、1 次 cancel POST，第二 Run 的 stream GET 恰为 4。可信原生目标记录包含“处理审批”“批准”“提交决策”“发送”“重新连接”“取消运行”“确认取消”。

证据： [case summary（原始产物已删除）（原始产物已删除）](../../../../../README.md#已删除的材料)。

### OSK 390×600 并存四操作：失败，未到取消

本例真实启动辅助 OSK，保留了 OSK 与 Tauri 并存、托盘提示、长正文及 30 行草稿的截图。审批阶段第一 Run `848b45e5317b469888ad1a0737c984cf` 完成；发送阶段第二 Run `53f73fd8c5c447e49803bf016e74e99a` 启动。可信原生事件记录了审批处理/批准/提交、草稿发送和“重新连接”点击；第二 Run 的 `/stream` GET 恰为 4，API trace 共有 2 次 stream POST 与 1 次 approval POST。

用例最终在等待 body 文本“观察已建立”处超时，因此 runner 标记失败且没有继续取消阶段。失败快照中 body 未包含该文本，但同一快照的完整 DOM `focus` 字段里 `.app-connection` 节点含“后端已就绪 · 观察已建立”；这与窄屏下该提示不进入 body 可见文本相符。故不能把此次失败解释为重连动作未发出，也不能把整项 AC 记为通过：自动化仍未走到取消和终态检查。原失败及两阶段证据保留。

证据： [failure snapshot（原始产物已删除）](../../../../../README.md#已删除的材料)、[审批/发送阶段数据（原始产物已删除）](../../../../../README.md#已删除的材料)、[审批截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[发送截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[并存截图（原始产物已删除）](../../../../../README.md#已删除的材料)。

### 390×844 四操作：失败，批准目标未点击

用例已用原生 composer 发出准备消息并显示等待审批；随后 helper 准备真实鼠标点击“批准”时，`WindowFromPoint` 返回 HWND 65752，与预期 Tauri HWND 8259332 不同。保护断言在点击前终止，因而没有“批准”点击/approval POST，也没有后续阶段。此结果证明本次物理命中前置条件未满足，不能据此判断产品审批按钮本身失效。

用例结束后从默认 DPI 上下文的 PowerShell 做的只读查询发现 HWND 65752 属于 PID 8892 `explorer` 的 `Shell_TrayWnd`；当时返回的 `(0,0)-(127,960)` 是被 DPI 虚拟化的坐标，不能与测试进程屏幕坐标比较，也不能证明点击时的窗口状态。随后通过导入 `window_acceptance.py`（与测试相同的 `SetProcessDPIAware()` 路径）只读复核：system-aware primary monitor 为 `[0,0,2880,1920]`，work area `[190,0,2880,1920]`，任务栏 `[0,0,190,1920]`。原始坐标记录及其限制见 [早期 HWND 查询（原始产物已删除）](../../../../../README.md#已删除的材料)、[早期 monitor 查询（原始产物已删除）](../../../../../README.md#已删除的材料)；一致坐标空间复核见 [DPI-aware monitor 查询（原始产物已删除）](../../../../../README.md#已删除的材料)。这些查询未读窗口标题、激活或关闭窗口。失败本身仍是点击前 ownership guard 阻止批准动作，不能回推为产品按钮缺陷。

## 清理与边界

post-batch 快照确认本批平台/runner 源哈希未变；9238、45200 无监听，无本批剩余 Tauri、backend 或 OSK 进程，也没有新增匹配的临时目录。5173 PID 23344 与 TabTip PID 14204 仍在。完整预检、命令输出及清理记录见 [preflight（原始产物已删除）](../../../../../README.md#已删除的材料)、[invocation（原始产物已删除）](../../../../../README.md#已删除的材料)、[stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../../../README.md#已删除的材料)、[post-batch cleanup（原始产物已删除）](../../../../../README.md#已删除的材料)。未运行付费模型、完整回归或 Git 命令；没有修改产品/测试源码、断言或系统设置。

本批没有完成 OSK 并存场景的取消阶段；390×844 也未越过真实鼠标点击的 HWND 守卫。保留两项失败，不重复运行。该报告只记录验证证据，不关闭 ticket 23。
