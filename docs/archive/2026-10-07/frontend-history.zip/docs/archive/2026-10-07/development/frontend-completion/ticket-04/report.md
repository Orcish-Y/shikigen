> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 04 票：原文发送并保留持久消息草稿

日期：2026-10-05。第 04 票核心验收已完成；**完整后端回归未全绿**，审批恢复结算超时另行追踪。只推进本票，未启动第 05 票。

## 做了什么、为什么、用什么 API

- 原文由 Composer 的按钮和 Enter 共用动作传给 `ConversationStore.send`，`trim` 只判空，最终 `ChatRequest.message` 保留首尾空格、缩进、换行。后端既有 surrogate 替换未改，用公开 HTTP 和持久消息接口确认。
- `MessageDrafts` 在 App 所有者里按会话保存文字和单调版本；固定 localStorage 命名空间，重启能恢复。POST 发出时保存提交原文、版本及前次 Run。只有本次 POST 的新 Run 有效 metadata 接受，才清原文与版本均对应的草稿；改写后又改回同文也算新版本。
- 接受前失败/中止/EOF 保存“发送结果待确认”，仅 GET 核对。重开后旧 pending 按未知处理；已接受 Run ID 仅作查询线索。历史同文和 GET metadata 不作为接受证明。
- 用户可以选择实际已提交 human 消息后人工确认，或者经说明主动“作为新任务发送”。新任务用之前提交的原文，当前新草稿保留，状态/身份/记录 ID/Retry-After 均重新判断。没有自动 POST、排队或自动开始下一次任务。
- 404 保留原会话文字，可复制或复制到新会话再手动发送；Run 快照 404 不误报会话删除。本地保存失败回退内存并提示。
- 普通 Enter 无资格时拦截，Shift+Enter 换行；IME 候选优先，长按不重复。运行/审批/发送 pending 时可编辑。新增核对区域与确认对话复用既有样式，没有修改 CSS、Rust 或后端产品。

修改范围见 [files.txt（原始产物已删除）](../../../README.md#已删除的材料)，差异见 [change.diff（原始产物已删除）](../../../README.md#已删除的材料)，完整交接见 [validation-context.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-04/validation-context.md`）。

## 开发过程

公开 seams 沿用前几票确认的 HTTP/SSE、BackendSession、ConversationStore 和真实 Tauri 页面。主要 TDD 片段：跨重启选择/文字先失败；提交接受信息先失败；POST500 原始错误丢失先失败；Run404 错当会话删除先失败；各片实现后定向通过。

主 agent 只做开发定向检查、direct tsc 和正式用例维护。最终批量验证及两轴独立审查均交给显式 `gpt-6-luna`、`max`、`fork_turns:none` 子 agent。前端原生窗口串行；后端验证使用隔离临时数据库和其他端口。主 agent 核对实际日志、四份原生 result.json 和两张新增 UI 截图后收尾。

## 最终验证

所有命令除表中注明外，工作目录为 `C:/code/shikigen-agent`。完整命令、资源及覆盖说明见[前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-04/frontend-report.md`）与[后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-04/backend-report.md`）。

| 验证 | 实际结果与证据 |
| --- | --- |
| cwd `frontend`：`node --experimental-strip-types --test tests/*.test.mjs` | 69 通过，0 失败／跳过，exit 0；[全套日志（原始产物已删除）](../../../README.md#已删除的材料)。这是最后审查补修之前的全套结果。 |
| cwd `frontend`：`node --experimental-strip-types --test tests/message-drafts.test.mjs tests/conversation-state.test.mjs tests/run-reconstruction.test.mjs` | 最后补修后相关 49 通过，0 失败／跳过，exit 0；[定向日志（原始产物已删除）](../../../README.md#已删除的材料)。没有把这次定向复核称为最新完整全套。 |
| `node frontend/node_modules/typescript/bin/tsc --noEmit -p frontend/tsconfig.json` | 最终 exit 0；[类型检查日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| cwd `frontend`：`pnpm.exe build` | 最终 exit 0；当前 JS 为 `index-BfBYdbL-.js`；[构建日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/message_drafts_acceptance.py tests/test_server.py` | exit 0；[Ruff 日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| `.venv/Scripts/ruff.exe format --check frontend/src-tauri/tests/message_drafts_acceptance.py tests/test_server.py` | exit 0；[格式检查日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/message_drafts_acceptance.py` | 最新构建真实 Tauri 4/4 通过，32.051 秒，exit 0；[日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/run_reconstruction_acceptance.py` | 同构建第 03 票真实 Tauri 回归 3/3 通过，20.642 秒，exit 0；[日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_server.py -v` | 17/17 通过，新增原文／surrogate 用例包含两个子测试；[日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_text_safety.py -v` | 2/2 通过；[日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| `.venv/Scripts/ty.exe check app packages/harness` | exit 0；[日志（原始产物已删除）](../../../README.md#已删除的材料)。 |
| `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` | **291 项中 289 通过、1 环境跳过、1 错误，exit 1**，636.388 秒；[完整日志](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-04/backend-full-suite.log`）。 |

后端唯一错误为 `test_waits_for_previous_cleanup_and_survives_caller_cancellation`：等待结算事件 3 秒超时。正式用例隔离复测两次仍失败；两个 scratch 探针成功不能抵消正式失败。该产品路径和正式用例本票未改，根因尚未确认。独立问题：[审批恢复结算超时](../../../../../issues/approval-resume-settlement-timeout.md)。跳过项明确为 Windows symlink 权限不足，不计作通过。

原生首轮 4 项失败的夹具原因是 `BackendClient` 构造时已绑定 fetch，启动后注入传输包装无法观测实际请求。主 agent 改为在页面创建前通过 `Page.addScriptToEvaluateOnNewDocument` 注入，保留全部业务断言；[首轮失败日志（原始产物已删除）](../../../README.md#已删除的材料)仍保留。最新版四项均通过，实际 POST 和历史正文一致。

实机证据包含：原文首尾空格／缩进／尾换行逐字一致；关闭原生宿主后新进程恢复草稿；本 POST 迟到接受保留新草稿；隐藏已接受响应后的未知记录由用户选择真实消息确认；主动新任务创建另一次 POST 且保留新草稿；运行期间可编辑、普通 Enter 不发任务／不取消，刷新仍保存。见 [native 证据目录（原始产物已删除）](../../../README.md#已删除的材料)、[待确认核对区截图（原始产物已删除）](../../../README.md#已删除的材料)、[主动新任务确认截图（原始产物已删除）](../../../README.md#已删除的材料)。

## Standards

做得好：草稿／提交快照由一个持久模块维护，运行事实继续由 Store 管理；Enter 与输入法规则独立，沿用当前组件风格。

需要修：初次 1 项硬违规（未知状态缺少实时播报）已修为常驻 `role="status" aria-live="polite"`。最终硬违规 **0**。

值得讨论：3 项 heuristic 中，重复草稿投影与 `unknown()` 命名已修；剩余 **1 项**是 CTA 与说明各自判断 `runStatus`。当前行为有覆盖，作为后续简化建议保留。见 [Standards 审查](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-04/standards-review.md`）。

## Spec

存储 API 缺失告警与 Run 快照 404 错误归属已补齐，并由最后 49 项相关测试验证。最终 Spec 违规 **0**，scope creep **0**。见 [Spec 审查](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-04/spec-review.md`）。

## 边界

- 本票底部 running 显示“取消运行”但禁用；interrupted“处理审批”定位当前已有审批提示。完整可操作取消/审批卡片、提交、正文封存分别归第 10/12 票，不声称本轮已实现这些流程。
- WebView 中文 composition 自动化不等于系统中文候选面板/物理键盘。所有系统 IME、窄屏、多尺寸、窗口边框、触控与焦点联合验收仍归第 23 票。
- 未执行 Git 暂存/提交/分支操作；发现已有暂存状态，原状保留。审查使用本轮开始副本，不依赖仅工作树 diff。
- 原生验收已逐字节确认 5173 HTML 与声明的 JS／CSS 对应当前 dist；主产物 SHA-256 见前端报告。5173 PID 23344 创建归属不确定，按约定保留；夹具清理自有 Tauri／后端，最后 9238 和 45200 已释放。
- 只读 `git diff --check` 通过；暂存内容检查排除统一差异证据文件后通过。`change.diff` 的空白上下文行带统一差异格式前缀，原始暂存检查会把它们报告为尾空格；没有为消除此证据格式提示而调整暂存区。
