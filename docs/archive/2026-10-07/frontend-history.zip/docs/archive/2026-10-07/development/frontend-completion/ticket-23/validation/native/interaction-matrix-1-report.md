> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 1440 桌面四操作原型验收

日期：2026-10-07  
模型：gpt-6-luna / max  
工作目录：C:\code\shikigen-agent

## 结果

仅运行指定 1440×900 原生单例一次。结果为 **1 selected / 1 executed / 0 passed / 1 failed / 0 error / 0 skip**，runner exit 1。

命令：

    .venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch interaction-matrix-1 --tests NativePlatformAcceptance.test_1440_native_send_approve_cancel_and_reconnect

静态预检：native_platform_acceptance.py 与 native_runner.py 的 Ruff check 和 ruff format --check 均 exit 0；精确列表为 1 项。frontend/dist 的 38 文件、1,049,454 bytes 与 final-4 manifest 逐项一致，manifest SHA-256 为 fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f。运行前后源码哈希相同：platform 55a696452c261167ca28075ef7f89798b638e554f37a2b97f5b8d13c3f83cab3，runner ae37fa57dea7f351a0caca5587312704b17203b2e17e6a11267c010feb6802b1。

用例到达真实缺托盘图标提示、运行中的长正文和 1440×900 布局；审批请求被读取并显示“审批请求已核实，等待处理”，单项批准选择显示 1/1。真实鼠标路径执行“提交决策”后，等待工具运行状态变为“已完成”超时。failure snapshot 仍显示“等待审批”和“全部动作已选择”，因此审批没有被确认完成。没有保存 approval workflow stage JSON；不能从本批保存的 raw artifact 核实 approval POST 是否发出。当前 artifacts 只有 failure.json、window.png、native-focus.json、空 host-0.log、summary.json 和 cases.json，没有 CDP Network 事件、请求正文或后端审批事件记录。

因此本批没有执行后续长草稿发送、断流重连、最终取消操作断言；四操作验收未通过。原型也没有启动屏幕键盘，所以不验证 OSK 与四操作并存。失败可能与阅读锚点恢复滚动位置后控件物理坐标变化有关，但本批没有捕获实际 DOM 命中目标，不把这个假设当成已证实原因。父 agent 已解锁源码并计划增加滚动稳定、elementFromPoint 目标核实和物理鼠标事件证据。

unittest stdout 报 39.571 秒，cases.json 记 34.484 秒；两种时长都保留。没有重跑此失败，也没有运行模型任务、修改源码、改断言、系统配置、剪贴板或 Git。

## 运行与清理证据

- [预检记录（原始产物已删除）](../../../../../README.md#已删除的材料)、[命令与执行记录（原始产物已删除）](../../../../../README.md#已删除的材料)、[post-cleanup 状态（原始产物已删除）](../../../../../README.md#已删除的材料)、[临时目录时间纠正记录（原始产物已删除）](../../../../../README.md#已删除的材料)
- [stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases（原始产物已删除）](../../../../../README.md#已删除的材料)
- [失败 snapshot（原始产物已删除）](../../../../../README.md#已删除的材料)、[截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[原生焦点记录（原始产物已删除）](../../../../../README.md#已删除的材料)

运行后，本例 Tauri HWND 32181582 和 owner PID 3348 均已退出；没有本例 OSK 或 backend_window/shikigen 进程残留。9238/45200 无监听；预存 5173 PID 23344 与 TabTip PID 14204 保持。UTC 修正后的临时目录检查未发现本批新建/更新的 shikigen native acceptance 目录；早先 post-cleanup JSON 中列出的是旧目录，纠正说明已单独留存，未删除任何目录。

此原型仅记录本次真实 Windows 窗口交互的失败阶段，不关闭票据。
