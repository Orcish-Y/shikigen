> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 05 票 Spec 审查

基点 `994ac75d94f19c8b00dd3f769df7aad9196b251d`；按 `files.txt` 审查完整 tracked/untracked 快照 `change.diff`。只读审查，未运行测试。

## 做得好

有限 GET 预算、1/2/5 秒等待、Retry-After、Abort/租约失效、错误分类和纯快照查询与票据 AC 2–6、契约 §8/§11 一致。已接受 POST 断流转同 Run GET，并以 `mergeMessages` 补持久正文而不覆盖 metadata（`conversation-state.ts`、`run-projection.ts`）；HTTP/SSE 诊断字段保留，列表刷新不重开耗尽轮次。

## 需要修

复核最初发现一项硬缺口，现已修复：有效 SSE 响应在未收到 metadata 时正常 EOF，旧路径把未知身份当“仍运行”并按可恢复 EOF 重试；这超出契约 §7“最后确认状态仍为 running”的范围，也违反票据 AC 5 协议错误停止自动恢复。现 `finishObservation` 将其转成不可恢复 `RunProtocolError`（`conversation-state.ts:569`），并新增空流专项（`stream-recovery.test.mjs:185`）。据主 agent 报告该用例修前失败、修后通过；本审查未重跑。其余重点（POST 未知/已接受故障、metadata 预算、同目标互斥、Retry-After 重入、正常 EOF/投影、纯查询）未发现其他未解决硬缺口。

## 值得讨论

未见产品范围扩张：票据明确“窗口显隐桥接和周期性轮询归第 06 票”，本轮未加桥接、轮询或 Rust。`window_acceptance.py` 改动限于锁屏下的原生退出清理路径，保留实际 tray 菜单身份/可用性断言；属于测试设施调整。原生物理输入与 IME 诊断仍待正式验收，按验证未完成记录，不计产品缺陷。
