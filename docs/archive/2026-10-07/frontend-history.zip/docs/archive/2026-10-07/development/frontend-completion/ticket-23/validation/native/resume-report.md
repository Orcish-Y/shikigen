> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 23 票原生续验收报告

日期：2026-10-07（Asia/Shanghai）  
验证模型：`gpt-6-luna / max`  
工作目录：`C:\code\shikigen-agent`

本报告仅归档本轮实际执行的验证，不代表第 23 票已完成或关闭。原生验收仍有需真实设备／Windows UI 取证的范围。

## 已复用的前端构建

复用 final-4 前端产物；runner 通过共享 HTTP 5173 实际比较 index 与直接引用的两个 bundle，确认与当前 `frontend/dist` 一致。manifest SHA-256 为：

`fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f`

原有 final-4 验证记录显示 TypeScript exit 0、Node 定向测试 20/20 通过、Vite build exit 0。本轮没有重跑这几项；记录见 [前端 final-4 results.json（原始产物已删除）](../../../../../README.md#已删除的材料) 与 [Vite build 记录（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 静态预检

- final-4 修复后，13 个指定 Python 文件 `ruff check` exit 0，`ruff format --check` exit 0（13 files already formatted）。命令、文件清单与日志见 [runner audit report（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 两个 runner 后续命名变更的 Ruff check 与 format 检查均 exit 0；完整原生方法 `--list` exit 0，列出 105 项、未创建窗口，记录同上。
- final-5 前又对同一 13 文件重跑 Ruff，两项均 exit 0；针对 Pagination 与 NativeWorkflow 的三项方法导入及 `--list` 选择检查 exit 0，恰好选中 3 项、未创建窗口。见 [final-5 preflight report（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 原生 final-4

命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch final-4 --classes ChatReadingAcceptance ClientAcceptance PaginationAcceptance NativeWorkflowAcceptance --tests ChatReadingAcceptance.test_switch_hide_host_reentry_and_restart_preserve_reading_intent ChatReadingAcceptance.test_accepted_send_stream_replacement_layout_and_internal_scroll ChatReadingAcceptance.test_only_active_approval_action_locates_and_focuses_timeline_card ClientAcceptance.test_late_real_history_cannot_replace_new_startup_thread ClientAcceptance.test_replayed_pause_cannot_override_current_resumed_run_status PaginationAcceptance.test_real_41_thread_pages_load_only_on_explicit_end_and_preserve_chat NativeWorkflowAcceptance.test_windows_sendinput_original_enter_and_global_modal_focus NativeWorkflowAcceptance.test_real_system_clipboard_receives_complete_message_without_mock
```

Runner 8 项全执行，exit 1；5 项通过、3 个不同用例失败、0 跳过。剪贴板失败用例的 cleanup 又抛出 1 个 error，因此原始 unittest 输出是 3 failures + 1 error，但仍只有 3 个失败用例。逐项结果见 [final-4 summary（原始产物已删除）](../../../../../README.md#已删除的材料) 和 [cases（原始产物已删除）](../../../../../README.md#已删除的材料)。

通过的 5 项：

- `ClientAcceptance.test_late_real_history_cannot_replace_new_startup_thread`
- `ClientAcceptance.test_replayed_pause_cannot_override_current_resumed_run_status`
- `ChatReadingAcceptance.test_switch_hide_host_reentry_and_restart_preserve_reading_intent`
- `ChatReadingAcceptance.test_accepted_send_stream_replacement_layout_and_internal_scroll`
- `ChatReadingAcceptance.test_only_active_approval_action_locates_and_focuses_timeline_card`

final-4 失败项及定位：

- `PaginationAcceptance.test_real_41_thread_pages_load_only_on_explicit_end_and_preserve_chat` 与 `NativeWorkflowAcceptance.test_windows_sendinput_original_enter_and_global_modal_focus` 都在窗口前景激活等待超时。保存的 Win32 诊断显示目标窗口未成为前景；点击坐标命中 HWND `1574800`，其 class 是 `Chrome_RenderWidgetHostHWND`、PID `5464`，根窗口 HWND `1050058` 的 class 是 `Chrome_WidgetWin_1`、PID `5464`。未读取或记录其它窗口标题或内容。元数据见 [focus target metadata（原始产物已删除）](../../../../../README.md#已删除的材料)，每项的 `native-focus.json`、failure JSON 与截图位于对应 case 目录。
- `NativeWorkflowAcceptance.test_real_system_clipboard_receives_complete_message_without_mock` 的界面显示复制按钮已完成，但系统 `CF_UNICODETEXT` 在等待期间未匹配预期完整消息。随后 `OleSetClipboard(original_clipboard)` 清理抛出 `CloseClipboard` 错误。原始 IDataObject 没有留存到磁盘，因此此轮失败后用户剪贴板的原值是否仍在无法确认；未读取或输出剪贴板原文。该失败与清理栈保存在 [final-4 stderr（原始产物已删除）](../../../../../README.md#已删除的材料) 和对应 case 的 `failure.json`。

## 原生 final-5 定向复验

主 agent 修正了窗口输入 fixture 与剪贴板保存／恢复方式。本轮只复验 final-4 的 3 个失败用例，没有重跑已通过用例、生产测试或在线模型任务。

命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch final-5 --classes PaginationAcceptance NativeWorkflowAcceptance --tests PaginationAcceptance.test_real_41_thread_pages_load_only_on_explicit_end_and_preserve_chat NativeWorkflowAcceptance.test_windows_sendinput_original_enter_and_global_modal_focus NativeWorkflowAcceptance.test_real_system_clipboard_receives_complete_message_without_mock
```

3/3 通过，0 failure、0 error、0 skip；用时 31.123 秒，runner exit 0。与 final-4 相同，runner 复用 PID 23344 的 5173 服务，并核实 index（396 bytes）及 2 个资产匹配当前 dist。证据见 [final-5 command（原始产物已删除）](../../../../../README.md#已删除的材料)、[summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases（原始产物已删除）](../../../../../README.md#已删除的材料) 与逐项目录中的截图、结果 JSON 和 `native-focus.json`。

剪贴板用例断言完整持久消息已复制，并在该次用例结束时恢复了 **final-5 开始时读取到的 Unicode 剪贴板值**。由于 final-4 的恢复尝试失败且当时没有持久化原始剪贴板快照，这不能证明用户在 final-4 开始前的值已恢复；该历史值目前无法从已保存证据确认。本轮未读取或输出任何剪贴板原文。

## 生产 exe final-2

命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\production_runner.py --batch final-2
```

当前生产 exe 验收 1/1 通过，运行 23.949 秒，runner exit 0。证据见 [production command（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases.json（原始产物已删除）](../../../../../README.md#已删除的材料) 和 case 目录中的 production host logs 与 `result.json`。该路径核实应用托管后端、动态端口、ready health、同一原生窗口、托盘“打开主窗口”原生 dispatch、第二次启动退出码和没有非 GET 请求。

## 清理与端口

final-5 后检查：9238 与 45200 无监听；共享 5173 仍由用户预置 PID 23344 提供服务，未停止。两项 final-5 原生 host PID（18672、34956）及其当前可见进程树均已退出；生产 final-2 记录的 host 与 Python descendants 也都已退出；没有残留 `shikigen-desktop` 进程。快照见 [final-5 process cleanup（原始产物已删除）](../../../../../README.md#已删除的材料) 与 [生产 cleanup state（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 当前仍需补的验收证据

- final-5 使用 Windows `SendInput` 注入按键；它验证真实 WebView 接收操作，不等同人工实体键盘输入，也不验证实际 IME 候选提交。
- 触控设备能力、实际 Windows 软键盘／TabTip 交互，以及物理触控操作尚无本轮行为证据。
- 真实默认 WebView 下载已通过；默认 Save As 对话框取消流程仍未验证。此前失败的取消探针未重跑，不能据此宣称取消行为通过。
- final-4 期间剪贴板原始 Unicode 值没有快照；final-5 恢复的是它开始时看到的值，不能确认是否与 final-4 前相同。

原生 runner 的逐用例目录保留截图、failure/native-focus 诊断与结果。最终完成状态仍需结合真实 Windows 输入法、触控／软键盘与 Save As 取消行为的后续取证判断。

## Windows 输入能力只读盘点

盘点结果完整保存在 [windows-input-inventory.json（原始产物已删除）](../../../../../README.md#已删除的材料)。只调用 Windows 查询 API、读取 OS 版本注册表、检查指定 TabTip 候选路径／服务状态，并检测 `comtypes` 导入和 PowerShell UIAutomationClient 程序集；没有枚举其它窗口标题或内容，也没有启动软键盘。

- `GetKeyboardLayoutList` 返回 2 个 HKL，语言 ID 为 `0x0804` 与 `0x0409`；当前线程 HKL 为 `0x0804`。这只说明该进程可见的输入布局，不证明存在实体键盘或发生过实体按键输入。
- `SM_DIGITIZER=0xC5`，包含 ready、集成触控、集成笔和 multi-input 标志；`SM_MAXIMUMTOUCHES=10`。这是系统报告的 digitizer 能力，不替代实际触控操作验收。
- 系统登记为 Windows 10 Home 25H2，build `26220.9568`。
- `C:\Program Files\Common Files\Microsoft Shared\Ink\TabTip.exe` 存在；盘点时 TabTip 进程已运行。`TextInputManagementService` 为 Running/Auto；`TabletInputService` 不存在。没有通过 TabTip 发键或点选候选。
- 当前 Python 3.12.13 环境无法导入 `comtypes`；PowerShell 7.6.6 可加载 `UIAutomationClient.dll` 和 `AutomationElement`。

## 默认下载单例验证

新增方法 `NativeSaveCancelExportAcceptance.test_default_download_retains_actual_complete_markdown_without_override` 经主 agent 修正格式后，单文件 Ruff check 与 format check 均 exit 0，`--list` 精确选中 1 项。较早的首次检查曾报 E501 与格式问题，记录见 [首次预检（原始产物已删除）](../../../../../README.md#已删除的材料)；修正后的预检见 [default-download-preflight-2（原始产物已删除）](../../../../../README.md#已删除的材料)。

行为命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch default-download --tests NativeSaveCancelExportAcceptance.test_default_download_retains_actual_complete_markdown_without_override
```

1/1 通过，测试用时 10.396 秒、runner exit 0。该用例通过本例隔离 profile 的真实默认 WebView 下载设置（`prompt_for_download=true`），没有调用 `Browser.setDownloadBehavior`；生成的 UTF-8 Markdown 与完整消息及工具记录核对一致，用户草稿／服务端事实未变。测试在应用退出后断言下载文件仍存在且字节未变。本轮没有显示出需要操作的 Save As 弹窗，也未对弹窗做额外点击。runner 保存的导出记录为 69,777 bytes，SHA-256 `01f89db3aea5faaf7850d8551a89a13829f5f08a122bd4589b0e2d7f864ad8b8`；保留副本见 [observed-default-export.md](../../../../../backend-history.zip)（包内：`docs/archive/2026-10-07/evidence/8da5ba861d2a1cd8-observed-default-export.md`），哈希／清理检查见 [download-state.json（原始产物已删除）](../../../../../README.md#已删除的材料)。测试结束后的单独文件检查看到 fixture 的源路径已不存在；保留副本仍与记录的字节数／哈希相同。用例自身已在宿主退出后断言当时源文件存在且字节未变。

此用例证明默认 WebView 下载可完成，不覆盖另存为弹窗取消。之前的取消探针仍保留，不移除或放宽。

## 后续 OS 输入与下载复验

验证模型仍为 `gpt-6-luna / max`。这些是独立串行批次；没有修改产品代码、测试断言或用户剪贴板，也没有运行在线模型任务。每个行为命令均由 native runner 按本用例隔离 profile 启动真实 Tauri/WebView；5173 复用用户预置 PID 23344，并由 runner 校验共享 dist index 与两个资产。manifest SHA-256 仍为 `fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f`。

### Windows 屏幕键盘

命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch os-input-3 --classes NativePlatformAcceptance --tests NativePlatformAcceptance.test_actual_windows_on_screen_keyboard_with_long_draft
```

1/1 通过，0 failure、0 error、0 skip，runner exit 0。该用例实际启动 Windows On-Screen Keyboard，通过 UIA 识别 `OSKMainClass` / `DirectUIHWND`，并使用经过目标窗口可见性及命中校验的屏幕截图回退；长草稿在 Tauri 窗口中保持可见。它证明 Windows 屏幕键盘路径，不代表 TabTip 操作或实体触控。测试创建的 OSK 已按精确 HWND 清理；保留的证据见 [os-input-3 preflight（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner output（临时产物已清理）](../../../../../README.md#已清理的临时产物)、[summary（原始产物已删除）](../../../../../README.md#已删除的材料) 与 case 截图。

### 系统输入法候选与 Enter 行为

候选 UI 单例命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch os-input-4 --classes NativePlatformAcceptance --tests NativePlatformAcceptance.test_real_system_ime_candidate_enter_commits_draft_without_sending
```

1/1 失败，0 error、0 skip，runner exit 1：真实焦点与拼音草稿到达 Tauri textarea，但候选 UI 等待 10 秒超时。只检查目标 IME 类与 `TextInputHost.exe`；唯一相关 `Windows.UI.Core.CoreWindow` HWND 4522920 属 PID 16344，DWM cloak flags 为 2，因此未当作可见候选，也没有读取其它窗口标题或控件内容。证据见 [os-input-4 preflight（原始产物已删除）](../../../../../README.md#已删除的材料)、[candidate metadata（原始产物已删除）](../../../../../README.md#已删除的材料) 与 [summary（原始产物已删除）](../../../../../README.md#已删除的材料)。当前不能声称已验证候选窗口交互。

独立的 Enter 结束拼音组合用例命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch os-ime-enter-1 --classes NativePlatformAcceptance --tests NativePlatformAcceptance.test_real_system_ime_enter_ends_composition_without_creating_run
```

1/1 失败，0 error、0 skip，runner exit 1。HKL 0x0804 下草稿到达 `nihao`，但浏览器 `compositionend` 事件的 `isTrusted` 为 false，严格信任事件断言失败；该次运行未继续到双 RAF、后端消息为空等后续断言。该结果不构成真实系统 IME Enter 行为通过。HKL 只表示线程输入布局；系统登记了 Microsoft Pinyin TIP，但用例没有从活跃 IME 上下文证明本次组合由该 TIP 处理。证据见 [IME Enter preflight（原始产物已删除）](../../../../../README.md#已删除的材料)、[case result（临时产物已清理）](../../../../../README.md#已清理的临时产物)、[failure snapshot（原始产物已删除）](../../../../../README.md#已删除的材料) 与 [cleanup state（原始产物已删除）](../../../../../README.md#已删除的材料)。

### Windows 注入式触控

第一次使用 pointer id 1 的 `os-touch-1` 在 `InjectTouchInput` 首个注入处收到 WinError 87，1 error、0 fail、0 skip；没有建立 touch contact。主 agent 按 Windows 样例改用 pointer id 0 后，独立运行：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch os-touch-2 --classes NativeTouchAcceptance --tests NativeTouchAcceptance.test_os_touch_menu_switch_close_and_long_content_scroll
```

`os-touch-2` 1/1 通过，0 failure、0 error、0 skip，runner exit 0；移动菜单打开、切换、关闭与长时间线滚动断言通过，草稿保留。DOM 记录 4 个 trusted pointerdown、3 个 trusted pointerup、4 个 touchstart 与 4 个 touchend；结果满足用例的 trusted pointerup 断言，但事件计数不表示每个手势都产生一个 DOM pointerup。注入由 `InjectTouchInput` 完成，属于 OS 级合成触控，不是实体手指／真实触摸屏操作。证据见 [os-touch-2 preflight（原始产物已删除）](../../../../../README.md#已删除的材料)、[command and source hashes（原始产物已删除）](../../../../../README.md#已删除的材料)、[case result（原始产物已删除）](../../../../../README.md#已删除的材料)、[summary](../../../../../native-acceptance-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/native/default-download-7-final/summary.json`） 与 [screenshot（原始产物已删除）](../../../../../README.md#已删除的材料)。

### 默认下载退出后持久性

更严格的默认下载用例先后在 `default-download-2`、`default-download-3` 失败：下载前内容校验通过，退出与 `stop_hosts()` 后源文件不存在。`default-download-3` 增加了只读 owned-window UIA／WebView History 取证；其 `EmbeddedBrowserDownloadView` bounds 是 Infinity，未发现可见原生 Save As 窗口或可操作取消控件。

为排除 Windows 路径预算影响，主 agent 只把 `default-download-4` 的隔离下载目录缩短到每个方法固定短名，未改断言、下载 preference 或 Browser 下载行为。四个关联 Python 文件的 Ruff check 和 format check 均 exit 0；`--list` 精确选择 1 项，记录见 [default-download-4 preflight（原始产物已删除）](../../../../../README.md#已删除的材料)。

命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch default-download-4 --tests NativeSaveCancelExportAcceptance.test_default_download_retains_actual_complete_markdown_without_override
```

1/1 失败，0 error、0 skip，runner exit 1；失败点是退出及 `stop_hosts()` 后的 `actual_download.is_file()`，原因 `default download disappeared after exit`。源路径从此前约 243 个字符缩短至 184 字符（200 UTF-8 bytes）；完整 basename `验证完整工具记录-2026-10-06T19-36-27-848Z.md` 与测试标题和时间戳格式匹配，共 36 字符（52 UTF-8 bytes），因此短目录排除了此前怀疑的文件名截断，但没有解决文件退出后消失。源目录在退出后为空，WebView History 数据库存在但 `downloads` 记录为 0。

退出前观察并归档的完整 Markdown 为 69,777 bytes，SHA-256 `6563f2bfdd43154fc1a71b8ed7f8e9b3d5f7e3d2e8f05f4ba77fc19fd9503fdb`；保存副本与下载观察记录完全一致。此哈希只用于核对本次 fixture 的副本，没有读取或输出 Markdown 正文。UIA 枚举 3 个本例 owned 窗口、20 个控件，`EmbeddedBrowserDownloadView` 仍为 Infinity bounds，没有原生 Save As 对话框；未额外点击任何猜测的取消控件。证据见 [command and source hashes（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner output（原始产物已删除）](../../../../../README.md#已删除的材料)、[summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[post-exit source check（原始产物已删除）](../../../../../README.md#已删除的材料)、[owned-window summary（原始产物已删除）](../../../../../README.md#已删除的材料) 与 [cleanup state（原始产物已删除）](../../../../../README.md#已删除的材料)。

### 清理与尚未覆盖范围

各新批次后，9238 与 45200 无监听；共享 5173 仍由 PID 23344 提供且未停止。已创建的 Tauri host PID 35208 退出；测试后没有自 03:36 起新启动的 Python／Shikigen 进程（[process snapshot（原始产物已删除）](../../../../../README.md#已删除的材料)）。TabTip PID 14204 是预先运行实例，保留未操作；没有可见 OSK 残留。`os-ime-enter-1` 后清理快照见 [IME cleanup（原始产物已删除）](../../../../../README.md#已删除的材料)，`default-download-4` 后快照见 [download cleanup（原始产物已删除）](../../../../../README.md#已删除的材料)。

仍未完成的原生验收包括：实体物理键盘与候选 UI 的真实交互、TabTip 路径、实体手指触控、默认下载 UI 的人工选择／取消行为。当前证据确认默认 WebView 已触发实际下载且内容完整，但短路径复验仍证明退出后的源下载文件丢失；也没有发现可以真实操作并取消的系统 Save As UI。物理设备和默认下载／取消验收仍未闭合，不能关闭第 23 票。

## 系统输入法 Enter 终态复验（os-ime-enter-2）

主 agent 调整了测试对 Chromium `compositionend.isTrusted` 的平台假设，并保留 `os-ime-enter-1` 原失败证据。本轮没有修改测试或产品代码；四个关联 Python 文件 Ruff check 与 format check 均 exit 0，`--list` 精确选中 1 项。预检、源文件 SHA-256 见 [os-ime-enter-2 preflight（原始产物已删除）](../../../../../README.md#已删除的材料)。

命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch os-ime-enter-2 --tests NativePlatformAcceptance.test_real_system_ime_enter_ends_composition_without_creating_run
```

1/1 通过，0 failure、0 error、0 skip，runner exit 0。runner wall elapsed 为 14.825 秒，unittest stdout 报告 11.066 秒，逐用例 `cases.json` 记录 6.875 秒；这三个原始 timing 值均保留。共享 dist manifest SHA-256 为 `fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f`，runner 显示复用 PID 23344 提供的 5173、index 396 bytes 与 2 个 asset。

`ime-completion-trace.json` 留存 14 个真实 WebView 输入事件及 Browser.getVersion（`Edg/155.0.4283.39`）：`compositionstart.isTrusted=true`；Windows Enter 经 `SendInput` 到达 trusted keydown（末个 key 为 `Process`）；真实浏览器 compositionend 的原始 `isTrusted=false` 被保留；JavaScript `dispatchEvent` 观察列表为空。compositionend.data 与草稿均为 `nihao`，严格拼音归一化断言通过；双 RAF 后后端 messages 为空、打开的 dialog 数为 0。用例没有伪造 composition 事件，也没有覆盖 `isTrusted`。截图 [ime-enter-native.png（原始产物已删除）](../../../../../README.md#已删除的材料) 已检查，显示草稿仍未发送；全窗口图与原始 trace 同在该 case 目录。逐项结论见 [case result（原始产物已删除）](../../../../../README.md#已删除的材料)、[summary（原始产物已删除）](../../../../../README.md#已删除的材料) 及 [IME completion summary（原始产物已删除）](../../../../../README.md#已删除的材料)。

本项证明了安装的 Windows IME composition 与 OS 键注入 Enter 的此条路径，不证明候选 UI 可见／已交互；候选窗口仍以 `os-input-4` 的 timeout 证据为准。它也不是人工实体键盘操作。清理后 9238 与 45200 无监听，5173 PID 23344 保留，TabTip PID 14204 保留且未操作，没有可见 OSK 或新启动的 Python／Shikigen 进程；只读取了 foreground HWND 的 class/PID（未读标题），快照见 [post-cleanup state（原始产物已删除）](../../../../../README.md#已删除的材料)。

### 默认 WebView 下载进度终态（default-download-5）

该单例新增只读 CDP observer，只订阅 `Page.enable`、`Page.downloadWillBegin` 与 `Page.downloadProgress`；没有设置 Browser/Page 下载策略、取消或额外点击。代码四文件预检的第一次 format 检查发现新 observer 未格式化；主 agent 格式化后第二次 Ruff check/format 与 exact `--list` 均 exit 0。随后 `native_platform_acceptance.py` 又因主 agent新增 OSK/中文输入用例而发生哈希变化；hash guard 在启动前安全中止，未创建窗口。第三次预检对稳定版本 exact 选中 1 项、format exit 0、`--list` exit 0；Ruff check 另有 1 个 E501，位于新 `os-ime-space` 用例说明行，而非下载 fixture。三次原始日志与 hash 分别保存在 [preflight 1（原始产物已删除）](../../../../../README.md#已删除的材料)、[preflight 2（原始产物已删除）](../../../../../README.md#已删除的材料)、[preflight 3（原始产物已删除）](../../../../../README.md#已删除的材料)；无行为运行的 source drift 记录见 [prelaunch guard（原始产物已删除）](../../../../../README.md#已删除的材料)。

实际唯一用例命令：

```powershell
.venv\Scripts\python.exe .scratch\frontend-completion\ticket-23\native_runner.py --batch default-download-5 --tests NativeSaveCancelExportAcceptance.test_default_download_retains_actual_complete_markdown_without_override
```

用例 1/1 失败，0 error、0 skip，runner exit 1。内容完整性校验先通过；随后等待 30 秒，没有收到终态 `completed` 或 `canceled`。CDP 原始事件共 6 条：1 条 `Page.downloadWillBegin` 给出完整 suggested filename `验证完整工具记录-2026-10-06T19-48-23-757Z.md`；5 条 `Page.downloadProgress` 全部为 `inProgress`，最后 `receivedBytes=totalBytes=69,777`。也就是说字节数达到总量，但当前 Wry/WebView 路径在 observer 等待范围内没有报告终态。超时后隔离下载目录为空；完整内容的只读归档副本为 69,777 bytes，SHA-256 `1B232288537BCC2C8DE3CBEB5DE1826C0251E49C9389137CD984D3597081D46A`。截图显示应用中导出提示已触发，没有出现 Save As 弹窗；未声称存在可取消 UI。

证据见 [run command and source hashes（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner output（原始产物已删除）](../../../../../README.md#已删除的材料)、[observer summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[raw download events（原始产物已删除）](../../../../../README.md#已删除的材料)、[screenshot（原始产物已删除）](../../../../../README.md#已删除的材料) 与 [cleanup state（原始产物已删除）](../../../../../README.md#已删除的材料)。owned host PID 37420 已退出；9238、45200 无监听，5173 PID 23344 保留，TabTip PID 14204 保留，没有可见 OSK 或自 03:48 起新启动的 Python／Shikigen 进程。

本结果定位到“收齐传输字节但 30 秒内没有 WebView 下载终态，且 host 结束后目标目录无文件”，没有将其描述为用户取消或已保存。Wry 的默认 handler 是否因此吞掉下载终态/保存 UI，仍需结合本地依赖代码与票据 AC 判断；此行为证据本身未修改产品。
