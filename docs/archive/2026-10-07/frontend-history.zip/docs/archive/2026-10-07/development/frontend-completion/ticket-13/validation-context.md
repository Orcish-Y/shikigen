> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 13 票验证交接

## 目标、约束与固定点

- 目标：完成 docs/wayfinder/frontend-completion/implementation/13-approval-draft-recovery.md 全部 7 条条件。阅读 AGENTS.md、.scratch/frontend-completion/PRD.md §8、docs/wayfinder/frontend-completion/tickets/003-approval-cancel.contract.md §5–6、frontend/design.md。
- 实際模型必须 gpt-6-luna，max。主 agent 实现与修复，子 agent 执行、诊断、报告。禁止修改产品、删除／弱化断言、忽略诊断；缺覆盖明确报主 agent。
- 用户明确禁止操作 Git：不 add/commit/stash/reset/checkout，不改索引。只读 diff/status 允许。开始工作区干净；固定点 29c3493a427e3132b76faee55dd47599dbec0c35，审查未提交 git diff + 所列未跟踪文件。

## 实现方案与改动文件

- frontend/src/approval-drafts.ts（新增）：应用命名空间 localStorage schema1 保存完整请求身份、Run、checkpoint、Interrupt namespace/value 与 choices、version。捕获 submission UUID、原 responses、draftVersion、pending/unknown/accepted、错误与 retryAt。重开 pending 转 unknown；读取资格／连接／租约不持久恢复；存储失败留内存并警示。
- frontend/src/approval-decisions.ts：草稿 version；完整 canonical identity 沿用完整 payload，对象键等价、数组顺序有意义。
- frontend/src/conversation-state.ts：应用级 ApprovalDrafts（不随 Workspace）。当前请求先只读，全量 GET 正常结束并匹配才开放。pending 与已接受分别持久保护，写响应按请求 controller/lease/selection 过滤；只清匹配 resolved/invalidated 或所属 Run 终态记录；未知结果与旧捕获内容保留，GET/Retry-After/互斥沿用有限协调。取消快照不授予审批恢复资格。
- frontend/src/useConversations.ts、App.tsx、新组件 frontend/src/components/ApprovalRecovery.tsx：孤立/未知输入只读核对和复制，不产生历史；细分409/422/503与未知结果反馈，样式沿用 business-notice/ContentBlock。
- frontend/tests/approval-draft-recovery.test.mjs（新增）：目前9个公开Store+BackendClient测试，含重启、指纹、新checkpoint选择、匹配清理、404、存储失败、未知500/网络/解析、422细节、重提409、已接收锁定、跨重启RetryAfter。
- frontend/src-tauri/tests/approval_draft_recovery_acceptance.py（新增3项）：实际WebView/独立SQLite/真实Graph，正常进程退出重开、GET完成前只读；发送前传输层阻塞保留旧pending并重开手动同Run提交；历史404只读完整输入与恢复。用Page新文档fetch边界制造故障，真实工具批准后才执行。
- .scratch/frontend-completion/ticket-13/native_runner.py：只选上述3项＋第12票4项，串行7个唯一用例；复用现有runner的逐字节dist验证和自有进程清理。必须设置所有被执行类artifact_root到本票。禁止覆盖旧票日志。
- 无后端产品/Rust/依赖/API契约变化。POST仍{responses}，不添加checkpoint条件或声称幂等。

## 已做快速检查（开发证据）

新增第一条红灯缺恢复原因，补持久化后绿灯。第二条红灯缺pending恢复，补捕获提交后绿灯。新增9项通过；旧审批12＋取消7等定向重叠检查通过。TypeScript最终开发检查 exit0。新Python Ruff check/format通过。未跑最终全套/构建/新原生，由验证子 agent完成。

## 命令与工作目录

Windows/PowerShell，cwd C:/code/shikigen-agent。Python .venv/Scripts/python.exe（依赖已安装）；Node frontend/node_modules已装，无需下载；已有frontend/src-tauri/target/debug/examples/backend_window.exe，本票无Rust更改。

frontend cwd:

1. node --import tsx --test tests/approval-draft-recovery.test.mjs tests/approval-decisions.test.mjs tests/run-cancel.test.mjs tests/message-drafts.test.mjs tests/visibility-polling.test.mjs（文件名先rg核对）。
2. 最终完整一次 node --import tsx --test tests/*.mjs，保留所有结果。
3. node node_modules/typescript/bin/tsc --noEmit
4. node node_modules/vite/bin/vite.js build

root cwd:

5. .venv/Scripts/ruff.exe check frontend/src-tauri/tests/approval_draft_recovery_acceptance.py .scratch/frontend-completion/ticket-13/native_runner.py；同范围 format --check。只报告，主 agent修复。
6. .venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-13/native_runner.py（构建完成后，原生7项串行）。
7. 可选相关HTTP回归 .venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_frontend_approval_flow.py -v（原生结束后，不并行占端口）。无需重复无产品变更的10分钟完整后端回归；所有前端完整回归和相关真实原生均必须执行。

## 环境、隔离与报告

- 危险全访问，approval never，不传sandbox_permissions。Native需要Console交互会话。5173可能已存在他人的python静态服务，只有index＋所有assets逐字节吻合当前dist才复用，禁止杀未知进程。9238/45200需空闲，runner仅清自己启动的宿主/服务。构建与native不能并行；原生与其他宿主/后端回归不能并行。
- 别执行class unittest discovery，继承会重复父类测试；runner列明确方法。不要将测试Bootstrap失败计为通过。旧票件3秒审批结算timeout、IME偶发和空宿主exit timeout保留needs-triage。旧Graph TypedDictLike兼容2diagnostics不在本次代码改动中，不改为通过。
- 分开记录专项与完整的重叠范围，不相加。日志/meta记录实际命令、cwd、起止、exit、通过失败错误跳过数量。新截图写本票；若任何结果失败保留初轮，然后主 agent修复，按需定向回归，不重跑已经通过的完整套件。
- report写 .scratch/frontend-completion/ticket-13/validation-report.md，明确实际模型gpt-6-luna/max、范围、命令、证据、失败复现、缺口。物理输入/系统IME、多视口联合验收属第23票。对测试夹具问题先定位给主 agent，不能暗自改产品或放宽断言。

## 风险重点

- GET/旧POST不能确认本次提交；内容与版本完整捕获，后续改草稿不改旧responses。隐藏/切换/lease失效仅停请求，unknown保留，不撤回决策。
- 再提交先全量正常GET，无法断言旧请求不再迟到；可能409，重建实际facts，不自动POST。
- 批准不带原因；拒绝原文保留；从不默认批准。新请求不复用oldchoice、oldresponse不能清newdraft。
- 404/GET解析失败只读保留完整choices可复制。取消核实快照可以恢复取消资格，但不能替代全量GET审批资格。
- accepted跨重启仍锁旧选择，直到真实处理／失效或terminal匹配清理。localStorage不存serverfacts/动态端口/lease。
# 最终验证补充记录（2026-10-06）

下文保留最初交接。后续通过测试子 agent 消息交接的最终变化如下：

- 恢复公开测试最终为 13 项；审查后收紧清理条件，只有完整匹配 required 身份的真实处理记录才删除备份，缺 required 保留只读。快照 404 撤销操作资格但保留输入；补充快照 500 仍沿用既有全量 GET 资格规则。
- 409 文案最终为“审批已变化，请核实同一运行；以当前请求和实际处理记录为准。”构建已在该文案修改后重新完成。
- 原生故障注入必须先 `Page.enable`，再安装新文档 fetch 脚本；重开夹具必须配置 SQLite checkpoint，父夹具默认内存不能支持进程重启后核实。审批历史核对使用已开放的 GET stream，尚未开放的 events 接口不参与本票。
- 保存失败、旧提交捕获内容与版本、503 Retry-After 跨重启、接受后锁定、旧 POST 迟到，以及缺 required 不清理已交给最终 91 项受影响专项；最初完整 164 项结果保留版本范围，不声称新增用例后再次跑了全套。
- 原生最终通过证据分布于首轮旧四项、SQLite 重试的 pending 一项、最终重试两项。全部七个唯一用例都有最终通过证据，历史失败批次不改算通过。
- 最终静态范围为原生验收文件和五个 runner，共六个 Python 文件。预置 5173 服务不得停止，独立只读 HTTP 核对覆盖当前 dist 全部 38 个文件。

原始命令、范围、失败定位和产物见 [validation-report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-13/validation-report.md`）；实现与验收对应见 [report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-13/report.md`）。产品及测试最终冻结后未追加重复验证，未执行 Git 写操作。
