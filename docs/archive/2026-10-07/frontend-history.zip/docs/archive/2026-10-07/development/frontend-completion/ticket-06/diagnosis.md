> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 两处实施中发现的问题

## 排队重载尚未立即撤销旧核实状态

反馈环：`node --experimental-strip-types --test --test-name-pattern 'history cannot reuse an already committed lifecycle sequence' frontend/tests/run-reconstruction.test.mjs`，cwd 根目录。

最终轻量验证首全套 104 项：103 通过／1 失败／0 跳过，见 `node-tests.log`。主按上述单 pattern 再次稳定 red：error 为 null，不匹配“协议问题”。测试在 reload 调用后等 history 非 loading，原来的同步 loading 契约被新增合并微任务遗漏，导致过早返回。其余两假设“迟到旧流覆盖”“错误被清掉”不符合失败发生在微任务执行前的顺序。

修复：`enter()` 排队前即标记当前 history loading／verified false。原正式测试未改断言；主同命令 green 1/1，轻量验证随后完整 104/104，见 `node-tests-final.log`。相同修复还阻止切回旧已读会话时短暂沿用旧发送资格。

## 慢摘要历史探针被新摘要超越

规格审查发现：R1 当前观察、R2 摘要启动慢 GET、下一轮已见 R3，旧 R2 GET 仍可能通过 previousRun 判断。原验收“旧摘要不抢新目标”需要将探针绑定最新摘要身份。

公开回归：`node --experimental-strip-types --test --test-name-pattern 'newer polled run' frontend/tests/visibility-polling.test.mjs`，cwd 根目录。测试先写，主执行 red：读取次数 2 != 3（新身份还在等旧探针），0 通过／1 失败。

修复：保存当前 summaryTarget，身份变化撤销旧 GET，立即核实最新摘要；接收前再次比对捕获的 target。切换／隐藏／租约失效清空探针与身份，已读事实仍保留。主同命令 green 1/1；测试断言旧请求 Abort、只观察 R1／R3，迟到 R2 不切换。轻量测试和 Spec 复核正在检查最终版本。

诊断未修改内部逻辑来取证、未增加产品测试钩子、未改既有测试断言，无 DEBUG 日志需清理。

## 显示终态后沿用旧暂停文案

主目视实际 native 截图发现：后台任务隐藏时完成，显示后的历史／快照和草稿均已恢复，观察文案仍是上次隐藏时的 paused。已有原生业务断言通过不能代替状态文案检查。

先新增公开回归 `node --experimental-strip-types --test --test-name-pattern 'completed while hidden' frontend/tests/visibility-polling.test.mjs`，主执行 red：paused != closed，0/1。修复终态恢复分支在快照读取前 idle、清旧重试信息，核实成功后 closed；同 pattern green 1/1。正式原生用例追加等待观察正常结束并断言无旧暂停文案。轻量 agent 对最终代码重做受影响的 Node／类型／构建与本票原生场景；不重复不受影响的 Rust／后端全套。
