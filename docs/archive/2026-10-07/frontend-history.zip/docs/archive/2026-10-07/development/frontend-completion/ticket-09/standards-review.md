> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

基点 `eceb020`；AGENTS/CONTEXT/design。
- **优点**：分层（design §5）；#5 `sameFact`键序/数组、#6记锚、#7 `readingHistoryReady` type-only门；#8 layout排除scrollTop；#9 `movedBeyondLayoutClamp`要求已有手势且排除夹紧。hook先采迟到移动再reconcile；controls缩高保手势，scroll只update，apply差异写scrollTop保Home。原生测试选中可见末尾pre并断言内滚、following不变；fixture尾90行代码/唯一ID。
- **需修**：首轮 Ruff format 失败经root仅排版修复；freeze/late-scroll复验均exit 0。
- **讨论（12项smell）**：逐项无证据。
通过。
