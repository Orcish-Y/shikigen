> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 3 票后端验证报告

## 执行信息

- 实际模型：gpt-6-luna，max。
- 工作目录：`C:\code\shikigen-agent`；Python 使用现有 `.venv`，命令加 `-X utf8`。
- 范围：后端定向测试、生产代码类型检查、完整 Python 回归，以及两个临时 HTTP/SSE 边界场景。全部测试使用测试夹具的临时数据库；HTTP 探针走 `httpx.ASGITransport`，未占用 5173、9238、45200，也未访问模型供应商。
- 本票变更清单没有后端 Python 文件；因此未运行面向改动 Python 文件的 Ruff 检查。`files.txt` 记录的票内产品变更均为前端代码和文档。

## 定向后端专项

六条命令均在仓库根目录执行，退出码均为 0；共 60 passed、0 failed、0 skipped。

| 命令（cwd 均为仓库根目录） | 结果 | 原始输出 | 退出码 |
| --- | ---: | --- | --- |
| `& '.\.venv\Scripts\python.exe' -X utf8 -m unittest discover -s tests -p 'test_run_observation.py' -v` | 9 passed | [backend-test_run_observation.log（原始产物已删除）](../../../README.md#已删除的材料) | [backend-test_run_observation.exitcode（原始产物已删除）](../../../README.md#已删除的材料) |
| `& '.\.venv\Scripts\python.exe' -X utf8 -m unittest discover -s tests -p 'test_recovery.py' -v` | 11 passed | [backend-test_recovery.log（原始产物已删除）](../../../README.md#已删除的材料) | [backend-test_recovery.exitcode（原始产物已删除）](../../../README.md#已删除的材料) |
| `& '.\.venv\Scripts\python.exe' -X utf8 -m unittest discover -s tests -p 'test_approval_resume.py' -v` | 11 passed | [backend-test_approval_resume.log（原始产物已删除）](../../../README.md#已删除的材料) | [backend-test_approval_resume.exitcode（原始产物已删除）](../../../README.md#已删除的材料) |
| `& '.\.venv\Scripts\python.exe' -X utf8 -m unittest discover -s tests -p 'test_server.py' -v` | 16 passed | [backend-test_server.log（原始产物已删除）](../../../README.md#已删除的材料) | [backend-test_server.exitcode（原始产物已删除）](../../../README.md#已删除的材料) |
| `& '.\.venv\Scripts\python.exe' -X utf8 -m unittest discover -s tests -p 'test_message_contract.py' -v` | 7 passed | [backend-test_message_contract.log（原始产物已删除）](../../../README.md#已删除的材料) | [backend-test_message_contract.exitcode（原始产物已删除）](../../../README.md#已删除的材料) |
| `& '.\.venv\Scripts\python.exe' -X utf8 -m unittest discover -s tests -p 'test_run_events.py' -v` | 6 passed | [backend-test_run_events.log（原始产物已删除）](../../../README.md#已删除的材料) | [backend-test_run_events.exitcode（原始产物已删除）](../../../README.md#已删除的材料) |

## 生产类型检查与完整回归

- 类型检查：`.\.venv\Scripts\ty.exe check app packages/harness`，退出码 0，输出 `All checks passed!`。日志：[backend-ty.log（原始产物已删除）](../../../README.md#已删除的材料)，退出码文件：[backend-ty.exitcode（原始产物已删除）](../../../README.md#已删除的材料)。
- 完整回归：`.\.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -v`，一次运行，退出码 0；`Ran 290 tests in 318.939s`，289 passed、1 skipped、0 failed。日志：[backend-unittest-full.log（原始产物已删除）](../../../README.md#已删除的材料)，退出码文件：[backend-unittest-full.exitcode（原始产物已删除）](../../../README.md#已删除的材料)。
- 唯一跳过项是 `test_runtime_data.RuntimeDataTests.test_symlink_data_and_parent_are_rejected`，原因明确为 Windows symlink privilege unavailable；该项不计为通过。

## GET 重建与恢复语义探针

我另外运行了验证专用脚本 [backend_get_reconstruction_probe.py（原始产物已删除）](../../../README.md#已删除的材料)，不是正式测试文件。脚本通过 `ApprovalResumeTests` 的确定性 Agent、隔离临时数据库与公开 HTTP/SSE GET 路由；命令为：

```powershell
.\.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-03\backend_get_reconstruction_probe.py
```

日志：[backend-get-reconstruction-probe.log（原始产物已删除）](../../../README.md#已删除的材料)，退出码：[backend-get-reconstruction-probe.exitcode（原始产物已删除）](../../../README.md#已删除的材料)，退出码 0。两个场景均通过：

1. 对真实 interrupted Run 连续 GET 两次：两次状态码均为 200、完整响应字节相同，首帧 metadata 为 `interrupted`，回放包含 approval required，响应正常以 EOF 结束且没有 error 帧；期间没有工具调用。探针同时将 `start_run` 与 `resume_run` 替换为失败断言，证明 GET 没有启动或继续执行。
2. 保留 Run 的审批事件与 checkpoint 坐标，但让 checkpoint 读取返回无任务、无 Interrupt 的状态：公开 GET 的重建先校验 checkpoint，再将状态确认为 `error`、`error_code=approval_state_corrupt`；没有调用工具，也没有启动或恢复 Run。

## 覆盖证据与剩余缺口

- **重复历史**：`test_server.test_get_existing_stream_rebuilds_and_rejects_cursors` 对完成态 GET 两次并断言响应相同、禁止调用 `start_run`；上面的探针再验证 interrupted GET 的重复回放一致。
- **同一 Run 继续执行**：`test_approval_resume.test_two_pauses_concurrent_response_and_exact_resume` 断言恢复返回原 `run_id`、使用精确 checkpoint、并发重复提交只有一次 Graph 调用及实际工具执行；第二次暂停与终态事实仍属于原 Run。`test_message_contract.test_same_run_checkpoint_resume_replay_returns_existing_fact` 验证 checkpoint 重放不产生重复消息事实。
- **checkpoint 一致性**：`test_recovery.test_corrupt_read_and_resume_defense` 覆盖 `read_run` 和恢复入口发现 Interrupt 缺失后的错误收敛；公开路由的等价情况由上述临时 GET 探针验证。路径代码为 `observe_run → runs.observe_run → read_run → recovery.reconcile_run`。
- **正式测试的明确缺口**：`test_server` 的 GET 重建断言只用 completed Run；`test_approval_resume` 通过 HTTP 重建有效审批历史，但没有直接断言 interrupted metadata、正常 EOF、无 error 帧或 GET 零工具副作用。`test_recovery` 的 checkpoint 损坏断言在 `read_run` 层，没有经公开 GET 路由。临时探针已实测这两个边界，但尚未沉淀为正式回归测试。
- `test_run_observation` 对 interrupted 历史投影的重开用例会 mock `reconcile_run`，并在测试注释中说明实际 checkpoint 校验由真实 Graph 恢复测试覆盖；因此它单独不能作为 checkpoint 校验的证明。
- 完整 Python 回归不能代替前端投影、浏览器页面或 Tauri 原生实机验收；这些由主 agent 的前端/桌面验证批次负责。

定向日志中的 `approval_state_corrupt`、`invocation_lost`、模拟磁盘/连接错误堆栈来自相应负路径测试；对应 unittest 项均以 `ok` 结束。完整回归另含唯一上述 Windows symlink 权限跳过。

