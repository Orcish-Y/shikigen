> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第16票实施与验证记录

日期：2026-10-06。Status: 已完成核心验收。

## 实现

- `conversation-export.ts` 从事实记录同步深复制点击快照，按 seq 排序、去重；冲突拒绝，预览与运行事件不进入快照，不请求更多消息或本地资源。
- `useConversations.captureExport` 点击时读取事实所有者，保留完整消息字段和已知运行状态／中止原因。未知原因不猜测，运行事件本身不导出。
- Markdown 头说明会话身份、UTC 时间、消息数、Run 与已加载 seq／空洞范围。记录外层及正文之外的完整字段使用 JSON；正文分别为可读 Agent Markdown、原文 markdown/text 围栏或完整数组 JSON。
- 反引号围栏按原内容最大连续长度加一，支持 HTML、引用定义、未闭合／嵌套围栏和无效 info string 的原文隔离；保留首尾空白、空/null artifact、未知字段及原资源引用。
- 工具栏沿用当前按钮与 business-notice 样式。生成 UTF-8 Blob，安全文件名包含标题及时间；派发只提示“已发起导出”，不会称文件已保存。空记录和同步派发错误局部反馈，下载取消不改变事实。
- 无 Python/Rust 产品、HTTP、依赖、数据库或权限修改。不执行 Git 命令。

## 开发阶段定向检查

接口：已定稿公开消息快照／Markdown 序列化、标准 Blob 下载、实际 Tauri 工具栏与公开 HTTP 事实。

- 初次专项模块缺失红灯：0通过／1失败。
- 测试预览字面量与范围说明碰撞，以及 Node document mock 使用不支持 API 两次夹具错误，已修正夹具且保留语义断言；当时最终专项6通过。
- `pnpm exec tsc --noEmit`：退出0。
- 新增无效反引号 info string 边界，真实 Markdown 解析吞后续记录：专项5通过／1失败。修正 scanner 后交轻量子 agent 专项复验，完整批次不重复。

## 最终验证

按 AGENTS.md 由显式 `gpt-6-luna / max` 测试子 agent 执行，主 agent 需核对原始日志、数量、文件和截图。

### 前端

显式 `gpt-6-luna / max`：完整 Node 基线 **188通过、0失败／取消／跳过**；它在新增生命周期摘要用例及围栏修正前执行，不能当成最终全套通过。所有后续修正后的导出专项 **7通过、0失败／取消／跳过**；最后纯命名闭环后 TypeScript、构建及两 Python 文件 Ruff check/format --check 退出0。最新构建主chunk **595.78kB（gzip181.73kB）**，>500kB提示保留。

命令、真实退出码及范围见[前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-16/validation/frontend/report.md`）和[命令结果（原始产物已删除）](../../../README.md#已删除的材料)。主 agent 已核对 `node-tests.stdout.log`、`export-focused-closed.stdout.log`、`build-closed.stdout.log/stderr.log` 与命令结果。早期 Ruff import／长行与格式失败均保留，不改算通过。后来仅原生测试／runner追加，由原生验证子 agent 补最终 Ruff；不重复 Node、后端或 Rust 回归。

### 原生批次与历史失败

- 普通权限的 `native-probe` 单例 **0通过／1错误**：在 `connect → evaluate(window.__TAURI_INTERNALS__)` CDP连接被远端关闭（WinError10054），未到任何导出断言，host日志0字节，无截图。未认定产品缺陷或确认根因。
- 自动审核允许提升权限后 `native-probe-2` 同一单例 **1通过、0失败／错误／跳过**（12.249秒），验证空记录提示与同步派发失败，不改变草稿／事实／状态。5173仅复用，index396bytes及2个入口assets与当前dist一致。
- `native-remaining-1` 六例 **5通过／1失败**（86.789秒）：实际 UTF-8 文件与点击快照、WebView deny 后手动下载、取消中止正文及两个既有工具／Markdown 回归通过。失败正文用例尚未导出便等待超时；主 agent 的变量改名误改共享夹具标记 `failure-text-ready`，恢复原字面量后单独回归。
- `native-final-targeted-1` 两例 **1通过／1失败**（34.045秒）：失败正文与真实原因通过；默认保存 UI 探针未找到其预期的 `#32770`／SaveAs 窗口。`native-save-trusted-1` 使用可信 `Input.dispatchMouseEvent` 再验，**0通过／1失败**（24.121秒），同样没有找到预期窗口。不认定用户激活为根因，也不将失败改算通过。
- 两次 UI 探针的隔离 profile 设置与目录断言通过，实际默认保存 UI／物理用户取消未验证。临时 profile 与 host 已清理，未在失败当时保存 HWND owner-chain，不能事后补成原始证据。探针代码与失败日志保留；runner 的 `--probe-default-save-ui` 明确用于额外调查，不属于规格要求的固定 UI 形态。
- 独立 Browser 取消诊断退出0，收到同 GUID 的 `Browser.downloadWillBegin → Browser.cancelDownload → Browser.downloadProgress(state=canceled)`，下载 69759 bytes、receivedBytes=0，目录为空，HTTP历史／草稿／状态不变。它不等同于策略 deny，也不代表用户点击保存弹窗。
- 主 agent 将真实 GUID 取消链纳入正式验收，`native-cancel-final-1` **1通过、0失败／错误／跳过**（10.103秒）；完整原始命令、取消响应、生命周期事件与事实写入 result.json。**六个正式新用例＋两个既有回归，共八个唯一用例分批各有通过证据**，不声称一次8／8全绿。

正式原生路径使用实际 Tauri/WebView2、当前 frontend/dist、真实 HTTP／SQLite 和可控 Agent；Browser.setDownloadBehavior 控制隔离目录及allow／deny策略，两者分别记录。下载取消通过调试协议控制实际下载，不调用应用内部取消逻辑。没有修改导出产品代码来通过 UI 探针。最终原生报告及逐命令结果见[原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-16/validation/native/report.md`）与[命令结果（原始产物已删除）](../../../README.md#已删除的材料)。最新两Python文件Ruff check／format --check均退出0，主agent已核对原始日志及退出码。清理检查退出0，宿主进程0、9238／45200监听0，已有5173服务保留、HTTP200／index396bytes。

### 文件与截图核对

主 agent 已读原始 Node／原生批次日志、命令结果、result.json，并查看真实 WebView 截图。文件存在、UTF-8 无 BOM，测试将落盘 bytes 与捕获 Blob 的 UTF-8 bytes 严格比较、将完整记录字段与公开 HTTP 历史逐条比较：

| 记录 | 实际文件大小 | 点击快照消息数 | 证据 |
| --- | --- | --- | --- |
| 完整工具记录／后到用户消息排除 | 69759 bytes | 11 | [结果（原始产物已删除）](../../../README.md#已删除的材料)／[界面（原始产物已删除）](../../../README.md#已删除的材料) |
| deny 后手动重发下载 | 69759 bytes | 11 | [结果（原始产物已删除）](../../../README.md#已删除的材料) |
| 取消运行后的完整中止正文 | 3215 bytes | 2 | [结果（原始产物已删除）](../../../README.md#已删除的材料)／[界面（原始产物已删除）](../../../README.md#已删除的材料) |
| 执行失败后的完整中止正文与真实原因 | 16617 bytes | 2 | [结果（原始产物已删除）](../../../README.md#已删除的材料)／[界面（原始产物已删除）](../../../README.md#已删除的材料) |
| 真实下载取消 | 无落盘文件 | 11 | [结果（原始产物已删除）](../../../README.md#已删除的材料)／[界面（原始产物已删除）](../../../README.md#已删除的材料) |

快照用例的第二次真实 POST 已提交新用户消息；可控模型重用 AI 消息身份后第二 Run 因冲突失败，截图保留真实错误。这个夹具不证明第二 Run 成功完成；它证明后到持久消息和新 Run 状态都没有进入旧 Blob。

## 验收对应

| 第16票验收 | 可核对证据 |
| --- | --- |
| 点击快照、仅已加载已提交、范围排除 | Node快照／冲突用例；实际延期派发后新POST、实际预览前后两次导出；captureExport只读当前事实所有者，没有GET入口 |
| seq排序、完整工具字段／空值／中止正文、结果一次 | Node完整公开记录及artifact六种空值；实际11条HTTP记录严格字段比较与ToolMessage数量；取消／失败真实文件 |
| 头部身份、时间、数量、Run／seq、空洞、安全文件名 | Node元数据注入及安全文件名；实际文件中文“会话”名、11或2条消息、已加载范围说明 |
| 可读Markdown、未知JSON、原文动态围栏 | Node真实react-markdown解析，HTML／引用／无效info string／未闭合和10反引号边界后每条记录标题仍独立；中止实机文件原文围栏 |
| 空白、未知字段、空artifact、正文外原因、资源原引用 | Node原文与全部字段断言；实际文件／HTTP全字段与正文核对、失败Run原始error；序列化无资源读取接口 |
| 公开事实与实际下载、空记录、取消／失败不改事实 | 六个正式Tauri导出用例＋工具／Markdown两回归；UTF-8落盘一致、sync failure、真实GUID取消及deny分别记录 |

## 保留的覆盖边界

- 默认保存 UI、物理鼠标／系统文件选择窗口／用户手动取消没有通过证据，两次额外探针失败保留，需第23票联合实机验收继续检查。真实WebView取消状态与实际UTF-8下载已验证；不声称默认UI通过。
- 使用可控本地 Agent、真实 HTTP/SQLite/Graph，不使用真实线上模型；下载由实际 WebView 执行，CDP限定自己的测试产物目录。WebView截图不含系统窗口边框。
- 当前票无后端／Rust产品变更，未重跑后端或Rust全套；完整Node基线与最终受影响专项分开记录。Vite大chunk提示未处理。
- 本轮未执行任何Git命令，未暂存／提交／切换分支。

### 两轴审查

- [Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-16/standards-review.md`）：初审3组硬命名／2启发、复核新增3组／2启发均已修复，最终 **0硬／0启发**。继承 `WindowAcceptance.record` 公共API保持兼容，测试替换误触碰调用已还原；实体、回调及bool采用领域命名。
- [Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-16/spec-review.md`）：生命周期 `message` 误标 `error` 的字段语义已修复，新增公开摘要专项；正式真实WebView取消与UTF-8文件下载满足票面要求，规格没有将某种SaveAs窗口形态设为前置条件，无剩余规格硬问题。`deny` 没有被当作取消，默认UI／物理操作仍为后续覆盖边界。

主agent已核对六条验收映射、两轴审查、轻量模型最终报告与原始证据，将第16票标记done／已验收。下一票为第17票“查看当前运行详情与真实累计用量”，本轮未开始。
