> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第18票：已提交运行事件与审批历史

日期：2026-10-06。实施与修复由主 agent 完成；最终验证及 Standards／Spec 审查均委派显式 `gpt-6-luna / max`，独立交接规格、源码、验收边界、命令、资源隔离与历史结果。

主 agent 已核对七条验收对应的日志、结果、请求与实机截图，第18票已完成。本轮未执行任何 Git 命令，未暂存、提交或切换分支。

## 实现

- 后端新增 `GET /api/threads/{thread_id}/runs/{run_id}/events`。纯读查询当前全部已提交公开事件、检查会话归属、按 seq 升序、统一 no-store；没有分页或服务端过滤。额外 query 参数被忽略，不声明为拒绝。Runtime 使用 `committed_query()`，不会修复 checkpoint 或恢复执行。
- JSON 与 SSE 共用 `project_run_event()`，公开结构相同。不兼容持久记录使整次查询返回 500／no-store，诊断携带完整 `raw_event`，不返回部分 `data`。客户端将该特定诊断展示为只读协议问题；普通 500 仍是读取失败。
- `RunEventHistoryReader` 负责详情专属事件读、独立重试、租约和目标失效、边界通知合并。快照与事件各自单一请求并行读取，关闭详情中止事件请求和等待，不中止会话 SSE。可恢复错误沿用 1／2／5 秒、最多三次自动重试及 Retry-After；404／500／协议问题停止自动重试。
- 事件进入既有 `RunProjection`，以真实 seq 合并。重复事实保留最早原文，缺项不删除，空洞允许；同 seq 冲突或审批身份冲突整批回滚，原文供只读核对。历史 lifecycle 不替代当前运行状态，事件 GET 不授予新的审批提交权限。
- 沿用现有运行详情和原稿字体、颜色、分隔线、400px 抽屉。默认显示运行／审批，勾选“包含消息事件”只在本地过滤。展示真实类别、服务端时间、seq、审批决策与原因；本地未提交选择和 HTTP 接受本身不生成历史。
- 完整事件 JSON 默认折叠，320px 区块内滚动，完整复制；完整查看复用同一前景只读子视图。返回恢复阅读位置和焦点；实机捕获的焦点自动滚动已用 `focus({preventScroll:true})` 修复。JSON 内图片、网页和路径保持文本。
- 正常 interrupted／终态 EOF、有效 cancel 终态触发一次事件补读。确认前的在途请求至多追加一次确认后读取，重复通知不排队，不凭当前终态合成事件。

命名按 AGENTS 统一为明确动作与领域名，包括 `getRunEvents`、`mergeEvent`、`mergeEvents`、`refreshHistory`、`formatEventTitle`、`eventRead` 及测试辅助函数；接口原有 `data` 与第三方 API 名保留。

## 验证命令与结果

### 后端

工作目录：`C:/code/shikigen-agent`。

- `.venv/Scripts/python.exe -m unittest discover -s tests -v`：一次完整回归 333 项，332 通过、0 失败／错误、1 Windows 符号链接权限跳过。它在最后坏记录诊断分支之前执行；未声称最新代码重新全量通过。
- `.venv/Scripts/python.exe -m unittest discover -s tests -p test_run_event_queries.py -v`：最后增量 5／5 通过，0 失败／错误／跳过。真实临时 SQLite／Runtime／FastAPI ASGI 验证 JSON=SSE、归属和纯读、驱动错误、预留序号空洞及取消事实、坏持久行完整原文且不入事实。
- `.venv/Scripts/python.exe -m ty check app packages/harness/shikigen` 与新增测试 ty：完整回归阶段通过；最后改动的 `app/routes/run.py tests/test_run_event_queries.py` 两文件 ty 通过。
- 后端本票四文件 Ruff check／format check 通过；最后两文件增量 Ruff／ty 均通过。

原始命令、退出码、逐项日志及模型见 [后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/backend/report.md`）、[命令结果（原始产物已删除）](../../../README.md#已删除的材料)、[坏记录增量报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/backend/incremental-2026-10-06/report.md`）及[最后命名复核](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/backend/naming-final-2026-10-06/report.md`）。最后仅测试变量改名后，5项专项与该文件 Ruff／ty 再次通过。SQLITE_CORRUPT 注入的 traceback 为预期错误日志，不是测试失败。旧审批结算和空宿主环境变量用例在完整回归通过；其历史超时根因仍未确认，旧 needs-triage 不关闭。

### 前端

工作目录：`C:/code/shikigen-agent/frontend`。

- `node --import tsx --test tests/*.mjs`：一次完整 Node 基线 208／208 通过，0 失败／跳过。此后增加坏 JSON／404／500／坏持久行诊断、样式与命名修正，仅追加受影响专项，不重复同一全套。基线跨过 App effect 一行修改；该套件没有导入或读取 App，仍如实保留启动边界。
- `node --import tsx --test tests/run-events.test.mjs tests/run-reconstruction.test.mjs tests/run-details.test.mjs`：最新受影响三文件 40／40 通过，0 失败／跳过（含事件专项12项）。覆盖独立并行读取、乱序／重复／冲突、边界补读、关闭／会话和租约切换、Retry-After／有限重试、原文协议问题和分区失败。
- `node node_modules/typescript/bin/tsc --noEmit` 与 `node node_modules/vite/bin/vite.js build`：最新产品源通过。Vite 主 JS chunk 616.93 kB／gzip 187.42 kB 的体积提示保留，CSS 70.21 kB；未扩大本票做代码分块。
- 两个原生 Python 夹具 Ruff check／format check：最后两文件通过。折行格式修复不更改断言或行为。

最新40项、TypeScript、构建和 Ruff 的命令／退出码见 [style-final-1 命令结果（原始产物已删除）](../../../README.md#已删除的材料)，原始 Node 计数见 [node-targeted.log（原始产物已删除）](../../../README.md#已删除的材料)。此前批次和源版本范围见 [前端历史报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/frontend/report.md`）及[早期命令结果（原始产物已删除）](../../../README.md#已删除的材料)。本项目没有前端 lint script。Rust 产品、宿主产品及依赖未修改，未重复 Rust 全套。

### 原生验证与审查

原生按隔离临时 profile／SQLite／工作目录串行运行；已有 5173 服务保持运行，每批先核对其 index 与 CSS／JS 两资产和当前 dist 字节一致。只回收本次启动的宿主／后端；测试 agent 最后复核5173保留、9238／45200无监听，记录于[最后验证报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/frontend/style-final-1/report.md`）。

工作目录 `C:/code/shikigen-agent`，命令前缀 `.venv/Scripts/python.exe .scratch/frontend-completion/ticket-18/native_runner.py`：

| 参数／批次 | 实际结果 | 范围 |
| --- | --- | --- |
| `--batch native-final-1 --regression` | 5项，0通过、2 failure、3 error | 默认沙箱 CDP 接入失败，未进入产品断言 |
| `--batch native-final-1-escalated --regression` | 5项，4通过、1失败、0错误／跳过 | 真实取消／失效历史、分区失败／关闭中止、坏 wire 事件只读原文、两项旧消息／工具回归通过；完整事件返回滚动位置失败 |
| `--batch native-scroll-fix-1 --tests test_required_complete_json_actual_decisions_eof_and_reading_position` | 1项，1通过、0失败／错误／跳过 | 修复后原断言通过；真实 required→resolved→completed、完整JSON／复制、过滤、焦点和位置、恰好一次EOF补读 |
| `--batch native-timeline-evidence-1 --tests test_required_complete_json_actual_decisions_eof_and_reading_position` | 1项，1通过、0失败／错误／跳过 | 在行为断言后定位事件区，补实际时间线截图 |
| `--batch native-style-final-1 --tests test_required_complete_json_actual_decisions_eof_and_reading_position` | 1项，1通过、0失败／错误／跳过 | 最后命名与样式修改后验证；新增严格检查JSON 12px／20px，全部原行为断言及时间线截图通过 |

共五个唯一原生用例分批各有通过证据，不声称一次5／5全绿，不用后续通过抵消早期失败。提升权限重跑通过授权的相同夹具解决 CDP 环境限制；实际产品失败预期 scrollTop 250.2857、实际 1013.1429，修复后保留原断言。其余四项没有在最后仅命名／次要控件／JSON字体变化后重复运行，避免重复成本；最后原生场景重新核实受影响位置、字体与完整JSON。

主 agent 已核对成功 result／失败 trace、读请求、实际事件和截图。最终成功场景：required JSON `maxHeight=320px`、fontSize=12px、lineHeight=20px、clientHeight=319、scrollHeight=15104（早期11px批次为12484）；返回 scrollTop=250.2857，运行结束阅读位置=180；查询从4条事实补至9条（seq1–9），总共3个events GET分别为两次打开和一次EOF补读。审批历史含实际拒绝原因，本地未提交原因未入历史。取消场景实际 invalidated，已确认seq为1／3／4／5／6；读取500不清快照，关闭在途请求被中止。坏 wire event seq900不成为事实，只读原文没有图片或链接节点。

证据见 [原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/native/report.md`）、[原生命令结果（原始产物已删除）](../../../README.md#已删除的材料)、[完整事件最终结果（原始产物已删除）](../../../README.md#已删除的材料)、[最终时间线截图（原始产物已删除）](../../../README.md#已删除的材料)、[取消结果（原始产物已删除）](../../../README.md#已删除的材料)、[协议问题只读截图（原始产物已删除）](../../../README.md#已删除的材料)。

[Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/standards-review.md`）硬性遗留0项；[Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/spec-review.md`）缺口／行为错配／范围外扩均0项。两路审查以完整编辑前副本和18文件1732行差异为基准，未使用Git；关闭票据后重新生成的差异还包含本次完成记录。保留一项可读性建议：历史事件标题与当前运行标签文案不同，暂不抽象合并两套状态映射。重要正文14px、普通次要操作12px、JSON12px／20px的层级由两路复核，符合设计稿与契约；窄屏操作44px。

## 覆盖边界

- 本票 Tauri 用例使用真实窗口宿主、HTTP／SQLite／Graph 和离线模型／工具夹具，不调用付费模型。事件传输故障和 wire-level 不兼容响应在 fetch 外部边界注入；坏持久记录另由真实 SQLite／ASGI 测试覆盖。
- 原生复制断言捕获 `navigator.clipboard.writeText` 的完整文本，不代表 OS 剪贴板实测；图片为 CDP WebView 内容区截图，不包含原生窗口边框。
- 404 的重新读取入口由静态源码和读取失败测试核对，没有单独实机按钮用例。物理输入／系统 IME、原生边框、多尺寸联合验收与系统剪贴板仍归第23票。
- 第19票的待结算用量有限轮询尚未实施。

## 七条验收对应

| 验收 | 实现与已核对证据 |
| --- | --- |
| 1. 公开事件纯读、seq／SSE一致 | 后端5项专项及完整333基线；错误归属404、busy503、corrupt500、无效行原文500，均no-store／历史快照不变 |
| 2. 并行／独立请求与事实保留 | Node12项事件专项；关闭／租约／切会话中止，缺项／空洞、重放／乱序、同seq批量回滚；原生分区失败保持快照 |
| 3. 本地过滤与真实标记 | SSR标记测试；原生默认序号和勾选消息后全seq比对，实际required／resolved／invalidated和生命周期来自真实HTTP |
| 4. 真审批历史和只读协议原文 | 原生本地原因不入历史、真实提交原因保留；SQLite未来事件完整诊断与Node分区保护；协议问题截图无图片／链接 |
| 5. 完整JSON／复制／子视图 | 原生完整JSON与API逐字段相等、复制全字符串，320px内滚动；单dialog、无textarea、返回焦点及scroll精确恢复 |
| 6. 有限补读／关闭保留SSE | Node取消确认前在途＋一次后读、interrupted EOF、重试上限／关闭；原生完成EOF只增加一次GET且保留180px阅读位置 |
| 7. 公开链路和实机 | HTTP／SQLite／Runtime与SSE等价测试、真实Tauri／Graph审批和取消；分批五唯一原生用例最终有通过证据，失败历史与物理验收限制如上 |
