> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 22 票真实 Tauri 验证报告

## 身份与验证边界

- 实际模型：`gpt-6-luna`，推理强度 `max`。
- 原生验证工作目录：`C:\code\shikigen-agent`，PowerShell；Vite 构建工作目录：`C:\code\shikigen-agent\frontend`。
- 覆盖票据 [22-command-panel-shortcuts.md](../../../../../../../wayfinder/frontend-completion/implementation/22-command-panel-shortcuts.md) 与交互契约第 9、10 节：本地命令搜索、已加载标题、方向键／Enter／Esc／Tab 与焦点、禁用原因、共用页面动作、pending／迟到响应、输入法保护、前景模态边界、窄屏导航与桌面偏好。
- 原生用例运行真实 Tauri `backend_window.exe`、WebView、HTTP API 与独立 SQLite fixture；模型回复使用本地确定性 fixture，没有调用外部模型服务。所有历史失败和修订后的证据均保留，批次间不覆盖。
- 未执行 Git 命令，没有修改产品代码或正式断言。主 agent 修复了 dialog CSS 与测试取证／纯格式问题。此报告不更新票据状态。

## 批次结果

| 批次 | 范围 | 通过 | 失败 | 错误 | 跳过 | 结果 |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| `final-1` | 第 22 票五个新原生用例 | 4 | 1 | 0 | 0 | 50.266s；case 4 的偏好计数因双层测试埋点失败，保留历史批次 |
| `final-2` | 第 22 票五个新原生用例，修正埋点／增加 URL 查询记录后 | 4 | 1 | 0 | 0 | 51.418s；case 4 实测 390px dialog 为 356px，精确 358px 断言失败，促成 CSS 修复 |
| `final-3` | 修复后的四档尺寸用例 | 1 | 0 | 0 | 0 | 12.587s；通过，初始布局指标后来发现没有写入汇总 JSON |
| `final-4` | 同一四档尺寸用例，仅补存每档 layout metrics | 1 | 0 | 0 | 0 | 12.124s；通过，完整保存 DPR、native DPI 与 Win32 窗口矩形 |
| `ticket22-menu-final` | 第 21 票菜单／过滤／焦点恢复回归 | 1 | 0 | 0 | 0 | 17.232s；通过 |
| `ticket22-original-ime-final` | 第 04 票原文发送／IME／重启草稿回归 | 1 | 0 | 0 | 0 | 13.756s；通过 |

上述批次有重叠。最终五个新场景由 `final-2` 的四个通过用例加 `final-4` 的四档用例覆盖；没有把它们描述成同一批次的 5/5。`final-3` 与 `final-4` 是同一个四档方法的两次单项通过，final-4 用于补齐最终可核对的布局证据。

## 执行命令与权限

`final-1`、`final-2` 在初始受限环境中执行，命令使用 `UV_CACHE_DIR=%TEMP%\ticket22-uv-cache`。两次均按交接说明以 `require_escalated` 申请本机 CDP／后端端口访问，调用已运行并返回测试结果，没有自动审核拒绝。

```powershell
uv run python .scratch/frontend-completion/ticket-22/native_runner.py --batch final-1
uv run python .scratch/frontend-completion/ticket-22/native_runner.py --batch final-2
```

恢复任务时权限已切换为 `danger-full-access`、approval policy 为 `never`。之后的命令均省略 `sandbox_permissions`，没有再申请提权。

```powershell
# frontend cwd；实际 Node v24.21.0，Vite v7.3.6
node node_modules/vite/bin/vite.js build

# 以下均为 repository root cwd
uv run python .scratch/frontend-completion/ticket-22/native_runner.py --batch final-3 --tests test_four_sizes_shortcut_modal_permissions_tab_focus_and_navigation_preference
uv run python .scratch/frontend-completion/ticket-21/native_runner.py --batch ticket22-menu-final --tests test_menu_preserves_filter_pages_scroll_reading_and_single_foreground_focus
uv run python .scratch/frontend-completion/ticket-22/validation/native/ticket04_ime_regression_runner.py
uv run python .scratch/frontend-completion/ticket-22/native_runner.py --batch final-4 --tests test_four_sizes_shortcut_modal_permissions_tab_focus_and_navigation_preference
uv run ruff check --output-format concise frontend/src-tauri/tests/command_panel_acceptance.py .scratch/frontend-completion/ticket-22/native_runner.py .scratch/frontend-completion/ticket-22/prepare_review.py
uv run ruff format --check frontend/src-tauri/tests/command_panel_acceptance.py .scratch/frontend-completion/ticket-22/native_runner.py .scratch/frontend-completion/ticket-22/prepare_review.py
```

首次 final-3 build 准备因 turn interruption 中断，随后核实无 Vite build 进程、stdout/stderr 均为零字节；这两份日志改名为 `final-3-vite-build.interrupted-preparation.*.log`，不计作构建失败或构建通过。新构建 exit 0，用时 28.298s；日志和元数据见 [Vite build stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../../../README.md#已删除的材料)、[meta（原始产物已删除）](../../../../../README.md#已删除的材料)。

最终 Ruff 使用 Ruff 0.16.0。`final-4-ruff-check` 首次报告测试文件 8 条 E501；主 agent 将长行拆成相邻字符串／换行，未改变请求、按键语义、拼接内容或断言。随后 `final-5` 对同三文件重新检查，check 与 format check 均 exit 0。初始 Ruff 失败日志保留，没有覆盖：见 `final-4-ruff-check.log`、`final-4-ruff-format-check.log`；最终日志和 exit code 见 `final-5-ruff-check.log`、`final-5-ruff-check-exit-code.txt`、`final-5-ruff-format-check.log`、`final-5-ruff-format-check-exit-code.txt` 与 `final-5-ruff.meta.json`。

## 五个场景覆盖

1. **只查本地动作和已加载标题。** 用 41 条已命名会话、普通会话行、当前草稿及侧栏过滤验证。未加载标题不出现，搜索不匹配 ID／状态，运行详情禁用项说明“尚未开始运行”，无匹配 Enter 不创建会话。方向键选择可用项、环绕、长列表在结果区滚动；关闭后焦点返回草稿，侧栏过滤文本与 180px 列表位置、草稿原文保持。最终 request recorder 同时保存 `path/search/method`；列表只出现 `?limit=20` 和真实分页 `?limit=20&cursor=…`，命令搜索后请求集合未增长；断言 GET `/api/threads` 查询键只允许 `limit`、`cursor`，没有服务端 q/search 参数。
2. **创建 pending、重复按键与迟到创建。** hold 住真实 POST 响应，快捷键 repeat 与面板新建均不能发第二次创建。pending 项展示“正在创建会话”；期间用命令面板切到目标会话并改写草稿，再释放迟到创建，当前选择和新草稿不被抢回或覆盖。请求记录只有一次创建 POST。
3. **迟到历史、其它运行与详情替换。** 源会话在真实本地 fixture run 处于 running 时，切换到目标会话；hold 源历史再释放，目标选择和草稿保持。回到源会话后既有 Run 与草稿恢复；命令面板转为唯一运行详情前景，详情打开时 K／N／B 不能替换它，也不增加流／取消请求。
4. **桌面、平板和手机尺寸／焦点／导航偏好。** 宽度 1440、1280、1024、390px 下核对 dialog、Tab／Shift+Tab、K／N／B、焦点返回、Esc 与对话层数量。仅两个桌面 B 动作各写一次桌面偏好；repeat 无额外写入，1024／390 下 B 控制自己的导航视图，不写桌面偏好；窄屏普通菜单默认会话列表，导航视图可自行关闭。草稿原文和布局请求基线保持。
5. **中文 IME、repeat 与其它前景层。** 在 WebView 中用 CDP `Input.imeSetComposition`／`Input.insertText` 和 `KeyboardEvent` 的 `isComposing`／`keyCode=229` 值验证 K／N／B 与 Enter 不误触；结束 50ms 窗口、repeat 与 pending 创建不能重复请求。取消确认弹窗保持唯一前景，默认焦点是“继续运行”，Esc 只关闭本弹窗；详情内容面板中全局快捷键也不触发工作台动作。

## 四档实测数据与截图

所有档位的 WebView `devicePixelRatio` 为 1.5，`GetDpiForWindow` 为 144。下表中的 `window rect` 与 `client rect` 来自真实 Win32 窗口查询；截图仅是 WebView，未包含 OS 标题栏。390px 下 CSS 宽度目标 358px，final-2 观察到 356px，修复后 final-4 的 computed `max-width=none`、computed width 与 bounding rect 均为 358px，原精确断言未放宽。

| WebView viewport | Dialog | `window rect` | `client rect` |
| --- | ---: | --- | --- |
| 1440×900 | 480px | `[228, 38, 2410, 1444]` | `[0, 0, 2160, 1350]` |
| 1280×800 | 480px | `[228, 38, 2170, 1294]` | `[0, 0, 1920, 1200]` |
| 1024×768 | 480px | `[228, 38, 1786, 1246]` | `[0, 0, 1536, 1152]` |
| 390×844 | 358px | `[228, 38, 835, 1360]` | `[0, 0, 585, 1266]` |

每个尺寸的 dialog 初始状态和交互状态 JSON／PNG、窗口截图和布局汇总均在 [final-4 原生证据目录（原始产物已删除）](../../../../../README.md#已删除的材料)。四档最终偏好写入为 `true,false` 两次，1024／390 不再追加。关键图片：

- [390px 初始 dialog（原始产物已删除）](../../../../../README.md#已删除的材料) 与 [390px交互状态（原始产物已删除）](../../../../../README.md#已删除的材料)。
- [1440px 初始 dialog（原始产物已删除）](../../../../../README.md#已删除的材料)、[1280px（原始产物已删除）](../../../../../README.md#已删除的材料)、[1024px（原始产物已删除）](../../../../../README.md#已删除的材料)。
- final-2 其他场景截图：[长命令列表（原始产物已删除）](../../../../../README.md#已删除的材料)、[创建 pending（原始产物已删除）](../../../../../README.md#已删除的材料)、[详情替换（原始产物已删除）](../../../../../README.md#已删除的材料)、[IME／前景保护（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 旧回归证据：[第 21 票菜单恢复（原始产物已删除）](../../../../../README.md#已删除的材料)；[第 04 票原文／IME／重启草稿（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 两次失败的诊断

- **final-1 偏好计数失败：**测试先运行 `start_completed()`（其中 `instrument_layout()` 安装 Storage wrapper），随后 `instrument_commands()` 重载并再包一层；新 wrapper 调旧 wrapper 时，一次 `setItem` 被两层都写入同一数组，实测 2、预期 1。根因是测试埋点双计数，不是产品两次写偏好。修复后保留 1／2 次严格断言。
- **final-2 窄屏宽度失败：**390px 下 viewport 的 dialog bounding rect 为 356px，测试按既定 `calc(100vw - 32px)` 预期 358px。final-2 未保存 computed style，因此当时不能从该批次证明 clamp 来源；主 agent 在 `.command-dialog` 加 `max-width:none`，保留宽度公式与精确断言。final-4 computed style 显示 `maxWidth=none`，rect 为 358px。

## 清理与未覆盖范围

最后检查时 `backend_window`／宿主窗口进程为 0，9238 和 45200 无监听。5173 有外部共享 dist 服务（PID 23344），HTTP 200、入口 396 bytes；runner 报告 `SHARED_DIST_SERVER_MODE=reused` 并比对入口引用的两个静态资源均与当前 dist 字节一致，因此未停止外部服务。

本轮 IME 验证是 CDP 注入及 `KeyboardEvent` 的 `isComposing`／`keyCode=229`，不是物理键盘或 OS 候选窗验收。Windows 物理键盘、系统候选面板与 OS 标题栏归第 23 票；原生窗口截图不含标题栏，系统窗口范围由 Win32 rect／DPI 数据证明。macOS 原生 Cmd 未实测，本轮只通过 platform mapping 单测检查该分支，不把它列作第 23 票义务。外部在线模型供应商行为未覆盖。

前端 Node、TypeScript 与 Vite 历史结果见[前端验证报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-22/validation/frontend/report.md`）：268/268 完整 Node 测试发生在命名修正前；命名修正后专项 13/13、tsc 与 build 均通过。final-3 是 CSS-only 构建；其后测试夹具增加 evidence 字段，并进行纯格式换行，因此没有再跑 Node／tsc，也没有重复 Vite 构建。
