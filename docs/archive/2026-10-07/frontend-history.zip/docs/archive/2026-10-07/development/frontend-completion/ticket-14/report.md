> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 14 票实施与验收报告

日期：2026-10-06。范围：[自动预览工作目录内的本地图片](../../../../../wayfinder/frontend-completion/implementation/14-workspace-image-preview.md)。

主 agent 负责实现与修复，最终后端、前端、原生验证及双轴审查均显式使用 `gpt-6-luna / max`。主 agent 已读取原始命令结果、请求记录、截图和报告。用户禁止 Git 操作：本轮没有执行任何 Git 命令，也没有暂存、提交或切换分支。

## 实现了什么、为什么、使用哪些 API

Agent Markdown 中明确的本地图片引用，现在可以自动显示工作目录内的当前图片。聊天内保持比例、正文宽度和 320px 高度上限，可用现有详情抽屉查看完整图片、核对实际文件并复制引用或实际路径。缺失、越界、变化、格式和大小错误在图片处显示，保留引用并提供手动重试。图片明确标注“当前磁盘内容 · 非生成时快照”。

资源服务放在 Runtime 的 `WorkspaceResources` 中，根目录在装配时固定为实际绝对路径； owned Runtime 的文件工具使用同一根目录。这样相对引用与 Agent 文件工具一致，也不会因后来改变 cwd 而读到别处。资源服务负责路径、实际目标、根身份、普通文件、版本、格式与大小，HTTP 路由只调用纯读入口。

| 公开 GET API | 用途 |
| --- | --- |
| `/api/workspace` | 当前 opaque workspace 身份与实际根目录 |
| `/api/workspace/resources/resolve?path=...` | 解析相对路径、绝对路径或 file URI，返回资源身份、实际／相对路径、名称、MIME、大小、修改时间、版本及预览能力 |
| `/api/workspace/resources/{resource_id}/image` | 再核对路径与版本后返回图片字节，最多 20MiB |

查询不创建 Run、不调用 Graph／工具、不写文件。响应使用 `no-store`、正确 MIME 和 `nosniff`；错误分别是非法引用 422、越界／不可读 403、不存在或旧启动资源身份 404、根／目标／版本变化 409、超限 413、格式不支持 415。

前端由当前 `BackendSession` 读取 metadata 和 Blob；`WorkspaceImages` 按当前可见会话管理读者、共享读取与 URL，消息组件只使用受控 Blob URL。用户消息、工具原文、代码、未知 JSON 和网页图片不会触发本地读取；SVG 仅作为 `<img>` 图片源。隐藏、切换会话和租约失效时中止读取并释放 URL，迟到结果不会新建 URL；恢复可见后重新解析原引用。新增 Markdown 段落锚点，避免长单条消息上方图片变高时抢走阅读位置。

沿用原有配色、字体、边框和详情层，没有依赖、Rust 产品、数据库 schema 或写 API 变更。第 15 票的文件确认／系统程序打开仍待实施。

## 改动文件

- 后端：`packages/harness/shikigen/runtime/workspace_resources.py`（新增）、`app/routes/workspace.py`（新增）、`app/server.py`、`packages/harness/shikigen/runtime/composition.py`。
- 前端：`frontend/src/backend-client.ts`、`frontend/src/workspace-images.ts`（新增）、`frontend/src/components/WorkspaceImage.tsx`（新增）、`MessageBody.tsx`、`ContentViewer.tsx`、`frontend/src/App.tsx`、`frontend/src/styles.css`。
- 验证：`tests/test_workspace_resources.py`、`frontend/tests/workspace-images.test.mjs`、`tests/desktop_workspace_image_fixtures.py`、`frontend/src-tauri/tests/workspace_image_acceptance.py`（均新增），本票 `.scratch/` 中的串行 runner 和证据。

依 AGENTS 命名约定修正了图片读者回调、重试／释放函数、Blob 工厂、布尔可见标志和对象命名；删除没有读取者的内部 `ResourceBinding.metadata` 字段。公开资源响应仍返回全部元数据。

## 七条验收条件与证据

| 验收条件 | 实现与实际验证 |
| --- | --- |
| 1. 仅 Agent 明确引用；路径／链接在根内；与文件工具共根且不随 cwd 改变 | HTTP 专项覆盖相对／绝对／file URI、cwd 改变、owned Runtime 实际文件工具、Windows junction 越界／重定向；原生检查用户／代码／JSON／网页图片与文件普通链接没有本地读取请求。 |
| 2. opaque 身份、完整 metadata、普通文件、根／路径／版本及当前磁盘说明 | HTTP 返回字段及同文件身份断言；替换根、删除／替换文件、同大小同 mtime 的 inode 变化、重装 Runtime 旧 ID 失效；原生完整查看与实际路径复制。 |
| 3. 纯读、完整状态码、20MiB、响应头 | HTTP 8 项全部通过，覆盖状态码及头、修改／旧身份、20MiB 边界、读取前后版本；实际资源请求均 GET，数据库线程／事件及文件内容的纯读断言。 |
| 4. 六格式、去重、SVG 仅 img、原路径不直接加载 | API 检查 PNG／JPEG／GIF／WebP／BMP／SVG、伪扩展与不支持格式；Node 共享读取／URL 断言；原生 3 个 PNG 引用共用 1 次二进制读取，SVG 另 1 次，全部源为 Blob，SVG script 未执行。实机解码专项使用 PNG 和 SVG，没有声称实机逐一解码六格式。 |
| 5. 比例、宽／高、完整查看／复制、局部错误与重试 | 原生 400×800 图片显示为 160×320，SVG 240×100，均在正文宽度内；抽屉完整图片 naturalHeight 800、复制实际路径、关闭返回入口；Node 验证 403／404／409／413／415 局部错误及手动重新解析版本。 |
| 6. 隐藏／切换／租约、释放、迟到、重新核实与上翻锚点 | Node 中止／忽略中止响应、跨租约和多读者专项；原生延迟图片后同段落偏移从 -11.8828px 到 -11.7891px，切回／托盘恢复继续同锚点；隐藏未完成读取后旧响应不建 URL；ready→ready 租约测试撤销旧 URL、关闭详情、新读取后同 Run 不变。 |
| 7. 公开边界与真实长会话／完整查看 | 8 项 HTTP 专项、7 项新增 Node 图片测试（包含在完整 172 项内）、4 项新图片原生用例及 4 项旧正文／阅读回归分批有通过证据。真实 Tauri 窗口、Python fixture Graph、HTTP、实际磁盘图片；租约输入的模拟边界见下文。 |

## 最终验证结果与执行命令

完整命令、起止时间、stdout／stderr／meta 和覆盖边界分别见[后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-14/validation/backend-report.md`）与[前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-14/frontend-report.md`）。以下数量有重叠，不相加。

| 范围 | 实际结果 |
| --- | --- |
| 唯一完整后端回归 | 329 项：328 通过、0 失败／错误、1 Windows symlink 权限跳过。最后的等价命名／删除未使用字段之后没有再跑完整后端，已跑最终 HTTP8 及静态检查。 |
| 最终后端 HTTP 专项 | 8 通过、0 失败／错误／跳过，最终资源产品代码与测试版本。 |
| 前端完整 Node | 首轮 172 通过；App 租约关闭逻辑修复后追加完整回归 172 通过、0 失败／取消／跳过。最后仅 updater 参数等价改名，未再重复 Node 全套。 |
| 最终静态与构建 | TypeScript、Vite 构建通过；后端 5 个文件 Ruff check／format、4 个产品与测试文件 ty 通过；原生／fixture／runner 5 文件 Ruff check／format 通过，其他验证 helper 的 Ruff 也通过。 |
| 原生首批 | 7 项：4 通过、1 失败、2 错误；4 条旧回归通过，新图片夹具问题修正后另跑三项。 |
| 图片专项重验 `recheck-1` | 3 通过、0 失败／错误／跳过。 |
| 租约详情红灯 `lease-red-1` | 1 失败：旧 URL 已释放、正文重新加载，图片详情仍打开；证明 Spec 缺口可复现。 |
| 租约详情修复 `lease-final-1`／当前构建 `lease-final-2` | 各 1 通过；final-2 使用含最终 updater 参数名的构建。共有 8 个唯一原生用例分批取得通过证据，没有一次“8／8 全绿”批次。 |

主要复现命令（cwd：repo；Node、tsc、Vite 命令的 cwd：`frontend`）：

```text
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_workspace_resources.py -v
.venv/Scripts/ruff.exe check app/server.py app/routes/workspace.py packages/harness/shikigen/runtime/composition.py packages/harness/shikigen/runtime/workspace_resources.py tests/test_workspace_resources.py
.venv/Scripts/ruff.exe format --check app/server.py app/routes/workspace.py packages/harness/shikigen/runtime/composition.py packages/harness/shikigen/runtime/workspace_resources.py tests/test_workspace_resources.py
.venv/Scripts/ty.exe check app/routes/workspace.py packages/harness/shikigen/runtime/workspace_resources.py packages/harness/shikigen/runtime/composition.py tests/test_workspace_resources.py
node --import tsx --test tests/*.mjs
node node_modules/typescript/bin/tsc --noEmit
node node_modules/vite/bin/vite.js build
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-14/native_runner.py
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-14/native_retry_runner.py
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-14/native_lease_rotation_runner.py --artifact-suffix lease-final-2
```

原生 runner 拒绝覆盖既有证据；重验需要新的 artifact suffix／目录。5173 的预置 dist 服务经 index 与直接 assets 字节核对后复用，未关闭原进程；9238／45200 的原生测试串行执行，没有并行争用端口或窗口。

关键最终原始记录：

- [HTTP8 meta（原始产物已删除）](../../../README.md#已删除的材料)、[后端完整回归（原始产物已删除）](../../../README.md#已删除的材料)。
- [App 修复后 Node 全套（原始产物已删除）](../../../README.md#已删除的材料)、[最终构建 meta（原始产物已删除）](../../../README.md#已删除的材料)。
- [完整查看结果（原始产物已删除）](../../../README.md#已删除的材料)／[截图（原始产物已删除）](../../../README.md#已删除的材料)。
- [段落锚点结果（原始产物已删除）](../../../README.md#已删除的材料)／[截图（原始产物已删除）](../../../README.md#已删除的材料)。
- [隐藏与迟到结果（原始产物已删除）](../../../README.md#已删除的材料)。
- [租约红灯日志（原始产物已删除）](../../../README.md#已删除的材料)／[失败截图（原始产物已删除）](../../../README.md#已删除的材料)。
- [当前构建租约绿灯日志（原始产物已删除）](../../../README.md#已删除的材料)／[结果（原始产物已删除）](../../../README.md#已删除的材料)／[截图（原始产物已删除）](../../../README.md#已删除的材料)。

## 发现、修复与审查

原生首批测试的 SVG 统计把界面图标算进内容，另外两个新用例使用了不存在的 tray 方法；修正 fixture 为仅排除界面图标、使用既有托盘 API，图片安全、取消、释放、阅读锚点等业务断言保留。没有把首轮失败改算通过。

Spec 审查发现同会话／同 Run 的直接 ready→ready 租约更换可能保留旧图片详情。新增公开桥接原生红灯证明问题，再修正 App 在 session／可见性变化时关闭图片详情；新租约的聊天图片重新解析与读取，final-2 同 Run 不变且旧 URL 释放。Standards 提出的对象／回调命名和未使用字段问题也已修复。

审查固定点使用实施前实际文件副本与新增文件空基准，由 `prepare_review.py`／difflib 生成 [review.diff（原始产物已删除）](../../../README.md#已删除的材料)，没有调用 Git。[Standards 报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-14/standards-review.md`）无剩余硬违反或 smell；[Spec 报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-14/spec-review.md`）最终未解决发现为 0。主 agent 已核对全部七条验收证据，第 14 票已验收并标记 done。

## 保留的限制

- 后端完整回归的 Windows symlink 权限跳过未算通过；本票另实际验证了 Windows junction 越界／重定向。
- 租约原生用例通过 Tauri `plugin:event|emit` 注入 ready 状态帧，保持实际 HTTP／Graph／文件／Run，只改变 startup／revision。它验证桥接新租约的 UI 行为，**没有验证真实 BackendManager 子进程重启**。
- 最终主 JS chunk 583.20 kB，Vite 的默认 500 kB 提示仍存在，构建 exit 0。物理系统 IME、多窗口尺寸与边框联合验收归第 23 票。
- 首轮原生失败、红灯和静态检查诊断保留；之前票据的独立 needs-triage 记录继续保留，本票完成不代表那些问题已查明。
