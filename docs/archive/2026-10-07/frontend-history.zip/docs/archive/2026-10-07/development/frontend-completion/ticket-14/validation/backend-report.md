> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 14 后端最终验证报告

## 结果

- 执行模型：`gpt-6-luna`，推理强度 `max`（按验证任务派发）。
- 工作目录：`C:\code\shikigen-agent`；Windows PowerShell；Python 3.12.13、ruff 0.16.0、ty 0.0.83。依赖已预装，本次未下载依赖；未运行 Git 命令。
- 最终代码定向验证：HTTP 专项 **8/8 通过**；Ruff check、Ruff format check、ty 全范围均通过。
- 唯一完整后端回归：**329 项，328 通过、0 失败、0 错误、1 跳过**，进程 exit 0。跳过项为 `test_symlink_data_and_parent_are_rejected`，原因是 Windows symlink privilege unavailable；它没有计入通过。
- 期间观察到一次 ty 测试诊断。主 agent 为 `registry` 增加 `ToolRegistry | None` 类型声明，并在调用前增加非空断言后，我对最终状态追加 HTTP 专项、Ruff 和完整 ty 检查，全部通过。验证 agent 未修改产品实现或测试代码；仅添加了本票日志 runner 和本报告。

## 交接与验收范围

读取了 `.scratch/frontend-completion/ticket-14/validation-context.md`、`AGENTS.md`、`docs/wayfinder/frontend-completion/implementation/14-workspace-image-preview.md`、`.scratch/frontend-completion/PRD.md` §13，以及 `docs/wayfinder/frontend-completion/tickets/004-message-tools-export.contract.md` 的本地资源约定。

后端实现方案是把已解析的 workspace 根与 opaque workspace/startup 资源身份放进 Runtime；文件工具与资源 API 共用根目录。资源查询为纯读 HTTP：解析引用、绑定路径和版本，只接受普通文件；图片读取前后核对根、路径和文件版本，并限制格式和 20 MiB 大小。路由分别提供 workspace、resource resolve 与 image bytes，设置 no-store、MIME 和 nosniff。

本次后端验收覆盖：相对/绝对/file URI 统一身份，越界路径与链接拒绝，普通文件与真实元数据，启动租约和文件版本失效，图片格式/大小限制，纯读行为及工具共用根目录。相关文件：

- `packages/harness/shikigen/runtime/workspace_resources.py`
- `app/routes/workspace.py`
- `app/server.py`
- `packages/harness/shikigen/runtime/composition.py`
- `tests/test_workspace_resources.py`

专项 8 个测试方法：

- `test_current_image_metadata_and_bytes_are_pure_read_facts`
- `test_relative_absolute_and_file_uri_have_same_current_identity`
- `test_invalid_missing_outside_directory_and_unreadable_paths`
- `test_version_change_deletion_and_old_startup_never_read_new_bytes`
- `test_formats_limits_and_untrusted_suffix`
- `test_links_outside_and_link_retarget_are_rejected`
- `test_replaced_root_and_same_size_replaced_file_invalidate_identity`
- `test_owned_runtime_binds_the_same_root_for_resources_and_file_tools`

## 执行记录

所有命令 cwd 均为 `C:\code\shikigen-agent`。原始 stdout、stderr 和 meta JSON 分开保存于 `.scratch/frontend-completion/ticket-14/validation/backend/`；meta 记录 argv、时间、exit code、输出字节数和测试/诊断计数。空 stdout 也保留了对应的零字节日志。

| 验证 | 结果与时间（UTC） | 原始证据前缀 |
| --- | --- | --- |
| HTTP8 首轮：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_workspace_resources.py -v` | 8/8 通过，0 跳过，exit 0；02:19:14.449–02:19:18.333 | `20261006T021914.449382Z-618f26b5-http8` |
| 完整后端回归：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` | 329 项；328 通过、0 失败、0 错误、1 跳过；exit 0；02:19:26.164–02:24:07.447。unittest 记录运行 276.787 秒，runner 总耗时 281.283 秒。 | `20261006T021926.164523Z-c955b062-full-backend` |
| HTTP8：同首轮命令 | 8/8 通过，0 跳过，exit 0；02:24:30.169–02:24:34.224 | `20261006T022430.169002Z-8b6ad466-http8` |
| Ruff：`.venv/Scripts/ruff.exe check app/server.py app/routes/workspace.py packages/harness/shikigen/runtime/composition.py packages/harness/shikigen/runtime/workspace_resources.py tests/test_workspace_resources.py` | exit 0、0 诊断；02:24:39.549–02:24:39.619 | `20261006T022439.549615Z-609dc570-ruff-check` |
| Ruff format：`.venv/Scripts/ruff.exe format --check app/server.py app/routes/workspace.py packages/harness/shikigen/runtime/composition.py packages/harness/shikigen/runtime/workspace_resources.py tests/test_workspace_resources.py` | exit 0、0 需格式化文件；02:24:40.529–02:24:40.573 | `20261006T022440.529536Z-715c909e-ruff-format` |
| ty 首次全范围：`.venv/Scripts/ty.exe check app/routes/workspace.py packages/harness/shikigen/runtime/workspace_resources.py packages/harness/shikigen/runtime/composition.py tests/test_workspace_resources.py` | exit 1；唯一诊断是测试 `tests/test_workspace_resources.py:300` 的 `registry.tools` 被推断为 `None | Unknown`；02:24:41.485–02:24:42.502 | `20261006T022441.485529Z-d4285f49-ty-check` |
| ty 产品范围：`.venv/Scripts/ty.exe check app/routes/workspace.py packages/harness/shikigen/runtime/workspace_resources.py packages/harness/shikigen/runtime/composition.py` | exit 0、0 诊断；02:25:03.007–02:25:03.303 | `20261006T022503.007592Z-335b002f-ty-product-check` |
| 最终 HTTP8：同首轮命令 | 主 agent 修正测试类型后的最终树，8/8 通过，0 跳过，exit 0；02:25:35.645–02:25:39.852 | `20261006T022535.645035Z-6fa305a8-http8` |
| 最终 Ruff check：同上列 Ruff 命令 | 最终树 exit 0、0 诊断；02:25:40.817–02:25:40.853 | `20261006T022540.817958Z-16b3f2ec-ruff-check` |
| 最终 Ruff format check：同上列 format 命令 | 最终树 exit 0、0 需格式化文件；02:25:41.449–02:25:41.478 | `20261006T022541.449810Z-9de86133-ruff-format` |
| 最终 ty 全范围：同首次 ty 命令 | 主 agent 修正测试类型后的最终树，exit 0、0 诊断；02:25:42.046–02:25:42.270 | `20261006T022542.046710Z-c35d13a4-ty-check` |

## 变更期间与验证边界

完整回归开始后，主 agent 在运行期间对后端方法做了等价动宾重命名（`workspace` → `describe_workspace`、`resolve` → `resolve_resource`、`image` → `read_image`，以及对应调用点）。该回归按启动时载入的 Python 模块执行，不能视为对重命名后最终测试源码的完整回归。重命名后的 HTTP8 在 02:24:30 已通过；随后主 agent 为测试加上 `ToolRegistry` 类型声明与非空断言，完整回归之后的最终 HTTP8、Ruff 和 ty 均在最终树上再次通过。按交接约定没有再运行第二次完整回归。

剩余覆盖边界：完整回归中有一项因 Windows symlink privilege unavailable 而跳过；本票专项另覆盖 Windows junction/链接越界和重定向样例。完整回归之后主 agent 先改了测试类型注解与非空断言；随后又做了本报告下方记录的两项后端等价调整。完整回归没有在这些后续修改后重跑，本轮只追加规定的窄改专项和静态检查。浏览器前端、Tauri 原生窗口及端到端实机验收不属于本后端验证范围，由其他验证任务执行。

## 捕获 runner

仅为本票增加 `.scratch/frontend-completion/ticket-14/validation/backend/run_backend_validation.py`，用来调用规定命令并生成逐命令 stdout/stderr/meta 证据；不参与产品运行，也不改测试行为。新发现的 runner 自身 lint/format 问题只在该验证脚本中修整，前后原始日志都保留。

## 后续等价调整后的最终窄改验证

本轮主 agent 说明仅做了两项等价后端改动：`app/routes/workspace.py` 的局部变量 `coordinates` 改为 `workspace_identity`；`WorkspaceResources.ResourceBinding` 移除未被读取的 `metadata` 字段及构造实参，公开 HTTP response 仍保留完整元数据。未改公开 API 语义。以下命令均在 `C:\code\shikigen-agent` 运行，时间为 UTC；完整 329 项回归没有重复执行。

| 验证 | 结果与时间（UTC） | 原始证据前缀 |
| --- | --- | --- |
| HTTP8：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_workspace_resources.py -v` | 8/8 通过、0 跳过，exit 0；02:35:51.399–02:35:55.616 | `20261006T023551.399632Z-7f6731cd-http8` |
| Ruff check：`.venv/Scripts/ruff.exe check app/server.py app/routes/workspace.py packages/harness/shikigen/runtime/composition.py packages/harness/shikigen/runtime/workspace_resources.py tests/test_workspace_resources.py` | 5 个文件，exit 0、0 诊断；02:35:56.452–02:35:56.512 | `20261006T023556.452616Z-1a06f26a-ruff-check` |
| Ruff format：`.venv/Scripts/ruff.exe format --check app/server.py app/routes/workspace.py packages/harness/shikigen/runtime/composition.py packages/harness/shikigen/runtime/workspace_resources.py tests/test_workspace_resources.py` | 5 个文件，exit 0、0 个需格式化文件；02:35:57.394–02:35:57.435 | `20261006T023557.394688Z-444686b3-ruff-format` |
| ty：`.venv/Scripts/ty.exe check app/routes/workspace.py packages/harness/shikigen/runtime/workspace_resources.py packages/harness/shikigen/runtime/composition.py tests/test_workspace_resources.py` | 产品和测试 4 个文件，exit 0、0 诊断；02:35:58.299–02:35:58.587 | `20261006T023558.299184Z-1030e7d4-ty-check` |
| 验证 runner Ruff check/format | 最终均 exit 0；check 02:37:17.136–02:37:17.168，format 02:37:17.954–02:37:17.995。自检初次发现 6 个 lint 项和未格式化；只清理/格式化验证 runner 后复验通过，初次失败日志保留。 | `20261006T023559.468466Z-ce7ef140-ruff-runner-check`（初次失败）；`20261006T023600.473808Z-009f6225-ruff-runner-format`（初次失败）；`20261006T023717.136499Z-465185c6-ruff-runner-check`、`20261006T023717.954841Z-f90bee1a-ruff-runner-format`（最终通过） |
| Review 准备脚本 Ruff check/format：`.scratch/frontend-completion/ticket-14/prepare_review.py` | 按主 agent 给出的隐藏目录准确路径只运行静态 Ruff；两项 exit 0、0 诊断/待格式文件；02:37:18.890–02:37:18.933 与 02:37:19.792–02:37:19.836。没有执行该脚本。 | `20261006T023718.890690Z-76b8a653-ruff-prepare-review-check`、`20261006T023719.792639Z-032d851f-ruff-prepare-review-format` |

最终窄改验证范围内没有失败或跳过。最近一次完整回归仍是前文 02:19–02:24 那轮，覆盖启动时导入代码；它不覆盖上述最新等价调整，因此不能将其描述为当前文件树上的完整回归。验证 agent 未运行 Git 命令，未修改产品或测试。
