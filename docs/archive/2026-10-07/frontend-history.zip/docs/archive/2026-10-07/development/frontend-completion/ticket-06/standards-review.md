> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 06 票 Standards 审查

- 基点：`c7931c2779e67d9437a2b1aec8ebfd668f33c093`；最终核对包含 `conversation-state.ts` 最新 4 行状态标记。
- 审查模型：调度显式指定 `gpt-6-luna / max`（部署内部 SKU 未额外披露）。
- 规范来源：`AGENTS.md`、`frontend/design.md`；未发现额外 CONTRIBUTING/STANDARDS/子目录 AGENTS 规范。
- 已读完整验证上下文、五个 tracked diff 文件与五个新增 frontend 源/测试文件。只读命令：`git status --short`、`git rev-parse c7931c2779e67d9437a2b1aec8ebfd668f33c093`、`git log c7931c2779e67d9437a2b1aec8ebfd668f33c093..HEAD --oneline`、`git diff --stat/name-status c7931c2779e67d9437a2b1aec8ebfd668f33c093 -- frontend`、`git diff --no-ext-diff --unified=18 ... -- frontend`、对新增文件的 `Get-Content -Raw`。未运行测试；最终验证由指定验证 agent 负责。

## 做得好的

- 原生状态读取后再发带 revision 的可见性事实；前端先订阅后查询并忽略旧 revision。会话 store 集中撤销读取租约，保留本地事实；新增测试走可复用公开 seam。
- `ConversationStore.enter()` 现在在排队前立即置 `history: loading / verified: false`，避免读取开始前继续展示旧发送资格。

## 需要修的

- 未发现违反仓库硬规范的改动；未确认需报告的 Fowler smell。

## 值得讨论

- 新增跨层文件与原生/React 边界相符；测试未增加组件内部钩子。

补充复核：`summaryTarget` 将 thread/run 身份绑定，新目标会撤销旧历史探针，回调会校验捕获的目标身份。
`stopSelection()` 清理目标；新增公开交错测试覆盖慢旧探针被新目标超越后的迟到响应。
未发现硬规范违规或新增确定的 Fowler smell。

最终增量复核：终态恢复在读取并核实 Run 快照后将观察标记为 closed，并清除旧暂停/重试失败状态；这符合 `CONTEXT.md` 的 Run 快照/终态词汇、`frontend/design.md` 的运行观察表达和 `AGENTS.md` 协作规则。
Node 测试用 store 公开快照断言 completed/closed，原生场景检查正常结束且不含“观察已暂停”，未增加内部测试钩子。
只读复核未发现新增硬规范违规或确定的 Fowler smell。

原生流恢复验收将正文子串等待改为工具栏 Run 状态“已完成”且观察正常结束，保留原 20 秒时限和既有断言，并新增最终历史所有消息均为 completed 的检查；这符合 `AGENTS.md` 不放宽断言的规则，也与 `CONTEXT.md` / `frontend/design.md` 区分 Run 终态和正文事实的语义一致。
只读复核未发现硬规范违规或新增确定的 Fowler smell。
