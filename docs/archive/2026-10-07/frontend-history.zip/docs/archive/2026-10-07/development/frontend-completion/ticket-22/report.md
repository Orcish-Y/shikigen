> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第22票：本地命令面板与受限全局快捷键

状态：已验收，2026-10-07关闭第22票。用户授权实现下一票，本轮未执行任何 Git 命令。

## 架构与实现

- [命令投影](../../../../../../frontend/src/command-panel.ts)只读操作名称与已加载会话的显示标题；同名会话保留各自身份，不搜索会话 ID、状态或时间，不请求服务端搜索或批读历史。
- [快捷键判断](../../../../../../frontend/src/workspace-shortcuts.ts)集中平台普通 Cmd／Ctrl 组合、IME／229／组合结束后50ms、repeat 和前景权限；hook注册窗口事件并使用最新动作引用。
- [命令面板](../../../../../../frontend/src/components/CommandPanel.tsx)沿用现有原生 dialog、Geist、Slate／Indigo 和 Phosphor regular 图标。独立搜索、两类结果、区内滚动、禁用原因、初始搜索焦点与方向键选择。
- 工作台共用新建、会话切换、导航及详情动作。创建资格与 pending 共用；新建不清侧栏过滤，切换不清原文草稿、阅读位置，不建立第二条 SSE 或取消其他 Run。
- 手机普通菜单按钮仍默认会话列表；主导航命令与 B 直接进入导航视图。窄屏操作不写桌面导航偏好。
- 命令面板只允许 K 关闭自身，主导航覆盖只允许 B 关闭自身；其他前景拦截全局动作。Esc 只关闭当前层，Tab约束焦点，入口失效时回稳定工作区。
- dialog 显式去除原生最大宽度限制，保持 `min(480px, 100vw - 32px)`。390px内容区实测358px，保留精确断言。
- 修正受影响代码中实体／可调用命名，包括 `resolveSelectedCommand`、`detectShortcutPlatform`、`noShortcutDecision` 及测试回调名称。

## 验证身份与证据

最终验证与双轴审查均使用显式 **gpt-6-luna / max**。产品实现与修复由主 agent 完成；轻量 agent 执行测试、定位失败及保留证据。主 agent 核对原始计数、退出码、请求／事实、Win32几何及截图后收尾。

- [前端验证报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-22/validation/frontend/report.md`）：命令、范围、原始 stdout／stderr／元数据。
- [原生验证报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-22/validation/native/report.md`）：真实 Tauri／HTTP／SQLite／离线 Harness，完整命令、失败、截图及环境边界。
- [Standards 审查](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-22/standards-review.md`）、[Spec 审查](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-22/spec-review.md`）；固定点是 [实施前文件快照（临时产物已清理）](../../../README.md#已清理的临时产物) 与 [文件差异（原始产物已删除）](../../../README.md#已删除的材料)，没有使用 Git。

### 前端与静态检查

| 批次 | 检查 | 结果 |
| --- | --- | --- |
| final-1，命名修正前 | 唯一完整 Node 回归 | 268通过，0失败／取消／跳过／todo |
| final-2，命名修正后 | 命令投影及快捷键两文件 | 13通过，0失败／取消／跳过／todo |
| final-2，命名修正后 | TypeScript、Vite | exit0；类型输出为空 |
| final-3，最后 CSS 宽度修改后 | Vite生产构建 | exit0；28.298s，JS642.05kB／gzip195.04kB |
| final-5，验收脚本纯格式修正后 | 三文件 Ruff check／format --check | exit0；All checks passed／3 files already formatted |

268与13有重叠，不相加。全套发生在纯命名修正之前；最终业务／类型检查后只有CSS和验收脚本取证／格式变化，因此仅补构建、四档取证及Ruff，没有重复整套Node或类型检查。Vite超过500kB的主chunk告警保留，没有提高阈值或隐藏告警。

开发期有一次列表可见恢复的夹具过早断言；等待第二次列表读取完成后修正。它不属于最终批次，仅工具输出留档，不能冒充独立日志。

### 原生批次与失败处理

| 批次 | 实际结果 | 后续处理 |
| --- | --- | --- |
| final-1 | 5项：4通过／1失败／0错误或跳过；50.266s，exit1 | 继承初始化与新夹具重复安装Storage／fetch记录器；主与测试agent分别读源码确认。去除重复初始化，保留次数断言。 |
| final-2 | 5项：4通过／1失败／0错误或跳过；51.418s，exit1 | 单层记录证实只有两笔桌面偏好；390px dialog真实356而非358，主修CSS最大宽度。 |
| final-3 | 四档定向1通过，0失败／错误／跳过；12.587s，exit0 | 修复后宽度480／480／480／358通过。后续发现成功结尾覆盖各档Win32布局记录，属于取证缺口，未改算失败。 |
| final-4 | 四档取证定向1通过，0失败／错误／跳过；12.124s，exit0 | 每档保留layout；产品、所有断言与final-3一致。 |
| 既有第21票菜单回归 | 1通过，0失败／错误／跳过；17.232s，exit0 | 过滤、分页、列表位置、聊天锚点、单前景和焦点保留。 |
| 既有第04票原文／IME／重启回归 | 1通过，0失败／错误／跳过；13.756s，exit0 | 已保存用户正文完全保留首尾空白／缩进；原生重启startup_id变化，草稿恢复。 |

**五个本票唯一场景分批各有最终通过证据**：本地搜索、创建pending、迟到历史／运行切换／详情、IME与确认保护采用final-2；四档采用final-4。另有两项既有回归通过。不能累加重跑为更多唯一用例，也不声称最后单批5／5或7／7。

final-4后的Ruff首次check报8条E501，format --check通过；主仅拆长字面量和嵌入JS空白，最终final-5两项通过。原失败日志保留。环境切换曾中断最后构建准备，0字节输出另存为interrupted-preparation，没有有效构建执行结果，不算构建失败或通过。

### 四档实机与公开事实

| CSS内容区 | dialog宽度 | DPR／DPI | Win32 client物理像素 |
| --- | ---: | --- | --- |
| 1440×900 | 480px | 1.5／144 | 2160×1350 |
| 1280×800 | 480px | 1.5／144 | 1920×1200 |
| 1024×768 | 480px | 1.5／144 | 1536×1152 |
| 390×844 | 358px | 1.5／144 | 585×1266 |

各档Window／Client rect和DPR记录于 [final-4 result.json（原始产物已删除）](../../../README.md#已删除的材料)。桌面偏好累计只有 `true／false` 两次，1024与390未追加；repeat不多写。主已查看长列表、禁用创建、桌面／平板及390截图，确认沿用原稿色彩、字体、图标、间距和行式布局。截图仅WebView内容，不含原生窗口边框。

公开请求记录包含路径、method和URL.search；本地搜索时 `GET /api/threads` 仅有分页limit／cursor，不带搜索参数，不批读历史或增加SSE／POST。键盘defaultPrevented在宏任务采集，首轮过早微任务字段不用于结论。详情替换、迟到创建与历史、未匹配Enter、取消／内容前景保护、过滤及原文草稿有公开动作与真实事实证据。

## 六条验收对应

| 验收条件 | 实现与证据 |
| --- | --- |
| AC1 本地搜索、约480px、独立过滤和内部滚动 | 命令投影单测；final-2本地搜索／长列表；final-4四档宽度 |
| AC2 可用项方向键、Enter／Esc、IME／repeat、禁用与无匹配 | 两文件13项；final-2本地搜索及IME；final-4Tab／关闭自身 |
| AC3 共享动作资格／pending、前景替换、不清草稿或重复运行 | final-2创建pending／迟到结果、历史切换／详情；请求及草稿／锚点 |
| AC4 普通输入可用，平台普通组合，前景与输入法保护 | 快捷键单测；final-2中文IME与确认；final-4草稿／侧栏输入K、K／B只关自身 |
| AC5 当前层Esc、Tab及返回焦点，窄屏不写桌面偏好 | final-2取消／内容Esc；final-4四档焦点／偏好；第21票菜单回归 |
| AC6 公开动作和真实Tauri专项 | 五个唯一场景分批证据、两项既有回归、Win32窗口／DPI／截图 |

## 审查

Standards最终产品／测试快照14文件1470行：**0硬性违规，1项低风险判断性重复观察**。Overlay键盘关闭有IME／repeat守卫，原生cancel始终关闭；分别处理符合事件差异，未增加额外布尔参数helper。

Spec最终六条验收均符合，未决遗漏／错误实现／范围蔓延为0。历史390px宽度缺陷已修复；原生证据完成后解除此前验收阻塞。主已逐项核对结果与双轴报告，将本票标记done、已验收。

双轴审查快照为14文件1470行；之后仅关闭票据及同步索引／报告，最终文件差异为15文件1511行。产品与测试源码没有继续变化，未重复已通过的验证。

## 覆盖边界与后续

- 本票是Windows真实Tauri WebView2、真实HTTP／SQLite及离线Harness；中文输入为CDP imeSetComposition／insertText加明确229／isComposing事件，repeat为可信WebView按键事件。**没有验证物理键盘、OS候选面板或macOS原生Cmd输入**；Mac映射只有单元测试。上述物理输入、系统IME、原生边框与全流程联合验收归第23票。
- 无后端／Rust产品、API、依赖或配置变更，未重复其完整套件。不要把本票通过等同于全仓库所有测试通过。
- 既有审批结算／环境退出及IME超时needs-triage记录保留；旧IME再次隔离通过不证明历史根因已解决。
- 只完成本票；第23票尚未开始。本轮没有暂存、提交、切换分支或执行任何Git命令。
