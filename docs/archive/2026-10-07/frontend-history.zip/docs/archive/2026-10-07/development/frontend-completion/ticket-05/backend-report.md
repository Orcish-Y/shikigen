> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 05 票后端验证报告

日期：2026-10-05（Asia/Shanghai）  
执行模型：`gpt-6-luna / max`  
工作目录：`C:\code\shikigen-agent`  
范围：公开 HTTP、恢复、Run 观察、`ty` 类型检查、完整 Python unittest。未运行前端构建或 native 验收；未改产品代码、正式测试或票据状态。

## 结果

| 检查 | 实际结果 | 退出码 | 原始日志 |
| --- | --- | ---: | --- |
| `test_server.py` 公开 HTTP | 17 通过，0 失败，0 跳过 | 0 | [backend-server.log（原始产物已删除）](../../../README.md#已删除的材料) |
| `test_recovery.py` | 11 通过，0 失败，0 跳过 | 0 | [backend-recovery.log（原始产物已删除）](../../../README.md#已删除的材料) |
| `test_run_observation.py` | 9 通过，0 失败，0 跳过 | 0 | [backend-observation.log（原始产物已删除）](../../../README.md#已删除的材料) |
| `ty check app packages/harness` | All checks passed | 0 | [backend-ty.log（原始产物已删除）](../../../README.md#已删除的材料) |
| 完整 unittest（单次） | 291 项：290 通过、0 失败、0 错误、1 跳过；运行 358.668 秒 | 0 | [backend-full-suite.log（原始产物已删除）](../../../README.md#已删除的材料) |

各专项是完整套件之外的定向运行，其计数不与完整套件相加。完整套件唯一跳过项为 `test_symlink_data_and_parent_are_rejected`，日志说明 Windows symlink privilege 不可用。

## 命令

以下命令均在仓库根目录 `C:\code\shikigen-agent` 执行，Python 命令均显式使用 UTF-8：

```powershell
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_server.py -v
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_recovery.py -v
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_run_observation.py -v
.venv/Scripts/ty.exe check app packages/harness
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v
```

每条命令的测试输出及实际进程退出码均保存在对应日志末尾的 `COMMAND_EXIT` 行。

## 已知失败核对

第 04 票留下的审批清理等待问题记录于 `.scratch/approval-cleanup-test-timeout/issues/01-approval-resume-settlement-timeout.md`：先前完整回归为 291 项中 289 通过、1 跳过、1 错误，两个隔离复现也超时。本轮完整套件中的同一用例 `test_waits_for_previous_cleanup_and_survives_caller_cancellation` 标记为 `ok`，完整套件也以退出码 0 通过。因此这次没有复现旧错误；旧记录所述运行仍是历史证据，本次通过不能确定该历史错误的根因，也不代表旧问题已完成调查。验证子 agent 未修改旧问题记录；主 agent 已追加本轮复核结果，保留 needs-triage 状态和原始失败证据。

测试日志中的 `invocation_lost`、`approval_state_corrupt`、模拟 `JSONDecodeError` 等异常输出均出现在对应测试 `ok` 前，是错误路径测试日志，不是 unittest 失败。完整汇总及退出码以完整日志末尾为准。

## 环境与覆盖缺口

- 所有命令均在默认工作区权限下完成，无需请求提升权限；未操作共享的 5173、9238、45200 端口或 native 窗口。Recovery crash matrix 和 unittest 启动器均正常退出。
- 当前有 1 项因 Windows symlink 权限跳过，未覆盖该平台条件下的 symlink 拒绝路径。
- 此报告不覆盖前端 UI/native 实机行为、Node 前端套件、TypeScript 前端检查或构建；这些由前端验证者执行。
