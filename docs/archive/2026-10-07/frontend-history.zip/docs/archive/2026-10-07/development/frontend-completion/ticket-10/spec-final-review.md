> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 10 最终 Spec 审查

## 审查范围

- 审查模型：`gpt-6-luna / max`。
- 工作目录：`C:/code/shikigen-agent`；基准：`d7862fb50a7c5654661ca6d8967195d863c2d80e`。
- 依据：Ticket 10 八条验收条件、PRD §§10–11、`frontend/design.md`、`tickets/003-approval-cancel.contract.md`，以及最终工作区相对基准的产品和测试改动。
- 只读审查；未运行功能测试、GUI 或构建。验证结果来自交接及验证报告；审查者没有把未完成的检查计作通过。

## 做得好的

- **AC 1–3：**`AIContent` 对新 AI 消息写出 `generation_status`，旧省略值规范为 `complete` 并参与幂等比较。正文缓冲按 `(thread_id, run_id)` 持有；取消与事件接入互斥，保留 message ID、预留 seq、拼接顺序和空白。取消正文、生命周期、Run 终态及暂停 Run 的审批失效在同一持久事务提交，之后才封口、广播及请求协作停止。正常结算也使用同一接入锁；回滚不会先清空缓冲。新增后端测试覆盖首事件窗口、取消／完成竞争、重复事实、回滚、暂停后取消、断开请求及 HTTP 结果与重开历史。
- **AC 4：**取消目标带有 thread、run 和启动租约；确认时再次检查当前身份、状态和资格。原生 dialog 使用既有 Overlay，初始焦点为“继续运行”，确认文案说明已发生和已启动工具操作的边界；关闭、Esc、遮罩不发取消请求，隐藏或目标失效时关闭确认。
- **AC 5–6：**取消 POST 与同 Run 写状态互斥；有效的 cancelled／completed／error 快照直接收敛到真实终态。身份异常、损坏或非终态响应进入有界 GET 核实，服从 Retry-After，不自动重发 POST。AbortController 只管理客户端请求生命周期，取消行为仍调用既有 cancel API。
- **AC 7：**终态按 Run 补读一次消息，合并完整事实并替换已确认预览；重复终态通知不会重复补读。失败时保留现有预览和终态，并提供手动读取。中止原因显示在正文外，预览复制和导出仍保持各自边界。
- **AC 8：**后端和前端专项代码包含票据列出的竞态及失败场景；native 验收包含取消确认、未知结果、暂停审批失效、隐藏／自然终态等真实窗口路径。最终 native 联合批次尚未取得结果，故本条目前只能确认覆盖设计，不能签作验收通过。

## 需要修

当前没有未解决的硬性 Spec finding。审查过程中的两项 P2 均保留如下历史：

1. **[P2，已修复] 首事件未与取消事务封口互斥。** 首次审查时，取消前尚无预览状态会留下竞态，迟到 delta 或完整 Graph 消息可能在取消后进入。`RunEventIngestor.cancel` 现先为该 Run 建立状态并持锁；门控专项覆盖 delta 和完整消息两条首事件路径。验证报告记载该专项 10 项通过。
2. **[P2，已修复] 取消确认没有显示所属会话。** `tickets/003-approval-cancel.contract.md` §8 要求确认弹窗展示所属会话。首次最终复核发现 UI 只有通用标题和副作用文案。现由 [App.tsx](../../../../../../frontend/src/App.tsx) 按捕获的 `cancelTarget.threadId` 显示会话名称；[cancel_partial_acceptance.py](../../../../../../frontend/src-tauri/tests/cancel_partial_acceptance.py) 断言弹窗会话名与当前工具栏会话名一致。按捕获目标查找可避免弹窗展示当前选择而非确认目标。此测试断言尚待最终 native 批次运行。

## 值得讨论

- **启发式，非硬性违规：**终态集合在 `App.tsx`、`Conversation.tsx`、`backend-client.ts` 等处重复列出，而 `run-projection.ts` 已有 `terminalRun` 谓词。可在后续维护时统一，当前不影响规格匹配。
- **覆盖观察，非硬性 finding：**1/64 CSS px 的几何抖动被视为同一布局，锚点位移 1 px 仍可区分；`useChatReading.ts` 仅在差值大于 0.5 px 时写 `scrollTop`。新增 Node 断言覆盖几何判定，没有放宽既有断言。该阈值可能有意忽略小于 0.5 px 的真实滚动；DOM 写入和原生滚动行为仍应由 Ticket 09／最终 native 回归证据确认。
- **范围判断：**没有无关功能扩张。阅读位置容差是与当前滚动回归相邻的窄修复；第 11 票失败正文、第 12 票完整审批 UI、第 23 票多尺寸、物理键盘及 IME 联合验收均不计入本票缺项。

## 验证状态与限制

- 本审查未执行测试、GUI、类型检查或构建。
- 后端报告：本票专项 10/10 通过；全量 301 项为 299 通过、1 错误、1 环境跳过。错误仍是历史 `test_approval_resume.ApprovalResumeTests.test_waits_for_previous_cleanup_and_survives_caller_cancellation` 超时（needs-triage）；跳过项因 Windows 符号链接权限不可用。不能称全量回归通过。
- 前端验证报告记录过 133 项 Node 测试通过，以及 TypeScript 和 build 通过。随后主 agent 报告更新后的 Node 套件 134 项通过；所属会话文案修复后，主 agent 报告冻结源代码的 TypeScript、build、11 项 Python Ruff check/format 和 5 个测试／夹具 ty 均通过。以上均为验证代理／主 agent 提供的结果，不是本审查者重新执行的结果。
- 首轮 23 项 native 批次为 14 通过、8 失败、1 错误，失败涉及测试注入时序、旧宽泛 URL 计数和旧滚动用例诊断等；首轮结果不能视为通过。最终修订后的 23 项 native 联合批次在本报告定稿时仍在执行。须等该批结果并核对截图／请求／持久事实后，才能完成 AC 8 的实机验收判断。

## 审查依据与命令

先读取仓库 `AGENTS.md`，再读取 Ticket 10、implementation index、PRD §§10–11、前端设计规范、审批与取消契约、既有 Spec 审查和验证交接。检查基准差异、最终修复和测试变化所用命令包括：

```text
rg --files docs/wayfinder | rg "(frontend-completion|10-cancel-partial-message|tickets/003-approval-cancel\.contract)"
git status --short
git diff --stat d7862fb50a7c5654661ca6d8967195d863c2d80e
git diff d7862fb50a7c5654661ca6d8967195d863c2d80e -- <changed product and test paths>
git diff --unified=0 d7862fb50a7c5654661ca6d8967195d863c2d80e -- frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/visibility_polling_acceptance.py frontend/tests/chat-reading-position.test.mjs
rg -n "(async )?def test_|^test\\(" tests/test_cancel_partial_message.py frontend/tests/run-cancel.test.mjs frontend/src-tauri/tests/cancel_partial_acceptance.py
```

命令均在 `C:/code/shikigen-agent` 进行；没有调用任何测试命令。

**Spec 计数：0 项未解决硬 finding，2 项已修复 P2；AC 1–7 代码映射符合，AC 8 最终 native 验收待结果。**
