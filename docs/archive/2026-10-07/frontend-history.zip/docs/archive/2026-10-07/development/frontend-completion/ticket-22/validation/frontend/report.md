> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第22票前端验证报告

## 验证身份与范围

- 实际模型：`gpt-6-luna`，推理强度 `max`。
- 工作目录：`C:\code\shikigen-agent\frontend`，PowerShell。
- 验证对象：本地命令面板与受限全局快捷键（第22票）。最终命名修正涉及纯命名，没有改变功能逻辑。
- 按要求未执行任何 Git 命令。此报告只记录前端 Node、TypeScript 与 Vite 验证；原生验收由主 agent 串行安排。

## 执行结果

| 批次 | 命令 | 结果 | 耗时 |
| --- | --- | --- | ---: |
| final-1，命名修正前的完整前端回归 | `node --import tsx --test tests/*.mjs` | exit 0；268 tests、268 pass、0 fail、0 cancelled、0 skipped、0 todo | 39.616s |
| final-1，命名修正前类型检查 | `node node_modules/typescript/bin/tsc --noEmit` | exit 0；stdout/stderr 为空 | 18.487s |
| final-1，命名修正前生产构建 | `node node_modules/vite/bin/vite.js build` | exit 0；构建完成 | 43.205s |
| final-2，命名修正后专项回归 | `node --import tsx --test tests/command-panel.test.mjs tests/workspace-shortcuts.test.mjs` | exit 0；13 tests、13 pass、0 fail、0 cancelled、0 skipped、0 todo | 0.606s |
| final-2，命名修正后类型检查 | `node node_modules/typescript/bin/tsc --noEmit` | exit 0；stdout/stderr 为空 | 12.624s |
| final-2，命名修正后生产构建 | `node node_modules/vite/bin/vite.js build` | exit 0；构建完成，dist 对应命名修正后的源码 | 33.626s |
| final-3，CSS-only 原生验收修正后构建 | `node node_modules/vite/bin/vite.js build` | exit 0；Vite 7.3.6、4893 modules；CSS 75.36 kB，JS 642.05 kB；保留 chunk >500 kB 警告 | 28.298s |

final-1 的 268 项完整回归发生在命名修正之前；final-2 对修正影响到的两个测试文件做了专项复验，并运行类型检查与构建。final-3 在后续只改 CSS 的 `max-width` 约束后重新构建。此后原生测试夹具补充了测量结果留存，并做了不改变语义的纯格式换行；没有再改产品代码。批次数量不相加，也没有把全套 Node 回归描述为最后一次产品源码上的重复执行。

## 专项覆盖

- `command-panel.test.mjs`：只投影已加载会话标题和动作名称；搜索不匹配 ID、状态或辅助信息；同名会话保留各自身份；不可用项跳过、选择环绕、无匹配不默认新建；创建资格覆盖未就绪、隐藏工作区、列表读取与创建 pending，阻止重复 POST。
- `workspace-shortcuts.test.mjs`：macOS 与其他平台的 Cmd/Ctrl 映射；普通修饰键边界；按住不重复执行；其他前景模态阻断后台动作，只有对应命令面板 K／导航面板 B 可关闭自身；IME composing、legacy keyCode 229、compositionend 后 50ms 窗口。
- 开发期曾有一次夹具在列表可见状态恢复前过早断言的失败；等待第二次列表读取完成后修正夹具。该记录不属于 final-1 或 final-2 批次，两批日志中的最终执行均无失败。

## 构建告警

final-1、final-2 与 final-3 的 Vite 构建均 exit 0，但保留了 Vite 的 `Some chunks are larger than 500 kB after minification` 告警。final-3 主 JS chunk 为 642.05 kB，gzip 为 195.04 kB；CSS 为 75.36 kB，gzip 为 33.18 kB。告警没有被隐藏或抑制。

## 证据文件

每条命令的完整 stdout、stderr 与元数据均独立保存于本目录：

- `final-1-node-tests.stdout.log`、`final-1-node-tests.stderr.log`、`final-1-node-tests.meta.txt`
- `final-1-tsc.stdout.log`、`final-1-tsc.stderr.log`、`final-1-tsc.meta.txt`
- `final-1-vite-build.stdout.log`、`final-1-vite-build.stderr.log`、`final-1-vite-build.meta.txt`
- `final-2-node-tests.stdout.log`、`final-2-node-tests.stderr.log`、`final-2-node-tests.meta.txt`
- `final-2-tsc.stdout.log`、`final-2-tsc.stderr.log`、`final-2-tsc.meta.txt`
- `final-2-vite-build.stdout.log`、`final-2-vite-build.stderr.log`、`final-2-vite-build.meta.txt`
- `final-3-vite-build.stdout.log`、`final-3-vite-build.stderr.log`、`final-3-vite-build.meta.json`

一次被中断的构建准备阶段留下的零字节日志已单独命名为 `final-3-vite-build.interrupted-preparation.*.log`，没有作为构建结果计算。

## 尚未由这些前端命令覆盖

Node 单元测试不渲染 DOM，也不证明实际窗口交互。仍需原生/实机验收确认：dialog 尺寸及长列表区内滚动、搜索初始焦点、Tab 约束与可见焦点、关闭后的有效焦点返回、Esc 仅关闭当前层、页面动作不重建 SSE／不取消其他 Run／不清草稿、迟到切换边界、导航偏好与四档视口，以及真实中文输入法候选和按键长按行为。上述项目不计作已通过，交由主 agent 的原生专项取得证据。
