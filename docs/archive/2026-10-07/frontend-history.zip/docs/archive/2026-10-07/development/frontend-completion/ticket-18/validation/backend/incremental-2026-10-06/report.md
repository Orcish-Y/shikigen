> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 18 票后端增量验证

日期：2026-10-06。模型：`gpt-6-luna`，推理强度 `max`。工作目录：`C:\code\shikigen-agent`，Python 3.12.13，PowerShell。

本轮仅针对 `app/routes/run.py` 的不兼容事件投影处理和 `tests/test_run_event_queries.py` 新增第 5 项；未改产品代码或断言，也未重跑已通过的完整 333 项后端回归。原始完整回归证据保留在上级目录的 [`report.md`](../../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/backend/report.md`） 和 [`command-results.json`（原始产物已删除）](../../../../../../README.md#已删除的材料)。

## 结果

| 命令 | 结果 | 统计 |
| --- | --- | --- |
| `.venv/Scripts/python.exe -m unittest discover -s tests -p test_run_event_queries.py -v` | 通过，退出码 0 | 5/5 通过、0 失败、0 错误、0 跳过；2.429s |
| `.venv/Scripts/ruff.exe check app/routes/run.py tests/test_run_event_queries.py` | 通过，退出码 0 | 2 个文件 |
| `.venv/Scripts/ruff.exe format --check app/routes/run.py tests/test_run_event_queries.py` | 通过，退出码 0 | 2 个文件已格式化 |
| `.venv/Scripts/ty.exe check app/routes/run.py tests/test_run_event_queries.py` | 通过，退出码 0 | 2 个文件 |

`.venv/Scripts/ruff.exe` 与 `.venv/Scripts/ty.exe` 均存在并成功运行。逐命令退出码、模型、cwd、摘要和 stdout/stderr 路径见 [`command-results.json`（原始产物已删除）](../../../../../../README.md#已删除的材料)；原始日志在本目录的对应 `*.stdout.txt`、`*.stderr.txt`。

## 新增验收覆盖

契约 §7 要求无法通过协议校验的事件只作为读取问题的只读原文，不接入已确认事件。新测试用真实临时 SQLite 事务插入未来 schema 的 lifecycle 事件，连续两次请求 events 均返回 500、`Cache-Control: no-store`，detail 包含 `code=invalid_run_event` 和完整 `raw_event`，响应不含 `data`。每次失败后，运行快照和已提交事件历史均与查询前完全相同，证明该分支不写入或恢复 Run。

同一专项还重验原有成功 JSON/SSE 投影相等、排序、归属 404、SQLite BUSY/CORRUPT 错误映射、取消后的 seq 空洞，以及暂停态纯读。成功 JSON 与 SSE 结构未回归。SQLite CORRUPT 驱动注入会产生预期的 `committed_query_failed` traceback，测试仍通过。

本轮只执行目标 ASGI/SQLite 专项与三项静态检查，不包含网络端口、桌面或完整后端回归；原报告中的历史覆盖与限制继续适用。
