> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 09 Home 失败诊断（Ticket 10 回归批次）

**执行模型：** `gpt-6-luna / max`。只读检查源码、历史报告和失败证据；未启动 Tauri、未占用 GUI/端口。按 root 后续指示只执行一条 Node RED 回归；没有修改源码、测试或旧证据。

## 证据

三个旧 09 原生用例都在 `ChatReadingAcceptance.home()` 的“滚到顶部”等待超时（`frontend/src-tauri/tests/chat_reading_acceptance.py:49-66`）。ticket-10 副本最后采样均为 `following=false`，但仍在消息中段：accepted-send `top=5117.33`（锚点 message seq 5）、approval `top=3057.33`（seq 3）、switch/hide `top=5031.33`（seq 5）。证据路径为 `.scratch/frontend-completion/ticket-10/native/09-chat-reading/<case>/failure-evidence.json`；按交接只读取了 `id/top/following` 几何字段，没有展开正文。

approval 用例在 `chat_reading_acceptance.py:284-289`、`tests/desktop_reading_fixtures.py:33-50` 中先等模型输出长正文，再于开放 `allow-reading-stream` 门控前调用 Home。该样例此时没有终态 `runMessages` 补读；对应资源记录也没有 `/runs/<id>/messages`。因此迟到终态补读不能解释三例共同失败，尽管它可能干扰另外两例。现有失败 JSON 只有资源 URL，没有 Home 期间的事件/时间序列。

## 排序假设与可证伪预测

1. **锚点测量抖动被判成布局变化（较强候选，局部已复现）。** `sameTimelineLayout` 对 `anchor.top` 使用精确 `===`（`frontend/src/chat-reading-position.ts:17-21`）；测量值由 DOMRect、容器 top 与 `scrollTop` 相加减得到（`useChatReading.ts:5-11`）。Home 期间若 1/64 px 量化抖动令布局比较失败，`update()` 会清除 `intentUntil`（`useChatReading.ts:53-63`），随后 reconcile 可能把滚动恢复到旧锚点。预测：原生 trace 会看到小于 0.5 px 的 anchor delta、`sameTimelineLayout=false` 及其后的 `intentUntil=0`，并先于 Home 停止。
2. **近似相等的 scrollTop 写入打断原生滚动（可能但尚未证实）。** `apply()` 仅用严格不等判断后设置 `element.scrollTop`（`useChatReading.ts:40-44`）。若同一目标因亚像素尾差不同，赋值可能竞争 Home 动画。预测：停滞前能观察到 `target !== current`、`abs(delta)<0.5` 的 setter；加容差后同一原生用例到顶。纯 JS 算术探针显示，近邻锚点的往返通常精确相等；仅特定远距离双精度输入出现约 `4.55e-13 px` 差异，不能证明 WebView setter 会取消动画。
3. **迟到内容/其他布局更新（局部候选）。** 前两例的资源列表确有运行消息读取，但没有时间戳；approval 例没有终态读取且门控阻止后续 delta，故不是共同解释。预测：若它是前两例附加因素，带时间戳的请求与 DOM/layout trace 会在它们 Home 停止前出现，approval 例则无该事件。

历史上 `ticket-09/diagnosis.md:49-53` 记录了同形失败：阅读操作行缩小视口曾清除 Home 手势；后续加入 `controlResize` 保留逻辑。`ticket-09/native-report.md:68` 记载最终冻结构建的三个 09 用例通过。当前错误重现尚无单帧 trace，不能把上述任一候选宣布为 Home 根因。

## 已运行的快速信号

在 `frontend` 执行：

```text
node --import tsx --test --test-name-pattern=亚像素测量抖动不算布局变化 tests/chat-reading-position.test.mjs
```

结果 exit 1：1 项失败、0 通过、0 跳过；`chat-reading-position.test.mjs:112` 的 `sameTimelineLayout(previous, jitter)` 实际为 `false`，预期 `true`。原始日志：`logs/reading-jitter-red.log`。这验证 comparator 确实将测试构造的 1/64 px 锚点抖动当作布局变化，但不单独证明原生 Home 路径触发了同一序列。未运行原生窗口，因而没有完成 Home 的红色实机反馈环。

## 下一步诊断点

frontend nativeagent 的临时 trace 应对同一次 Home 记录：`keydown` 的时间/目标/默认是否取消；`intentUntil`、`controlResize`、`sameTimelineLayout`、`movedBeyondLayoutClamp`；旧/新 anchor top 差值；`apply` 的 target/current/delta 及 setter 是否执行；每次 scroll 的 `scrollTop`。另给运行消息 GET 记录完成时间。先用 trace 判断假设 1 或 2，再一次只改变 comparator/apply 容差验证。当前只确认了 comparator 的 RED 回归，未确认原生根因。
