> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第17票实施与验收

日期：2026-10-06。票据：[查看当前运行详情与真实累计用量](../../../../../wayfinder/frontend-completion/implementation/17-run-details-usage.md)。当前状态：代码、前端验证与七个唯一原生场景完成，主 agent 核对后验收。

## 实现

- 后端现有纯读 RunSnapshot 已满足接口需求；本票没有新增端点、后端产品、Rust 产品、权限或依赖。
- BackendSession 的 RunUsage 接纳实际 calls 与 by_model；共享 RunProjection 记录执行阶段、用量组、结果组和状态的确认版本。SSE 省略保留，明确 null 表示未知；审批继续或新 GET 观察先撤销旧结算结论，保留累计值。
- ConversationStore 独立协调快照，进入会话／新 Run 自动读取，详情刷新复用在读请求，适用 SSE 并行。旧阶段／旧字段响应不清新事实，同 updated_at 可补晚量。有效取消立即确认结果；取消前 GET 不冒充取消后核实，边界信号至多合并一次串行补读。读取失败保留内容与输入，不写成执行错误。
- App 的工具栏、会话栏摘要和命令入口共用详情。切会话关闭，新 Run 保持详情但清除旧展开及只读选择。详情按运行信息／本次运行用量／观察连接分区，沿用400px抽屉和窄屏底部面板、既有字体颜色边界。
- 展示真实 ID、中文状态、错误与 code、服务端时间和完整 UTC 原值；保留微秒供复制，未知结束时间不推造。本 Run lifecycle 说明可在错误快照未取得时先只读显示，注明来源，不混另一 Run 或读取错误。
- 未知与零分开，数值直接展示，不重算总量，不补模型／调用次数。模型默认折叠，长字段可换行，完整内容在同一前景子视图查看，返回保留位置与焦点。

第18票事件查询与审批历史、第19票有限定时结算核实未实施；当前单次边界补读和共享请求入口为后续票据提供基础。

## 开发与修复

沿用已确认的 BackendSession HTTP／SSE、ConversationStore公开事实、真实 Tauri 操作和只读呈现边界。第一项新用例先失败：进入 running 会话未读取快照（0次，期望1次）；接通独立快照后通过。开发期间的定向检查是快速检查，不计作子 agent 最终批次。

完整前端回归发现隐藏期间完成的运行恢复仍显示 running，修复历史状态接纳后原断言通过。规格审查补齐 GET 首帧前发布待确认状态、取消 POST 旧 null 的字段保护、取消前省略字段 GET 的串行新核实及 UTC 微秒保留。没有删除测试或放宽功能断言；三个既有测试文件仅调整新增进入快照所需的准确请求次数和异步等待点，保留原状态／审批／输入要求。

命名按AGENTS.md收敛：shouldPreserveStatus、isCompact、snapshotRead、backend_snapshot、cancel_snapshot、startedAt／finishedAt和具体响应回调。新Python测试夹具经格式整理；早期lint错误不宣称通过。

原生零用量探针的真实值、ID和微秒UTC复制已通过后，发现夹具把client rect浮点宽度400.0000305175781与整数400严格比较。改为严格核对computed CSS宽度`400px`，同时保存rectWidth与devicePixelRatio；产品样式未改，设计要求未放宽。此前CDP握手ERROR及宽度FAIL、此次编辑后一次格式检查失败均保留，由子agent按新批次复验。

后续六项原生批次有四项通过、两项失败。未知用量首次响应被hold时应显示“正在读取用量”，夹具却期待响应交付后的“暂无用量数据”；修正前者且保留release后未知与pending断言。Markdown旧回归受DPI=1.75量化，computed焦点线宽1.71429px；尝试读取outlineWidth长属性时因含var的简写未展开取得空数组，该次复验亦失败。最终直接核对完整CSS声明`2px solid var(--accent)`、offset3px与既有按钮/返回后完整computed样式精确一致；原功能、颜色、可见性和焦点断言保留，并在断言前记录样式。两项分别有新批次通过证据，既有通过用例不重复。失败日志显示编码与UTF-8 JSON不同，真实UI中文正常，不将日志显示问题归为产品编码错误。

## 最终验证分工与结果

最终验证子 agent 均显式 `gpt-6-luna / max`、无历史继承，收到票据、规格、实现、命令、依赖、权限、共享端口和覆盖风险。主 agent 实现与修复，子 agent 执行和报告；Standards／Spec分别静态检查。

| 验证 | 实际结果 | 证据 |
| --- | --- | --- |
| 完整 Node，早期源码 | 195项：194通过、1失败，0跳过／取消 | [前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-17/validation/frontend/report.md`）、原始node日志 |
| 隐藏恢复修正后3文件 | 37通过，0失败／跳过／取消 | targeted-after-fix日志 |
| 取消版本保护后6文件 | 70通过，0失败／跳过／取消；后续产品变化前的基线 | final-targeted日志 |
| 最新产品6文件 | 72通过，0失败／跳过／取消 | final2-targeted日志，14.21秒 |
| 最终 TypeScript／构建 | exit0；主chunk606.40kB／gzip184.69kB，500kB提示保留 | final2-tsc／final2-build日志与meta |
| 真实 Tauri，零用量修正后 | 1通过，0失败／错误／跳过 | native-probe-fix-1，15.328秒 |
| 真实 Tauri，剩余6项首次 | 4通过、2失败，0错误／跳过；未知读取文案及Markdown DPI夹具失败 | native-remaining-1，94.229秒 |
| 真实 Tauri，两项定向复验 | 1通过、1失败，0错误／跳过；未知通过，Markdown长属性读取失败 | native-recheck-1，24.858秒 |
| 最终 Markdown 实机复验 | 1通过，0失败／错误／跳过 | native-markdown-recheck-1，10.675秒 |
| Python静态 | 最终4文件Ruff check／format通过；最后Markdown修正后该文件再次通过 | [原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-17/validation/native/report.md`）、原始日志及meta |
| Standards | 0硬性问题，2个Fowler启发式建议 | [报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-17/standards-review.md`） |
| Spec | 0遗留规格偏差／范围外行为／错误实现 | [报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-17/spec-review.md`） |

完整套件修复后未重复；原失败保留，已包含于最新72项。37／70／72有重叠，不能相加为通过总数。最后只对测试resolver作等价改名，没有重复行为测试。主agent已核对前端原始日志、meta的退出码／时长、合法JSON、构建产物说明与两轴报告。

五个本票原生场景与两个既有回归，共七个唯一用例分别有最新源码通过证据；不声称某次单批7／7全绿。早期普通CDP握手ERROR、提升权限的几何FAIL及后续三个夹具FAIL原样保留。模型为离线真实Graph回调，HTTP／SQLite／Run结算真实执行；非外部供应商账单。复制测试在clipboard外部边界记录正文，不声称实际OS剪贴板操作。截图为真实Tauri WebView截图，不能代替窗口边框或物理输入验收。静态复核中的“复验中”按当时进度记录；最终以原生报告为准。期间额度中断后由用户“继续”恢复，没有将未执行检查算通过。

主agent核对了零用量原始UTC微秒与400px/DPR=1.75、两模型累计15/12/27与calls=2、第二Run身份、取消快照pending=true到相同updated_at的false/0tokens、未知用量的单条观察请求、失败完整只读正文及Markdown三组焦点样式。未修改后端／Rust产品，未重复其全套回归。

最终原生报告与command-results.json已由子agent归档并由主agent读取核对。历史12次执行为7通过／4失败／1错误／0跳过，唯一七项各有最终通过证据；清理日志确认9238／45200无监听，原5173仍HTTP200、index396字节。七条验收已勾选，实施索引更新为1–17完成，下一票18待实施。

## 七条验收对应

| 条件 | 核对依据 |
| --- | --- |
| 1 自动快照、复用、不阻塞与保值 | run-details Node专项；unknown原生hold/release；多模型500刷新保值 |
| 2 当前目标与失效 | 公开store切换／隐藏／租约测试；多模型外部第二POST更换目标与新会话拒绝旧GET |
| 3 身份、状态、时间、错误 | 零用量真实快照和完整复制；unknown尚未结束；失败原生正文逐字核对；SSR终态未知时间 |
| 4 真实累计、零／未知与缺项 | 零／unknown／多模型原生；SSR总量不重算、calls未提供与空模型；实际模型完成回调fixture |
| 5 阶段、字段版本与晚量 | Node审批继续、首帧前待确认、旧null保护；取消竞态专项；同updated_at取消晚量原生 |
| 6 现有摘要与分区样式 | RunUsage／RunDetails与styles静态核对；主agent检查零、unknown、失败截图；长模型原文与完整JSON核对 |
| 7 详情与观察独立、单前景 | unknown开关请求记录；多模型/失败单dialog完整视图；工具与Markdown现有实机回归 |

两个Fowler建议为简单四指标平行数组及测试setup名字，属于可读性建议；没有功能或规格偏差，不扩大本票重构。运行事件、有限轮询及物理键盘／IME／窗口边框和多尺寸联合检查分别留在第18／19／23票。

## 用户授权边界

本轮没有执行任何 Git 命令，未暂存、提交、切分支或修改 Git。审查固定点为编辑前副本，见baseline及prepare_review.py产生的review.diff。Markdown旧回归的整份Copy因目标子目录不存在失败；使用修改前工具读取的精确焦点段markdown-focus-before.txt进行该段diff，不声称有整份原始副本。未修改AGENTS.md。
