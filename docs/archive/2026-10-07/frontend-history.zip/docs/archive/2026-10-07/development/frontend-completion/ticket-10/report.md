> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 10 票：取消运行与中止正文保存

当前状态：已验收。全部 8 条核心验收关闭，Standards／Spec 无剩余硬性问题；历史审批结算超时另行保留 needs-triage。

基准：`d7862fb50a7c5654661ca6d8967195d863c2d80e`；当前分支 `master`。

## 实现

- 后端新增 AI `generation_status`，默认完整；历史缺省完整参与幂等比较。取消在一个事务中保存全部已接入的非空未提交正文、运行终态、生命周期和必要审批失效记录；沿用原消息身份、预留顺序及空白，不补造工具调用。
- 预览缓冲按 Run 持有，审批暂停回收执行句柄不丢正文。取消和正常结算都与消息接入互斥，提交成功才封口、发布、通知协作停止；回滚保留可重试正文，迟到片段与根快照不覆盖既有事实。
- Tauri 沿用现有弹窗样式，每次取消先确认，默认焦点“继续运行”。关闭、Esc、遮罩、隐藏及目标失效不取消；确认时重新核实会话、Run、地址租约和操作资格。
- 有效取消快照立即显示真实终态；异常或未知只做有限 GET 核实，遵守 Retry-After，保留手动入口，不自动重发 POST。确认终态后一次补读 Run messages，完整事实替换预览，并在正文外标“因取消中止”；读取失败保留终态和预览，允许手动重读。

接口复用 `POST /api/threads/{thread_id}/runs/{run_id}/cancel`、普通 Run GET 与 Run messages GET；未增加依赖或 Rust 产品代码。

## 验证

最终验证分配给显式 `gpt-6-luna / max` 子 agent。主 agent 负责实现、修复及证据核对。

| 范围 | 当前结果 | 证据 |
| --- | --- | --- |
| 后端专项 | 10 通过，0 失败／跳过；包含首事件前取消与两种结算事务屏障 | [原始日志（原始产物已删除）](../../../README.md#已删除的材料) |
| 后端完整单测 | 最终无原生并行的串行一轮：301 项，300 通过，0 失败／错误，1 Windows 符号链接权限跳过 | [最终日志（原始产物已删除）](../../../README.md#已删除的材料)、[后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/backend/backend-report.md`） |
| 前端完整 Node 单测 | 阅读位置修复后 134 通过，0 失败／跳过／取消 | [日志（原始产物已删除）](../../../README.md#已删除的材料) |
| 前端类型与构建 | 包含最终弹窗会话说明的 `pnpm exec tsc --noEmit`、`pnpm build` 均 exit 0 | [类型命令（原始产物已删除）](../../../README.md#已删除的材料)、[构建命令（原始产物已删除）](../../../README.md#已删除的材料) |
| Ruff、ty | 全部 11 个 Python 文件 Ruff check/format 通过；未变产品范围与最终 5 个测试／夹具 ty 通过 | [Ruff（原始产物已删除）](../../../README.md#已删除的材料)、[格式（原始产物已删除）](../../../README.md#已删除的材料)、[产品类型（原始产物已删除）](../../../README.md#已删除的材料)、[后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/backend/backend-report.md`） |
| 原生 Tauri | 最终单个 runner 串行两组：本票 4＋旧 19＝23 个唯一用例通过，0 失败／错误／跳过 | [命令与 exit（原始产物已删除）](../../../README.md#已删除的材料)、[逐项日志（原始产物已删除）](../../../README.md#已删除的材料)、[原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/native-report.md`） |

专项与完整单测有重叠，不相加；本次未重复运行无产品改动的 Rust 套件，旧票结果不计为本次结果。

最终完整回归原命令为 `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v`，工作目录仓库根；UTC 12:55:43.315–13:01:53.553，exit 0，unittest 359.477 秒。主 agent 核对 10 项取消专项和既有审批结算用例均为 ok。较早 final5 完整回归为 299 通过、1 错误、1 跳过，正式审批隔离两次分别 1 通过／1 错误；[原完整失败](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/backend/full-unittest-final5.log`）、[隔离一（原始产物已删除）](../../../README.md#已删除的材料)、[隔离二](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/backend/approval-timeout-isolated-2.log`）均保留。超时位于既有测试第 258 行，根因未确认，本票也触及结算互斥路径，不能断言与本票无关或仅归因资源争用；[独立问题](../../../../../issues/approval-resume-settlement-timeout.md)继续 needs-triage。最终未复现不等同于修复。

主 agent 已核对最终原始命令、逐项日志和实机证据：[取消确认（原始产物已删除）](../../../README.md#已删除的材料)显示所属会话及默认继续运行焦点；[取消后正文（原始产物已删除）](../../../README.md#已删除的材料)显示独立中止标记；[重开记录（原始产物已删除）](../../../README.md#已删除的材料)保留原始正文、空白和草稿。第 9 票回归的 [Home 与流式阅读记录（原始产物已删除）](../../../README.md#已删除的材料)中 initial／streaming 的 scrollTop 均为 0，切回场景保存和恢复同一锚点及偏移。

原生历史尝试保留：第一批 14 通过、8 失败、1 错误；第二批 19 通过、4 失败。测试注入必须在 BackendClient 绑定 fetch 前安装，审批已提交 AI 内容块需原样比较，事件读取使用真实 Run stream；按钮等待保留原断言，请求计数分开核对 Thread 与 Run messages。三个 Home 用例捕获到应用因亚像素测量变化反复写回 scrollTop；新增 1/64 px 抖动单测先红，产品使用 0.5 CSS px 容差并避免近似相等的 DOM 回写后，三个原生用例均通过。第二批新增首项在进入取消前出现 Failed to fetch，最终未复现，原因未确认。失败尝试的日志、DOM、请求和截图不改算通过，见原生报告。

开发中模拟旧库的 sqlite 连接未关闭，导致 Windows 清理临时数据库报错；已修复，最终 8 项包含该场景并通过，该开发尝试只有交接记录，无独立原始日志。第一次默认根目录 `ty check` 有 474 个诊断，包含历史 scratch 脚本及新增测试曾误用 `self.run` 的类型冲突；测试已改为 `run_id`，产品范围正式检查为 `ty check app packages/harness`。新增测试附带 `--extra-search-path tests --extra-search-path frontend/src-tauri/tests` 检查，Tauri 验收关闭连接前补显式非空断言后通过。原失败日志保留，不将默认根目录检查记为通过。

## Standards

独立审查未发现文档硬性标准违规。记录 1 项可能的 Repeated Switches：多个接口边界重复列举终态集合，可在后续状态层整理中提取共享谓词，属于维护建议。本票状态值由既有 RunStatus 限定，无新增终态，保留当前实现；没有为此添加跨层依赖。完整审查见[Standards 报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/standards-review.md`）。

最终增量审查确认阅读位置容差与两处旧原生测试调整无硬性违规、未弱化断言。几何单测不能替代 Home 的 DOM 行为验证，最终原生批次单独核对；见[增量 Standards 报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/standards-final-review.md`）。

## Spec

原独立审查发现 1 项 P2：取消发生在首事件之前时尚未创建预览 state，迟到首个事件可能继续接入。已统一创建 state 并持锁封口，新增公开竞态测试修复前红、修复后绿；复核无剩余 finding。最终增量审查发现弹窗缺所属会话说明，已按捕获的取消目标显示会话名称，并增加原生断言；只读复核已关闭该项，未发现其他硬性 Spec finding。见[Spec 报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/spec-review.md`）及[最终增量报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/spec-final-review.md`）。

最终审查报告定稿时原生和完整回归仍待结果，其“待验收”是当时状态；后续结果以本报告和原始日志为准。最终 23 项真实 Tauri 已验证会话文案、默认焦点、放弃零 POST、确认取消、未知结果、审批失效与重开正文，AC 8 的原生缺口已关闭。

## 边界

完整正文指取消结算停止接收前后端已经接入的内容。强杀前仅在内存的片段不承诺跨进程恢复；取消不会撤销已发生的工具操作，也不保证已开始的操作立即停止。执行失败的正文保存归第 11 票；正式逐项审批 UI 归第 12 票。

物理输入、系统 IME、多窗口尺寸的联合实机检查归第 23 票。既有审批结算／空宿主环境退出超时的 needs-triage 记录保留，本票经过的回归不替代根因调查。
