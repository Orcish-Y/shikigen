> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 06 票实施与验证交接

工作目录：`C:/code/shikigen-agent`。固定基点：`c7931c2779e67d9437a2b1aec8ebfd668f33c093`，本轮开始工作树干净，禁止任何 Git 写操作。

收尾更新：本票已验收。最终 Node106、Rust23通过；后端291总项（290通过、1环境跳过）；本票最终native1项及旧03/04/05正式native3/4/2项通过。详见[最终报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-06/report.md`），以下历史定向结果与派发约束保留供后续 agent 参考，不能理解为当前仍未执行。前端复用旧agent的运行时仍受限，原生由本轮新建 `gpt-6-luna / max` agent 在当前权限执行；终态显示及旧05精确等待补修均有专项回归。

## 目标与规格

用户授权 `$implement docs/wayfinder/frontend-completion/implementation/index.md 完成下一票`，仅第 06 票。

- `docs/wayfinder/frontend-completion/implementation/06-visibility-polling.md`：六条 AC 全部覆盖。
- `.scratch/frontend-completion/PRD.md` §6（约 221–233 行）、`docs/wayfinder/frontend-completion/tickets/002-run-projection.contract.md` §8、12：显隐、有限恢复和原生桥接。
- `frontend/design.md`：现有原稿风格。本票不加页面或 CSS。
- `AGENTS.md`：主 agent 写产品及修复，最终验证必须显式 `gpt-6-luna / max`，全套与错误路径充分验证；不可放宽测试断言。

预先定稿 seam：BackendClient/BackendSession 真实 HTTP/SSE fetch 边界、宿主状态/可见性公开输入、系统时间、原生 Win32/托盘/真 Tauri 窗口。不得新增组件内部测试钩子。

## What／Why／How

原生 Desktop 增加 `{revision, visible}`。`get_workspace_visibility` 在原生事件循环读取实际主窗状态；`workspace-visibility-changed` 在成功 hide/show 后发现实际值变化才递增发事件。失焦、最小化不等同 hide，窗口操作/查询失败不伪造值。前端订阅先于查询、按 revision 丢弃旧结果，查询失败保留已知值，初次未知 true。

App 层 hook 独立于 Workspace 和 BackendSession 生命周期；ConversationStore `setVisible` 与租约/选择统一协调。隐藏撤销 GET/SSE、等待与轮询，不 cancel 后台；未确认 POST 成 unknown，原文与新草稿保留，无自动重发。ready/show/select 同一轮微任务合并历史定位；后续手动/显式重入仍可新恢复轮次，继续遵守第 05 票 Retry-After。

第一页请求完成后等待 5 秒，无并发同一页轮询；失败保留列表、Retry-After 推迟下一次，不加流式三次重试。显示恢复不清更早页、分页游标、选择或草稿。不同摘要 run_id 通过额外历史 GET 核实，确认新身份前保留原观察，历史确认后统一恢复；同 Run 摘要不会重开已耗尽轮次。晚到旧租约/旧选择响应不能写入。

## 改动文件

- `frontend/src/workspace-visibility.ts`：可见性订阅契约。
- `frontend/src/useWorkspaceVisibility.ts`、`App.tsx`、`useConversations.ts`：Tauri API 绑定和 App 级接入。
- `frontend/src/conversation-state.ts`：visibility、单一页轮询、微任务合并重入、不同摘要历史核实和暂停。
- `frontend/src-tauri/src/desktop.rs`、`lib.rs`：实际原生显隐状态与命令。
- `frontend/tests/workspace-visibility.test.mjs`、`visibility-polling.test.mjs`：13 项新公开行为验证，含 HTTP-date、初次隐藏、R2 慢探针被 R3 撤销、隐藏期间完成后恢复观察文案。
- `frontend/src-tauri/tests/visibility_polling_acceptance.py`：1 项完整原生场景（真实 native close/tray menu，失焦不算隐藏、后台运行继续、隐藏停止读取、显示恢复正文草稿、仅一个发送 POST）。
- 不修改后端产品、CSS、AGENTS、Git；既有原生05用例的全页文本等待改为精确 Run 终态＋观察 EOF，保留原20秒与全部断言并增加历史状态核对，不放宽验收。

## 已有定向结果

TDD 首次缺 visibility 模块失败，首次轮询 1 != 2 失败，setVisible 未定义失败，摘要变化未查历史失败，随后 9 项新测试通过。包含旧分页/恢复的四文件定向 39 项通过（新增尾部边界前）。两次 direct tsc exit0。原生 red：1 项因 `Command get_workspace_visibility not found` 失败，原日志 `native-red.log`。尚未执行新构建原生 green 或最终全套。

最终验证过程中两项补修，已通知 agent 按最新源重跑：① 首轮 Node 104 项 103/1，既有 lifecycle seq 冲突重载用例拿到旧 ready；enter 排队前立即 history loading／verified false 修复，原 pattern 红绿，随后完整 104/104 通过。② Spec 发现慢 R2 摘要探针可在后续轮询已看到 R3 后夺回目标；最新 summaryTarget 身份变化撤销旧 probe，并校验捕获 target。新增公开交错用例 red（2 != 3）后 green，预计完整 105 项。Rust 自之前最终检查后未改，前端 Node/tsc/build 重做，已通过的 Rust 不重复。首次/中间日志保留，详情 `diagnosis.md`。

Rust 初 fmt 两处格式差异已 cargo fmt；native Python 初 ruff 3 条（I001、两 E501）已 format/check --fix。最终模型必须重新核对。

## 最终验证命令与资源

### 前端＋Rust＋原生（串行资源所有者）

在根目录执行，保存 stdout/stderr 和 exitcode/count；无需 sandbox_permissions 参数（当前 danger-full-access、审批 never）。

1. `node --experimental-strip-types --test frontend/tests/*.test.mjs`（Node 24 可直接类型擦除）。
2. `node frontend/node_modules/typescript/bin/tsc --noEmit -p frontend/tsconfig.json`。
3. `pnpm.exe build`，cwd `C:/code/shikigen-agent/frontend`。pnpm.cmd 不存在。
4. `cargo fmt --check`、`cargo test`、`cargo build --example backend_window`，cwd `C:/code/shikigen-agent/frontend/src-tauri`。本轮主 agent 构建可能仍在进行，必须确认已完成后启动，避免锁竞争。
5. `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/visibility_polling_acceptance.py`；`format --check` 同文件。
6. `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/visibility_polling_acceptance.py`。
7. 旧 03/04/05 正式方法回归通过 ticket-06 的 `run_native_regression.py --ticket 03|04|05`（如提供此文件）；只改证据目录，不改方法/断言。一次仅一原生进程族，5173/9238/45200 必须空闲；已有未知端口/应用不得终止，明确报告阻塞。

原生 fixture 自建临时后端 SQLite＋ResidentModel，所有事实真实生成，模型仅外部边界可控。原生窗口测试仅正式宿主 example，不是浏览器预览，WebView CDP 用于页面输入/截图；关闭和显示走本 host PID 核实过的真实原生 WM_CLOSE／托盘菜单。桌面本轮可能仍锁屏；不解锁、不绕过，物理键鼠及系统 IME 仍票 23，不能把合成焦点/CDP 当物理测试。

旧测试 artifact 必须隔离到 ticket-06/native-regression，不能覆盖 ticket-03/04/05 历史证据。父类继承测试入口不要用 unittest discovery 全执行；明确每票已公布方法列表。

### 独立后端验证（可与前端并行）

后端产品未变，必要完整回归：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v`；`.venv/Scripts/ty.exe check app packages/harness`。cwd 根目录，均保存日志。

后端 pytest 不是本仓库入口。测试用例自身隔离临时目录/动态端口，前端原生 5173/9238/45200 不可占。旧第 04 票 `ApprovalResumeTests.test_waits_for_previous_cleanup_and_survives_caller_cancellation` 结算超时 needs-triage，05 全套未复现、未根因修复；本轮失败或通过都保留历史。初版交接误写另一个方法名，已按正式 issue 和本轮日志核正。

## 重点边界／覆盖审计

- revision 订阅/查询竞态、查询失败 fallback、dispose 晚到监听；native 重复 show/query 不增加 revision。
- 可见且 ready 才轮询；5 秒、不并发、网络/503/HTTP-date 失败不丢更早页、cursor、selection、draft；Retry-After 后只有一正常轮询。
- 同 Run 概要不恢复耗尽流；不同摘要先历史，不以旧摘要抢新目标，probe 期间切换/隐藏/新 POST不能写入；健康观察和失败预算沿用05。
- 隐藏时已接受/未确认 POST 的读取停止不取消后台；未知记录跨重新显示保留，绝不多 POST；迟到旧 startup_id、历史和分页结果忽略。
- ready/show/select 合并，重复 visible 值及普通重渲染无新读取；布局与详情不改变依赖。
- 原生失败 hide/show 分支代码审查，当前无外部可控 failure seam，不能把没有实机制造的错误标成通过。

## 报告要求

显式记录实际模型 gpt-6-luna / max；命令/cwd/exitcode，pass/fail/skip 数量，原始日志/截图路径、失败复现与剩余缺口；不能只说“通过”。测试 agent 不改产品／正式测试，发现问题先报告主 agent，再由主 agent 修复后有针对性验证。保留首次失败，不把 skipped/block 当 passed。不改票据 done（主 agent 收集证据后做）。
