> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 08 票开发与验证记录

## 开发定向检查

主 agent 在已确认的公开消息形状／工作台 TSX 边界先加入唯一关联用例，执行 `frontend` 中 `node --import tsx --test tests/tool-records.test.mjs`，首次因尚无 `message-presentation.ts` 失败。实现展示适配、只读关联与卡片后该用例通过。

随后增加同名、乱序、跨会话／Run、重复调用／结果、空正文与附加数据空值、失败展开／手动选择、已结束 Run 等条件。初次附加数据的安全断言把整个工作台静态 `/logo.svg` 的图片与 React preload 纳入了检查，产生假阳性。修正为检查工具卡片范围，仍严格拒绝工具数据生成图片、链接或审批按钮；没有删除内容执行断言。

第一次类型检查发现 `flatMap` 从独立结果分支推断出必需 result，使等待结果分支不兼容；明确公开返回元素类型 `ToolRow` 后通过。最终定向 Node 为 6 通过、0 失败／跳过；最终批量由轻量测试 agent 执行，主 agent 未重复全套。

## Ruff 修正

后端／Standards 子 agent 首次新 Python 验收脚本 Ruff 为 8 条错误：6 条 E501 长 JavaScript 字符串、2 条 B023 循环 lambda 未显式绑定变量。主 agent 将长字符串分段，轮询比较绑定 `card=card, result=result`，保持原公开 HTTP 全字段比较。原日志保留在 `ruff-check.stdout.log`；增量结果以最终后端报告为准，不将首次错误改成通过。

## 验证记录原则

最终命令、退出码、模型和精确计数分别保留在各分工报告。原生用例使用真实 Tauri、公开 HTTP／SSE 与确定性工具，不读数据库内表来代替 API，不访问供应商模型。设备视口模拟与物理 Windows／IME 联合检查分别记录；历史后端退出和审批结算超时仍保留原问题状态。

## 补充复制入口验证

原生报告指出参数／artifact／未配对结果的具体按钮尚未逐项点击；主 agent 增加第 4 个正式用例，仅增量运行这一项，原 15 项未复跑。新用例先成功逐项验证参数、全部非 null artifact 的复制、完整抽屉及焦点恢复，再在未配对结果的精确复制比较处失败。首批日志为 `native-copy-actions.*`，保存失败。

主 agent 未更改产品或比较强度，仅增加失败诊断记录；第二次仍失败，`native-copy-diagnostic/test_parameters_artifacts_and_independent_result_full_view_and_copy/result.json` 保存实际复制值、预期和完整 HTTP／原始 UI 记录。实际公开工具正文是 **字符串**，其中包含 JSON 数组文字。实际复制值与这条公开字符串逐字相等；测试误对该字符串再次 `json.dumps`，预期因此多了一层引号与转义。不是字段丢失、数组重排或对象键次序问题。

按契约 §5 的“字符串复制原字符串；对象／数组复制完整格式化 JSON”，主 agent 将预期改为根据实际 HTTP 字段类型选择原字符串或完整 JSON。仍保留逐字复制比较、完整查看精确比较、公开历史不变和无额外 POST 断言，没有删断言或修改产品。原生增量最终结果见本轮原生报告；两个失败批次不抹掉。
