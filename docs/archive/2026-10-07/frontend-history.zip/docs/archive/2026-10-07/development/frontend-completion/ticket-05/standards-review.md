> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 05 票 Standards review

审查模型：`gpt-6-luna / max`。本次定向复核 aria-live 修复及原生菜单清理 helper；未重跑测试、类型检查或 lint。

## 做得好的

- 面向用户的状态和错误说明沿用中文领域词汇；观察异常单独展示，没有把连接失败伪装成 Run 错误。恢复逻辑集中在 `observation-recovery.ts`，投影事实仍由现有 `RunProjection` 维护。
- 界面沿用 `business-notice`、次按钮和现有轻样式；连接状态有文字说明，符合 `frontend/design.md` 的状态可读规则。

## 需要修

无未解决的明确标准违例。此前关于倒计时 live region 的发现已修复：`ObservationStatus.tsx:24` 的 live region 现在只播报状态／尝试／查询变化，倒计时移至普通段落 `ObservationStatus.tsx:28`；符合 `frontend/design.md:278` 的适量播报要求。

## 值得讨论

- **启发式 smell（非硬违例）：**`ObservationStatus.tsx:10-18` 与现有 `Sidebar.tsx:30-41` 重复了 250ms 轮询并计算重试秒数的逻辑（baseline：Duplicated Code）。若后续还要维护这两处倒计时，可考虑提取共享 hook；若两种提示生命周期不同，保持独立即可。
- **验收范围说明：**`window_acceptance.py:283` 的 `native_command` 分支核对菜单项、ID 和启用状态，再向已核实的 tray-icon owner 发送 `WM_COMMAND`（`window_acceptance.py:286`、`300`）；默认鼠标选择仍在 `window_acceptance.py:325`。注释明确该分支只用于锁屏清理，不代表物理输入验收；锁屏物理键鼠行为仍未验证，作为已声明的覆盖边界，不记为标准违例。

未发现与 `AGENTS.md`、`CONTEXT.md`、`docs/agents/*` 或 `frontend/design.md` 其他明确约定相冲突的硬违例。仅更新本审查报告，未改产品代码、测试、票据或 Git 状态。
