> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 09 票开发与失败记录

## 开发 TDD

公共边界：既有工作台 UI、浏览器滚动/几何/布局和 HTTP/SSE。复用规格已确认边界；几何用字面浏览器测量输入，不 mock 产品内部协作者。

1. 首次最新/会话切回：新增一项先 `ERR_MODULE_NOT_FOUND`，实现 App 内存阅读所有者后 1通过。
2. 暂缺等待/失效最近邻/隐藏：新增一项先 `null !== 70`，实现 verified 后寻找旧顺序最近邻、height0保留记录，2通过。
3. 主动上翻/新内容/布局/最新：新增一项先新内容false!=true，实现内容签名比较及主动latest，3通过。
4. 本次发送接受：新增一项先450!=900，实现按接受ID一次恢复跟随，4通过。

每次命令 `node --import tsx --test tests/chat-reading-position.test.mjs`，cwd frontend。断言保持字面规格预期，无删除/放宽。

接入 UI 后 `node --import tsx --test tests/chat-reading-position.test.mjs tests/tool-records.test.mjs`：10通过0失败0跳过，233047.3297ms。首次 tsc 报可空 `record.anchor.offset`，fallback前保留偏移后 tsc exit0。原生 Python 初稿两个三引号闭合和长JS行错误已修，Ruff format/check exit0。均是开发定向检查，不代替轻量模型最终验收。

## 最终验收

正在由 `gpt-6-luna / max` 执行，最终结果及后续定位追加于本目录对应报告。原生/Spec agent 因新线程数量限制，复用上一票显式采用该模型的 `ticket08_native_spec`，本次所有证据归档 ticket09；模型与职责保持轻量测试/只读审查。

主 agent 补充检查发现：JSON字符串签名会将同一对象的键顺序变化误当新内容，而既有 `RunProjection.sameFact` 明确对象键顺序不属于事实。追加第五项先 RED (`true !== false`)，复用 `sameFact` 比较只读内容结构，保留数组顺序/字段省略语义，位置算法不变。交轻量 agent 增量专项/类型/构建；原生03–08旧批次继续，09等增量构建后运行，不重复已经通过的批次。初次121前端通过是修复前历史结果，不改称最终122全套。

### 初次原生失败与诊断

初批runner固定19项，无组间暂停入口，未在08末阻止09开始；保留 `native-full-pre-fix.*`：03–08共16通过，09三项失败，exit1，历史失败不改算通过。初次正式测试只在成功尾部写证据，三份失败没有截图/当前几何，仅traceback和宿主日志；此缺口明确保留。

sameFact增量52项及类型/构建通过后，专用 `native-recheck-runner.py` 重现三项，并在teardown前保存 `native/09-recheck/<method>/failure-evidence.json`、截图，含body、几何、期望锚点、HTTP历史、backend快照、请求。主 agent读取原始JSON核对：

- 切回：期望末尾Agent消息seq5、scrollTop4541、offset约-15.77；实际首用户消息seq2、scrollTop0、offset18，paused仍正确。浏览器位置已变但scroll事件未递送，切换丢最后位置。第6公开几何单测先RED（remember不存在）后GREEN；新增remember测量入口，App新建/切换前采集，连接的时间线卸载时也采集，不改变跟随模式。
- 局部滚动：原先Home的1秒手势资格仍残留；点击“回到最新”后代码scrollIntoView产生主时间线上翻，被误当新用户操作。跟随恢复时清除旧手势资格，保留内部滚动不改模式断言。最终原生定向确认此实际路径。
- 审批：HTTP消息真实run_status=interrupted、工具名bash，页面为“审批尚未恢复，请刷新数据重新核实”。既有POST审批不带GET核实资格，`finishObservation`仅GET重建后标 verified，本票不改审批恢复写入逻辑。测试增加等待真实“等待审批”及assert_anchor，然后主动刷新GET核实，再保留全部原定位/focus/1POST断言。此为测试准备修正，未把未核实状态算已核实。
- 夹具复用：第二Run沿用同tool_call_id导致checkpointer认定已处理，第二历史少工具结果。夹具改为每次模型工具调用唯一ID，使第二Run真正执行工具，保持真实ToolNode/middleware路径，不修改后端产品。

原native子agent在诊断执行后远程上下文压缩遇到模型capacity错误；其失败文件和日志保留。后续交已有显式 `gpt-6-luna/max` 前端验证agent兼任原生/Spec，仍与Standards agent独立，不使用主agent代跑最终验证。最终只追加受影响专项/类型/构建、09三项及07/08六项原生，不盲重跑后端291、Rust25或未受影响03–06。

### 读取结束门槛

主 agent 静态复核 AC2：GET首metadata可先 `verified=true`，但 `observation=open` 的消息重建尚未结束，不能用这个身份核实标记确认锚点已失效。第7门槛测试先RED（缺readingHistoryReady导出）后GREEN；新增只读门槛 `history=ready && verified && observation in [idle,closed]`，已存在锚点继续定位，只有暂缺锚点落点延迟到整轮读取结束。useConversations复用此门槛。53项/类型/构建是此变更前历史通过结果；native尚未启动final，在冻结后交轻量agent追加54项/类型/构建，然后开始最终原生，不重复后台/Rust。

### 布局夹紧与滚动事件竞态

54项/类型/构建通过，38个静态资源逐字节/SHA匹配后 `native/09-final` 三项为2通过1失败，38.401秒，exit1；切换/隐藏/重启与审批定位通过。流式/动态布局在窄屏恢复宽屏后同一末尾消息偏移漂移：预期scrollTop9917/offset-16.047，实际10677/offset-328.453，following仍false。完整失败截图和请求/几何/历史保存于 `native/09-final/test_accepted_send_stream_replacement_layout_and_internal_scroll/`。主 agent读取事件和截图核对：图片+工具增高448已恢复，宽屏自动clamp的scroll早于ResizeObserver，仍被先前Home的一秒资格视为用户上翻，覆盖偏移。

新增第8项几何边界先RED（缺sameTimelineLayout导出），实现比较height/total/锚点身份和内容坐标、忽略纯scrollTop；DOM适配器保存最近布局，scroll发现布局变化先恢复旧锚点，再由后续真正滚动更新意图。8项开发专项GREEN。原生测试准备和严格的同锚点/2px偏移断言均未改。交轻量agent定向55项/类型/构建，再用独立 `native/09-layout-final` 重跑3项及通过后07/08六项，保留已有全部失败。

冻结前补齐另一递送顺序：update观察到新布局即清除旧手势资格；无新手势的浏览器scroll只重申锚点、不捕获阅读意图，ResizeObserver在前/在后均不覆盖旧偏移。核对旧事件发现内部wheel实际命中P而不是PRE：旧测试的scrollIntoView后自动最新改变了命中位置。夹具末尾追加真实可滚动代码，在最新处对最后PRE先assert elementFromPoint确实命中，向下wheel并等待内部scrollTop>0保持following，再向上wheel保持following；移除测试scrollIntoView，不放宽任何断言。这项测试真实性修正及两新Python文件交轻量agent追加Ruff，后台完整suite不重复。

轻量Standards/Backend agent 的 layout-final Ruff lint exit0，format --check exit1：新增等待内部scrollTop的多行lambda缺Ruff建议括号；主agent只改行格式，保留失败日志 `backend/layout-final-ruff-format.*`，交子agent追加layout-freeze格式/静态检查，原生逻辑和断言不变。

### 自身操作行与原生 Home

`native/09-layout-final` 0通过3失败，112.387秒，三项均在home helper等待顶端时失败。原始geometry显示following=false但仍靠底部（前两项scrollTop5207.5/total5793/height546，第三3205/3790/546），截图及完整事件各保存在该目录。主agent核对：上翻显示reading-controls令视口高度减小，前一保护把自身UI变化也视为外部布局，清除了正在执行的Home手势；另外写入相同scrollTop也可能取消浏览器平滑动作。

仅修DOM适配：controls显隐且其他布局不变时保留当前手势，采集尚未递送的真实滚动；只有目标不同才写scrollTop。外部布局仍清旧资格并重申锚点。原生测试/夹具/55定向断言未变；由轻量agent再55/type/build及38静态预检后写独立 `native/09-controls-final` 三项，再07/08。后台/Rust/Ruff无相关产品变化不重复。

### React 更新早于迟到滚动、可见 PRE 的选择

`native/09-controls-final` 1通过2失败，30.519秒：审批定位通过；切换期望末尾seq5/offset-15.773/top4541，但编辑草稿后再切回首用户seq2/offset18/top0；React更新在App remember前先reconcile覆盖了尚未递送的滚动。主agent新增第9几何边界，先缺movedBeyondLayoutClamp导出RED，再9项GREEN；update有真实输入资格时先采集不属于浏览器clamp的移动，若同时布局已变则用之前内容坐标和当前top保存原偏移，再reconcile。scroll统一走update，防止React与scroll两个入口遗漏。

另一失败为代码命中点(621.5,717.453)不在可见PRE。主agent查看实际截图：Markdown末尾代码框可见，最后一个DOM PRE却属于闭合的原始文本块details。验收选择排除closed details/[hidden]，保留命中检查、内部scrollTop>0、两个following断言，不让隐藏DOM充当代码区覆盖。两失败完整证据在 `native/09-controls-final` 对应case目录。新增字段仅测试引用真实DOM，未mock内部产品。最终由轻量agent56定向/type/build、38预检、`native/09-scroll-final` 三项及通过后07/08；Standards独立核对，Python增量Ruff。

### 验证中断与接续

late-scroll的56项、类型、构建和38项静态预检通过后，原轻量agent收到 `Your workspace is out of credits`，未执行新原生三项与07/08，不将这些未执行项算通过。用户继续后，主agent重新派发显式 `gpt-6-luna / max`：native_finish负责最后原生批次，spec_finish负责独立规格核对及最终文档检查。此时沙箱改为workspace-write/受限网络；新原生进程按工具审批规则执行，原有5173共享服务保留，CIM命令行查询拒绝访问已记录，38项HTTP哈希和端口监听证据可核对。
