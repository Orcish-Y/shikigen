> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 08 票原生验证报告

**模型：** gpt-6-luna / max

**目录：** `C:\code\shikigen-agent`（PowerShell）

**运行时间：** 2026-10-05 14:16:26–14:18:39 +08:00

## 命令与结果

```powershell
$env:PYTHONPATH = 'C:\code\shikigen-agent\frontend\src-tauri\tests;C:\code\shikigen-agent\tests;C:\code\shikigen-agent\packages\harness'
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-08/native-runner.py 1> .scratch/frontend-completion/ticket-08/native.stdout.log 2> .scratch/frontend-completion/ticket-08/native.stderr.log
$resultCode = $LASTEXITCODE
Set-Content -LiteralPath '.scratch/frontend-completion/ticket-08/native.exit.txt' -Value $resultCode -NoNewline
```

实际运行将 stdout、stderr、退出码分别写入 `native.stdout.log`、`native.stderr.log`、`native.exit.txt`；工作目录和 runner 均在仓库根目录 / 本票目录。退出码 0：**15 通过、0 失败、0 跳过**。

| 回归组 | 项数 | 通过 | 失败 / 跳过 | 用时 |
| --- | ---: | ---: | ---: | ---: |
| 第 03 票 Reconstruction 原入口选择 | 3 | 3 | 0 / 0 | 21.805s |
| 第 04 票 MessageDraftAcceptance 本类 | 4 | 4 | 0 / 0 | 27.099s |
| 第 05 票 StreamRecoveryAcceptance 本类 | 2 | 2 | 0 / 0 | 25.994s |
| 第 06 票 VisibilityAcceptance 本类 | 1 | 1 | 0 / 0 | 14.667s |
| 第 07 票 MarkdownAcceptance 本类 | 2 | 2 | 0 / 0 | 15.273s |
| 第 08 票 ToolRecordsAcceptance 本类 | 3 | 3 | 0 / 0 | 24.803s |

第 07 票正式组仅执行 2 项；未通过子类发现继承测试或重复计数。第 08 票真实 fixture 使用 `create_agent`、工具 middleware、checkpointer、持久 HTTP 事实和无网络固定 `ToolModel`。三项覆盖唯一身份／状态／seq 与完整 HTTP 记录、空值 artifact 和 unmatched 结果、复制及完整查看、失败自动展开、手动折叠跨刷新／切换保持、重启默认、失败延迟到达和窄屏溢出。

## 构建、隔离与证据

- 前端 agent 报告 `pnpm test` 117 项、`tsc`、`pnpm build` 通过；Rust agent 报告 `cargo test` 25 项、`cargo fmt --check`、`cargo build --example backend_window` 通过。example build 退出码 0 后才启动原生测试。
- `frontend-ready.json` 中 index、`index-BS3lAzYV.js`、`index-CaRrHnyf.css` 的 SHA-256 与磁盘一致。测试前后，已有 5173 服务的这三项资源均与 dist 逐字节相同；保留该服务。9238/45200 测试前后均空闲。各例使用隔离临时项目、DB、WebView；测试宿主退出后端口已释放。
- 第 08 票截图：`native/test_true_status_pairing_full_records_empty_values_and_complete_copy/desktop-tool-content.png`、`narrow-tool-records.png`、`window.png`；`native/test_manual_collapse_survives_replay_selection_and_native_restart_resets/window.png`；`native/test_failure_arrival_respects_manual_collapse_of_waiting_card/window.png`。各组还有 `result.json` 与 `host-*.log`。
- stdout/stderr/退出码：`native.stdout.log`、`native.stderr.log`、`native.exit.txt`。回归组截图及 JSON 归档于 `native/03`–`native/07`。

## 证据目录问题与剩余覆盖

首次 runner 未按组覆盖继承来的 `artifact_root`，因此旧第 03–07 票目录收到了本轮新文件。按 runner 启动时间筛出 41 份文件复制至本票 `native/03`–`native/07`，清单见 [native-artifact-manifest.csv（原始产物已删除）](../../../README.md#已删除的材料)，每项含 source、target、SHA-256。主 agent 独立核对哈希并已恢复旧票据的 35 份 tracked evidence；另 6 份无旧 tracked 对应的临时文件已在校验后移除源副本。本票保留本轮全部数据。runner 已修正为每组写入本票隔离目录，未重跑。

新增方法最终复核后，参数和每个非 null artifact 的复制、完整查看按钮均有原生逐项覆盖，并继续复用第 07 票已验收的 `ContentBlock`。物理窗口尺寸与系统 IME 留给第 23 票。重复 tool_call_id 由公开 TSX 测试及工作台示例覆盖；持久后端 fixture 遵守工具身份幂等，不伪造重复保存。

## 后续定向补测

主 agent 增加第 4 个本票原生方法后，仅运行 `test_parameters_artifacts_and_independent_result_full_view_and_copy`，未重跑原 15 项，也未改产品或断言。命令入口为 `native-copy-actions-runner.py`；runner 将 `ToolRecordsAcceptance.artifact_root` 指向 `native-copy-actions`。运行前 9238/45200 空闲，5173 三项静态资源再次与 dist 字节相同。

本次专项 **0 通过、1 失败、0 跳过，exit 1**，约 39.36 秒。参数及所有非 null artifact 的复制、完整查看和焦点恢复均已通过；随后 orphan `fixture-orphan` 的完整数组复制未在时限内匹配预期，失败位置为 `tool_records_acceptance.py:382`。失败后未到 orphan 查看、无额外 POST、HTTP history 不变断言及截图/`result.json` 记录。日志：`native-copy-actions.stdout.log`、`native-copy-actions.stderr.log`、`native-copy-actions.exit.txt`；stderr 保存完整 traceback，失败专属 `host-0.log` 为空。该次运行后原 15 项结果保持独立记录；当时新增方法尚未通过，因此没有累计为 16 项通过。

按主 agent 请求，随后再次只运行该方法，runner 使用 `native-copy-diagnostic` 独立 artifact root；没有重跑其他套件。此次仍是 **0 通过、1 失败、0 跳过，exit 1**，39.227 秒。失败捕获保存了 `native-copy-diagnostic/.../result.json` 与 `window.png`。证据值如下：公开 HTTP 的 orphan `content.content` 类型为 string；它与 `window.__copied` 逐字一致（均 61 字符），两者经 `JSON.parse` 的值也相同。测试 expected 对这条已经是 JSON 文本的 string 再做 `json.dumps(indent=2)`，得到 73 字符、带外层引号和转义的字符串字面量，因此比较失败。`original_result` 与当前 HTTP history 中的原始工具内容相等；差异不是缺字段、数组顺序或对象键顺序。参数和非 null artifact 的复制、查看与焦点恢复在失败前已通过；仍未到 orphan 完整查看及末尾的 no-POST/history 断言。日志：`native-copy-diagnostic.stdout.log`、`native-copy-diagnostic.stderr.log`、`native-copy-diagnostic.exit.txt`。原 15/15 通过记录保持不变，未改 Spec review 结论。

## 修正 oracle 后的最终定向复核

主 agent 仅调整了测试 oracle：当 HTTP `content.content` 已是字符串时按原文比较；非字符串仍按缩进 JSON 比较。产品代码和断言未放宽。本次仅运行 `test_parameters_artifacts_and_independent_result_full_view_and_copy`，artifact root 为 `native-copy-final`，没有重跑前 15 项、前后端测试或构建。实际命令（仓库根目录，PowerShell）：

```powershell
$env:PYTHONPATH = 'C:\code\shikigen-agent\frontend\src-tauri\tests;C:\code\shikigen-agent\tests;C:\code\shikigen-agent\packages\harness'
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-08/native-copy-final-runner.py 1> .scratch/frontend-completion/ticket-08/native-copy-final.stdout.log 2> .scratch/frontend-completion/ticket-08/native-copy-final.stderr.log
$resultCode = $LASTEXITCODE
Set-Content -LiteralPath '.scratch/frontend-completion/ticket-08/native-copy-final.exit.txt' -Value $resultCode -NoNewline
```

结果 **1 通过、0 失败、0 跳过，exit 0，10.011 秒**。与先前 15 项合计为 **16 个唯一用例全部通过**：第 03–07 票 12 项，第 08 票 4 项；第 07 票仍只有 2 项。之前两次失败运行是同一新增方法的 oracle 诊断，不计作额外用例，原始失败日志及截图继续保留在 `native-copy-actions`、`native-copy-diagnostic`。

通过路径覆盖了参数 JSON 的复制、完整查看及焦点恢复；6 个非 null artifact（`""`、`0`、对象、`[]`、`{}`、`false`）逐个复制并完整查看；orphan JSON 文本字符串的原文复制与查看；HTTP history 不变且没有额外 POST。最终逐字复制文本为：`[{"type": "unknown", "text": "完整未知结果", "fields": [0, false]}]`。结果记录在 `native-copy-final/test_parameters_artifacts_and_independent_result_full_view_and_copy/result.json`，Tauri 截图为同目录 `window.png`，宿主日志为 `host-0.log`；runner stdout/stderr/exit 分别为 `native-copy-final.stdout.log`、`native-copy-final.stderr.log`、`native-copy-final.exit.txt`。

本次沿用既有隔离临时项目、DB、WebView 和原生端口；启动前后 9238/45200 空闲，保留已有 5173 服务。前后核对 5173 的 index、`index-BS3lAzYV.js`、`index-CaRrHnyf.css` 均与本票 dist 字节相同。未改产品代码。
