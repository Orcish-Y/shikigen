> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# OSK 并存与取消可达性复验

日期：2026-10-07  
验证模型：gpt-6-luna / max  
工作目录：C:\code\shikigen-agent

## 结果

仅运行一项 Windows/Tauri 原生单例，结果为 **1 selected / 1 executed / 0 passed / 1 failed / 0 error / 0 skip**，runner exit 1。此次没有运行付费模型；没有修改产品或测试源码、断言、系统配置、剪贴板或 Git 状态。

命令：

    .venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch osk-coexistence-2 --tests NativePlatformAcceptance.test_osk_long_draft_tray_notice_and_native_cancel_remain_reachable

Ruff check 与 ruff format --check 对 native_platform_acceptance.py、native_runner.py 均 exit 0；精确 --list 选中 1 项。运行前 frontend/dist 的 38 个文件、1,049,454 bytes 与 frontend-rust/final-4/vite-build.json 的 SHA-256 清单逐文件一致，manifest SHA-256 为 fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f。源文件前后哈希未变：platform daf41472e38f11f92773baf7a2b7134859ae5dc28847d7d6afdf1e4d84cb4dd4，runner ae37fa57dea7f351a0caca5587312704b17203b2e17e6a11267c010feb6802b1。

用例实际触发了原生缺托盘图标状态，页面出现 TrayNotice；长正文、30 行草稿、390×600 布局和阅读锚点断言通过。新建的屏幕键盘 PID 24696、HWND 33491382 与 Tauri 窗口并存。取消按钮位于可见区域，WindowFromPoint 命中本例 Tauri 窗口；真实 Win32 鼠标点击打开取消确认框，Windows Esc 将其关闭。其后草稿、阅读锚点和“运行中”状态断言均通过。以上断言之后，测试保存结果并释放阅读流，随后失败于 self.complete() 内 wait_until(self.at_latest()) 超时：本例仍保持暂停阅读位置，因此未满足该清理 helper 的回到最新条件。用例未到达后续的无托盘 WM_CLOSE 和宿主 wait 断言，故不能把整项记为通过。unittest stdout 报 41.343 秒，cases.json 记 36.25 秒；保留两种原始计时，不自行归并。

本批只覆盖取消确认的可达性；不覆盖 Story 114 要求的发送、审批、重连操作，也不声称 OSK 输入键值或物理手指硬件通过。父 agent 将另补其余操作验收。本批前的 osk-coexistence-1 失败仍保留，失败在 TrayNotice 出现前；这次只证明 TrayNotice 触发路径已到达，不覆盖旧失败历史。

## 证据

- [预检记录（原始产物已删除）](../../../../../README.md#已删除的材料)、[命令及 runner 结果（原始产物已删除）](../../../../../README.md#已删除的材料)、[post-hash 与计数核对（原始产物已删除）](../../../../../README.md#已删除的材料)
- [stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases（原始产物已删除）](../../../../../README.md#已删除的材料)
- [失败快照（原始产物已删除）](../../../../../README.md#已删除的材料)、[结构化结果（原始产物已删除）](../../../../../README.md#已删除的材料)
- [OSK 截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[Tauri 原生截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[窗口截图（原始产物已删除）](../../../../../README.md#已删除的材料)
- [post-cleanup 观察（原始产物已删除）](../../../../../README.md#已删除的材料)

清理核对时，本例 OSK PID 24696 已退出，HWND 33491382 已失效；没有本例 OSK 或 Tauri/native backend 进程残留。9238/45200 无监听；5173 仍由 PID 23344 提供；预存 TabTip PID 14204 保持运行。

## 汇总到本次后续验证

原报告上方的总结果只计算最初三项。追加后续批次后，当前九项 Tauri 单例合计 **4 pass / 5 fail / 0 error / 0 skip**：download-7 1 pass；IME paced 1 fail；full-preedit 两项 2 pass；osk-coexistence-1 与 osk-coexistence-2 各 1 fail。OSK/IME 独立 Win32 控制 probe 是诊断，不并入此用例计数。旧失败均保留原始状态。

此报告记录取消可达性单例；不更新票据状态，也不关闭第 23 票。

