> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Standards 审查

**做得好**：`frontend/src/run-projection.ts` 双向校验事件与历史／增量的 seq 和身份，冲突完整消息不覆盖已确认事实。

**需要修**：无硬性违规；原 `backend-client.ts` 的重复 metadata 校验已移除，`validateFrame` 负责一次校验。

**讨论**：`frontend/src/run-protocol.ts:8-16,47-69` 的 `object/identity/sequence/date/approval` 含义偏泛（possible Mysterious Name），可改为 `isRecord` 等。新增 TS 引号、间距与邻近代码不一；无强制规则，属风格建议。
