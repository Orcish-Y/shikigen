> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 23 票 Standards 定向复核

模型：**gpt-6-luna / max**。当前快照：26 文件／3918 diff 行；`review.diff` SHA-256：`E75309A0108A83F64298B714DEEEFA7214665FCECB25FE7FC15803831C31504D`；`native_platform_acceptance.py` SHA-256：`965AB30E612AC5E5E880460B5334B66EAD37210E91D77C3B4453874998274E62`。本轮仅核对票据／索引的闭票差异及主报告结尾；产品与测试源码未变。静态命令：PowerShell `Get-Content`、`rg`、`Get-FileHash`。未运行测试、构建、窗口、端口或 Git 命令。

## 硬性规范

**0 项新增硬违规。**工作区 helper 只移动自有 HWND，使用当前测试进程的 `GetMonitorInfo`／`GetWindowRect` 坐标；不改尺寸、Z 序或激活状态。先选择能容纳原生外框的工作区，按目标 CSS 尺寸重查布局，再断言最终原生外框四边均在工作区内（`native_platform_acceptance.py:541`）。不移动 taskbar、OSK 或其他应用。每次原生点击先聚焦自有窗口，点击前将 `WindowFromPoint` 根窗口与自有 HWND 比较；记录目标点、命中类、窗口矩形和前景 HWND。失败清理会释放按下的鼠标键并恢复光标（`:773`）。

重连等待要求 `.app-connection` 的 DOM 状态文本包含“观察已建立”（该元素在窄屏隐藏）、对应的恢复通知节点消失，并以真实 backend GET 确认 run status 为 `running`；每二次 run 的四个 GET、原有发送计数及最终单次取消／`cancelled` 断言保留，未见以隐藏元素或省略断言制造通过（`:962`）。命名清楚，资源清理未见新增硬问题。

OSK coexistence 的原生键盘截图现移至真实四阶段交互完成后；仅对该 OSK HWND 读取原生控件，要求 `DwmFlush()` 返回 0，再执行原有桌面帧采集。原 `capture_window_frame` 的 HWND 可见性、九点遮挡归属、矩形稳定和非空帧断言保留；未发现产品验收断言被删除或放宽（`native_platform_acceptance.py:675`）。

## 闭票文档核对

票据的 `Status: done`、`实施进度：已验收` 及八项勾选，与索引的 `Status: done`、第 1–23 票均已验收且无待实施项一致。报告注明 final-3 的两项功能结果保留、旧背景页截图无效，并将有效 OSK 图像归于 final-4；人工／硬件与 OSK 点键未验、临时目录残留均保留边界。三处文档都说明未执行 Git、父地图保持关闭，未见闭票状态或证据表述冲突。

## 保留的判断性意见

1. OSK 关闭依赖系统级快捷键；若窗口状态并发变化，仍有误关风险。输入探针窗口、布局与 COM 的顺序清理意见维持。
2. GDI helper 在 `try` 前初始化资源，部分初始化失败可能泄漏。
3. 失败截图／页面内容可能含会话隐私。
4. 多个 runner 有重复骨架，可在后续变化时考虑抽取。
5. 失败采证尚不能为所有提交路径提供 HTTP 响应码及 backend 状态。此次成功重连会读取 run status，但不覆盖失败路径；另 `native-control-target.json` 每次写入同一路径，最终只保留最后一次点击的 HWND 命中快照，阶段级位置与事件记录仍保留其余操作信息。建议后续按阶段留存该窗口级快照。

## 验证边界

1024 有 final-2 实际通过记录，1440／1280 通过记录沿用。final-3 的两项功能通过保留；其旧 `osk-coexistence-native.png` 是背景页，不能作为键盘像素证据。final-4 OSK 定向复验 **1／1 通过、0 失败／错误／跳过**；主 agent 与测试子 agent 实际查看到完整键盘画面，四阶段、backend／frame／身份、请求与清理证据均已核对。该图补齐的是截图证据，不把旧背景图改记为有效；实体设备及 OSK 点键仍未验。本轮文档核对未运行测试。完整执行记录见 [report.md](report.md)。

**汇总：0 项硬性违规；5 项判断性意见保留，其中第 5 项补充目标快照覆盖写风险。**
