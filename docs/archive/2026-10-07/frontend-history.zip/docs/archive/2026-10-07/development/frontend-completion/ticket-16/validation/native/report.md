> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第16票 Tauri 原生验证报告

日期：2026-10-06（Asia/Shanghai）  
模型：`gpt-6-luna`，`max`  
工作目录：`C:\code\shikigen-agent`（PowerShell）  
票据：`docs/wayfinder/frontend-completion/implementation/16-conversation-export.md`

## 结果

正式验收由多批定向运行组成：6 个新增场景和 2 个既有回归共 8 个唯一 case，各自都有最终通过证据；没有一次性运行包含全部 8 个 case 的全套。定向重跑后的唯一case结果为 8 pass、0 fail、0 error、0 skip。按批计数及原失败均保留：native-probe-1 为 0 pass/0 fail/1 error；native-remaining-1 为 5 pass/1 fail；native-final-targeted-1 为 1 pass/1 fail；native-save-trusted-1 为 0 pass/1 fail（后两批的默认UI探针单列，不计入正式case）；native-probe-2 与 native-cancel-final-1 各 1 pass。CDP/loopback ERROR 和夹具 marker FAIL 分别在后续重跑通过。两次默认系统保存 UI 探针未找到可识别的 `#32770` SaveAs 对话框，保留为诊断失败。

新的正式取消case通过真实 WebView 下载事件和同一 GUID 的 `Browser.cancelDownload` 证明取消边界。它不证明默认系统保存 UI 或物理鼠标/键盘取消行为。另有一次独立的 `Browser.cancelDownload` 诊断得到同样的真实 canceled 事件；两者均不使用 download policy `deny` 代替取消。

## 正式case

| Case | 结果 | 原生证据 |
|---|---|---|
| `test_empty_and_sync_failure_keep_draft_history_and_run` | 通过（提升权限重跑；早期未提升尝试以 WinError 10054 ERROR 结束） | [probe-2 output（原始产物已删除）](../../../../../README.md#已删除的材料) |
| `test_actual_utf8_download_complete_tool_records_and_click_snapshot` | 通过；实际文件 69,759 bytes，正文与点击时 HTTP fact snapshot 完整匹配；延迟派发期间新消息未混入 | [result.json（原始产物已删除）](../../../../../README.md#已删除的材料), [window.png（原始产物已删除）](../../../../../README.md#已删除的材料) |
| `test_webview_download_denied_does_not_modify_facts_then_manual_download` | 通过；deny 不改 facts，切至 allow 后实际文件 69,759 bytes | [result.json（原始产物已删除）](../../../../../README.md#已删除的材料) |
| `test_preview_excluded_then_actual_cancelled_body_downloaded` | 通过；preview 文件 1,019 bytes，实际取消正文文件 3,215 bytes | [result.json（原始产物已删除）](../../../../../README.md#已删除的材料), [window.png（原始产物已删除）](../../../../../README.md#已删除的材料) |
| `test_actual_failed_body_and_reason_download_without_changing_run` | 通过；实际导出文件 16,617 bytes，包含失败正文和错误原因。首次失败是 fixture marker 被误改，未到导出断言；恢复 `failure-text-ready` 后定向重跑通过 | [result.json（原始产物已删除）](../../../../../README.md#已删除的材料), [window.png（原始产物已删除）](../../../../../README.md#已删除的材料) |
| `test_actual_webview_download_cancel_keeps_facts_and_draft` | 通过；同 GUID 开始、cancel response 成功、progress=`canceled`；总字节数匹配 UTF-8 Blob，已接收 0 bytes；下载目录为空，HTTP history、draft、run status不变 | [result.json（原始产物已删除）](../../../../../README.md#已删除的材料), [window.png（原始产物已删除）](../../../../../README.md#已删除的材料) |
| `test_true_status_pairing_full_records_empty_values_and_complete_copy`（旧回归） | 通过 | [result.json（原始产物已删除）](../../../../../README.md#已删除的材料), [desktop-tool-content.png（原始产物已删除）](../../../../../README.md#已删除的材料) |
| `test_real_messages_full_copy_drawer_and_single_foreground`（旧回归） | 通过 | [result.json（原始产物已删除）](../../../../../README.md#已删除的材料), [desktop-drawer.png（原始产物已删除）](../../../../../README.md#已删除的材料) |

正式取消case的核对值：导出文件名 `会话-2026-10-06T07-06-08-775Z.md`；Blob URL 为 `blob:http://127.0.0.1:5173/6e7efcfc-a1da-4718-ab98-1cd5e1b38ab7`；UTF-8 Blob 长度和 `Browser.downloadProgress.totalBytes` 均为 69,759；`receivedBytes=0`；download GUID `3d473dfd-5ee6-4953-b3bc-9d4666d7c349` 在 `downloadWillBegin`、cancel command 和 `state=canceled` 中一致；cancel command 返回 `{}`。11 条 HTTP history facts、草稿“尚未提交的秘密草稿”和“已完成”run badge保持不变。

## 默认保存 UI 诊断

父agent要求保留原默认 UI case，并将它作为 `--probe-default-save-ui` 才运行的附加探针。此前两次单独运行都在15秒窗口内未找到可识别的 `#32770` SaveAs 对话框：

- `native-final-targeted-1`：使用 Runtime.evaluate 的 `.click()`；case等待系统保存框超时，exit 1。[failure.json（原始产物已删除）](../../../../../README.md#已删除的材料)、[window.png（原始产物已删除）](../../../../../README.md#已删除的材料)。
- `native-save-trusted-1`：使用 `Input.dispatchMouseEvent` 的 trusted 输入重试；仍未找到保存框，exit 1。[failure.json（原始产物已删除）](../../../../../README.md#已删除的材料)、[window.png（原始产物已删除）](../../../../../README.md#已删除的材料)。

第二次探针在点击前验证私有 WebView `Preferences` 中 `download.default_directory` 指向本case工作区 `native-save-downloads`，且 `prompt_for_download=true`；这两项断言通过。下载目录最终为空；页面截图显示“已发起导出”提示。fixture清理删除了私有 WebView profile，因此 Preferences 原文件未保留。失败时未采集 HWND/owner-chain JSON；宿主已退出，无法事后恢复窗口状态。原生默认保存框中的手动取消没有执行，因为没有检测到保存框；未再运行其他两个保存框脚本。

Microsoft WebView2 SDK 文档说明，`DownloadStarting` 的默认 `Handled=false` 会显示默认下载对话框；host 可以设置 `Cancel` 取消下载。该 SDK 文档不证明当前 Wry host 已注册该事件，也不据此判断产品的默认 UI 成败：[ICoreWebView2DownloadStartingEventArgs](https://learn.microsoft.com/en-us/microsoft-edge/webview2/reference/win32/icorewebview2downloadstartingeventargs?view=webview2-1.0.4129.50)。

## 独立真实下载取消诊断（非正式case）

`browser_cancel_download_diagnostic.py` 在隔离下载目录用 `Browser.setDownloadBehavior(allow)` 观察实际 Blob 下载：收到 `Browser.downloadWillBegin`，对该 GUID 发 `Browser.cancelDownload`，随后收到同 GUID 的 `Browser.downloadProgress(state=canceled)`。`totalBytes=69,759`、`receivedBytes=0`；cancel前后目录为空，HTTP history、draft和run badge不变。诊断exit 0，但它使用CDP取消命令，不是原生保存弹窗或物理用户输入。

- [diagnostic result.json（原始产物已删除）](../../../../../README.md#已删除的材料)
- [WebView screenshot（原始产物已删除）](../../../../../README.md#已删除的材料)
- [stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../../../README.md#已删除的材料)、[exit（原始产物已删除）](../../../../../README.md#已删除的材料)。stdout包含原始CDP截图base64，约463 KB；精简事件和一致性字段见 result.json。

## 命令与退出状态

所有命令都在仓库根目录执行。完整逐命令记录、唯一case最终状态和日志路径见 [command-results.json（原始产物已删除）](../../../../../README.md#已删除的材料)。关键结果：

- 正式Tauri run：`native-probe-2` exit 0；`native-remaining-1` exit 1（5 pass，1 fixture failure）；`native-final-targeted-1` exit 1（失败正文重跑 pass，默认UI探针 fail）；`native-save-trusted-1` exit 1（默认UI探针 fail）；`native-cancel-final-1` exit 0（1 pass）。
- 早期 `native-probe` exit 1：CDP query 时 WinError 10054；提权后 `native-probe-2` 通过。
- Ruff：对最新 `conversation_export_acceptance.py` 与 `native_runner.py` 执行 `ruff check --output-format concise` exit 0（All checks passed）；`ruff format --check` exit 0（2 files already formatted）。没有运行 Node、Rust build或其他未授权回归。

## 环境与清理

显式配置 `Browser.setDownloadBehavior` 的下载用例将 `downloadPath` 指向测试 evidence 目录，并核对实际文件；默认UI探针只核对了私有 profile 的 `download.default_directory` 设置及该工作区目录为空，未验证浏览器最终下载目标。验证脚本没有读取、枚举或清理用户 Downloads；这不证明默认UI探针触发后应用未向该目录写入文件。`native-cancel-final-1` host log 115 bytes，测试正常退出；批次结束后 `backend_window` 进程数为0，9238和45200没有监听项。运行器报告 `SHARED_DIST_SERVER_MODE=reused`；5173现存服务仍返回 HTTP 200，index 396 bytes，未停止或重启。没有清理用户进程；所有 stdout、stderr、exit、JSON和截图证据均保留。旧的失败证据未覆盖。清理核对输出见 [cleanup-check.stdout.log（原始产物已删除）](../../../../../README.md#已删除的材料)、[cleanup-check.stderr.log（原始产物已删除）](../../../../../README.md#已删除的材料)、[cleanup-check.exit-code.txt（原始产物已删除）](../../../../../README.md#已删除的材料)。

scratch诊断文件保留在 `validation/native/`：`browser_cancel_download_diagnostic.py` 已运行；`trusted_default_save_dialog_diagnostic.py` 和 `webview2_default_download_diagnostic.py` 未运行。



