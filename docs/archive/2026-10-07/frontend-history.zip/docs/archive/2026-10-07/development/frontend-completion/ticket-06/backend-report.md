> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 06 票后端最终回归

- 调度模型：显式指定 `gpt-6-luna / max`（部署内部 SKU 未额外披露）。
- 工作目录：`C:/code/shikigen-agent`。

## 执行结果

| 命令 | 退出码 | 结果 |
| --- | ---: | --- |
| `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` | 0 | 共 291 项：通过 290、失败 0、跳过 1、expected failure 0；运行 340.563 秒。 |
| `.venv/Scripts/ty.exe check app packages/harness` | 0 | `All checks passed!`，0 error、0 warning。 |

唯一跳过项：`test_symlink_data_and_parent_are_rejected`，原因是当前 Windows 环境没有创建符号链接所需的权限。该项按 skip 计数，没有计入通过。

日志：

- 完整 unittest stdout/stderr、退出码及计数：`.scratch/frontend-completion/ticket-06/backend-full-suite.log`
- 完整 `ty` 输出、退出码及诊断计数：`.scratch/frontend-completion/ticket-06/backend-ty.log`

原始 unittest 输出末尾为 `Ran 291 tests`、`OK (skipped=1)`。日志还保留了首轮计数解析 footer（误报 PASS=263），随后追加 `VERIFIED SUMMARY` 更正；最终通过数按 unittest summary 计算为 291 − 1 skip − 0 fail − 0 error = 290。

## 错误路径与历史事项

没有失败项或失败复现步骤。日志中有数据库损坏、数据库锁定和 request failure 等异常栈，但对应故障注入用例均以 `ok` 结束，属于预期错误路径。

主 agent 初版交接误记了另一方法名，已按正式 issue 核正。实际历史超时用例与当前正式用例均为 `ApprovalResumeTests.test_waits_for_previous_cleanup_and_survives_caller_cancellation`（`tests/test_approval_resume.py`），本轮为 `ok`。第 04 票历史超时仍为 `needs-triage`；本次通过不构成根因修复或关闭依据。

## 清理与覆盖边界

两个命令均正常退出；后端测试按仓库现有用例使用临时目录和动态端口，没有占用前端原生测试的固定端口、Cargo 或 dist 资源。未额外执行全局端口/临时目录扫描。前端 Node、TypeScript、build 与原生验收由各自资源所有者负责，本报告不重复执行。
