> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 12 票双轴审查范围

固定点：a35232d461b38bdb48a8cbdad4ed6a59561dba0c，开始时工作区和暂存区干净，当前尚未提交；本次按提交前工作区做审查。

已跟踪修改：`git diff a35232d461b38bdb48a8cbdad4ed6a59561dba0c -- frontend/src docs/wayfinder/frontend-completion/implementation/12-approval-resume.md`。

新增文件也必须检查（未暂存，常规 git diff 不含它们）：

- frontend/src/approval-decisions.ts
- frontend/src/components/ApprovalCard.tsx
- frontend/tests/approval-decisions.test.mjs（当前 10 用例）
- tests/desktop_approval_fixtures.py
- tests/test_frontend_approval_flow.py
- frontend/src-tauri/tests/approval_resume_acceptance.py

需要 diff 形式时使用只读 `git diff --no-index -- NUL <新增文件>`；退出码 1 表示存在差异，不是失败。不得为获取 diff 而 git add。新日志和验证报告在本票 scratch，不是产品功能。

规格：docs/wayfinder/frontend-completion/implementation/12-approval-resume.md（8 条验收条件）；003-approval-cancel.contract.md 与 frontend/design.md 补充身份／样式边界。第 13 票负责跨重启持久审批草稿及完整未知提交交互，不能要求本票提前完成全部 13。

标准：根 AGENTS.md，CONTEXT.md、docs/agents/domain.md、相关 docs/adr/。重点命名词性、显式可调用参数、本地 Markdown tracker、原文输入和事实权威。实现方案、修改范围、快速／最终验证及历史问题在 validation-context.md。

Standards 与 Spec 各自独立报告，按“做得好的／需要修的／值得讨论”呈现，硬问题与启发式建议分开。产品修改由 root 完成，子 agent 只审查、不写产品、不改 Git。最终模型 gpt-6-luna / max。
