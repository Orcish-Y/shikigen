> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 07 后端验证报告

## 环境与范围

- 验证 agent：`gpt-6-luna`，推理强度 `max`（按任务派发）。
- 工作目录：`C:\code\shikigen-agent`，Windows PowerShell。
- 仅运行后端回归与类型检查；未修改产品代码或正式测试，未触碰 Git 状态。
- 原生/WebView suite、Rust suite、前端 suite 未在本报告范围内；它们由对应 agent 独占执行。

## 结果

| 验证 | 命令 | 结果 | 耗时 | 证据 |
| --- | --- | --- | ---: | --- |
| 完整 Python suite | `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` | `Ran 291 tests in 384.388s`; **289 passed, 1 error, 1 skipped**；exit 1 | 397.408s（包含启动和收尾） | [backend-unittest.log](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/backend-unittest.log`） |
| 首次隔离复测 | `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_desktop.py -k test_environment_loaded_before_config_without_overriding_host -v` | 1 passed, 0 failed/error, 0 skipped；exit 0 | 10.548s（unittest 10.039s） | [backend-isolated-environment-test.log](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/backend-isolated-environment-test.log`） |
| 第二次隔离复测 | 同上 | 1 passed, 0 failed/error, 0 skipped；exit 0 | 10.960s（unittest 10.374s） | [backend-isolated-environment-test-2.log（原始产物已删除）](../../../README.md#已删除的材料) |
| Python 类型检查 | `.venv/Scripts/ty.exe check app packages/harness` | 通过，exit 0 | 2.101s | [backend-ty.log（原始产物已删除）](../../../README.md#已删除的材料) |

完整 suite 的唯一 skip 是 `test_runtime_data.RuntimeDataTests.test_symlink_data_and_parent_are_rejected`，原因是 `Windows symlink privilege is unavailable`。该 skip 单独计数，没有计入通过数。

## 失败与复测

完整 suite 唯一错误为 `test_desktop.DesktopTests.test_environment_loaded_before_config_without_overriding_host`。traceback 定位到 [tests/test_desktop.py](../../../../../../tests/test_desktop.py#L225)：`value == ""` 的宿主环境变量分支，在 `await asyncio.wait_for(process.wait(), 20)` 收到 `TimeoutError`。`None` 与 `"host-model"` 是同一循环中的其他值。

按该用例原样隔离运行两次后均通过；每次单测会依次走完 `None`、空字符串和 `host-model` 三个分支。此结果未解释完整 suite 中的首次 timeout，根因仍未确定；初次失败继续按 1 error 记录，不能由两次隔离通过抵消。完整复现命令：

```powershell
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_desktop.py -k test_environment_loaded_before_config_without_overriding_host -v
```

另一个历史关注项 `test_approval_resume.ApprovalResumeTests.test_waits_for_previous_cleanup_and_survives_caller_cancellation` 在本轮完整 suite 中通过（日志第 78 行为 `... ... ok`）；此前记录的 3 秒超时不属于本轮失败。

## 新增 fixture 与覆盖边界

`tests/desktop_markdown_fixtures.py` 定义了预置 `ToolModel` 响应、Markdown/未知内容块和 `markdown_echo` 工具原文，意图供真实 Agent + middleware / HTTP / SSE 原生验收使用，不访问模型网络。默认 `unittest discover` 的 `test*.py` 文件模式不会发现这个 `desktop_markdown_fixtures.py`；因此本轮后端 suite 没有验证它与原生 runner、WebView 的实际接线。该集成仍需由独占 native agent 执行 `frontend/src-tauri/tests/markdown_content_acceptance.py` 验证。本轮没有截图或原生窗口日志。

## 汇总

类型检查通过，但完整后端 suite 有一个仅在完整运行中出现、隔离重试两次未复现的 ERROR，以及一个受 Windows 权限限制的 skip。当前证据不足以断言 timeout 根因或将其归为资源竞争；失败需保持独立跟踪。没有运行额外的 Rust、前端或原生验收命令。
