> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 06 票：隐藏暂停读取并轮询会话状态

实施日期：2026-10-05。状态：已验收，票据 done，六条验收条件完成。

## 改动

**What**：主窗口显隐桥接、可见且后端就绪时第一页轮询、隐藏暂停读取及显示恢复、列表新运行提示的历史核实。

**Why**：停止隐藏窗口的网络观察，同时让后端任务继续执行；显示后重新取得真实状态，保留完整消息、分页、草稿及未知发送记录。

**How**：原生 `get_workspace_visibility`／`workspace-visibility-changed` 返回 `{revision, visible}`；前端先监听再查询。会话应用级 Store 接受 `setVisible`／`setSession`，以同一读取所有者协调暂停与恢复，继续使用既有 `/api/threads?limit=20`、历史、Run JSON／GET stream。

- 实际 hide/show 成功并读到状态变化后才递增 revision；查询在相同原生事件循环执行，失焦不等同隐藏，查询失败保留已知值，初次未知视为可见。
- 第一页读取完成后等 5 秒，单一请求不叠加；503 的 Retry-After 推迟下一轮。按 ID 合并排序，旧页、游标和当前选择不清除。
- 隐藏、租约失效、切换撤销相关 GET／SSE／计时器；不调用 cancel，不重发 POST。未知发送原文与新草稿仍保存。
- show／ready／select 同一轮合并历史定位；排队时立即显示读取中并撤销旧发送资格。布局、详情变化不重建观察。
- 摘要只提示新 Run，历史核实后切目标；更晚摘要身份使旧探针 Abort，迟到结果不接管观察。同 Run 轮询不重开第 05 票耗尽预算。

未修改后端产品、CSS、设计风格、AGENTS 或 Git 暂存／提交；未开始第 07 票。第 05 票原生测试的终态等待点按真实状态修正，原断言和 20 秒等待时限保留并加强事实核对。

## 验收证据

| 条件 | 证据 |
| --- | --- |
| 先订阅后查询、revision 竞态和失败 fallback | workspace-visibility 3 项公开桥接测试；原生 is_ok／实际读取分支及 Spec 审查 |
| 可见 ready、5 秒、不并发、失败保留及 Retry-After | visibility-polling 的慢读取、503 秒／HTTP-date、初次隐藏测试 |
| 保留旧页／游标／选择／草稿；新 Run 先核实 | 分页既有回归、503/显示保 cursor、新身份／旧摘要及 R2→R3 交错测试 |
| 暂停读取不 cancel、不撤回 POST、保留输入与事实 | 隐藏 open 观察、未知 POST、晚到历史和页面结果测试；native-final 的真实后台运行／恢复证据 |
| 合并恢复、不绕预算、不因布局重渲染重入 | ready/show/select 单次历史测试、既有第 05 票恢复全套、React 依赖审查 |
| 旧 startup_id 隔离、真实后台执行及显示恢复 | 新租约迟到结果测试；native-final 正式用例及请求／历史／revision JSON |

## 最终验证记录

调度使用 `gpt-6-luna / max`。复用旧前端验证 agent 运行 Node／类型／构建／Rust；本轮新建的 Spec／Standards agent 分别完成两轴审查，Standards agent 接续后端全套，Spec agent 接续当前权限下原生验证。主 agent 实现、修复、核对原始证据，不重复已通过的批量检查。

- Node：**106 通过／0 失败／0 跳过**，`node-tests-final-106.log`，exit 0。
- direct tsc、pnpm 生产构建：exit 0，`tsc-final-106.log`、`pnpm-build-final-106.log`；dist 引用及 34 个 CSS 资源均存在，见 `dist-verification-final-106.log`。
- Rust：**23 通过／0 失败／0 ignored**，`cargo-test-final.log`；fmt／原生 example 构建均 exit 0，`cargo-fmt-final.log`、`cargo-example-build-final.log`。
- Python ruff／format：新原生测试检查 exit 0，`ruff-check-final-106.log`、`ruff-format-final-106.log`；最终原生验证 agent 对新脚本和补改的旧第 05 票脚本一起复核，两份均通过，见 `native-ruff-106.log`。
- 后端完整 unittest：**291 总项：290 通过／1 跳过／0 失败或错误**，340.563 秒、exit 0，`backend-full-suite.log`。唯一跳过为 Windows 缺符号链接权限。初脚本 footer 的 PASS=263 为解析误差，原文保留并追加依据 unittest 真摘要核正为 290。
- 后端 ty：exit 0，`backend-ty.log`。
- 本票最终真 Tauri：**1／1 通过**、15.052 秒、exit 0，`native-visibility-final-106.log`，正常托盘退出由正式 `host.wait()==0` 断言核对。主目视最终截图，顶栏为“观察正常结束”，正文与草稿完整。revision **0 true → 1 false → 2 true**，隐藏期间不再发客户端读取请求；后台从 running 到 completed；显示后仅一次历史定位＋快照 GET，原文发送 POST 恰一次。
- 旧 03／04 票原生回归 **3／3、4／4 通过**。旧 05 票首轮 **1 通过／1 失败**，原单项诊断 **1／1 通过**；补强等待点后最终 **2／2 通过**、26.117秒、exit0，`native-regression-05-final-106.log`，保留初失败日志与产物。本票及旧票正式不同用例共10项通过，不将诊断或重复运行叠加为用例数。

完整执行命令和限制见 [交接](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-06/validation-context.md`）、[前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-06/frontend-report.md`）、[后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-06/backend-report.md`）、[原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-06/native-fresh-agent-report.md`）。旧回归在 build105 上执行；最后终态显示补修后全量 Node106／类型／构建与本票 native-final 重新验证，未重复源码无关的 Rust／后端全套；旧 05 等待点补强后执行两项原生针对回归。

## 红绿与审查整改

新增订阅、轮询、暂停、新摘要路径均先公开 seam red 再实现；初原生旧构建准确失败于缺新 command，见 `native-red.log` 和 `native-red/`。

最终首次 Node 104 项 103/1：合并微任务前未即时 loading，原 lifecycle seq 冲突重载用例过早读旧状态。原断言未改，主定向 red 后修 enter，随后 104/104。Spec 唯一 hard 是旧 R2 慢探针在新 R3 摘要后接管；新增交错 red（2 != 3）后修 summaryTarget，最终 105/105。详见 [诊断](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-06/diagnosis.md`）。

最后视觉复核发现终态显示恢复后沿用旧 paused，新增公开用例先 red（paused != closed）后修复，终态 JSON 核实成功后 closed；失败保留未核实及 queryFailure。全套106和实际 native-final 通过。旧 05 首失败实际顶栏仍运行中，仅 AI 正文包含“已完成”，原用例全页匹配提前触发；精确等待 Run 终态＋EOF，保留原20秒与全部断言并增加保存消息状态检查，未以扩时限或删断言取得通过。

Standards：无 hard 违规、无确认 smell。Spec：原 1 hard 已解决并复核，定向 race 1/1；历史发现保留于 [Spec 报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-06/spec-review.md`）。[Standards 报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-06/standards-review.md`）已补核最终 summaryTarget／终态显示及测试等待点增量，未发现放宽断言／时限。

## 原生环境与剩余检查

首正式新构建原生用例在 connect 阶段未取得 CDP endpoint（39.234 秒，0 通过／1 失败），业务路径尚未执行，见 `native-visibility-final.log` 与 `native-before-connect-fix/`。复用旧测试 agent 确认仍是 `workspace-write / auto_review`，当前 root／本轮新建 agent 为 `danger-full-access / approval never`；转交本轮新建 agent、产品／脚本不变首次即 1／1 通过（15.878秒），与环境差异一致；首失败没有自然退出码，无法还原确切 Win32 失败原因，不伪称确认了某条底层错误。最后终态补修后的 final106 1／1 单独验证，初次及各轮失败日志均保留。

未解锁、不绕过锁屏、未终止未知 PID 23344 的匹配静态服务。物理鼠标／键盘、系统 IME、带边框多尺寸与联合验收仍属第 23 票；原生窗口操作失败分支本轮通过审查与查询失败公开测试核对，未伪称实机注入了 hide/show 故障。

第 04 票审批结算超时问题本轮相关正式用例 `test_waits_for_previous_cleanup_and_survives_caller_cancellation` 为 ok，未改路径、未查明旧根因，仍保留 needs-triage。
