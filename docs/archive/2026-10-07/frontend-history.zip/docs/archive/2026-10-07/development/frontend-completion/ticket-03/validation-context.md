> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 3 票验证交接

模型要求：gpt-6-luna，max。根目录 C:/code/shikigen-agent，PowerShell。全程中文。禁止 Git 写操作、修改 AGENTS.md、修改产品代码、删除或放宽正式测试。

目标：实施 docs/wayfinder/frontend-completion/implementation/03-run-fact-reconstruction.md。统一规格 .scratch/frontend-completion/PRD.md §4–5；规划契约 docs/wayfinder/frontend-completion/tickets/002-run-projection.contract.md；样式 frontend/design.md。票 01、02 已完成，当前只完成 03，草稿持久化/自动重连/审批提交/详情 UI 为后继票。

公开验证边界已确认：HTTP/SSE、BackendSession、ConversationStore、Runtime、真实页面。不要测试私有投影方法或假造保存事实。允许可控 HTTP/流传输作测试系统边界；真实模型使用现有 deterministic fixture，不访问供应商网络。

实现：frontend/src/run-protocol.ts 校验四类 SSE、完整消息、审批 checkpoint/Interrupt、Run 身份并保留非法原文；run-projection.ts 按会话 seq 合并完整消息和预览、Run 事件、终态保护；conversation-state.ts 按租约/选择 controller/观察对象/Run 过滤迟到结果，GET 首个有效 metadata 重置自身预览，仅正常 interrupted GET EOF 核实审批身份。backend-client.ts 解析协议并校验。useConversations.ts、App.tsx 为页面提示。完整 fields/未知额外消息内容不裁剪；审批仍只读，本票不加写审批按钮。

验收：历史 running/interrupted GET 全量 stream，不加 cursor 或 Last-Event-ID；delta 同 seq/重复文字逐段追加；完整事实覆盖预览与重复去重；metadata 前失败保留预览，首次有效 metadata 只重置目标 Run；metadata 部分更新/省略与 null；终态不回退，interrupted→running 可以继续；历史 lifecycle 保留但不改当前状态；持久事件按 thread/run/seq 排序、去重、冲突和不合法载荷留只读原文；空洞与查询缺项不删除事实；审批 required/resolved/invalidated 按 seq 重建，本次 GET 正常 EOF 且 interrupted 且有效请求才核实，JSON 不替代；切换只关观察不 cancel，旧启动/旧选择/旧代次不发布；新 Run 不继承旧错误/usage/完成时间；真实页面可演示 POST 与刷新 GET 恢复。

环境：依赖已有，Python .venv/Scripts/python.exe -X utf8；.venv/Scripts/ruff.exe 与 ty.exe。避免 uv 缓存权限。前端 pnpm.exe 可用，pnpm.cmd 不存在；本地 node_modules/.bin/tsc.cmd。不要动现有 5173 服务（归属未知）；原生测试需核实端口，使用/清理自己创建的资源，所有临时DB/Agent配置隔离。记录运行 session_id、原始日志及 exitcode，长任务应持续轮询但不重跑。

主 agent 开发已定向 red/green：重建缺项/preview 失败→通过；审批 EOF 身份失败→通过；冲突原文失败→通过；终态列表回退失败→通过；新 POST 目标被稀疏历史回退失败→通过。新正式 frontend/tests/run-reconstruction.test.mjs（当前 10 项）包含这些和 malformed/truncated SSE、error+EOF、invalidated/乱序、迟到选择、usage=null。已更新旧 fixture 的真实 event_type/created_at、完整消息、usage 字段；running fixture 保持连接，不能把 running EOF 当正常完成。最终产品已就绪；后端产品未修改，可以立即独立验证。

补充：一次主 tsc.cmd 会话 33841 未返回结果，不计通过，不杀未知 node 进程；后续直接 `node frontend/node_modules/typescript/bin/tsc --noEmit -p frontend/tsconfig.json` 已 exit0（根目录）。若 wrapper 也悬挂可用直接入口。

新增原生验收 frontend/src-tauri/tests/run_reconstruction_acceptance.py，根命令 `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/run_reconstruction_acceptance.py`：精确加载3项真实 Tauri 方法（页面发送/刷新、当前 interrupted GET 正常回放身份、不让旧 interrupted 覆盖同 Run 已恢复 running）。只复用逐字节匹配最新 dist 的 5173 既有服务，未占用时共享 fixture 创建清理；9238/45200 必须空闲。当前 backend_window.exe 若存在可复用（本票 Rust 无变化）；先构建前端。退出仍使用既有 tray quit 断言，若失败报告事实，不掩盖。Windows默认沙箱可能不能创建原生窗口或读取CDP，可根据明确用户实现/实机授权在自动审批允许时 require_escalated；被拒报告action/reason及覆盖缺口，不无限重试。不要更改脚本，仅查证与报告，修复由主 agent 处理。

后端命令（根目录）：专项 unittest discover -s tests -p test_run_observation.py -v、test_recovery.py、test_approval_resume.py、test_server.py、test_message_contract.py、test_run_events.py；最后完整 unittest discover -s tests -v 一次。ty check app packages/harness；ruff 按实际改动 Python 文件。必要专项可以由完整回归覆盖，但报告需指出对应各模块计数。Windows symlink privilege 缺失的既有跳过不计通过。原始输出含预期负路径 stack 的方法仍 ok 时不要误报失败。完整回归预计 10–12 分钟。

前端命令（frontend）：node --experimental-strip-types --test tests/*.test.mjs，node_modules/.bin/tsc.cmd --noEmit，pnpm.exe build。可另写 scratch public HTTP/SSE 边界探针，不改正式测试。核对现有断言强度，不仅跑容易通过部分。报告模型、每条命令/cwd/退出码/数量、失败复现、日志、剩余覆盖。

本轮审查固定点 `.scratch/frontend-completion/ticket-03/before/` 工作副本；新文件在 files.txt 中标记。不是 HEAD 整体 diff，不评审用户已有变更。所有测试/审查产物写本目录。
