> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 17 票 Standards 审查

## 审查范围

依据实现与夹具定稿时的 `.scratch/frontend-completion/ticket-17/review.diff`（18 个文件，1641 行）及旧焦点代码摘录 `.scratch/frontend-completion/ticket-17/markdown-focus-before.txt`。本次续审聚焦运行详情与 Markdown 焦点两个原生验收夹具修正；焦点旧证据只覆盖被改动的代码段，不视为整份文件的编辑前副本。规范来源为 `AGENTS.md`、`CONTEXT.md`、`frontend/design.md`、`docs/agents/domain.md`。未运行 Git、测试、构建或原生程序。

主agent收尾注：验收结束后仅更新实施票据与索引，重新生成的差异为1667行；产品与测试夹具没有再变。

## 结果：硬性规范 0 项；Fowler 启发式 2 项

此前指出的实体、布尔值与回调命名问题均已在最新差异中改正。HTTP/SSE JSON 中的 `data` 键属于外部契约，不按本地变量命名问题报告。

### Fowler 启发式（此前产品审查建议，保留）

- **可能的 Data Clumps** — `frontend/src/components/RunDetails.tsx:32-34` 用两组平行数组按 `index` 配对指标标签与数值。可将每行的标签和值放在同一条目中迭代，消除位置耦合。此项是可读性建议，不是硬性违规。
- **可能的 Mysterious Name** — `frontend/tests/run-details.test.mjs:18` 的 `setup` 创建客户端、存储、会话与流夹具，但名字没有说清楚创建哪种夹具；可考虑 `createRunDetailsFixture`。此项是可读性建议。

## 本次原生夹具增量复核

- `frontend/src-tauri/tests/run_details_acceptance.py:179-185` 精确断言 `getComputedStyle(...).width === "400px"`，并将 rect 宽度与 DPR 一同记入证据。设计规格使用 CSS px，因此精确检查 CSS 声明对应的计算宽度，同时保留原生尺寸背景供核对，没有放宽抽屉宽度标准。
- 同文件 `:107-121` 在请求保持 pending 时要求显示“正在读取用量”，排除“暂无用量数据”和“已保存”；释放后再断言真实未知用量及“仍在结算”“尚未结束”。这区分了读取中、无累计值与结算状态，没有用空态掩盖请求状态。
- `frontend/src-tauri/tests/markdown_content_acceptance.py:259-304` 检查 CSS 规则中的 `outline` 声明精确为 `2px solid var(--accent)`、偏移精确为 `3px`，与 `frontend/src/styles.css:50-51` 的现有规则一致；同时保留计算颜色及 content／关闭按钮／焦点恢复三者的完整状态相等断言。原生 DPI 可能量化计算后的 outline 数值，因此以声明验证规格，并将实际 `focus_styles` 在断言前记录。该调整没有降低视觉规格或焦点恢复要求。

本次没有发现新增 Standards 问题；只读静态审查未执行任何验证命令。
