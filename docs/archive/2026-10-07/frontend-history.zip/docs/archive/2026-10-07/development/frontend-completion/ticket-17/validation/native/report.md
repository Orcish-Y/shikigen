> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第17票：运行详情与用量最终验收

最终结论：7 个唯一原生场景均取得当前源码下的通过证据，分多个串行 batch 完成，不是一次 7/7 单批运行。历史受限环境错误与夹具断言失败保留在日志中。最终清理确认测试端口已释放，原有 5173 服务仍然可用。

## 环境与范围

- 执行模型：gpt-6-luna，推理强度 max（按委派要求）。
- 工作目录：C:\code\shikigen-agent；Windows PowerShell；Python 解释器：.venv/Scripts/python.exe。
- 规格：docs/wayfinder/frontend-completion/implementation/17-run-details-usage.md、docs/wayfinder/frontend-completion/tickets/005-run-details.contract.md、PRD §16/17。事件 GET 和有限结算轮询属于后续范围。
- 使用真实 Tauri WebView、HTTP/SQLite 与离线 Graph fixture，模型完成回调和工具链实际执行；未访问外网或供应商。
- 每项使用隔离临时 profile/SQLite。各 native batch 启动前都校验 5173 当前 dist 的 index/资产字节匹配（index 396 字节、2 个资产），并复用已有服务；没有重启或停止 5173。
- 子 agent 未修改产品或测试文件，未运行 Git 命令；夹具与断言调整由主 agent 完成。

## Python lint / 格式

当前相关四个 Python 文件均有通过证据：run_details_acceptance.py、desktop_usage_fixtures.py、native_runner.py、markdown_content_acceptance.py。最终四文件 Ruff check 和 format --check 通过；主 agent 最后更新 Markdown CSS 断言后，又对该文件单独复查，两项仍通过。准确命令、exit code 和日志见 command-results.json。

## 当前源码下的七个唯一原生场景

| 场景 | 通过 batch | 结果证据 |
| --- | --- | --- |
| 真实 0 用量、服务端时间与复制 | native-probe-fix-1 | usage 为 input/output/total=0、calls=1、by_model={}、pending=false；会话/Run/UTC 时间复制成功。result.json、window.png。 |
| running 未知用量、打开详情复用 pending GET | native-recheck-1 | hold 阶段显示正在读取，打开详情复用请求；release 后继续显示真实未知/结算状态；不建第二 SSE。result.json、window.png。 |
| 多模型累计、外部第二 POST、500 保值、旧 GET 隔离 | native-remaining-1 | input=15、output=12、total=27、calls=2；by_model 为两个真实模型键（含长模型名）；第二运行切换目标，500 保留值，旧响应不污染新会话。result.json、window.png。 |
| 取消后同 updated_at 晚到用量 | native-remaining-1 | 取消快照为 cancelled/pending=true；晚到快照 updated_at 相同、usage=0、calls=0；显示真实取消状态。result.json、window.png。 |
| 真实执行失败的只读详情 | native-remaining-1 | 实际 error 完整显示，可查看后返回，始终只有一个前景层。result.json、window.png。 |
| 工具记录既有回归 | native-remaining-1 | 工具 status 配对、完整记录、空值和复制断言通过。result.json、window.png、narrow-tool-records.png。 |
| Markdown 完整内容既有回归 | native-markdown-recheck-1 | 完整内容、复制、焦点与返回状态通过。声明 outline 为 2px solid var(--accent)、offset 3px；content/button/restored 的 focus-visible 与 computed 样式完全一致。result.json、window.png、desktop-drawer.png、narrow-content.png。 |

当前唯一用例状态为 7 通过、0 失败、0 错误、0 跳过，依据来自多个批次，具体路径列在 command-results.json。

## 历史失败与修订

- 普通受限环境首次探针在 CDP WebSocket 握手 EOF，计为 error；提升权限后 WebView 可启动。
- 初版零用量探针严格比较 getBoundingClientRect 的浮点宽度，400.0000305175781 与 400 不等。主 agent 改为验证 CSS 声明 400px 并记录 rect/DPR；当前探针通过，记录 DPR=1.75。
- 初版 unknown fixture 在 RunSnapshot 被 hold、尚未交给界面时仍期待“暂无用量数据”，实际界面正确显示“正在读取用量”。主 agent 修正 hold 阶段断言后专项复测通过。UTF-8 failure.json 和截图确认文本正常；早期乱码仅是 stderr 编码展示。
- Markdown 旧断言预期 computed outline-width=2px，WebView 在 DPI 下返回 1.71429px；随后测试从 CSSOM 的 outlineWidth 长属性读取，因源 CSS 声明 shorthand（outline: 2px solid var(--accent)）而得到空数组。主 agent 改为检查原始 shorthand 声明；最终单项复测通过，computed 值在 content/button/restored 间一致。
- 原始失败均保留：native-probe-1、native-probe-elevated-1、native-remaining-1、native-recheck-1 的日志和 failure JSON/截图没有覆盖。全部历史执行共 12 次：通过 7、失败 4、错误 1、跳过 0；当前 7 个唯一场景均有通过证据。

## 清理与限制

- 最终端口检查：9238=false、45200=false；5173=true，HTTP 200、index 396 字节。结果在 validation/native/native-final-cleanup.*。
- 截图为 WebView CDP 截图，不代表 OS 桌面原生截图。未验实体键盘/IME、原生窗口框、四档联合视口。
- 离线 Graph fixture 证明本地累计/呈现路径，不证明真实供应商用量或账单金额。
- 本轮没有重建 dist，也没有重复前端 72 项测试、TypeScript 或 build 检查。
