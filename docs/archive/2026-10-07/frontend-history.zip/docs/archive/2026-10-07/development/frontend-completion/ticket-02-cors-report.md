> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 02 CORS 回归报告

## 执行信息

- 执行模型：gpt-6-luna，推理强度 max。
- 工作目录：`C:\code\shikigen-agent`，PowerShell。
- 覆盖规格：`docs/wayfinder/frontend-completion/implementation/02-paginated-conversation-list.md`（AC6 Retry-After），以及总规格 `.scratch/frontend-completion/PRD.md`。
- 本轮只执行票 02 的回归；未启动 GUI、未占用固定 native 端口。未修改产品代码、测试断言或 Git 状态；主 agent 修改 `app/desktop.py` 暴露 `Retry-After`，并缩短新测试方法名以通过 Ruff。

## CORS red/green

新公开 HTTP 回归启动隔离的桌面子进程并访问随机端口上的 `/api/threads`。它验证 `http://127.0.0.1:5173` 和 `http://tauri.localhost` 都获准读取 `Retry-After`，并验证 `https://unrelated.example` 不获 ACA-Origin。

首次 red 命令：

```powershell
& .\.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_desktop.py -k desktop_origins -v
```

- 结果：退出码 1；运行 1 个测试方法。两个允许 Origin 的子测试都因 `access-control-expose-headers` 为空、集合为 `{''}`，缺少 `retry-after` 而失败。
- 两个子测试失败后测试仍继续；日志没有不允许 Origin 的断言失败。修复后的定向用例完整通过包括不允许 Origin 的断言。
- 复现原始输出：`.scratch/frontend-completion/ticket-02-cors-red.log`。

主 agent 添加 `expose_headers=["Retry-After"]` 后，原筛选命令通过（1/1，退出码 0），日志为 `.scratch/frontend-completion/ticket-02-cors-green.log`。测试方法后来改名为 `test_desktop_origins_can_read_retry_after`，断言未变；最终定向复核仍用 `-k desktop_origins`：

```powershell
& .\.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_desktop.py -k desktop_origins -v
```

- 结果：1/1 通过，退出码 0；日志 `.scratch/frontend-completion/ticket-02-cors-final.log`。

## 专项回归

以下命令按顺序执行，未并行运行共享桌面测试：

| 命令 | 结果 | 原始日志 |
|---|---:|---|
| `.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_desktop.py -v` | 12/12 通过，退出码 0 | `.scratch/frontend-completion/ticket-02-desktop.log` |
| `.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_desktop_lifecycle.py -v` | 3/3 通过，退出码 0 | `.scratch/frontend-completion/ticket-02-desktop-lifecycle.log` |

## 静态检查

- 首次尝试 `uv run ruff check app/desktop.py tests/test_desktop.py` 退出码 2：uv 无法访问全局缓存目录 `C:\Users\Orcs0\AppData\Local\uv\cache`（拒绝访问）。日志：`.scratch/frontend-completion/ticket-02-ruff.log`。
- 随后运行 `.venv\Scripts\ruff.exe check app/desktop.py tests/test_desktop.py`，发现新测试方法定义行 91 列、超过 88 列（`tests/test_desktop.py:127`），退出码 1。主 agent 缩短方法名后重检同一范围，通过、退出码 0。失败诊断：`.scratch/frontend-completion/ticket-02-ruff-local.log`；最终通过日志：`.scratch/frontend-completion/ticket-02-ruff-final.log`。
- `.venv\Scripts\ty.exe check app packages/harness`：通过，退出码 0。日志：`.scratch/frontend-completion/ticket-02-ty.log`。

## 完整 Python 回归

```powershell
& .\.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -v
```

- 结果：286 项，285 通过、1 跳过、0 失败；退出码 0，耗时约 271 秒。
- 唯一跳过项：`test_symlink_data_and_parent_are_rejected`，原因是 Windows 符号链接权限不可用。
- 原始完整输出：[本轮 286 项日志（原始产物已删除）](../../README.md#已删除的材料)。原来的 `ticket-02-python-final.log` 保留上一轮 285 项输出，两个阶段的证据分别归档。

## 覆盖边界

Python HTTP 回归检查 `/api/threads` 的 CORS 响应头和 Origin 限制。此报告未验证真实 503 响应中的 `Retry-After` 值，也未在原生 WebView 中读取该头；这些真实服务端错误与浏览器路径由 native agent 单独补证。此次没有重跑未受后端 CORS 改动影响的 Node、TypeScript 检查或前端构建。
