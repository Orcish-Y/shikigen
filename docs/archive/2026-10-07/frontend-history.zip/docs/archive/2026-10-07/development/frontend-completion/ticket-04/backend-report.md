> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 04 后端最终验证报告

- 执行模型：`gpt-6-luna / max`（主 agent 指派）
- 工作目录：`C:/code/shikigen-agent`
- 范围：后端专项、类型检查及一次完整 Python 回归。没有改产品代码或正式测试；未执行 Git 写操作。真实 Tauri 窗口由前端验证 agent 独占。本次确认后端完整回归仅用内存 ASGI、临时 SQLite 和隔离后端服务子进程；其临时端口及 `654xx` 端口测试不占 `45200`／`9238`，没有打开原生窗口。

## 结果

| 检查 | 结果 |
| --- | --- |
| `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_server.py -v` | 通过，17 项；新增原文/surrogate 用例通过，含 2 个 subtests。日志：`backend-test-server.log` |
| `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_text_safety.py -v` | 通过，2 项。日志：`backend-text-safety.log` |
| `.venv/Scripts/ty.exe check app packages/harness` | 通过，`All checks passed!`。日志：`backend-ty.log` |
| `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` | **未通过**：291 项，289 通过、1 错误、1 跳过，运行 636.388 秒。日志：`backend-full-suite.log` |

完整回归跳过项：`test_runtime_data.RuntimeDataTests.test_symlink_data_and_parent_are_rejected`，原因是 Windows symlink privilege unavailable。唯一错误是 `test_approval_resume.ApprovalResumeTests.test_waits_for_previous_cleanup_and_survives_caller_cancellation`：`tests/test_approval_resume.py:258` 等待 `settled.wait()` 3 秒超时。

该精确用例按原命令隔离重跑两次，均以同一超时失败（日志：`backend-approval-resume-repro.log`、`backend-approval-resume-confirmation.log`）。scratch 诊断探针两次都在 3 秒等待内到达事件，但它们不计作正式用例通过。详细探针记录：`transitions is coordinator._settlement` 为真；包装的原始 `settle_execution` 无异常，约在 resume 起点 2.828 秒进入、3.297 秒返回并触发事件；触发时 Run 状态为 `interrupted`，registry 保留 second，后台 task 正在探针的 `release.wait()` 上，释放后 task 正常结束且 `exception=None`。观察提示可能受 3 秒时序窗口影响，根因仍不确定，且不能抵消两次正式定向失败。诊断日志：`backend-approval-resume-diagnostic.log`，脚本：`diagnose_approval_resume.py`。

## 复现命令

```powershell
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_approval_resume.py -k test_waits_for_previous_cleanup_and_survives_caller_cancellation -v
```

Ticket 04 未修改上述审批恢复产品路径或正式用例；该票只在 `tests/test_server.py` 增加原文/surrogate 用例，该专项通过。超时根因仍未确认，不能据此断言它与本轮差异完全无关。另行追踪：[审批恢复结算超时](../../../../../issues/approval-resume-settlement-timeout.md)。未覆盖项：真实 Tauri 窗口验收由前端验证 agent 执行；本报告没有截图。
