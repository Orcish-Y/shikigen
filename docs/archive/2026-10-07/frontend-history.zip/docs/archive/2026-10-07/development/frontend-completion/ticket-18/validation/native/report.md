> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 18 原生验收批次报告

执行模型：`gpt-6-luna`，推理强度 `max`。仓库：`C:\code\shikigen-agent`。Python：3.12.13；Ruff：0.16.0。

## Native 运行批次

| Batch | runner 选择 | 结果 | 解释 |
|---|---:|---:|---|
| `native-final-1`（默认沙箱） | 5 | 2 failures，3 errors，退出 1 | CDP DevTools endpoint 超时或 WebSocket `no close frame received` / WinError 10054；未到产品断言。原始证据保留。 |
| `native-final-1-escalated` | 5 | 4 passed，1 failed，退出 1 | 提升权限后 CDP 正常；发现详情子视图返回后的 scrollTop 从约 250.286 跳到 1013.143。 |
| `native-scroll-fix-1` | 1 | 1 passed，退出 0 | 修复后滚动与焦点恢复断言通过。 |
| `native-timeline-evidence-1` | 1 | 1 passed，退出 0 | 只在所有行为断言之后滚到事件区再截图，提供时间线视觉证据；没有改变断言。 |
| native-style-final-1 | 1 | 1 passed，退出 0 | 最终字体／行高样式下重跑同一受影响场景，包含时间线截图和 JSON 几何断言。 |

合计执行 13 次测试调用、5 个唯一测试方法。四个回归方法在 `native-final-1-escalated` 通过；主 agent 指示保留结果、不为滚动修复重复运行。唯一失败方法修复后先在两批通过，并在最终 JSON 样式复验批次再次通过。默认沙箱失败归为 CDP 环境失败，未作为产品失败或通过计算。

## 最终样式批次原生证据

- 最终时间线截图：[window.png（原始产物已删除）](../../../../../README.md#已删除的材料)。此前时间线截图仍保存在 [native-timeline-evidence-1（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 测试数据：[result.json（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 三次事件 GET 的服务端序号分别是 `1–4`（打开详情）、`1–6`（实际提交后重开）、`1–9`（正常终态 EOF 一次补读）；全都未 abort。EOF 通知只额外产生一次查询。
- required 事件完整 JSON 断言覆盖 80 行参数。最终几何断言为 max-height 320px、clientHeight 319px、scrollHeight 15104px、font-size 12px、line-height 20px；复制在 navigator.clipboard 边界捕获完整内容。
- 滚动位置为 250.2857px；子视图返回时焦点和位置断言通过。EOF 前位置为 180px。时间线开启消息过滤时显示 6 条，公开响应共 9 条。

## 首次故障与修复记录

提升权限的第一轮复现完整保存在 `native-final-1-escalated`：`failure.json` 保存页面、请求和焦点，`window.png` 保存当时画面。失败断言在 `run_events_acceptance.py` 第 119 行，返回子视图时位置跳到约 1013px。主 agent 修复 `trigger.focus({preventScroll:true})`，没有放宽断言；之后两个单项原生批次均通过。

默认沙箱的 EOF 证据保留在 `native-final-1/native-runner.stderr.log` 和各自的 `capture-error.txt`。提升权限重跑后 5 个场景正常启动，排除了 CDP 沙箱限制对产品测试结果的干扰。

## 服务与清理

每批 runner 输出均为 `SHARED_DIST_SERVER_MODE=reused`，并核对 5173 响应的 index 为 396 bytes、引用的 2 个资源与当前 `frontend/dist` 字节一致。runner 没有拥有或停止共享服务。最后复核：5173 仍在监听；9238 与 45200 均空闲，隔离 Tauri/backend listener 已结束。

## 限制

- `navigator.clipboard` 是 WebView 边界替身，不是 OS 剪贴板验证。
- `window.png` 是 CDP WebView 截图，不包含 Tauri 原生窗框；物理 IME 和四档 viewport 不在本票范围，归 23 票。
- 最终 JSON 字号／行高变更已在 native-style-final-1 通过专属原生场景复验；40 项定向 Node、tsc/build 和两份 Python 夹具 Ruff 检查结果见 [前端最终批次](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/frontend/style-final-1/report.md`）。

命令、cwd、权限、exit code、逐批计数、unique 方法和服务状态详见同目录 [command-results.json（原始产物已删除）](../../../../../README.md#已删除的材料)。所有 runner stdout/stderr 与截图/JSON 证据均按 batch 保留，未覆盖历史批次。

