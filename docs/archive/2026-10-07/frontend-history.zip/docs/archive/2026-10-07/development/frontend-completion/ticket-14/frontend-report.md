> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 14 票前端与原生验证报告

## 验证环境与范围

- 验证模型：`gpt-6-luna`，推理强度 `max`（按交接指定）。
- 前端目录：`C:\code\shikigen-agent\frontend`；原生、Ruff 与报告命令工作目录：`C:\code\shikigen-agent`。
- 依据：第 14 票、PRD §13、资源契约 §7、`frontend/design.md`。验证覆盖 Agent Markdown 本地图片、受控 Blob 生命周期、图片完整查看/复制、阅读锚点、当前 workspace/租约，以及 Tauri 的真实 Graph、HTTP 与窗口行为。
- 未运行 Git 命令。没有 Rust 产品或依赖变更，未重建 Rust。

## 命令结果

所有时间均为 2026-10-06 Asia/Shanghai。原始 stdout、stderr 和逐命令 JSON 元数据保存在表内目录。

| 时间 | 命令 | 结果 | 证据 |
| --- | --- | --- | --- |
| 10:20:16–10:20:28 | `node --import tsx --test tests/*.mjs`（frontend cwd；首轮完整回归） | exit 0；172 tests，172 pass、0 fail、0 skipped | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:32:51–10:32:58 | `node --import tsx --test tests/workspace-images.test.mjs tests/message-content.test.mjs tests/chat-reading-position.test.mjs`（frontend cwd；最终命名树） | exit 0；22 tests，22 pass、0 fail、0 skipped | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:32:58–10:33:02 | `node node_modules/typescript/bin/tsc --noEmit`（frontend cwd） | exit 0 | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:33:02–10:33:13 | `node node_modules/vite/bin/vite.js build`（frontend cwd） | exit 0；最新 `dist` 已用于原生重验 | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [stderr（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:33:56 | `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/workspace_image_acceptance.py tests/desktop_workspace_image_fixtures.py .scratch/frontend-completion/ticket-14/native_runner.py .scratch/frontend-completion/ticket-14/native_retry_runner.py`（repo cwd） | exit 0 | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:33:56 | `.venv/Scripts/ruff.exe format --check`，同上 4 个文件（repo cwd） | exit 0；4 files already formatted | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:25:25–10:26:29 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-14/native_runner.py`（repo cwd；首次 7 项批次） | exit 1；7 tests：4 pass、1 fail、2 error | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [stderr（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:34:08–10:34:32 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-14/native_retry_runner.py`（repo cwd；最终树 3 个图片专项） | exit 0；3 tests，3 pass、0 fail/error/skipped | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [stderr（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |

原始全量 Node 回归为 172/172。发现并修复 App 的租约轮换 overlay 缺口后，按主 agent 要求又执行一次全量回归，仍为 172/172，见文末闭环复验记录。最后一次只把 effect updater 的局部变量从 `current` 政名为 `currentOverlay`；该变更后补跑了 tsc、Vite 与单项 Tauri 验收，没有再重复完整 Node。

## 原生失败诊断与最终结果

首次 7 项批次中的两条旧 Markdown 用例和两条旧阅读位置用例均通过。三条新图片 fixture 当时有测试问题：第一条的 SVG 计数把界面 Phosphor 图标算进内容，得到 `12 != 0`；另外两条调用 fixture 不存在的 `tray_left` 方法。主 agent 修正为过滤界面图标并使用现有 `tray_menu` API，保留了图片安全、隐藏中止、Blob URL 释放与阅读锚点断言。未删减产品断言。

最终树上的 `recheck-1` 三条图片用例全部通过。原首次批次日志和截图仍保留于 `native/batch-1/`，没有覆盖失败证据。最终图片批次的逐例结果、截图和结构化结果位于 [native/recheck-1（原始产物已删除）](../../../README.md#已删除的材料)；包括延迟图片锚点以及隐藏时中止/迟到结果过滤的独立证据。

原生服务检查确认 5173 上的既有 PID 23344 仍由原进程持有，runner 逐字节核对并复用了它：dist index 396 bytes、2 个直接引用 assets 均与本轮最终 `frontend/dist` 一致。没有关闭此进程；9238 与 45200 在原生运行期间空闲，结束后也无监听。

## 构建提示与覆盖边界

最终 Vite 构建成功，但报告了非阻断 bundle 警告：最新主 JS chunk 为 583.20 kB（gzip 177.84 kB），超过默认 500 kB 阈值。完整 Node 回归在 App 行为修复后通过；之后纯局部变量改名未再重复整套。四条旧原生用例在首次 7 项批次通过，按主 agent 指示没有重复；三条图片专项在 App 租约详情修复前的当时构建通过，租约轮换单项在最新构建通过。没有在最终构建重复全部原生用例。完整回归计数及逐命令时间可在各自 `.meta.json` 中核对。

## App 修复后的闭环复验

App 现随 `BackendSession` 或窗口可见状态变化关闭已打开的图片详情。完整 Node 回归确认原生/DOM 单元覆盖无回归；真实 Tauri 单项确认图片详情关闭、旧 URL 释放、当前图片重新解析，以及 Run ID 保持一致。

| 时间（Asia/Shanghai） | 命令与目录 | 结果 | 证据 |
| --- | --- | --- | --- |
| 10:42:12–10:42:22 | `node --import tsx --test tests/*.mjs`（frontend cwd；App 行为修复后完整回归） | exit 0；172 tests，172 pass、0 fail、0 skipped | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:41:57–10:42:01 | `node node_modules/typescript/bin/tsc --noEmit`（frontend cwd） | exit 0 | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:42:01–10:42:12 | `node node_modules/vite/bin/vite.js build`（frontend cwd；App 行为修复后） | exit 0 | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [stderr（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:42:32–10:42:33 | `.venv/Scripts/ruff.exe check` 与 `.venv/Scripts/ruff.exe format --check`，均覆盖 `frontend/src-tauri/tests/workspace_image_acceptance.py`、`tests/desktop_workspace_image_fixtures.py`、`.scratch/frontend-completion/ticket-14/native_runner.py`、`.scratch/frontend-completion/ticket-14/native_retry_runner.py`、`.scratch/frontend-completion/ticket-14/native_lease_rotation_runner.py`（repo cwd） | 两命令 exit 0；5 files already formatted | [Ruff check stdout/meta（原始产物已删除）](../../../README.md#已删除的材料) / [Ruff check meta（原始产物已删除）](../../../README.md#已删除的材料) / [Ruff format stdout/meta（原始产物已删除）](../../../README.md#已删除的材料) / [Ruff format meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:42:48–10:43:02 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-14/native_lease_rotation_runner.py --artifact-suffix lease-final-1`（repo cwd） | exit 0；1 test pass | [结果（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:43:28–10:43:44 | `node node_modules/typescript/bin/tsc --noEmit` 后 `node node_modules/vite/bin/vite.js build`（frontend cwd；最终局部命名树） | 两命令 exit 0；新构建产物用于 `lease-final-2` | [tsc stdout/meta（原始产物已删除）](../../../README.md#已删除的材料) / [Vite stdout/stderr/meta（原始产物已删除）](../../../README.md#已删除的材料) |
| 10:43:57–10:44:09 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-14/native_lease_rotation_runner.py --artifact-suffix lease-final-2`（repo cwd；最终构建） | exit 0；1 test pass，9.287s；测试内 Run ID 相等断言通过 | [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [stderr（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料) / [截图（原始产物已删除）](../../../README.md#已删除的材料) |

`lease-final-2` 使用 updater 局部命名调整后的最终构建：5173 index 为 396 bytes，2 个引用 assets 与 `frontend/dist` 字节一致，服务被复用。事件帧仍通过公开 Tauri `plugin:event|emit` 桥接注入 ready→ready startup 租约变化；它使用真实 Tauri、fixture backend/Graph/HTTP 与图片资源读取，但不模拟 BackendManager 子进程本身的重启。最新 build 主 JS chunk 为 583.20 kB（gzip 177.84 kB），Vite 仍给出超过默认 500 kB 的非阻断警告。

## ready 租约轮换缺口（红灯基线）

在主 agent 修复 App 前，单项真实 Tauri 测试运行结果：

| 时间（Asia/Shanghai） | 命令与目录 | 结果 |
| --- | --- | --- |
| 2026-10-06 10:38:40–10:38:56 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-14/native_lease_rotation_runner.py --artifact-suffix lease-red-1`，repo cwd | exit 1；1 test、1 fail，13.483s。失败点为 `workspace_image_acceptance.py:301` 等待 `dialog[open]` 数量变为 0，超时后仍打开。 |

截图显示完整图片 overlay 仍在右侧。失败诊断同时显示：图片 `/image` 请求总数 4，旧 2 个 Blob URL 已 revoke，4 个消息图片当前都由新 URL 显示；因此红灯具体落在 overlay 没有随 ready→ready startup 租约事件关闭。Run ID 后续相等断言未执行，不能计作通过。[failure JSON（原始产物已删除）](../../../README.md#已删除的材料) / [截图（原始产物已删除）](../../../README.md#已删除的材料)；命令 [stdout（原始产物已删除）](../../../README.md#已删除的材料) / [stderr（原始产物已删除）](../../../README.md#已删除的材料) / [meta（原始产物已删除）](../../../README.md#已删除的材料)。

该用例在真实 Tauri 窗口中使用真实 fixture backend、Graph、HTTP 与图片请求；仅 `backend-state-changed` 输入是通过 `plugin:event|emit` 公共桥接发出的 ready→ready 测试帧（startup_id 改变、revision 增加）。这验证 App 对桥接收到的新租约事件如何响应，**不证明真实 BackendManager 子进程重启**。5173 既有服务经 index 与两个 assets 字节核对后复用，没有关闭；9238/45200 空闲。
