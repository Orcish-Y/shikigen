> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 08 票：完整呈现工具调用、结果与附加数据

日期：2026-10-05。状态：已验收。核心 15 项原生验收与修后新增 1 项通过，累计 16 个唯一用例；补充检查的两次失败和测试预期修正完整保留。Standards／Spec 独立审查均无剩余 finding。

## 实现

**What**：调用卡片内查看真实参数、结果、附加数据和原始记录；无法唯一关联的结果独立保留。

**Why**：让用户核对工具实际做了什么，并保留长会话的阅读节奏。

**How**：既有 HTTP／SSE 完整事实经 `presentMessage` 保留到 `Message.record`；`toolRows` 按会话／运行／tool_call_id 唯一关联，只调整展示位置。`ToolCard` 复用 `MessageBody`、`ContentBlock`／`ContentViewer`，应用级 `ToolCardPreferences` 保存本次运行期间的阅读选择。`RunProjection.snapshot().runStatuses` 提供各调用所属运行的只读状态说明，不新增后端接口。

- 按 tool_calls 原顺序放在 Agent 消息下，原调用与结果及其 seq、ID、名称、status、artifact 和公开额外字段均保留。
- 真实 ToolMessage／status 决定“等待结果／已返回／工具失败”。Error 字样不改变状态；运行已结束且没有结果，仍保留等待并说明所属运行已结束。
- 空字符串／空数组正文说明已返回且为空；明确文本块按工具原文展示，未知结构和额外字段可完整核对。
- 正常默认折叠，首次失败只展开卡片和结果。手动收起跨会话切换、数据刷新和重复回放保持，重启重新使用默认；参数、附加数据与原始记录独立折叠。
- 非 null artifact 包括空字符串、0、false、[]、{} 均完整只读，省略／null 不造区；内容不执行路径、媒体或审批操作。
- 沿用 Slate／白色／1px／8px 和靛蓝焦点，失败有匹配红色图标与文字；长结果最高 320px 内滚动，完整查看／复制不裁剪。浏览器示例“工具完整记录示例”覆盖同名、乱序、重复身份、空值与未配对结果。

固定基点 `0c52c18060158ebe23151a66fcba88feb4273ccd`，本轮开始工作树干净。未修改后端产品、依赖、AGENTS 或后续票据代码。完整会话导出仍归第 16 票。

## 最终验证

全部最终验证和两轴审查由显式 `gpt-6-luna / max` 子 agent 执行；主 agent 核对原始日志、退出码、完整复制结果以及桌面／窄屏截图。完整上下文：[validation-context.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-08/validation-context.md`）；开发初次失败与修正：[diagnosis.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-08/diagnosis.md`）。

| 检查 | 工作目录与实际命令 | 结果 | 证据 |
| --- | --- | --- | --- |
| 前端完整测试 | `frontend`：`pnpm.exe test` | 117 通过，0 失败／跳过 | [stdout（原始产物已删除）](../../../README.md#已删除的材料)、[退出码（原始产物已删除）](../../../README.md#已删除的材料) |
| 类型检查 | `frontend`：`node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json` | exit 0 | [退出码（原始产物已删除）](../../../README.md#已删除的材料) |
| 生产构建 | `frontend`：`pnpm.exe build` | exit 0；保留 500 kB chunk warning | [构建（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[dist hash（原始产物已删除）](../../../README.md#已删除的材料) |
| Rust 完整测试 | `frontend/src-tauri`：`cargo test` | 25 通过，0 失败／忽略 | [stdout（原始产物已删除）](../../../README.md#已删除的材料)、[退出码（原始产物已删除）](../../../README.md#已删除的材料) |
| Rust 格式／验收宿主构建 | `frontend/src-tauri`：`cargo fmt --check`；`cargo build --example backend_window` | 两项 exit 0 | [fmt（原始产物已删除）](../../../README.md#已删除的材料)、[宿主（原始产物已删除）](../../../README.md#已删除的材料) |
| 真实 Tauri 串行验收 | 根目录：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-08/native-runner.py`，PYTHONPATH 包含原生测试／tests／harness | 15 通过，0 失败／跳过；03／04／05／06／07／08 分别 3／4／2／1／2／3 | [原生 stderr（原始产物已删除）](../../../README.md#已删除的材料)、[分组（原始产物已删除）](../../../README.md#已删除的材料)、[退出码（原始产物已删除）](../../../README.md#已删除的材料)、[报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-08/native-report.md`） |
| 原生复制入口修后专项 | 根目录，同一 PYTHONPATH：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-08/native-copy-final-runner.py` | 仅新增方法 1 通过，0 失败／跳过，10.011 秒；累计 16 个唯一用例，本票 4 个、旧票 12 个 | [专项 stderr（原始产物已删除）](../../../README.md#已删除的材料)、[退出码（原始产物已删除）](../../../README.md#已删除的材料)、[公开记录与复制值（原始产物已删除）](../../../README.md#已删除的材料)、[完整查看截图（原始产物已删除）](../../../README.md#已删除的材料) |
| 后端完整测试 | 根目录：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` | 291 项：290 通过、0 失败／错误、1 权限跳过，exit 0 | [stderr（原始产物已删除）](../../../README.md#已删除的材料)、[退出码（原始产物已删除）](../../../README.md#已删除的材料)、[报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-08/backend-report.md`） |
| 后端类型 | 根目录：`.venv/Scripts/ty.exe check app packages/harness` | exit 0 | [退出码（原始产物已删除）](../../../README.md#已删除的材料) |
| 新 Python 文件 lint／格式 | 根目录：`.venv/Scripts/ruff.exe check`／`format --check`，目标 `tests/desktop_tool_records_fixtures.py`、`frontend/src-tauri/tests/tool_records_acceptance.py` | 首次 lint 8 条；修后及新增方法／预期修正后的最终两项均 exit 0 | [初次（原始产物已删除）](../../../README.md#已删除的材料)、[最终 lint（原始产物已删除）](../../../README.md#已删除的材料)、[最终格式（原始产物已删除）](../../../README.md#已删除的材料) |

开发期间的 6 项定向检查不重复加进最终 117 项；本票原生 4 项不计入 Rust 25 项。产品冻结后仅修 Python 测试字符串／闭包及补充复制检查的类型预期，未重复运行已通过的前端／Rust／后端完整批次或旧 15 项原生批次。

补充复制入口的前两次尝试各失败 1 项，日志分别见[初次（原始产物已删除）](../../../README.md#已删除的材料)与[诊断复跑（原始产物已删除）](../../../README.md#已删除的材料)。公开 HTTP 的 orphan 正文已经是 JSON 文本字符串，客户端逐字复制正确；测试对这个字符串再次 JSON 编码产生额外引号和转义。预期修正为字符串直接使用原文、其余值使用完整 JSON，严格相等、完整查看、无额外 POST 和 history 不变断言均保留，产品未改。修后只重跑新增方法通过；失败尝试不算通过数，诊断证据见[原始比较（原始产物已删除）](../../../README.md#已删除的材料)与[说明](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-08/diagnosis.md`）。

## 验收条件

| 条件 | 可核对证据 |
| --- | --- |
| 唯一关联／顺序／原 seq | Node 包含同名、乱序、跨会话／Run、重复调用／结果与先到结果；原生核 8 个调用按原顺序、一个 orphan 独立，并对每个原始结果全字段严格比较公开 HTTP 记录。 |
| 真实状态／运行结束仍等待 | Node 文本 Error 不改 success、终态后等待；原生同时验证真实 error、成功 Error 正文、运行完成但 waiting 没有结果。 |
| 空正文／额外与未知字段 | Node 保留任意额外字段、不同结果名称与空数组；原生比较完整记录、参数、结果名称、空正文和未知块，工具内容没有 Markdown 图片或链接执行。 |
| 折叠与首次失败 | 原生 3 项分别核默认／失败展开，手动收起后刷新／切会话／重启，以及等待期间已手动收起、失败到达仍保持选择；Node 验重复失败与应用偏好重建。 |
| artifact 完整空值与只读 | Node 与原生覆盖空字符串、0、false、空数组／对象、null／省略；原生逐项核附加区存在性与完整原值，新增方法点击全部 6 个非 null artifact 的复制／完整查看并严格比较原值，原始记录保留字段区别。 |
| 完整查看／复制／样式 | 原生失败长正文复制严格等于 20,503 字符原文，完整抽屉文本一致，关闭恢复入口及草稿；390×780 WebView 结果区最高 320px、主区不超宽。主 agent 已查看[桌面抽屉（原始产物已删除）](../../../README.md#已删除的材料)和[窄屏卡片（原始产物已删除）](../../../README.md#已删除的材料)。 |

新增方法同时逐字核参数与独立工具结果的复制／完整查看、入口焦点恢复，并确认只有原始 1 次 POST、公开历史不变。主 agent 已核专项日志、退出码、保存的复制值及新完整查看截图。

## 审查与证据收尾

- [Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-08/standards-review.md`）：0 剩余硬规则／明确启发式 finding；工具诊断及其修正保留。
- [Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-08/spec-review.md`）：0 剩余 finding；按第 08 票、定稿消息／工具契约及现有设计规范独立核对。
- 原生 runner 首批沿用了旧类 artifact_root，覆盖旧票目录内本批产物。归档本批新写的 41 份文件到 `native/03..07` 并逐项核 SHA-256，主 agent 随后恢复 35 份 tracked 旧记录，仅在归档 hash 相同后清理 6 份本批新副本；本次证据完整保留，旧票内容已恢复。见 [归档与恢复清单（原始产物已删除）](../../../README.md#已删除的材料)。runner 已将未来每组产物指定到本票独立目录，未为此重复测试。

## 覆盖边界

- 唯一后端跳过是 Windows symlink 权限；不算通过。历史[审批结算超时](../../../../../issues/approval-resume-settlement-timeout.md)与[空宿主环境退出超时](../../../../../issues/empty-host-environment-startup-exit.md)本次完整回归均未复现，未改相关代码或确认根因，原 needs-triage 与旧失败证据仍保留。
- 390×780 是真实 WebView 的设备视口模拟，物理 Windows 输入、IME、窗口边框和多尺寸联合验收仍归第 23 票。
- 浏览器预览夹具覆盖重复工具身份和乱序；后端持久工具身份幂等，不伪造重复提交。实际工具节点、middleware、持久 API 和重启路径由本票原生夹具验证，无供应商模型网络。
