> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Standards 静态审查（第 18 票）

模型：gpt-6-luna / max。范围：完整副本 baseline 对照最新 `review.diff`（18 个文件、1732 行）及当前源文件。依据：`AGENTS.md` 命名规则、`CONTEXT.md`、`frontend/design.md`（§4、§7、运行详情规范）、根/包 `pyproject.toml`、frontend README 与 Wayfinder tracker；`docs/adr/` 不存在。仅做静态审查；本审查未运行 Git 命令或测试，也未改产品、测试或票据文件。

## 结论

**硬标准遗留：0。** 此前的命名问题均已修复并同步调用点：`runEvents`→`getRunEvents`、`canonicalEvent(item)`→`normalizeEvent(runEvent)`、`event`→`mergeEvent`、`targetKey/readOnce/refresh`→`createTargetKey/readEventsOnce/refreshHistory`、`eventTitle`→`formatEventTitle`、`RunEvents.read`→`eventRead`。测试 helper、事件/快照/错误实体名及 native helper 也改为领域名词或动宾名（如 `waitForState`、`required_event`、`cancel_response`）。对应 `AGENTS.md` 命名规则。布尔名具判断语义。

`RunEventHistoryReader` 将 merge/publish 回调绑定到 `EventTarget`；切换 target 会 abort 旧请求，`isCurrent` 防止迟到响应写入，loaded/retry 状态按 target key 保存，边界通知共用单个请求任务（`frontend/src/run-event-history.ts:15-70`）。未见 target 所有权、分区或重复排队方面的 Standards 问题。普通次要控件为 12px、正文为 14px、JSON 为 12px/20px，窄屏触控目标保持 44px（`frontend/src/styles.css:890-907`），符合 `frontend/design.md:82,88-90,98`。

`RunFrame`/HTTP envelope 中的 `data` 是既有协议字段，Node `t.mock.timers.tick` 是外部测试 API；本轮未把它们误报为可重命名项。未改动的 `RunProjection.delta(data)` 属于 baseline，不计入本轮 finding。

## Fowler 判断建议

`RunEvents.tsx:8` 与 `backend-client.ts:81` 有重复状态映射，可视作 **Duplicated Code** 观察；历史事件标题与当前 Run 状态文案语义不同（例如“运行已完成”与“已完成”），目前不建议抽象合并。
