> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 07 票 Spec 审查

范围：按 07 票直接 AC，核对统一 PRD §12/§14/§19、004 contract §4/§5/§8 与 `frontend/design.md`。工具调用与结果的 `tool_call_id` 配对、参数/artifact 和长工具输出属于下一票 08 的 AC（08 `Blocked by` 07）；故未把这些列作 07 缺陷。

## 做得好的

- `MessageBody.tsx` 对 Agent 文本逐块做 Markdown 渲染，用户/工具文本保留原文，type=text 的扩展字段及未知对象可查看完整 JSON；数组另有完整 JSON 查看/复制，符合 PRD §12、004 §4。
- `markdown-policy.ts` 先将 HTML 节点文本化，再经 sanitize；脚注 ID 按消息/块命名空间，Windows/UNC 原引用不进入 `href`/`src`。代码通过解析得到的原始 code value 复制，语言/文件名不猜测；CRLF、行内尾空格和 Tab 的 remark AST 检查均保留。
- `web_open.rs` 严格限制显式 HTTP(S)，`lib.rs` 将命令限制在 main 并关闭 opener 自动链接；前端链接只调用受控命令。`Overlay` 与 CSS 复用单个前景 dialog、400px 抽屉和 80dvh 窄屏面板，关闭时尝试返回有效焦点。
- 第一轮Tauri原生回归12/12通过：07为2/2，03／04／05／06回归10/10。校准焦点oracle后，最终dist上再跑07两项也为2/2通过、0失败、0错误、0跳过。07真实WebView证据核对公开HTTP历史、完整数组复制、恶意HTML不执行、只读任务列表、局部表格滚动、代码全文复制、单前景、草稿与入口焦点保持，以及HTTP(S)系统打开和局部失败。详见[原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/native-report.md`）、[`native-tabfix`日志（原始产物已删除）](../../../README.md#已删除的材料)与[最终07日志（原始产物已删除）](../../../README.md#已删除的材料)。
- Rust拒绝未知协议，真实系统opener接受本机临时页面且WebView地址不变；Ctrl+Shift修改点击仍只进受控命令一次。测试没有把“浏览器UI确实显示了页面”混同于操作系统已接受打开。

## 需修

- 目前未发现07直接范围内仍未解决的规格缺失、部分实现、越界或明显错误。窄屏面板、焦点、完整查看与复制、受控网页打开现已取得最终Tauri原生结果；焦点差异探索和校准细节保留于[原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/native-report.md`）。

## 值得讨论

- 08 的工具关联行为仍未由当前 diff 实现；例如 `Conversation.tsx:60-78` 仍分别呈现调用 JSON 与 ToolMessage。按 08 票归属暂不阻挡 07，关闭 07 不表示 08 已验收。
- `open_web_url` 实机验收覆盖了合法本机HTTP目标、Rust对拒绝输入的响应、操作系统接受以及当前会话不导航。系统默认浏览器中页面的真实呈现没有被自动化断言；PRD §14 对命令返回语义是“系统已接受”，所以报告只作该层结论。
- 窄屏面板使用DevTools `390×780` CSS px视口emulation并测得624px（80dvh），不代表真实物理窗口尺寸验收；多个物理尺寸、系统IME与原生frame输入组合归23票。
