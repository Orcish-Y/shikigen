> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 07 前端与 Rust 验证报告

模型：gpt-6-luna / max（按验证交接调度）。工作区：`C:\code\shikigen-agent`。产品代码和正式测试保持只读；输出日志与本报告写入本票 scratch 目录。起始 HEAD 为 `2cde5b5757e1065049fdfdc21e98d17ed6fd68ec`。

## 验证结果

| 命令 | 工作目录 | 结果与计数 | 耗时 | 日志 |
|---|---|---|---:|---|
| `pnpm.exe test` | `frontend` | exit 0；111 passed、0 failed、0 skipped、0 cancelled | 17.592 s | `frontend-test.log` |
| `node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json` | `frontend` | exit 0；类型检查通过 | 4.241 s | `tsc.log` |
| `pnpm.exe build` | `frontend` | exit 0；Vite 转换 4861 modules | 23.348 s（Vite 18.32 s） | `frontend-build.log` |
| `cargo fmt --check` | `frontend/src-tauri` | exit 0；格式通过 | 0.666 s | `cargo-fmt.log` |
| `cargo test` | `frontend/src-tauri` | exit 0；25 passed、0 failed、0 ignored；lib/main/doc 共 0 项 | 56.983 s | `cargo-test.log` |
| `cargo build --example backend_window` | `frontend/src-tauri` | exit 0；示例构建成功 | 2.280 s | `cargo-build-example.log` |
| `.venv/Scripts/ruff.exe check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py` | 根目录 | exit 0；All checks passed | 0.097 s | `ruff-check.log` |
| `.venv/Scripts/ruff.exe format --check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py` | 根目录 | exit 0；2 files already formatted | 0.089 s | `ruff-format.log` |

Cargo 测试 25 项来自 backend_config 2、backend_logs 4、backend_manager 8、backend_retry 3、backend_shutdown 4、managed_process 2、web_open 2。Cargo test 和 example build 都保留了 Windows linker stdout 生成 `.lib`/`.exp` 的 warning，`shikigen-desktop` 因此有一条 `linker_messages` warning；未隐藏或抑制。

## 构建资产

`frontend/dist/index.html` 指向 `/assets/index-B5nx-h-x.js`。入口 JS 522,585 bytes（Vite 报告 522.59 kB，gzip 161.50 kB），CSS `index-ab2XaoTv.css` 61,656 bytes（gzip 30.81 kB）；JS SHA-256 `9E02FC7617ABCE38E1BCFBCB9BB387479F18EE77BC556A35B18B81B7869EEBA6`。构建日志保留 Vite 的 `Some chunks are larger than 500 kB after minification` warning。

构建产物检查确认入口包含脚注 `footnote-label`、可聚焦脚注 `tabIndex:-1`、预览复制标签“复制当前片段”以及预览说明“生成中 · 尚未保存，以下为当前片段。”，与最后脚注 ID／preview 补修一致。

## 限制与记录

原生桌面验收未由本 agent 执行，已在 build 结束后立即通知 `/root/ticket07_spec_native`，由其独占运行；因此本报告不替代原生窗口覆盖率。首次日志捕获因从 `frontend` 目录使用了根相对路径而在 PowerShell 重定向阶段失败，未启动 pnpm；之后用绝对日志路径运行一次有效的 `pnpm.exe test`，表中计数对应该次运行。

## 增量复核与 Ruff（native 诊断修正）

未重跑 pnpm、TypeScript、Rust 全量或构建；这次改动限于验收测试。Native agent 独占原生验收。

| 命令 | 工作目录 | 结果 | 耗时 | 日志 |
|---|---|---|---:|---|
| `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/markdown_content_acceptance.py tests/desktop_markdown_fixtures.py` | 根目录 | exit 0；All checks passed | 0.051 s | `ruff-check-incremental.log` |
| `.venv/Scripts/ruff.exe format --check frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/markdown_content_acceptance.py tests/desktop_markdown_fixtures.py` | 根目录 | exit 0；3 files already formatted | 0.060 s | `ruff-format-incremental.log` |

增量 Standards 复核结论和诊断证据见 `standards-review.md`。本次只新增两份 Ruff 日志和更新本票报告；未改产品代码。

## 增量最终验证（focusfix；与此前批次分开记录）

模型：gpt-6-luna / max。此批针对最后一次产品焦点修复；不与之前 `frontend-test.log` 的 111 项或 `cargo-test.log` 的 25 项合并。没有 Rust 源码变更，本批未重跑 Rust。

| 命令 | 工作目录 | 结果/计数 | 耗时 | stdout/stderr 证据 |
|---|---|---|---:|---|
| `pnpm.exe test` | `frontend` | exit 0；111 pass、0 fail、0 skip | 8.724 s | `frontend-test-final-focusfix.log`（合并捕获） |
| `node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json`（首次 PowerShell wrapper） | `frontend` | exit -1；248.582 s 后停止本任务进程；未得类型结果，不能计通过 | 248.582 s | `tsc-final-focusfix.log`、`tsc-final-focusfix-stall-diagnostic.log`（合并捕获及线程快照） |
| 同一 direct tsc 命令（Python Popen，stdout/stderr 双 pipe 持续 drain） | `frontend` | exit 0；类型检查通过 | 35.681 s | `tsc-final-focusfix-pipe.log`、`tsc-final-focusfix-pipe.stdout.log`、`tsc-final-focusfix-pipe.stderr.log` |
| `pnpm.exe build`（Python Popen 启动该原命令） | `frontend` | exit 0；Vite 转换 4861 modules；保留 >500 kB warning | 17.092 s | `frontend-build-final-focusfix.log`，分流文件 `.stdout.log`/`.stderr.log`，捕获问题见 `frontend-build-final-focusfix-capture-diagnostic.log` |
| `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/markdown_content_acceptance.py tests/desktop_markdown_fixtures.py` | 根目录 | exit 0；All checks passed | 0.085 s | `ruff-check-final-focusfix.log` |
| `.venv/Scripts/ruff.exe format --check frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/markdown_content_acceptance.py tests/desktop_markdown_fixtures.py` | 根目录 | exit 0；3 files already formatted | 0.101 s | `ruff-format-final-focusfix.log` |

首次 tsc 记录的 PID 37684（node，父 PID 21260 pwsh）CPU 3.515625 s、working set 142,626,816 bytes、180 handles；8 个线程均等待。已只停止本任务启动的 node/pwsh，等待 4:08.767 后报告 exit -1；根因未知。随后双 pipe direct tsc 同命令成功，才运行 build。

Build 的分流线程把 stdout 转发到 GBK 控制台时遇 U+2713 的 `UnicodeEncodeError`；stdout capture 因而不完整，完整资产表不在日志。进程自身 exit 0，stderr 日志完整包含 Vite chunk warning；未重跑 build。实际 dist 通过 `index.html` 引用的资产读取：入口 JS `assets/index-BwvqD-g5.js` 为 522,820 bytes，SHA-256 `B54BE6A51C2A46D0A2135D3D8C47F8D70118971D564A984CBCB9964CC162BA8A`；CSS `assets/index-ab2XaoTv.css` 为 61,656 bytes，SHA-256 `77CEF017826CAC703563AF89BAC6D7A04B7A98642A8CE0433A808C1E76644DE2`。Index bytes=396。JS 确认含 `footnote-label`、`tabIndex:-1`、预览复制标签和预览提示，来自本轮构建。

Native 焦点验收由 `/root/ticket07_spec_native` 独占重跑；本 agent 未重复任何原生测试。

## 增量 Ruff（copy oracle 修正；不重跑产品验证）

Native 首次 copy-case 红记录保留在 `native-focusfix-run.log`：整批12项中该组2项有1失败，失败在 test expected 的字典 key 插入顺序；其他03–06组通过。root 更新了 formal-test oracle 后，本 agent 只对最新 3 个 Python 测试文件运行 Ruff，不重跑 native/pnpm/tsc/build/Rust。

| 命令 | 工作目录 | 结果 | 耗时 | 日志 |
|---|---|---|---:|---|
| `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/markdown_content_acceptance.py tests/desktop_markdown_fixtures.py` | 根目录 | exit 0；All checks passed | 0.047 s | `ruff-check-final-history-orderfix.log` |
| `.venv/Scripts/ruff.exe format --check frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/markdown_content_acceptance.py tests/desktop_markdown_fixtures.py` | 根目录 | exit 0；3 files already formatted | 0.042 s | `ruff-format-final-history-orderfix.log` |

最新原生回归仍由 native agent 执行；本记录不把此前 red 当作新补修后的通过结果。

## 增量最终验证（tabfix；修复 Tab 首尾循环后）

模型：`gpt-6-luna / max`。本批验证与之前的 111 项、类型检查、构建及 Rust 25 项记录分开；本批仅因 Overlay 产品焦点行为改变而重跑前端全套、tsc、build，并对最新 3 份 Python 验收文件跑 Ruff。原生窗口由 `/root/ticket07_spec_native` 独占。

| 命令 | 工作目录 | 结果与计数 | 耗时 | 日志 |
|---|---|---|---:|---|
| `pnpm.exe test` | `frontend` | exit 0；111 passed、0 failed、0 skipped、0 cancelled | wrapper 10.016 s；Node 测试报告 7.523 s | `frontend-test-tabfix.log`、`frontend-test-tabfix.stdout.log`、`frontend-test-tabfix.stderr.log` |
| `node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json` | `frontend` | exit 0；类型检查通过，stdout/stderr 均空 | 10.016 s | `tsc-tabfix.log`、`tsc-tabfix.stdout.log`、`tsc-tabfix.stderr.log` |
| `pnpm.exe build` | `frontend` | exit 0；4861 modules transformed；保留 >500 kB warning | 20.017 s（Vite 11.08 s） | `frontend-build-tabfix.log`、`frontend-build-tabfix.stdout.log`、`frontend-build-tabfix.stderr.log` |
| `.venv/Scripts/ruff.exe check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py frontend/src-tauri/tests/client_acceptance.py` | 根目录 | exit 0；3 文件全部通过 | 0.8 s | `ruff-check-tabfix.log` |
| `.venv/Scripts/ruff.exe format --check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py frontend/src-tauri/tests/client_acceptance.py` | 根目录 | exit 0；3 files already formatted | 0.4 s | `ruff-format-tabfix.log` |

Ruff 首次尝试把 `tests/desktop_markdown_fixtures.py` 误写为 `frontend/src-tauri/tests/desktop_markdown_fixtures.py`，两条命令均未形成对完整目标集的有效检查；原始工具输出分别为 exit 1。为保存诊断，又将相同错路径分别复跑并记录：`ruff-check-tabfix-path-error.log` 的 Ruff exit 1，`ruff-format-tabfix-path-error.log` 中 Ruff 报错且 PowerShell 捕获到 Ruff exit 2（其余两个已存在文件显示 formatted）。这四次错路径调用均不计作通过；仅以上两次正确路径命令计入结果。错误来自命令行路径笔误，未修改源码。

本批 `dist/index.html` 引用 `assets/index-CRxAs_nQ.js` 与 `assets/index-ab2XaoTv.css`。直接读取当前文件确认 JS 为 523,240 bytes、SHA-256 `985CDECD67BF9A9D50BAA841131210F80EB7C3710955E4C6CB58FDAEC1B11E76`；CSS 为 61,656 bytes、SHA-256 `77CEF017826CAC703563AF89BAC6D7A04B7A98642A8CE0433A808C1E76644DE2`。JS 包含 `footnote-label`、`tabIndex:-1`、预览复制标签与尚未保存说明，和最后焦点/预览修正一致。Native agent 收到此 hash 后再执行原生验收。

本批无跳过的前端测试；Ruff 错路径调用不构成测试失败，也不计成有效检查。未重复后端或 Rust 批量验证，因为相应产品源码未变。类型检查首次 focusfix 时长时间无输出并被停止、随后同命令通过的历史记录仍保留在上文，不与本批成功合并。完整 native 和 Spec 结果由 root/native agent 汇总，本小节不代表其通过。

## 增量最终验证（stylefix）

模型：`gpt-6-luna / max`。本批只验证根 agent 根据原生截图补充的焦点样式修复：生产 build 一次，并对最新 3 份正式 Python 文件运行 Ruff check/format。没有重跑 Node 111 项、独立 tsc、Rust 或后端测试；`pnpm.exe build` 自身脚本包含 `tsc --noEmit && vite build`。

| 命令 | 工作目录 | 结果 | 耗时 | 日志 |
|---|---|---|---:|---|
| `pnpm.exe build` | `frontend` | exit 0；4861 modules transformed；Vite 内部 build 13.01 s；保留 >500 kB warning | 19.168 s | `frontend-build-stylefix.log`、`frontend-build-stylefix.stdout.log`、`frontend-build-stylefix.stderr.log` |
| `.venv/Scripts/ruff.exe check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py frontend/src-tauri/tests/client_acceptance.py` | 根目录 | exit 0；3 files pass | 约 0.9 s | `ruff-check-stylefix.log` |
| `.venv/Scripts/ruff.exe format --check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py frontend/src-tauri/tests/client_acceptance.py` | 根目录 | exit 0；3 files already formatted | 约 0.9 s | `ruff-format-stylefix.log` |

本批构建后的 `dist/index.html` 引用 JS `assets/index-BOOLs1PU.js`（523,240 bytes，SHA-256 `985CDECD67BF9A9D50BAA841131210F80EB7C3710955E4C6CB58FDAEC1B11E76`）和 CSS `assets/index-C37yfSMR.css`（61,653 bytes，SHA-256 `75CDA7B59E7B971ED646F8F87403C26D04D19CE0C4305F100D17B0C55964DD38`）。直接检查生成 CSS 确认通用 `[tabindex]:focus-visible` 规则、2px `var(--accent)` outline 与 3px offset 都进入产物。

root 从 `native-tabfix07/narrow-content.png` 发现 `pre` 聚焦时仍显示浏览器默认黑色 outline，补上通用 tabindex 焦点选择器。stylefix 版正式原生批次为 2 项中 1 pass、1 fail；失败在旧 oracle 把 WebView `getComputedStyle(...).outlineOffset` 硬要求为 `3px`，实际为 `2.66667px`，但 CSS 声明、outline 颜色和宽度符合样式目标。根 agent 后续按独立只读 CSSOM 诊断修正了 oracle；见 offsetfix 记录。此前零 finding 的 Standards 初审因未发现截图中的差异而不完整，后续复核见 `standards-review.md`。

## 增量复核与 Ruff（offsetfix oracle）

模型：`gpt-6-luna / max`。本批只审查正式验收的焦点样式 oracle，并对最新三份 Python 文件运行 Ruff；没有改源文件，没有重跑 build、Node、独立 tsc、Rust 或后端。

独立诊断 `native-offset-diagnostic/07/test_real_messages_full_copy_drawer_and_single_foreground/focus-offset-diagnostic.json` 记录：DPR `1.0000000298`、viewport scale `1`、document zoom `1`。代码 `pre`、关闭按钮以及返回 `pre` 的快照均处于 active 且 `:focus-visible`；三者由当前活动 CSSOM 匹配到的声明均为 `outline-offset: 3px`、颜色 `rgb(79, 70, 229)`、宽度 `2px`，WebView resolved `outlineOffset` 均为 `2.66667px`。旧原生失败完整保存在 `native-stylefix-run.log`（2 项：1 pass、1 fail）和单项诊断日志 `native-offset-diagnostic-run.log`（1 项失败，复现旧的 computed-offset 期待值）。这些是历史红结果，不能与更新后尚未运行的正式测试合并。

最终正式 oracle 只读公开 `dialog pre` 与关闭 button，遍历当前 document CSSOM 的适用 media/support rule，要求两者 matched 声明严格为 `['3px']`；每个快照还严格要求 active 与 `:focus-visible`、颜色和宽度原值，并完整比较 content/button/restored 三份快照相等。它不读取应用私有状态、不使用 CSSOM computed offset 的容差，也不改变 CSS 来补偿 resolved 表示。新 oracle 已检查，native agent 尚未运行最终版两项专项。

| 命令 | 工作目录 | 结果 | 日志 |
|---|---|---|---|
| `.venv/Scripts/ruff.exe check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py frontend/src-tauri/tests/client_acceptance.py`（初次） | 根目录 | exit 0；3 文件通过 | `ruff-check-offsetfix.log` |
| `.venv/Scripts/ruff.exe format --check tests/desktop_markdown_fixtures.py frontend/src-tauri/tests/markdown_content_acceptance.py frontend/src-tauri/tests/client_acceptance.py`（初次） | 根目录 | exit 1；仅 `markdown_content_acceptance.py` 将被重新格式化，另外 2 文件已格式化 | `ruff-format-offsetfix.log` |
| root 对单个 `markdown_content_acceptance.py` 执行 Ruff format | 根目录 | exit 0；1 file reformatted，仅换行格式 | root 报告；随后三文件复检见下 |
| 同上 Ruff `check`（复检） | 根目录 | exit 0；All checks passed | `ruff-check-offsetfix-final.log` |
| 同上 Ruff `format --check`（复检） | 根目录 | exit 0；3 files already formatted | `ruff-format-offsetfix-final.log` |

以上是独立命令结果，初次 format 失败保留，不将其计为通过；复检只覆盖同三份正式 Python 文件。本记录的剩余限制是更新后的原生两项验收结果尚未返回。
