> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 16 票 Standards Review

范围：依据编辑前固定点、最新 `review.diff` 与当前文件复核命名及 Fowler 启发式；未运行 Git 或测试。问题按组计数。

## 最终计数

- 初审：硬性命名 3 项、启发式 2 项；均已修复。
- 第一次复核：新增硬性命名 3 项、启发式 2 项；均已修复。
- 最新复核：剩余硬性命名 0 项、启发式 0 项。

最终核对包括：`metadataText`、`wrapRawBlock(rawText)`、`requiresRawMarkdown(markdownBody)`、`currentThreadId`、`capturedAtMs`、`accepted_export_request` / `denied_export_request`，以及测试实体名和 `self.record(...)` 调用均与当前实现一致。既有共享 `WindowAcceptance.record` API 按本轮范围保持不变；导出内容中的 `extra` 是被保留的事实字段，不作为变量名问题。

未发现明确的重复逻辑、Feature Envy、数据团簇或职责分散问题。

## 追加复核：真实 WebView 下载取消与可选保存 UI 探针

固定点仍为 `.scratch/frontend-completion/ticket-16/review.diff`；仅复核其中新增的 `DownloadEventRecorder`、真实 WebView 下载取消用例和 `native_runner.py` 可选探针调度。未运行测试或 Git 命令。

- 硬性标准问题：0 项。`DownloadEventRecorder` 的事件、命令、响应及下载 GUID 状态共同服务于协议证据记录；对既有验收对象的依赖用于复用 WebSocket、序列号和断言能力。`call` 沿用要求保持兼容的共享 API，没有发现需要全面改名的新增命名违规。
- Fowler 启发式：0 项。取消用例分别等待下载取消事件与命令响应，两段轮询采集不同证据，不构成值得抽取的重复业务逻辑。新增可选探针由 `--probe-default-save-ui` 显式加入，未发现职责混杂、无需求泛化或散射修改问题。

本段是静态 Standards 复核结论，不代表测试或实机验收通过。
