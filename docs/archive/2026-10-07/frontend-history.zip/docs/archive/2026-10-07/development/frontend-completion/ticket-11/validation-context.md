> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 11 票验证交接

本次目标：`docs/wayfinder/frontend-completion/implementation/11-failure-partial-message.md` 的六项验收；统一规格 `.scratch/frontend-completion/PRD.md` 第 11 节（284 行起）。基线 HEAD：`e0ea6ae`（执行 `git rev-parse HEAD` 获取完整 SHA）。当前工作区起初干净，使用当前未提交 diff `git diff e0ea6ae` 检查本次内容。

遵守根 AGENTS.md；主 agent 写产品代码和修复，测试子 agent 明确 `gpt-6-luna / max`。只允许子 agent 写各自的证据、报告，不修改产品、测试或 Git。报告必须包括模型、工作目录、命令、实际数量、失败、跳过、时间、日志、未覆盖边界；不能把未执行算通过。

## 方案及文件

- 后端 `runtime/run_events.py`：同 Run 接入锁冻结所有非空未提交 AI 正文，失败标 `generation_status=error`；共用取消的正文提取，提交后才封口，回滚不清空。
- `runtime/runs.py`：失败消息、Run error、实际 error/code、生命周期、用量共同事务；已有终态先返回，保留 complete/tool 事实。迟到调用仍可结算用量。
- `runtime/run_execution.py`：原执行任务持有失败 outcome，存储失败后 1/2/4/8/10 秒（后续 10 秒）重试结算，不重跑 Graph，等待时释放协调锁，允许取消竞争。进程 shutdown 停止所有者，不伪造 terminal。启动失败交给有强引用的后台结算 Task，首次保存尝试后返回原启动异常；避免 accepted operation 无限等待阻塞 shutdown。
- 前端 `Conversation.tsx` 显示独立“因失败中止”；`RunFailure.tsx` 和 `App.tsx` 完整呈现真实错误代码和原因，复用 ContentBlock/ContentViewer/复制，沿用 frontend/design.md。
- `tests/test_failure_partial_message.py`：最终 12 项专项（通过 Runtime/ChatStore/HTTP/公开接入；SQLite 触发器是外部存储故障，插入处 barrier 是数据库边界注入）。覆盖正文身份/seq/空白、多条、空正文、complete/tool 不变、工具失败与断流不保存、interrupted、HTTP/SSE、回滚/重试所有者、两向取消竞争/迟到用量、迟到接入/下一 Run 重放、shutdown，以及启动失败回滚交接与关闭。
- `frontend/tests/run-failure.test.mjs`：6 项 UI/状态专项，真实失败原因/安全呈现、补读去重、读失败手动恢复、不导出预览、未知 generation_status、连接和工具错误；原 134 项测试保留。
- `tests/desktop_failure_fixtures.py` / `frontend/src-tauri/tests/failure_partial_acceptance.py`：1 项真实 Tauri 专项，离线 real create_agent 固定长正文和错误，完整原因查看/复制、独立标记、重开读取和草稿。原生 runner 串行新 1＋第 10 票 4＋第 03–09 票 19＝24 项唯一用例。
- 本票无 Rust 产品变更，不重复 Rust 构建/测试；实机使用既有 backend_window.exe，但必须先 pnpm build 得到本次 dist。

## 已有开发证据

主 agent TDD 定向检查：第一项先失败（仅用户消息，缺两条正文），实现后通过；回滚项先失败（任务已结束，丢失重试所有者），加入所有者重试后两项通过。UI 标记定向 1 项通过；首次 Node 工具调用未收集完成输出，不能把该次称作已验证的 red。最终子 agent 执行情况及原始日志以 backend-report.md、frontend-report.md、native-report.md 为准；首轮静态检查失败保留，修复后补验，不能覆盖原始结果。

## 环境、命令及资源

- Windows PowerShell，repo `C:/code/shikigen-agent`，Python `.venv/Scripts/python.exe`，ruff `.venv/Scripts/ruff.exe`，ty `.venv/Scripts/ty.exe`；pnpm 在 frontend 执行。权限 unrestricted/never，不传 sandbox_permissions，不发起批准请求。
- 后端专项（repo）：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_failure_partial_message.py -v`。相关旧专项 `test_cancel_partial_message.py`、`test_execution.py`、`test_run_events.py`、`test_runtime.py`、`test_run_cancel.py`、`test_run_usage.py`、`test_approval_resume.py`。
- 完整后端（repo）：`.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v`，**等待主 agent 明确 GUI 已全部结束后串行启动**。保留正式失败，禁止反复重跑到绿。全套仅一次，必要定位隔离由主 agent 决定。
- 产品 ty（repo）：`.venv/Scripts/ty.exe check app packages/harness`。新增测试 ty 加 `--extra-search-path tests`，原生再加 `--extra-search-path frontend/src-tauri/tests`。根默认 ty 历史 .scratch 会有已有诊断，不能宣称默认根检查通过。
- Ruff：本票改动 Python 文件 check 和 format --check。
- 前端（frontend）：`pnpm test`、`pnpm exec tsc --noEmit`、`pnpm build`。专项 Node `node --import tsx --test tests/run-failure.test.mjs`。新 fixture/原生文件由主 agent 继续编写，执行前接收补充消息。
- 记录脚本 `.scratch/frontend-completion/ticket-11/run-command.ps1` 支持 Name、WorkingDirectory、Executable、ArgumentsJson、EnvironmentJson，输出 stdout/stderr/meta 到本票 logs。可直接用它或等效脚本完整保存。
- 原生独占 9238、45200/45201，dist/5173；不要并行 GUI，不要杀未归属进程。旧 5173 静态服务若存在必须逐字节核实 dist，再复用保留；不匹配时报告，不能停未知服务。继承 ReconstructionAcceptance.setUpClass 可安全核实/建立静态服务。
- 临时数据库/Agent factory 由现有原生夹具隔离；离线固定模型仍使用 real create_agent、middleware、checkpoint，绝不调用供应商。

## 风险与已有问题

完整保存只承诺已接入的片段；强杀内存片段不承诺跨进程恢复。失败重试所有者只存活于当前进程，查询不能补写/重跑。取消不撤销已发生的工具操作。

历史审批 cleanup 超时 `.scratch/approval-cleanup-test-timeout/issues/01-approval-resume-settlement-timeout.md` 保持 needs-triage；第 10 票最终 300 通过/1 Windows symlink 环境跳过，但此前 1 正式错误、隔离 1 通过/1 错误。根因及与结算锁的关系未知，不能宣称无关。历史空宿主环境退出超时也保留。Node 原 134、真实 Tauri 原 23 unique 通过，仅为基线证据，不代替本票回归。

请逐项核实六项验收，报告错误/资源/连接问题是否影响真实 Run 或只影响观察。最终由主 agent 阅读日志与截图，再更新票据并 commit；子 agent 不改状态。
