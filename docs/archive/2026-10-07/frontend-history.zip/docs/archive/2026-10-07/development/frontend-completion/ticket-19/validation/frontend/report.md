> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 19 前端验证报告

日期：2026-10-06  
验证模型：`gpt-6-luna`，推理强度 `max`  
工作目录：`C:\code\shikigen-agent\frontend`

## 最终冻结源结果（主 agent 核对补充）

测试子 agent 使用 `gpt-6-luna / max` 执行，主 agent 读取实际日志核对：六文件相关回归 **82／82 通过，0 失败、0 跳过**，包含最终 22 个 `usage-settlement` 用例；最终 TypeScript 和 Vite 构建均退出 0。

- 精确命令、模型、工作目录、时间与退出码：`final82.result.json`、`final82-tsc.result.json`、`final82-build.result.json`。
- 行为与构建日志：对应 `final82*.stdout.log`／`stderr.log`。
- 最新构建主 JS 622.80kB／gzip 189.04kB，保留超过 500kB 的既有提示。
- 中间六文件批次：76 项中 75 通过、1 测试解构变量 ReferenceError；修正变量后 77／77，后续阶段归属修复 78／78、80／80。各批覆盖重叠，不相加。
- 最后八项新增覆盖：第十二次在读 GET 合并取消免费补读、false 终止自动在读、预算拒绝后人工入口可用、旧自动与手动查询跨阶段隔离、旧手动重试计费隔离、false 立即停止错误等待、EOF 已合并在读 GET 后 false 仍完成首次边界补读。
- 仅执行一次的较早完整回归仍为 **224 项，223 通过、1 失败**；修复后通过原用例在上述相关专项中的断言，完整套件未重跑。

下列章节记录较早的 14 用例／74 项批次；其中“最新构建”等措辞以本节最终 82 项记录为准。原生验收另见 native 报告。

## 首轮历史验证结果

| 阶段 | 命令 | 结果 |
| --- | --- | --- |
| 完整 Node 回归（修复前，仅执行一次） | `node --import tsx --test tests/*.mjs` | 224 项：223 通过、1 失败、0 跳过；退出码 1 |
| 定向回归（主 agent 修复后） | `node --import tsx --test tests/usage-settlement.test.mjs tests/run-cancel.test.mjs tests/run-details.test.mjs tests/run-events.test.mjs tests/stream-recovery.test.mjs tests/visibility-polling.test.mjs` | 74 项：74 通过、0 失败、0 跳过；退出码 0 |
| TypeScript（修复前、后各一次） | `node node_modules/typescript/bin/tsc --noEmit` | 两次退出码均为 0 |
| Vite build（修复前、后各一次） | `node node_modules/vite/bin/vite.js build` | 两次退出码均为 0；最新 dist 已构建 |

完整回归的唯一失败是 `tests/run-cancel.test.mjs` 第 88 行的场景，在第 101 行等待公开用量结算状态时超时。该场景先挂起取消前的 GET，再接受 `cancelled + usage:null + usage_pending:true`，释放一个只含旧 `status:'running'`、没有用量字段的快照，并要求串行补读一次。原实现只在取消快照被判定为旧用量组时才安排边界补读；此夹具中取消快照相对捕获版本并不旧，因而没有安排 GET #2。主 agent 修复后，该原断言未改动，并由上述定向回归通过。按要求未在修复后重跑完整套件，因此完整套件的修复后状态仍未验证。

最新定向回归执行后又有一次仅调整 `readSnapshot` try 块缩进的源文件格式修改。主 agent 确认没有行为或名称变化；未重复运行测试。该缩进不会改变 transpile 后的 bundle；最新 build 的 `frontend/dist` 可供 Tauri 验收使用。

## 14 个新增用例与验收条件覆盖

`usage-settlement.test.mjs` 的 14 个用例均在完整回归及修复后定向回归中通过。用例通过公开 `BackendClient` / `ConversationStore`，以 Node 的 `Date` / `setTimeout` mock 控制时间。

| 用例 | 覆盖重点 |
| --- | --- |
| 1 | 首次快照不计后续预算；每次请求完成后等待 5 秒；12 次后暂停；详情开关和普通刷新不重置；手动继续新轮；false 停止 |
| 2 | running 不轮询；interrupted EOF 合并一次首读；首次补读不计预算；省略 pending 不等于 false；重复详情通知不重复发请求 |
| 3 | 1/2/5 秒重试；失败和重试计入请求预算；成功但 pending=true 不重置预算 |
| 4 | 三次自动重试后暂停且不被五秒任务绕过；保留用量、草稿与 Run 结果；读取失败不改 Run.error |
| 5 | Retry-After 与手动刷新共享单一等待；隐藏时中止不造错误；重新显示保留同阶段预算 |
| 6–8 | 404、500、协议错误分别立即停止，保留最后用量与执行终态 |
| 9 | 隐藏／切回／重观察同阶段不重置；新租约允许新轮；丢弃旧租约晚响应 |
| 10 | interrupted→running 新阶段；旧阶段用量组不覆盖新值；同 updated_at 的取消晚到用量可补 |
| 11 | 摘要与详情共用暂停文案和“继续核实”；查询错误不显示成运行失败 |
| 12 | 第 12 个后续请求失败后不安排额外重试、不越过预算 |
| 13 | 有效取消快照立即可见；随后等 5 秒读取晚量；不等待聊天 SSE；保持取消终态 |
| 14 | 同阶段重新观察不重置预算；真实 interrupted→running 后开启新阶段预算 |

这 14 个用例覆盖了本票关于预算、资格、重试、错误停止、切换／隐藏／租约、阶段版本、同时间戳晚量、取消快照和主动继续的主要验收条件。取消期间既有旧 GET 的串行补读由保留的 `run-cancel.test.mjs` 原断言覆盖；修复后随 6 文件定向回归通过。消息保存与事件读取分别由 `run-cancel.test.mjs`、`run-events.test.mjs` 的既有用例检查，未在这 14 个新用量用例中重复模拟。

尚未由本次 Node 验证覆盖的是 Tauri 原生窗口中的真实晚量显示、真实手动继续入口和窗口尺寸／焦点体验；交给后续 native acceptance。完整 Node suite 修复后未重跑，见上文边界。

## 构建说明

最新 Vite build 退出码为 0，输出目录为 `frontend/dist`。构建打印一条非阻塞 chunk 大小警告：主 JS chunk 约 621.72 kB（gzip 约 188.81 kB），超过 500 kB 提示阈值。

## 日志与机器可读结果

- 完整 Node：`node.stdout.log`、`node.stderr.log`、`node.result.json`
- 修复后定向 Node：`targeted.stdout.log`、`targeted.stderr.log`、`targeted.result.json`
- TypeScript：`tsc.*` 与 `targeted-tsc.*`
- Vite build：`build.*` 与 `targeted-build.*`
- 汇总：`command-results.json`
