> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 05 票前端与真实 Tauri 验收报告

## 验收范围

- 验收对象：第 05 票的七项 AC，聚焦真实 Tauri 窗口内的 SSE 中断、有限 GET 恢复、HTTP 错误停止、手动查询/重连、已接受消息和草稿保留。
- 执行代理：gpt-6-luna / max（按委派明确选择）。
- 工作目录：C:/code/shikigen-agent；Windows PowerShell。
- 原生程序：复用已有 frontend/src-tauri/target/debug/examples/backend_window.exe；本轮没有改 Rust，也没有重建该 exe。测试使用真实 Tauri/WebView、临时后端和隔离数据目录。
- 验证者没有改产品代码或正式测试方法。主 agent 做了产品修复与验收辅助改动；验证器只在 .scratch/frontend-completion/ticket-05 写日志、报告、截图副本和诊断探针。
- 所有真实窗口命令均以 require_escalated 执行并获准；没有自动审批拒绝。

## 最终结果

- Node 前端全套：93/93 通过，包含“正常 EOF 缺少 metadata 时停止并报告协议错误”的新回归。
- direct TypeScript 检查：通过。
- pnpm 生产构建：通过，Vite 转换 4595 个模块。
- 新增/改动原生验收脚本 ruff check 与 format --check：通过。
- 真实 Tauri 本票验收：2/2 通过。
- 草稿原生回归：4/4 通过。
- Run 重建原生回归：3/3 通过。
- 通过数按各命令独立报告，没有把 Node 子测试或多组用例折成虚假的统一总数。

## 命令与结果

所有路径均相对于仓库根，除特别注明。

### 前端检查

1. cwd frontend  
   命令：node --experimental-strip-types --test tests/*.test.mjs  
   exit 0；93 tests，93 pass，0 fail、0 skipped。  
   日志：.scratch/frontend-completion/ticket-05/node-tests-93.log

2. cwd 仓库根  
   命令：node frontend/node_modules/typescript/bin/tsc --noEmit -p frontend/tsconfig.json  
   exit 0；无诊断输出，约 32 秒完成。  
   日志：.scratch/frontend-completion/ticket-05/tsc-final-93.log

3. cwd frontend  
   命令：pnpm.exe build  
   exit 0；Vite 7.3.6 转换 4595 个模块，构建用时约 1 分 03 秒。  
   日志：.scratch/frontend-completion/ticket-05/pnpm-build-final.log

4. cwd 仓库根  
   命令：.venv/Scripts/ruff.exe check frontend/src-tauri/tests/stream_recovery_acceptance.py frontend/src-tauri/tests/window_acceptance.py  
   exit 0。日志：.scratch/frontend-completion/ticket-05/ruff-check-final.log

5. cwd 仓库根  
   命令：.venv/Scripts/ruff.exe format --check frontend/src-tauri/tests/stream_recovery_acceptance.py frontend/src-tauri/tests/window_acceptance.py  
   exit 0。日志：.scratch/frontend-completion/ticket-05/ruff-format-check-final.log

### 真实 Tauri 最终回归

6. cwd 仓库根  
   命令：.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/stream_recovery_acceptance.py  
   exit 0；2 tests，2 pass。日志：.scratch/frontend-completion/ticket-05/stream-recovery-native-final.log

7. cwd 仓库根  
   命令：.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-05/run_native_regression.py --ticket 04  
   exit 0；正式草稿验收方法原样执行，4 tests，4 pass。日志：.scratch/frontend-completion/ticket-05/message-drafts-native-final.log  
   新证据隔离在 .scratch/frontend-completion/ticket-05/native-regression/04/

8. cwd 仓库根  
   命令：.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-05/run_native_regression.py --ticket 03  
   exit 0；正式 Run 重建验收方法原样执行，3 tests，3 pass。日志：.scratch/frontend-completion/ticket-05/run-reconstruction-native-final.log  
   新证据隔离在 .scratch/frontend-completion/ticket-05/native-regression/03/

两个旧回归使用 scratch runner，只更换 artifact_root 到第 05 票隔离目录；测试方法名、测试断言和产品逻辑均沿用正式类。主 agent 将原第 03/04 票的 23 个已跟踪证据文件恢复到基点状态，清单与 SHA-256 在 .scratch/frontend-completion/ticket-05/previous-artifacts-preserved.json；早期失败证据另存于 native-before-helper-fix/03 和 native-before-helper-fix/04。

## 原生证据核对

- 503 恢复截图：.scratch/frontend-completion/ticket-05/native/test_bounded_get_recovery_then_manual_query_and_reconnect/recovery-stopped.png
- 503 最终窗口截图：同目录 window.png；机器结果：同目录 result.json。
- 400 停止截图与机器结果：.scratch/frontend-completion/ticket-05/native/test_protocol_http_400_stops_without_extra_get_or_run_error/window.png 与 result.json。
- 我已目视检查两张最终截图。文字、错误详情、停止状态、重连/查询控件和下一条草稿可读；503 停止期间，已接受的原文已显示在正文，空会话提示已消失；工具栏仍显示运行中。400 停止截图也显示已接受消息和草稿，Run 仍为运行中，没有 Run 失败状态徽标。
- result.json 的 stream 请求只有 POST + 三次 GET。相邻间隔分别为 1046.1 ms、2011.0 ms、5010.0 ms，符合 1/2/5 秒退避。接受后等待恢复期间额外读取一次 messages；状态查询是独立快照 GET，不重启观察；人工重连增加第 4 次 GET。公开历史只有一条 human 消息，Run ID 与接受时的 Run 相同；第一次恢复耗尽时 snapshot 为 running 且 error=null。草稿保留，正常恢复后的历史只有该条用户消息和一条完成回复。
- 400 用例只进行一次 POST 和一次 GET stream；公开 human 消息 run_status=running，UI 停止自动重试并保留 HTTP 400 详情，没有将网络/读取故障记成 Run error。
- 规格中 UI 显隐桥接由第 06 票覆盖；本轮验证的是 Tauri WebView 内容和本票观察恢复入口。

## 构建资源与资源清理

最终 dist 的 SHA-256：

- frontend/dist/index.html：F087494AAA9951CFD88CDA5EAF39A74FDF2BBF8A48D1A8D61A729A55A0BB0DD9
- frontend/dist/assets/index-DTJXTmHw.js：DD6C55653505D46E308AD92F57D1F576D800250B3FD8C4077E4AB209E9556FB6
- frontend/dist/assets/index-CSJzwBNI.css：CE8B862FFC23677AE961CC94B149D3C6D87C2B00E7817CA69F48DBC862655EEE

index.html 引用 2 项脚本/样式资源，均存在，缺失数为 0；哈希清单在 .scratch/frontend-completion/ticket-05/dist-hashes-final.txt。最终验收启动前端口空闲，夹具从本次 frontend/dist 提供页面。结束时 5173、9238、45200 均无监听，backend_window 进程数为 0；清理记录在 resource-cleanup-final.txt。PID 23344 的所有权始终不明，本轮没有终止或干预它。

十个最终原生 host 日志各观察到一条 WebView 析构诊断：“Failed to unregister class Chrome_WidgetWin_0. Error = 1412”。原因本轮未调查；各项正式断言通过、宿主正常 exit 0，端口监听与 backend_window 清理检查也通过。对应原始日志保留在 native/ 和 native-regression/ 下。

## 早期失败、诊断与未确认事项

- 首次 ruff check 有两条 E501，初始日志 ruff-check.log 保留；代码换行修复后，最终 check 与 format --check 通过。
- 初次 stream 原生运行的退出路径被鼠标菜单坐标命中断言挡住；400 用例的宽泛字符串断言也把固定说明“连接异常不代表运行失败”误判为错误。主 agent收窄为检查工具栏 Run 状态。再次使用 popup PostMessage 键盘消息时，菜单项未高亮。首轮与中间失败日志分别是 stream-recovery-native.log 和 stream-recovery-native-after-fix.log；旧截图/JSON副本在 native-before-ui-history-fix/。
- 首轮 message_drafts 验收 0/4：一个用例在公开 human history 等待超时，另三个只在托盘菜单鼠标命中失败；首轮 run reconstruction 0/3 也只在同一类鼠标退出断言失败。日志分别为 message-drafts-native.log 和 run-reconstruction-native.log。之后新增退出清理路径并把新回归证据隔离，最终 4/4 与 3/3 通过。
- Enter/IME scratch 诊断按原测试方法单项运行一次。该次组合输入、synthetic keyCode 229、compositionend、CDP Enter keyCode 13、原文 POST/公开历史及下一条草稿保存断言通过；首个退出遇到 SetForegroundWindow 错误，未执行原生重启恢复的后半段，不能将该诊断算作重启验收通过。原生重启恢复由最终正式 4/4 回归覆盖。事件时间线、正文、草稿、history、截图和 host log 在 .scratch/frontend-completion/ticket-05/enter-diagnostic/。首轮公开 human history 超时的根因没有确认；不能以诊断运行宣称历史问题已定位。
- 首个全量 direct tsc 终检命令在 62 秒内没有输出仍未退出，PID 13060 的 CPU 约 3.59 秒、working set 约 140 MB，日志 0 字节；我中断了该轮，exit 1 并标记在 tsc-final.log，不计为通过。源码稳定后重跑的 tsc-final-93.log 正常 exit 0。

## 原生输入覆盖限制

本机处于锁屏输入桌面。只读 Win32 现场显示，常命中句柄 8194416 是覆盖全屏的 LockScreenBackstopFrame / Backstop Window，GetForegroundWindow 为 0，输入桌面名为 Default；记录在 win32-ui-diagnostics.json。物理鼠标菜单命中和物理键盘前台输入因此没有验收，过程中未尝试绕过锁屏。最终退出清理使用经过真实弹出菜单标签、菜单 ID、启用状态核验的宿主 WM_COMMAND/Muda 分发路径；最小真实窗口 quit probe exit 0，日志 quit-probe-after-native-command.log。该 probe 仅验证测试宿主清理，不算产品 AC 通过。实机物理输入仍是本轮原生覆盖缺口。
