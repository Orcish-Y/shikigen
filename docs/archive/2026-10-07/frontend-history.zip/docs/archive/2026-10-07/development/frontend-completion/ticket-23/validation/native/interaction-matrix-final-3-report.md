> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# interaction-matrix-final-3 验证记录

## 验收范围与执行

- PRD：`.scratch/frontend-completion/PRD.md`，#11 / Story 114。
- 用例：`docs/wayfinder/frontend-completion/implementation/23-native-workflow-acceptance.md`，补验 Story 114 四操作及 OSK/长内容/托盘提示并存路径。
- 模型：`gpt-6-luna / max`；工作目录：`C:\code\shikigen-agent`。
- 命令：

  ```powershell
  .venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch interaction-matrix-final-3 --tests NativePlatformAcceptance.test_390_native_send_approve_cancel_and_reconnect NativePlatformAcceptance.test_osk_long_draft_tray_notice_and_native_cancel_remain_reachable
  ```

- 结果：2 selected / 2 executed / **2 passed / 0 failed / 0 error / 0 skip**，runner exit 0；unittest 用时 43.593 秒。
- 运行前后源码 SHA-256 相同：`native_platform_acceptance.py` `46BDE0240876F7C0993A23AB8163FC14A400D43BAD328E4A233E68AC0AD56396`；`native_runner.py` `4F802C6F4BD38C18190D99C774E134CC3EFFC03D0BE6C804D8322B607E4F756D`。Ruff check/format check 均 exit 0；精确 `--list` 为 2 项。
- dist 38 个文件逐项 SHA/size 与 final-4 manifest 一致：38 files / 1,049,454 bytes，manifest `fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f`。

## 结果细节

### 390×844 手机布局四操作：通过

viewport 是 CSS 390×844、DPR 1.5、`phone` breakpoint。第一 Run `276c3491ceb341fab06aabdbf51e1c6f` 完成准备消息及审批；第二 Run `6dfc2de651f9457cba36b96887eaa1d6` 发送长消息、手动重连，最终取消。第二 Run stream GET 恰为 4；本线程共记录 2 次 stream POST、1 次 approval POST、1 次 cancel POST。人类消息记录为准备消息 14 字符和第二 Run 510 字符；最后 composer draft 为 420 字符。可信原生事件记录“发送”“处理审批”“批准”“提交决策”“重新连接”“取消运行”“确认取消”。

### OSK 390×600、长内容、TrayNotice 并存四操作：行为通过，截图证据有缺口

该 case 的 runner 结果为 pass，记录了 `approval → send → reconnect → cancel` 四阶段。真实 OSK PID 1028、HWND 8062746；UI viewport 390×600、DPR 1.5。第一 Run `8474b4575ead4fec8c0a11a8540a7607` 完成；第二 Run `2ff783c9f43a4f9b88840c3ea5505110` 发送后重连并最终取消。第二 Run stream GET 恰为 4；总计 2 次 stream POST、1 次 approval POST、1 次 cancel POST。长草稿及阅读位置数据保留在 result/workflow 中。

事后查看 `osk-coexistence-native.png` 发现它显示无关浏览器页面，没有屏幕键盘；该图不能作 OSK 可见性证据。`osk-coexistence-app-native.png` 显示 Tauri 页面、托盘提示和草稿，但也不能替代 OSK 图。原始 pass 不改写；图片缺口由下一批专门重拍处理。详见 [截图复核记录（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 坐标和资源

同测试 fixture 的 `SetProcessDPIAware()` 调用方式下只读测得 awareness 为 system-aware，monitor rect `[0,0,2880,1920]`，work area `[190,0,2880,1920]`，任务栏 `[0,0,190,1920]`。两个 Tauri 窗口的 390×844 / 390×600 CSS 布局均按 native rect 布置于 work area 内。详情见 [DPI-aware monitor 查询（原始产物已删除）](../../../../../README.md#已删除的材料) 与两个 case 的 `work-area-placement.json`。

清理后 9238/45200 空闲；本批 OSK 与 Tauri/backend 进程均退出。预存 5173 PID 23344、TabTip PID 14204 保持。源码 post hash 与 prehash 相同。完整预检、runner stdout 和 post-cleanup 记录见 [preflight（原始产物已删除）](../../../../../README.md#已删除的材料)、[invocation（原始产物已删除）](../../../../../README.md#已删除的材料)、[stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[post hashes（原始产物已删除）](../../../../../README.md#已删除的材料)、[cleanup（原始产物已删除）](../../../../../README.md#已删除的材料)。

