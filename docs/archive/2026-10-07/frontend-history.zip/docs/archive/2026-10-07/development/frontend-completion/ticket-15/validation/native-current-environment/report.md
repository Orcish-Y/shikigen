> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 15 票原生验收报告：当前桌面环境

日期：2026-10-06（Asia/Shanghai）  
模型：`gpt-6-luna`，推理强度 `max`  
工作目录：`C:\code\shikigen-agent`（PowerShell，Windows SessionId 1）

## 结果

当前 dist 的原生验收共覆盖 11 个唯一用例：11 通过、0 失败、0 错误、0 跳过。取消／遮罩／Esc／焦点 probe 单独先跑 1 项；随后跑其余 7 项文件打开专项与 3 项图片／Markdown 回归。

| 批次 | 命令所选 | 通过 | 失败 | 错误 | 跳过 | 耗时 | 退出码 |
|---|---:|---:|---:|---:|---:|---:|---:|
| `environment-probe` | 1 | 1 | 0 | 0 | 0 | 11.098 秒 | 0 |
| `final-current-environment` | 10 | 10 | 0 | 0 | 0 | 76.371 秒 | 0 |
| 合计唯一用例 | 11 | 11 | 0 | 0 | 0 | 两批合计 87.469 秒 | 0 |

## 执行命令

以下命令均在仓库根目录执行，未调用 Git、未修改产品或测试代码，也未重跑 Node、Rust 或 Python 全量测试。

```powershell
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-15/native_runner.py --batch environment-probe --tests test_each_click_default_cancel_copy_escape_backdrop_and_focus_never_open
```

`environment-probe`：1/1 通过。共享静态服务校验为 `SHARED_DIST_SERVER_MODE=reused`、index 396 字节、2 个资源；runner 复用了已有 5173 服务。

```powershell
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-15/native_runner.py --batch final-current-environment --tests test_changed_file_fails_then_manual_prepare_reconfirms_current_metadata test_public_commands_reject_outside_directory_old_lease_and_generic_opener test_switch_hide_lease_loss_and_reference_change_close_confirmation test_image_system_open_replaces_detail_with_one_fresh_confirmation test_source_message_identity_and_real_backend_failure_revoke_and_restore_focus test_explicit_confirmation_reaches_actual_default_program_once test_unassociated_file_uses_actual_os_result_and_never_reuses_confirmation --regression
```

`final-current-environment`：10/10 通过，含 7 个本票剩余专项，以及以下 3 个既有回归：

- `test_auto_preview_full_view_copy_and_only_explicit_agent_references`
- `test_ready_lease_rotation_closes_image_view_and_reacquires_current_file`
- `test_real_messages_full_copy_drawer_and_single_foreground`

具体的 unittest 逐项输出见批次 stderr 日志。

## 桌面与宿主证据

初始只读快照见 [environment-snapshot.stdout.log（原始产物已删除）](../../../../../README.md#已删除的材料)。采样 shell 与其 Codex 祖先进程均处于 SessionId 1；Windows API 返回前景窗口为 VS Code，`EnumWindows` 枚举到 277 个顶层窗口、28 个可见窗口。CUA inventory 当时为空（`apps=[]; browsers=[]`），所以没有通过 CUA 取得桌面截图。该 shell 能枚举真实桌面窗口，但本报告不推断旧 `final-2` 连接失败的原因。

本批真实宿主于 13:48:51 创建：`backend_window.exe` PID 34968、SessionId 1；其 WebView2 PID 24700 的命令行带 `--webview-exe-name=backend_window.exe`、本轮临时 profile 和 `--remote-debugging-port=9238`。9238 监听由该 WebView2 PID 持有，probe 与余下用例均成功连接。详细记录：[owned-host-startup-observation.log（原始产物已删除）](../../../../../README.md#已删除的材料)。

5173 是既有共享服务 PID 23344，创建于 2026-10-04 17:52:57，runner 核验其 index 与 2 个 bundle 和当前 dist 字节一致后复用；本轮未启动、停止或替换它。结束后 `backend_window.exe`、9238、45200 均无监听；5173 仍为 PID 23344。旧 `OpenWith.exe` PID 26016（13:16:47 创建）在开始和结束快照中均存在，未触碰。

## 关键验收证据

- 取消流程：默认焦点落在取消入口；复制路径、Esc、遮罩、关闭均不调用系统打开。probe 的四次点击记录只有 prepare/discard，没有 `open_prepared_workspace_file`：[result.json（原始产物已删除）](../../../../../README.md#已删除的材料)、[截图（原始产物已删除）](../../../../../README.md#已删除的材料)。截图显示白底确认层、Slate 细边框、靛蓝焦点、文件名、可换行完整路径及系统接受后的说明，整体文字可读：[确认界面截图（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 文件变化：确认目标变更后失败，保留真实错误；只有手动重新准备并再次确认才可尝试当前目标：[截图（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 权限边界与生命周期：越界路径、旧租约及通用 opener 被拒绝；会话、隐藏、租约和引用变化会关闭当前确认；图片“用系统打开”使用新的确认。相应原始记录在 [final-current-environment artifacts（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 系统默认程序：打开 `notes/report.txt` 时只发出一次 `open_prepared_workspace_file`，调用返回 `true`，系统创建了新窗口 `report.txt - Notepad`（HWND 36506162）；复用已消费的 request_id 返回 `invalid_file_intent`，操作前后消息历史相同。证据：[result.json（原始产物已删除）](../../../../../README.md#已删除的材料)。这证明系统接受派发并出现 Notepad 窗口，不证明程序已读完文件。
- 无默认关联：`AssocQueryStringW` 对本轮唯一扩展名返回 HRESULT `-2147023741`，默认 executable 为空；OS 调用返回 `true`。本轮新窗口为 PID 9960、HWND 9374332，路径 `C:\Windows\System32\OpenWith.exe`，标题“选取应用”，类名 `Open With Dummy Window Class For Interim Dialog`，`is_visible=true`，没有子控件文本。当前用例未记录该 HWND 是否为前景，也没有选择器截图；因此结果只证明无关联文件的 OS 派发及新 OpenWith 窗口证据，不据此宣称可见选择器完整呈现或文件已显示／读取。测试夹具仅向本轮新识别的 HWND 发送 `WM_CLOSE`；其后 PID 9960 不再存在，既有 PID 26016 保留未动。证据：[system-windows.json（原始产物已删除）](../../../../../README.md#已删除的材料)、[result.json（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 后端故障及焦点：用例改变原消息身份后确认作废，再通过 `TerminateProcess` 以退出码 73 关闭本轮真实自管后端进程；待用户操作的确认失效，焦点回到可用的 `.backend-screen`。这是实际进程故障路径，不是 BackendManager 重启：[result.json（原始产物已删除）](../../../../../README.md#已删除的材料)、[故障页截图（原始产物已删除）](../../../../../README.md#已删除的材料)。
- 图片与 Markdown：图片预览、完整查看与单前景抽屉回归通过；窄视口完整内容截图仍可读：[窄视口截图（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 原始日志与边界

| 文件 | 内容 |
|---|---|
| [environment-probe.stdout.log（原始产物已删除）](../../../../../README.md#已删除的材料) / [stderr（原始产物已删除）](../../../../../README.md#已删除的材料) / [exit code（原始产物已删除）](../../../../../README.md#已删除的材料) | 首个单项 probe 的完整输出与状态 |
| [final-current-environment.stdout.log（原始产物已删除）](../../../../../README.md#已删除的材料) / [stderr（原始产物已删除）](../../../../../README.md#已删除的材料) / [exit code（原始产物已删除）](../../../../../README.md#已删除的材料) | 余下 10 项逐项输出与状态 |
| [owned-host-process-observation-01.log（原始产物已删除）](../../../../../README.md#已删除的材料) | 完成后的端口快照；只见原有 5173，无测试宿主端口 |

本次未等待原生窗口真实经过 5 分钟；过期行为由 Rust 虚拟时钟专项验证。`ready → ready` 租约变化的这批前端用例使用公开 Tauri bridge 状态帧模拟，不代表真实 BackendManager 重启。CDP/WebView 截图不能替代物理键盘、IME、标题栏或四档视口联合验收；这些仍属于后续实机覆盖。无默认关联用例未采集前景状态和选择器截图，需按上文限制解读。

本报告未重跑 Node、TypeScript、Vite、Ruff、Cargo 或 Python HTTP 检查；对应最新结果由同票前端及后端验证报告记录。本轮没有新增失败复现。

