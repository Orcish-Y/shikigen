> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 20 前端验证报告

- 验证执行者模型：GPT-6-Luna，推理强度 max（按主 agent 交接要求）。
- 工作目录：`C:\code\shikigen-agent\frontend`。
- 验证日期：2026-10-06（Asia/Shanghai）。
- 本验证 agent 未改产品代码，未调用 Git。Native/Tauri 实机测试由主 agent 的独立轮次执行，不计入本报告的测试数量。

## Final-2 结果

| 检查 | 命令 | 结果 |
|---|---|---|
| 定向 Node 回归 | `node --import tsx --test tests/conversation-presentation.test.mjs tests/message-drafts.test.mjs tests/thread-pagination.test.mjs` | exit 0；46 pass，0 fail，0 skipped，0 cancelled；TAP 441 ms |
| TypeScript | `node node_modules/typescript/bin/tsc --noEmit` | exit 0；无编译诊断，约 9.45 秒 |
| Vite build | `node node_modules/vite/bin/vite.js build` | exit 0；29.23 秒构建成功 |

Final-2 命令、工作目录、时间和退出码汇总见 [run-record.txt（原始产物已删除）](../../../../../README.md#已删除的材料)。定向测试 TAP 见 [final-2-node-focused.log（原始产物已删除）](../../../../../README.md#已删除的材料)，命令退出记录见 [final-2-node-focused-run.txt（原始产物已删除）](../../../../../README.md#已删除的材料)；TypeScript 的安静成功记录见 [final-2-tsc-noemit.log（原始产物已删除）](../../../../../README.md#已删除的材料)；构建输出与退出记录见 [final-2-vite-build.log（原始产物已删除）](../../../../../README.md#已删除的材料) 和 [final-2-vite-build-run.txt（原始产物已删除）](../../../../../README.md#已删除的材料)。

## Earlier full-suite baseline

在 final-2 产品小修改之前，完整命令 `node --import tsx --test tests/*.mjs` 曾得到 245 pass、0 fail、0 skip、0 cancelled，exit 0。结果保留在 [node-test-full.log（原始产物已删除）](../../../../../README.md#已删除的材料)；它是较早的全套基线，不代表 final-2 修改后的全套重复回归。本轮按主 agent 指定只重跑与展示、草稿和分页相关的三个测试文件，共 46 项。

## Final-2 覆盖

定向测试覆盖标题来源、缓存跨重启和完整历史重核、部分/SSE 不清除较早标题、服务端标题与 null/空标题回退、存储失败、只读 GET/不批读所有会话、迟到历史不修改当前草稿、日期时间阈值和时区边界、示例文本原样追加，以及分页和草稿相关既有行为。

本轮 TypeScript 与 Vite 检查包含主 agent 在上一轮之后做的三项小改动：完整本地时间新增复制控件、`Conversation` 属性统一为 `isCreating`、`useConversations` 缩进整理。标题长度口径按主 agent 确认的“48 个 grapheme 正文，超长时另加省略号”理解。

## 失败与剩余核验

- Final-2 Node、TypeScript 与构建均成功，无失败或跳过的 Node 测试。
- Vite 构建有非致命警告：压缩后的 JS chunk 超过 500 kB；构建完成，dist 已更新。
- 本验证 agent 未执行 WebView/native 交互。主 agent 的 final-2 native 轮次仍需确认本地时间复制按钮，以及键盘/触控、可见性刷新和示例聚焦等实际交互。
- TypeScript 的 PowerShell 记录步骤在读取空编译输出时曾因对 null 调用 `.Trim()` 打印脚本错误；TypeScript 子进程此前已返回 exit 0，输出文件为空。`final-2-tsc-noemit.log` 和 `run-record.txt` 记录了该子进程的实际命令、时间、exit 0 与无诊断结果，不把 PowerShell 后处理提示当成编译错误。


## Final-3 结果（最新产品修复后的完整回归）

验证执行者仍为 GPT-6-Luna / max。本轮完整重跑了全量 Node 测试，并重跑 TypeScript 与生产构建，覆盖最近加入的标题缓存失败语义修复：标题缓存单独报错，不把已持久化的消息草稿误报为“仅内存保存”。对应新增用例为 `a title-only write failure never reports a persisted message draft as memory-only`，位于 `frontend/tests/conversation-presentation.test.mjs`。

| 检查 | 命令 | 结果 |
|---|---|---|
| 完整 Node 回归 | `node --import tsx --test tests/*.mjs` | exit 0；246 pass，0 fail，0 skipped，0 cancelled；约 32.07 秒 |
| TypeScript | `node node_modules/typescript/bin/tsc --noEmit` | exit 0；无诊断，约 11.82 秒 |
| Vite production build | `node node_modules/vite/bin/vite.js build` | exit 0；4886 modules transformed，约 36.43 秒 |

命令、工作目录、开始/结束时间与退出码记录分别在 [final-3-node-full-run.txt（原始产物已删除）](../../../../../README.md#已删除的材料)、[final-3-tsc-noemit-run.txt（原始产物已删除）](../../../../../README.md#已删除的材料)、[final-3-vite-build-run.txt（原始产物已删除）](../../../../../README.md#已删除的材料)。完整 TAP 输出见 [final-3-node-full.log（原始产物已删除）](../../../../../README.md#已删除的材料)；TypeScript 原始输出文件 [final-3-tsc-noemit.log（原始产物已删除）](../../../../../README.md#已删除的材料) 为 0 字节（无诊断）；构建输出见 [final-3-vite-build.log（原始产物已删除）](../../../../../README.md#已删除的材料)。本轮无失败、无跳过项，因此没有失败复现步骤。

完整回归覆盖本票的标题来源／持久缓存核对、服务端标题优先、只读范围、时间格式与边界、示例追加和草稿保留，并包含分页、输入草稿以及相关前端状态测试。全量结果现有 246 项；相比 earlier baseline 的 245 项，本轮加入并通过上述标题写入错误隔离回归。

Vite 仍提示压缩后的 JavaScript bundle 为 631.72 kB，超过 500 kB 提示阈值；此为非致命警告，构建成功。构建已更新 `frontend/dist`。本验证 agent 未运行 Native/Tauri 实机交互，相关焦点、可见性刷新、时间复制与示例填写需由主 agent 的独立 native 轮次核验。验证期间未调用 Git、未改产品代码。
