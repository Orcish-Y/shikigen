> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 07 票原生验收记录

日期：2026-10-05。第07票最终原生验收完成。首轮12项回归全部通过；焦点样式探索时严格computed字符串断言曾红，随后校准正式oracle，最终两项07专项均通过。所有中间失败证据均独立保留。

## 调度与命令

- 实际模型：`gpt-6-luna`，推理强度 `max`。
- 工作目录：`C:/code/shikigen-agent`，PowerShell。
- Runner：`.scratch/frontend-completion/ticket-07/native-focusfix-runner.py`。这是 scratch 分组／产物路径包装器；正式断言和正式等待不变，逐字节复用经验证的 5173 静态服务，逐组检查 9238／45200 空闲，串行执行07和03／04／05／06正式用例。
- Python 命令：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-07/native-focusfix-runner.py`
- 环境：`$env:PYTHONPATH="C:/code/shikigen-agent/tests;C:/code/shikigen-agent/frontend/src-tauri/tests;C:/code/shikigen-agent/packages/harness"`
- 执行前按 managed GUI 要求请求并获得命令升权；未使用其他工具绕过审批。
- 完整原始日志：[`native-tabfix-run.log`（原始产物已删除）](../../../README.md#已删除的材料)，命令退出码 `0`。

## 结果

| 范围 | 用例 | 通过 | 失败 | 错误 | 跳过 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 07 Markdown／网页打开 | 2 | 2 | 0 | 0 | 0 |
| 03 真实事实重建 | 3 | 3 | 0 | 0 | 0 |
| 04 消息草稿 | 4 | 4 | 0 | 0 | 0 |
| 05 流恢复 | 2 | 2 | 0 | 0 | 0 |
| 06 窗口可见性 | 1 | 1 | 0 | 0 | 0 |
| **合计** | **12** | **12** | **0** | **0** | **0** |

用例耗时依次为 16.196s、15.484s、26.155s、23.105s、11.334s，合计 92.274s。07 的两项测试均执行真实 Tauri host；测试中调用托盘退出，断言 host 在15秒内以 exit 0 结束。执行后没有 `backend_window`／`backend_host` 进程，也没有 9238 或 45200 的监听者；仅既有 5173 服务仍由 PID 23344 监听。测试未终止任何 Edge／WebView 进程。

## 静态服务与构建版本

执行前逐字节比较了 `http://127.0.0.1:5173/`、JS 和 CSS 与 `frontend/dist`，三者完全一致。5173 的 index 引用 `assets/index-CRxAs_nQ.js` 和 `assets/index-ab2XaoTv.css`。

| 资产 | 大小 | SHA-256 |
| --- | ---: | --- |
| JS | 523,240 bytes | `985CDECD67BF9A9D50BAA841131210F80EB7C3710955E4C6CB58FDAEC1B11E76` |
| CSS | 61,656 bytes | `77CEF017826CAC703563AF89BAC6D7A04B7A98642A8CE0433A808C1E76644DE2` |

主 agent 已交叉核对该版本 Node 111项、direct tsc 与前端 build 均通过；本次没有重跑这些检查。其后仅验证焦点样式规则及正式原生oracle，未重建产品资产。

## 焦点样式专项复验

主 agent 增加 `[tabindex]:focus-visible` 规则与正式computed-style断言后，新版dist同样先与5173服务逐字节核对，再只执行07原有两项正式用例。新版构建资产为 `index-BOOLs1PU.js`（523,240 bytes，SHA-256 `985CDECD67BF9A9D50BAA841131210F80EB7C3710955E4C6CB58FDAEC1B11E76`）及 `index-C37yfSMR.css`（61,653 bytes，SHA-256 `75CDA7B59E7B971ED646F8F87403C26D04D19CE0C4305F100D17B0C55964DD38`）；入口与两个资产均匹配5173响应。

- Runner：`.scratch/frontend-completion/ticket-07/native-stylefix-runner.py`，只组装两个既有正式方法并将产物写入独立新目录，未修改正式测试。
- 命令：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-07/native-stylefix-runner.py`。环境 `PYTHONPATH` 与前一段相同；工作目录仍为 `C:/code/shikigen-agent`。第二次Tauri命令也单独请求并获得managed GUI升权。
- 日志：[`native-stylefix-run.log`（原始产物已删除）](../../../README.md#已删除的材料)，退出码 `1`；用例为1通过、1失败、0错误、0跳过。
- `test_native_rejects_unsafe_urls_and_frontend_reports_open_failure` 通过。
- `test_real_messages_full_copy_drawer_and_single_foreground` 的原始20步Tab循环已通过，随后computed-style正式断言失败：WebView读到 `['rgb(79, 70, 229)', '2px', '2.66667px']`，期望 `['rgb(79, 70, 229)', '2px', '3px']`。此刻颜色和宽度符合设计，offset不符。错误发生在窄屏截图保存前，失败日志保留了实际computed值；不把该项计作通过。
- 只读诊断另执行原正式case1，仍保留原红断言。[`native-offset-diagnostic-run.log`（原始产物已删除）](../../../README.md#已删除的材料) exit 1，1项失败；[`focus-offset-diagnostic.json`（原始产物已删除）](../../../README.md#已删除的材料) 记录CSSOM、焦点状态和视口，配套[截图（原始产物已删除）](../../../README.md#已删除的材料)。诊断只在原computed读取前读取公开DOM/CSSOM，先focus关闭按钮再恢复原pre焦点，之后原断言仍以同一值失败。
- 诊断确认pre和同dialog关闭按钮在 `:focus-visible` 时匹配同一全局规则；CSSOM中`outline-offset`声明是 `3px`，computedStyle对两者均返回 `2.66667px`，颜色 `rgb(79, 70, 229)`、宽度 `2px`也相同。DPR约1、visualViewport scale 1、视口390×780、document/body zoom均为1。静态搜索未发现项目显式页面zoom或控件scale；不推定量化根因，也不对CSS做反向补偿。
- 目视探索期截图中pre边缘已呈Indigo焦点轮廓，黑色fallback已消失。上述精确字符串断言失败作为探索证据保留；最终正式oracle改为同时验证3px声明和关闭按钮基线，完成通过，见下节。

这轮结束后再次核对：仅既有5173 PID 23344仍监听；9238／45200无监听，`backend_window`／`backend_host`进程筛查为空。失败用例未走到显式托盘 quit，框架清理收回临时host；网页用例通过并显式断言正常 exit 0。

### 最终07正式复验

主 agent 将焦点oracle改为同时检查当前pre、同dialog关闭按钮和pre恢复焦点后的公开DOM/CSSOM快照：三者active且`:focus-visible`；匹配规则声明offset精确为`3px`；Indigo颜色及`2px`宽度符合设计；三份完整snapshot相同。没有改CSS做像素补偿，也没有使用数值容差。

- 实际模型`gpt-6-luna / max`，工作目录`C:/code/shikigen-agent`。
- Scratch runner：`.scratch/frontend-completion/ticket-07/native-final-content-runner.py`，只选07两项正式方法，逐字节检查5173与dist一致，并确认9238／45200空闲。命令：`.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-07/native-final-content-runner.py`；`PYTHONPATH`与上文相同。
- 按managed GUI policy单独请求并获得命令升权。日志[`native-final-content-run.log`（原始产物已删除）](../../../README.md#已删除的材料)：exit `0`；`Ran 2 tests in 12.323s`；2通过、0失败、0错误、0跳过。
- `result.json`里的content、button、restored三个focus snapshot完全相等：三者active／`:focus-visible`，声明offset为`3px`，computed颜色为`rgb(79, 70, 229)`、宽度`2px`、offset`2.66667px`。正式断言验证声明与同WebView既有button基线一致，并验证原pre重新获得同一焦点。
- 完整数组复制与公开历史严格相等；网页打开Rust拒绝、系统接受和IPC权限失败局部反馈项再次通过。两个host均执行托盘退出并断言正常exit 0。
- 最新截图为[`desktop-drawer.png`（原始产物已删除）](../../../README.md#已删除的材料)、[`narrow-content.png`（原始产物已删除）](../../../README.md#已删除的材料)。最终07产物有2个`result.json`、4张PNG、2份host日志，均非空。
- 执行后仅5173 PID 23344仍监听；9238／45200无listener，`backend_window`／`backend_host`进程为空。未停止既有服务或终止用户浏览器。

## 第 07 票实际覆盖

- 通过正式持久化历史响应核对完整内容块数组；用户与工具字符串原文、Agent Markdown 标题、额外字段／未知块、完整复制 JSON 的值和序列化键序均被检查。复制文本先解析后与完整数组比较，再与HTTP历史字节表示严格比较。
- 原始 HTML 只显示为文字；无执行脚本、iframe、表单或 image 元素；任务 checkbox disabled；宽表格在所属容器内滚动。长代码块有可识别文件名／语言、源代码全文复制，聊天代码区实际高度不超过320px。
- 桌面 drawer 的 DOM 宽度为400 CSS px；查看详情期间仍仅一个 `dialog[open]`，关闭后原始入口节点仍连接并获得焦点，草稿保留且没有新 POST／SSE。复制失败显示手动选择提示。
- 窄屏采用 DevTools 设备视口 `390×780` CSS px 模拟，底部面板测得 `390×624`（80dvh），完整数组仍一致。普通Tab与Shift+Tab以正确的 CDP 修饰键运行20步，每步检查焦点仍在当前dialog。
- Rust `open_web_url` 对 `file:`、`javascript:`、`mailto:` 和无效 `https://` 均返回拒绝；前端不能直接使用 opener plugin。真实 opener 对本机临时无网络页面返回系统接受，WebView 地址保持不变；Ctrl+Shift 修改点击仍只触发一次受控命令，注入的系统拒绝通过原生 IPC 回到链接旁局部提示。
- 网页验收仅证明受控命令和操作系统接受本机 inert URL；没有把“浏览器实际呈现页面”作为通过条件。

截图：[`desktop-drawer.png`（原始产物已删除）（原始产物已删除）](../../../README.md#已删除的材料)。

## 最终结论与未覆盖范围

第07票直接AC的原生验收通过。最终截图的窄屏pre使用Indigo焦点轮廓；原生断言保留2px宽、3px规则声明、当前WebView button基线一致和原入口焦点恢复检查。

此前焦点失败与诊断保留于[`diagnosis.md`](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/diagnosis.md`）、`native-focusfix-run.log`、`native-tab-diagnostic-run.log`；12项回归结果在`native-tabfix-run.log`；oracle探索期红结果在`native-stylefix-run.log`和`native-offset-diagnostic-run.log`及其artifact目录。最终全绿证据只记于`native-final-content-run.log`和`native-final-content/`，未覆盖任何早期结果。

其他验证本次未重跑：Node 111/111、direct tsc和前端build exit 0；Rust 25项通过、cargo fmt check与backend_window example build通过。完整后端291项为289通过、1错误、1权限跳过；另外两次隔离环境用例2/2通过。该错误是空host环境分支等待子进程退出20秒超时，不属于07，也未被本次原生结果抵销；详情见[`backend-report.md`](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-07/backend-report.md`）及独立needs-triage记录。

尚未覆盖的物理环境包括真实窄屏窗口 resize、多个物理尺寸、系统输入法及原生 frame 输入组合，这些在本轮明确属于23票验收范围。当前390×780为 WebView emulation，不能描述为物理窗口验收。
