> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 18 最终定向验证：style-final-1

执行模型：gpt-6-luna，推理强度 max。日期：2026-10-06。

## 前端验证

| 检查 | 结果 |
|---|---|
| 定向 Node：run-events、run-reconstruction、run-details | 40 通过，0 失败，0 错误，0 跳过；exit 0 |
| TypeScript：tsc --noEmit | exit 0 |
| Vite build | exit 0；4881 modules |
| Ruff check：原生验收夹具与 runner | exit 0 |
| Ruff format --check：同两文件 | exit 0 |

Node 测试运行 13.150 秒。Vite 产物 CSS 70.21 kB，JS 616.93 kB（gzip 187.42 kB），显示主 chunk 大于 500 kB 的建议警告；构建成功。Node、TypeScript、build 和 Ruff 的原始日志分别保存在本目录；PowerShell 合并保留每条命令的 stdout/stderr。

## 原生实机验收

指定真实 Tauri/CDP 方法 1/1 通过，Python unittest 用时 10.450 秒。测试记录了 3 次 events GET：打开详情取得 seq 1–4，实际审批后取得 seq 1–6，正常 EOF 补读后取得 seq 1–9；三次都未 abort。实际终态记录 seq 9；resolved seq 5 包含主流程与 child 的真实 approve/reject 结果和拒绝原因。

完整 JSON 参数含 80 行。实机几何断言记录 max-height 320px、font-size 12px、line-height 20px，内容滚动高度 15104px；返回详情后焦点和阅读位置断言通过。复制内容通过 navigator.clipboard 边界捕获。截图是滚动到时间线后的 CDP WebView 截图。

- [最终时间线截图（原始产物已删除）](../../../../../../README.md#已删除的材料)
- [测试结果与真实事件 JSON（原始产物已删除）](../../../../../../README.md#已删除的材料)
- [原生 runner stdout（原始产物已删除）](../../../../../../README.md#已删除的材料)
- [原生 runner stderr（原始产物已删除）](../../../../../../README.md#已删除的材料)

Runner 输出确认复用了共享 dist 服务，index 为 396 bytes、引用 2 个 assets。原生验证没有停止共享 5173 服务。最终网络探测表明 5173 仍可连接，9238 与 45200 无监听。

## 版本范围与限制

本批覆盖主 agent 最后提交的领域命名修正，以及次要控件 12px、正文 14px、窄屏触控尺寸 44px 和 JSON 12px/20px 样式。没有重跑完整 208 项 Node 套件；其更早的通过结果仅是历史基线。其余四个原生唯一场景沿用此前 regression 批次的通过证据，本批只重跑了受 JSON 字体／行高影响的场景。

navigator.clipboard 是 WebView API 边界捕获，不是 OS 剪贴板；截图不含 Tauri 原生窗框。物理 IME 和四种 viewport 仍由 23 票覆盖。

精确模型、cwd、命令、退出码、测试统计、几何和日志路径见 [command-results.json（原始产物已删除）](../../../../../../README.md#已删除的材料)。

