> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 18 票后端验证报告

- 实际模型：`gpt-6-luna`，推理强度 `max`
- 环境：Windows PowerShell，`C:\code\shikigen-agent`，Python 3.12.13
- 验证范围：只读 HTTP events、Run runtime 查询、SSE 投影复用、真实临时 SQLite、类型与格式检查、完整后端单测
- 验证职责边界：未修改产品代码／测试断言，未执行 Git 命令；除本报告列出的 Python 验证命令外，未操作其他进程、5173 端口或原生窗口

## 结果

| 检查 | 结果 | 统计 |
| --- | --- | --- |
| 定向事件查询测试 | 通过，退出码 0 | 4/4 通过，0 失败、0 错误、0 跳过（1.881s） |
| 产品类型检查 | 通过，退出码 0 | `ty check app packages/harness/shikigen` |
| 新测试类型检查 | 通过，退出码 0 | `ty check tests/test_run_event_queries.py` |
| Ruff lint | 通过，退出码 0 | 4 个文件 |
| Ruff format | 通过，退出码 0 | 4 个文件已格式化 |
| 完整后端测试 | 通过，退出码 0 | 333 个测试：332 通过、1 跳过、0 失败、0 错误；348.747s |

完整回归唯一跳过项：`test_symlink_data_and_parent_are_rejected`，原因是 Windows symlink privilege unavailable。`test_waits_for_previous_cleanup_and_survives_caller_cancellation` 本次全量日志为 `ok`。旧 issue `.scratch/desktop-environment-exit-timeout/issues/01-empty-host-environment-startup-exit.md` 指定正式回归 `DesktopTests.test_environment_loaded_before_config_without_overriding_host`，覆盖 None／空字符串／host-model 三分支；本次全量日志该测试为 `ok`。当前三分支回归通过，但旧 issue 中记录的历史完整回归退出超时根因仍未确认，本次通过不替代其历史根因 triage。

## 后端验收覆盖

- 定向测试通过真实临时 SQLite、组装后的 Runtime、FastAPI ASGI transport 请求 `GET /api/threads/{thread_id}/runs/{run_id}/events`。返回 `{data: [...]}`；完整历史按 seq 升序，公开 JSON event 与同 Run SSE event 相等；当前 fixture 的类别序列为 `lifecycle/message/lifecycle`（MessageAgent 持久用户消息，不持久 AI 消息）；含换行和 URL 的用户 payload 原文保留。
- 对暂停态 Run 重复读取 events，并核对快照不变；缺失 Run 和错误 Thread 均返回 404 且 `Cache-Control: no-store`。这证明查询不经由会恢复暂停态的读取路径。当前夹具是缺少有效审批事实的 interrupted Run，没有单独注入格式损坏的 checkpoint。
- 仅通过 SQLite 驱动注入 `SQLITE_BUSY`／`SQLITE_CORRUPT`：分别得到 503（`Retry-After: 1`）和 500；两类响应均 no-store。随后快照与事件仍可读，原已提交事实保持不变。CORRUPT 分支会按设计记录 `committed_query_failed` traceback，断言通过。
- 预留一个未提交消息序号后取消运行，events 返回 `[1, 2, 4]`，不把预览伪造成 seq 3 的事件，且取消事件 payload 是已提交的 `{status: cancelled}`。
- 当前专用测试覆盖 SSE 对比的是完成运行的全量事件；取消后的补齐断言只读取 JSON events。专用 JSON 测试没有构造 approval event，尽管现有 approval SSE 单测在完整回归中通过。HTTPX 使用 ASGI transport，没有绑定真实网络端口。
- 首版接口没有分页／服务端过滤，返回查询时全部公开事件；额外查询参数不参与查询。Runtime 调用被 `committed_query()` 包裹，SQLite 查询按 Thread／Run 归属并以 seq 排序。公开投影由 `project_run_event(DurableEvent)` 供 JSON 与 SSE 共用。（本句由主 agent 复核路由声明后校正措辞，不新增验证。）

## 命令与原始证据

工作目录均为 `C:\code\shikigen-agent`：

- `.venv/Scripts/python.exe -m unittest discover -s tests -p test_run_event_queries.py -v`
- `.venv/Scripts/python.exe -m ty check app packages/harness/shikigen`
- `.venv/Scripts/python.exe -m ty check tests/test_run_event_queries.py`
- `.venv/Scripts/python.exe -m ruff check app/run_contract.py app/routes/run.py packages/harness/shikigen/runtime/runs.py tests/test_run_event_queries.py`
- `.venv/Scripts/python.exe -m ruff format --check app/run_contract.py app/routes/run.py packages/harness/shikigen/runtime/runs.py tests/test_run_event_queries.py`
- `.venv/Scripts/python.exe -m unittest discover -s tests -v`

每项命令的退出码、模型、cwd、摘要以及 stdout/stderr 文件名收录在 [`command-results.json`（原始产物已删除）](../../../../../README.md#已删除的材料)。原始日志为对应的 `*.stdout.txt` 与 `*.stderr.txt`；完整回归的 81 KB stderr 包含逐项结果、跳过原因及预期错误注入日志。



## 增量验证（2026-10-06）

新增不兼容已提交事件的只读诊断分支已定向验证：5/5 专项通过，Ruff check/format 和 ty 检查均通过。未重跑完整后端回归；逐命令结果、原始日志与覆盖范围见[增量报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/backend/incremental-2026-10-06/report.md`）及其 [`command-results.json`（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 命名最终轻量复核（2026-10-06）

测试对象局部重命名后，5/5 专项通过，测试文件的 Ruff check/format 和 ty 全部通过；旧泛称局部赋值扫描无残留。未重跑全量回归。命令、模型、日志与命名审计见[命名最终复核报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-18/validation/backend/naming-final-2026-10-06/report.md`）。
