> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 05 票实施与验收报告

日期：2026-10-05（Asia/Shanghai）。用户授权第 5 票并要求延迟 30 分钟开始，已按约定于北京时间 02:30 开始。

当前状态：实现、审查补修及最终验收完成；第 05 票已标记 done，索引下一票为第 06 票，本轮未启动下一票。

## 改动及原因

- 新增 `frontend/src/observation-recovery.ts`，集中管理一个观察轮次：原连接失败后只用同一 Run 的 GET stream，失败后分别等待 1／2／5 秒，最多自动尝试三次。HTTP 503 尊重秒数或 HTTP-date 的 Retry-After；有效等待期限在重新选择、手动操作和新租约时仍保留。首帧 metadata 不清空预算，连续健康 30 秒或正常审批／终态回放才重置；安静的长工具不按输出超时失败。
- `ConversationStore` 使用该恢复任务，并增加互斥的 `reconnect` 和 `queryStatus` 公开入口。重连补接观察，查询只读 Run JSON；列表刷新不重开已耗尽的观察。切换会话和撤销租约 Abort 旧读取及计时器，保留后台运行、事实、草稿和已接受发送。
- 已接受 POST 断流恢复到同一 Run，等待期间补读真实消息，避免首帧之后立即断流时把已接受用户原文显示为空会话。新增 `RunProjection.mergeMessages` 只合并正文，不能用历史附带状态覆盖最近 metadata。未确认 POST 只 GET 核实，始终不会自动重发 POST。
- `BackendRequestError.detail` 和结构化观察／发送错误保留 HTTP status、detail、Retry-After，以及 SSE code、message、recoverable。未知错误保留说明；协议错误、GET 400／404／500、不可恢复 SSE 停止自动恢复。Run 404 不解释为删除会话。
- 工作台及导航分开显示宿主、观察和 Run 状态，沿用现有 `business-notice`、次按钮和浅色样式；新增恢复停止／等待提示、完整错误折叠查看、倒计时、“重新连接”和“查询状态”。秒级倒计时不放进 aria-live。

复用公开 API：`GET /api/threads/{thread_id}/messages`、`GET /api/threads/{thread_id}/runs/{run_id}/stream`、`GET /api/threads/{thread_id}/runs/{run_id}`。没有新增后端路由、Rust 产品命令或 CSS。

窗口显隐输入及五秒列表轮询归第 06 票，本轮未启动；本票验证重新选择、租约更新和 Abort 的共用恢复入口。

## 开发中的红绿证据

- 1／2／5 恢复专项先失败（没有重连），实现后通过；手动竞争专项先失败（没有公开入口），实现后通过。
- 原第 03／04 票测试保留既有身份、原文、单次 POST 和草稿断言，增加按定稿要求等待后 GET 的检查。没有删除测试或降低断言。
- 真 Tauri 首轮显示已接受发送后原文不可见。新增公开消息补读用例先红（20 通过、1 失败），主修补读及正文专用合并后，恢复＋重建专项 42／42 通过。
- Spec review 发现空 SSE 正常 EOF、没有 metadata 被错误地自动重试。新增用例先红（retry_wait 而非 failed），`finishObservation` 改为协议错误后绿 1／1，保留 running 和正文、停止自动重试。

## 验证分工及证据

主 agent 负责实现和修复；最终验证、Spec 和 Standards 审查均显式使用 `gpt-6-luna / max` 子 agent，fork none。交接含规格、七条 AC、方案、改动、风险、既有失败、完整命令、工作目录和权限限制，见[验证交接](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-05/validation-context.md`）。独立后端和前端验证并行；原生窗口、端口及构建由前端验证者独占并串行验收。

后端验证已完成并核对原始汇总：公开 HTTP 17／17、恢复 11／11、Run 观察 9／9、ty 通过；完整 Python 套件 291 项，290 通过、1 环境跳过、0 失败／错误，退出码 0。各专项不与全套相加。唯一跳过是 Windows symlink 权限不可用，见[后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-05/backend-report.md`）。

最新前端源码：Node 全套 **93／93**、direct tsc、pnpm build、两份原生脚本 ruff check／format 均退出码 0。主已核对原始日志汇总，见 [node-tests-93.log（原始产物已删除）](../../../README.md#已删除的材料)、[tsc-final-93.log（原始产物已删除）](../../../README.md#已删除的材料)、[pnpm-build-final.log（原始产物已删除）](../../../README.md#已删除的材料)、[ruff-check-final.log（原始产物已删除）](../../../README.md#已删除的材料)、[ruff-format-check-final.log（原始产物已删除）](../../../README.md#已删除的材料)。旧一轮 tsc 因新补修且进程迟迟不退出被中断，退出码 1 留在 [tsc-final.log（原始产物已删除）](../../../README.md#已删除的材料)，不计通过。

最终本票真 Tauri **2／2** 通过、退出码 0，见 [stream-recovery-native-final.log（原始产物已删除）](../../../README.md#已删除的材料)。主核对 result.json 及停止截图：POST 首 metadata 后断流，GET 时序间隔 **1046.1／2011.0／5010.0 ms**，初轮恰三次 GET；查询只读快照，不开新流，手动重连恰一次 GET。运行仍为 running、error=null，原文和下一条草稿可见；后台完成后正文、终态及草稿仍正确。

截图及原始记录：[停止后的工作台（原始产物已删除）](../../../README.md#已删除的材料)、[同 Run／单次用户消息与请求记录（原始产物已删除）](../../../README.md#已删除的材料)、[GET400 停止记录（原始产物已删除）](../../../README.md#已删除的材料)。构建 JS 为 `index-DTJXTmHw.js`，CSS 为 `index-CSJzwBNI.css`；HTML／两份资源 hash 及无缺失资源记录见 [dist-hashes-final.txt（原始产物已删除）](../../../README.md#已删除的材料)。

最新构建上的旧票实机回归也已核对实际日志：第 04 票 **4／4**，第 03 票 **3／3**，均退出码 0。本票加回归共九项正式 Tauri 用例；退出最小探针单独列出，不叠加到正式用例计数。日志：[message-drafts-native-final.log（原始产物已删除）](../../../README.md#已删除的材料)、[run-reconstruction-native-final.log（原始产物已删除）](../../../README.md#已删除的材料)；详细命令、资源清理与覆盖范围见[前端验证报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-05/frontend-report.md`）。

| 本票验收条件 | 核对证据 |
| --- | --- |
| 观察七态、running EOF 与正常审批／终态 EOF 分开 | 公开 SSE 专项；真实工作台状态、history／snapshot |
| 1／2／5、三次上限、Retry-After、无重复与并发 | 公开网络＋可控时间专项；原生实际请求时序 |
| metadata 不重置，健康 30 秒才重置，列表不重开 | 30 秒边界、安静连接、四次立即断流及列表刷新专项 |
| 手动／重新选择／新租约，Abort 不取消后台 | 手动竞争、延期重入、失效计时器专项；原生仅 GET 及后台完成事实 |
| 400／404／500／解析／不可恢复停止，长工具不超时 | 错误分类及空 metadata EOF 专项；原生 GET400 保持运行中 |
| POST 未知只查询、已接受同 Run 恢复，保留错误原文 | 草稿全套及恢复专项；原生同 Run、一条 human、下一条草稿保留 |
| 公开边界与工作台断流演示 | Node 93／93、原生本票 2／2、旧票回归 4／4＋3／3 |

第 04 票遗留审批清理等待错误本轮未复现；没有修改该产品路径或正式用例，根因仍未确认。主已向[独立问题](../../../../../issues/approval-resume-settlement-timeout.md)追加本轮证据，保留原始失败及 needs-triage。

## 原生验收的环境及初轮失败

- 使用真正 Tauri WebView、真实隔离后台及公开 HTTP。仅在 fetch 传输边界切断已接受 POST 或返回 GET503／400，产品状态层没有测试钩子。首轮 Node 为 91／91，之后的补修使旧构建不能代表最终代码。
- 初轮本票 2 项、第 04 票 4 项及第 03 票 3 项未完整通过，多数失败在托盘退出的物理鼠标命中；第 04 票首项一次未观察到 Enter 提交，独立诊断未复现，不能据此声称根因已解决。原始失败日志保留，不能计作通过。
- HTTP400 初轮宽泛的全页面“运行失败”否定断言误命中固定解释文案，改为精确核对真实工具栏“运行中”，同时保留公开 history 的 running 断言。
- 只读 Win32 诊断确认当前可见 `LockScreenBackstopFrame`、foreground=0；Windows 锁屏使全局物理输入不可用。两种键盘菜单尝试亦失败，随后停止输入探测，没有解锁或绕过锁屏。
- 测试夹具仅将生命周期退出清理改为真实原生菜单命令：核本宿主 popup 的两个标签、菜单 ID 及 enabled，WM_CANCELMODE 收起菜单后对本宿主 `tray_icon_app` 发送 WM_COMMAND。依据是本机 tray-icon 0.24.2 的 TrackPopupMenu 和 Muda 0.19.3 的原生菜单分发源码；未直接调用 JS／Rust 产品 handler。正常退出 0 及后台清理断言保留，原鼠标验收分支保留。最小真 Tauri 退出探针 1／1 通过，见 [quit-probe-after-native-command.log（原始产物已删除）](../../../README.md#已删除的材料)。
- 本轮旧票回归使用 [run_native_regression.py（原始产物已删除）](../../../README.md#已删除的材料) 导入正式用例、沿用原入口方法列表及全部断言，仅隔离产物路径至 `native-regression/03` 和 `/04`。先前被默认路径覆写的初轮失败产物已归档至 `native-before-helper-fix/03` 和 `/04`，随后只读固定基点 Git 内容，恢复 23 个旧票历史产物，见 [previous-artifacts-preserved.json（原始产物已删除）](../../../README.md#已删除的材料)。旧票已通过的历史报告保持原证据；没有写 Git 元数据。
- 最终原生宿主日志保留 `Failed to unregister class Chrome_WidgetWin_0. Error=1412` 的 WebView 析构诊断；本轮未调查其原因。正式断言、正常退出及清理检查通过，不据此宣称日志完全无错误输出。最终 5173／9238／45200 无监听，backend_window 进程为 0；先前未知所有权 PID23344 未被触碰。

## 审查

- [Standards review](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-05/standards-review.md`）：aria-live 发现已修复并复核，无未解决明确标准违例。重复倒计时逻辑列为非阻塞讨论项。
- [Spec review](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-05/spec-review.md`）：空流 EOF 硬缺口已通过红绿补修并复核，无其他未解决硬缺口。

## 剩余覆盖范围

锁屏期间验证的输入为真实 Tauri WebView 中的 CDP 输入，不代表系统 IME 候选或物理键鼠验收。解锁后的物理操作、窗口边框、多尺寸及联合流程留给第 23 票；窗口显隐暂停由第 06 票补齐。

开始基点：`994ac75d94f19c8b00dd3f769df7aad9196b251d`，开始工作树为空。本轮没有 stage、commit、reset 或其他 Git 写操作。

收尾只读核对：文档链接无断链（[链接记录（原始产物已删除）](../../../README.md#已删除的材料)），仓库换行设置下 `git diff --check` 退出码 0（[日志（原始产物已删除）](../../../README.md#已删除的材料)）；旧票历史产物按 Windows checkout 的 CRLF 恢复，工作树仅保留本票改动及旧问题复核记录。
