> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 2 票 Tauri 续验收报告

日期：2026-10-04。执行：`gpt-6-luna`，推理强度 `max`；主 agent 根据测试子 agent 的记录、原始日志、JSON 和截图汇总并核对。

规格：[第 2 票](../../../../../wayfinder/frontend-completion/implementation/02-paginated-conversation-list.md)、[统一规格](../PRD.md)。工作目录：`C:\code\shikigen-agent`，PowerShell。测试使用真实隔离 Tauri 宿主、临时 SQLite 与确定性 Agent，模型边界未访问外部服务。

## 结果与计数

14 项业务覆盖均有最终通过证据；这表示不同验收路径，不是一次全绿批次。含诊断与重测的 27 份根目录测试日志共记录 35 次测试方法执行：16 通过、17 断言失败、2 夹具错误、0 跳过。原始失败均保留，未作为通过结果。另有静态端口预检查以 88 退出、未启动测试，不计入上述次数。

| 范围 | 初次结果与最终补证 | 原始日志 |
| --- | --- | --- |
| 4 项既有客户端回归 | 首批 3 通过、1 退出阶段失败；该项保持原断言单独重测 1／1 通过 | [首批（原始产物已删除）](../../../README.md#已删除的材料)、[重测（原始产物已删除）](../../../README.md#已删除的材料) |
| 0／20／21／40／41 数量边界 | 首批 4 通过、0 条就绪探针失败；修正探针后 0 条重测 1／1 通过 | [首批（原始产物已删除）](../../../README.md#已删除的材料)、[0 条重测（原始产物已删除）](../../../README.md#已删除的材料) |
| 过滤、滚轮与 End | 最终 1／1 通过，41 条完整读取为 20／20／1 | [最终（原始产物已删除）](../../../README.md#已删除的材料)、[早期 2 项断言失败（原始产物已删除）](../../../README.md#已删除的材料) |
| 真实 503／CORS／可见重试 | 最终 1／1 通过；此前浏览器头读取／倒计时补证也 1／1 通过 | [可见按钮最终（原始产物已删除）](../../../README.md#已删除的材料)、[头读取补证（原始产物已删除）](../../../README.md#已删除的材料) |
| 真实 422／可见原位重载 | 最终 1／1 通过；顶部重载入口补证 1／1 通过 | [原位最终（原始产物已删除）](../../../README.md#已删除的材料)、[顶部入口（原始产物已删除）](../../../README.md#已删除的材料) |
| 长历史、中段阅读与活动 SSE | 最终 1／1 通过；此前 1 次缺 helper 错误、2 次验收基线断言失败 | [最终（原始产物已删除）](../../../README.md#已删除的材料)、[缺 helper（原始产物已删除）](../../../README.md#已删除的材料)、[滚动基线（原始产物已删除）](../../../README.md#已删除的材料)、[自然结束清理（原始产物已删除）](../../../README.md#已删除的材料) |
| 可信点击后 PageDown | 最终 1／1 通过；首轮已触发分页但在过滤隐藏行的选择断言失败 | [最终（原始产物已删除）](../../../README.md#已删除的材料)、[首轮（原始产物已删除）](../../../README.md#已删除的材料) |

## 执行命令

以下核心命令由执行子 agent 核对，不包含 PowerShell 的输出重定向和端口预检查包装。脚本在验收过程中迭代了用例选择和产物目录；当前版本指向最后一次专项，历史批次结果以对应日志为准。再次执行原生用例需要其既有测试依赖及允许启动桌面宿主的工具权限；不要并行争用端口。

```powershell
.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-02-native-resume\client_native_runner.py
.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-02-native-resume\client_replayed_pause_retry.py
.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-02-native-resume\boundary_native_runner.py
.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-02-native-resume\pagination_surface_runner.py
.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-02-native-resume\real_503_cors_runner.py
.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-02-native-resume\invalid_cursor_runner.py
.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-02-native-resume\active_sse_pagination_runner.py
.venv\Scripts\python.exe -X utf8 .scratch\frontend-completion\ticket-02-native-resume\page_down_pointer_runner.py
```

## 关键证据

- 数量边界：五种数量均核对实际 HTTP 的全页条数、游标和顺序，以及 WebView 首屏。0／20 条首屏停止；21／40／41 条首屏 20 行。41 条由真实页面完整读为 20／20／1；21 条经错误重试后读到末页。不能据此宣称五种数量均执行过实机末页操作。原始 JSON 位于 `boundaries/` 与 `boundaries-count0-retry/`。
- [过滤与 End JSON（原始产物已删除）](../../../README.md#已删除的材料)：少匹配 3 行／零匹配时键入不增加 GET；显式可信滚轮、End 各读取一页，最后显示“没有更多”；当前选择、草稿和聊天请求不变。[截图（原始产物已删除）](../../../README.md#已删除的材料)。
- [503 JSON（原始产物已删除）](../../../README.md#已删除的材料)：隔离后端的 ThreadStore 注入一次读故障，真实 HTTP 返回 503、`Retry-After: 1` 和允许的 CORS 头；同一 WebView 跨端口 fetch 可读取等待值。界面保留 20 行、等待期禁用重试，0.5 秒观察窗内没有自动重试；错误区和按钮滚动可达。解锁后可信点击只重试同一游标一次，恢复 21 行并清除错误。[可见按钮截图（原始产物已删除）](../../../README.md#已删除的材料)。
- [422 JSON（原始产物已删除）](../../../README.md#已删除的材料)：隔离后端注入失效游标，真实 HTTP 返回 422；保留 20 行，错误区按钮可见。可信点击“重新加载会话列表”发出不带游标的 GET，等待响应时保留列表、选择、草稿与聊天请求，成功后清除错误。[原位入口截图（原始产物已删除）](../../../README.md#已删除的材料)。
- [活动 SSE JSON（原始产物已删除）](../../../README.md#已删除的材料)：80 段已提交历史正文，8 次稳定采样均为 scrollTop=3600，可见锚点为 032、相对顶部 6px。活动流闸门未放行时，可信滚轮只新增一个游标 GET、加载到 40 行；分页前后聊天位置、锚点、选中会话、草稿及消息／流请求记录完全一致。
- 同一活动 POST 请求在 WebView 内以 `===` 核实身份，分页时 `aborted=false`、`EOF=false`、POST 数量为 1。透明 reader 审计原样转发真实 chunk；放行后同一响应交付 5 个 chunk，包含最终正文及 metadata，再自然 EOF。发送结束后现有 `reload()/openSelected()` 清理旧 controller 并补读历史，不属于分页中断；发送开始时已完成历史 GET 的 signal 已被清理，不能声称所有历史 signal 全程未 abort。[活动流截图（原始产物已删除）](../../../README.md#已删除的材料)。
- [PageDown JSON（原始产物已删除）](../../../README.md#已删除的材料)：可信点击 NAV 空白后，焦点在会话列表；真实 WebView 的 PageDown 为 `isTrusted=true`、`repeat=false`、目标／活动元素均为 NAV、`defaultPrevented=true`。无匹配过滤下只新增一个游标 GET，清除过滤后 40 行且仍选择原会话，聊天请求未变化。[截图（原始产物已删除）](../../../README.md#已删除的材料)。
- 行与 skeleton 主体实测均 63px、margin-bottom 4px；focus-visible 使用现有靛蓝 2px outline、3px offset。CSS 内容区 1440×900、DPR 2，截图只有 WebView 内容。

## 历史失败与复现条件

| 条件／观察 | 记录与处理 |
| --- | --- |
| 默认沙箱可见窗口未启动后端／CDP | [启动失败（原始产物已删除）](../../../README.md#已删除的材料)、`start-probe.json`；后续经允许的原生宿主权限继续，未把该次启动计为通过 |
| 物理 Win32 End／PageDown 没有送达目标 DOM；焦点／鼠标句柄夹具问题 | [elevated（原始产物已删除）](../../../README.md#已删除的材料)、[SendInput（原始产物已删除）](../../../README.md#已删除的材料)、[mousefocus（原始产物已删除）](../../../README.md#已删除的材料)、[clickfocus（原始产物已删除）](../../../README.md#已删除的材料)；保留为物理输入覆盖缺口 |
| 纯脚本聚焦后 CDP keyDown／rawKeyDown 无 DOM 事件 | [keyDown（原始产物已删除）](../../../README.md#已删除的材料)、[rawKeyDown（原始产物已删除）](../../../README.md#已删除的材料)；可信 NAV 点击激活后的定向用例通过，原失败不改写 |
| 初期错误场景未送达预期输入，等待页面错误超时 | [503（原始产物已删除）](../../../README.md#已删除的材料)、[503 wheel（原始产物已删除）](../../../README.md#已删除的材料)、[422（原始产物已删除）](../../../README.md#已删除的材料)、[422 wheel（原始产物已删除）](../../../README.md#已删除的材料)；最终故障由实际后端注入并用可信指针操作补证 |
| 客户端第 4 项在退出时托盘坐标断言失败 | 首批 4 项日志保留；保持原业务断言和退出 helper 的单项重测通过，仍记录退出夹具的不稳定性 |
| 0 条探针仅看空行数组，未等待会话列表就绪 | 首批误在启动页断言失败；等待真实列表出现再判空，单项重测通过 |
| 过滤少匹配场景错误地期待仍有 20 个可见行 | `pagination-surface.log`；核对过滤仅显示已加载匹配项，保留不自动分页与单次显式分页断言 |
| 活动 SSE 缺审计 helper／不稳定滚动基线／误要求自然结束后仍未 abort | 三份原始失败日志保留；补 helper、稳定采样，并按分页期间与自然结束时序分别断言；新增原响应 reader/EOF 证据，不修改产品 |
| PageDown 后从被过滤隐藏的列表行读取选择，得到 null | `page-down-pointer.log`；改为核对聊天标题，并清除过滤后核实原选中行；可信事件和恰一页请求断言不变，重测通过 |

## 资源与剩余边界

- 实际 API 始终由本次隔离 Tauri 宿主管理，使用临时数据目录；后端／CDP 端口为 45200／9238，串行执行。
- 测试子 agent 最后只读查询监听状态，确认 9238、45200 已释放。5173 既有服务为本仓库 `frontend/dist` 的只读 Python HTTP 服务；无法确认是哪次验收启动，未终止它。HTTP index 与引用 JS 已和当前 dist 逐字节比较，SHA-256 分别为 `ee96671dfdea86e90754b0e767e75ed16c4afe977b279586d5bed5704d5c47f5`、`1eec2c36624eefcdfd57ed93a290712dfaed072d7a8f9bc2746426e58ea8bdbd`。
- 可信 CDP 输入验证了实际 WebView 处理与公开请求，不等同物理 Windows 键盘／鼠标。物理焦点、IME、触控、原生标题栏及其他尺寸继续按既有[第 23 票](../../../../../wayfinder/frontend-completion/implementation/23-native-workflow-acceptance.md)验收；真实模型任务与跨分支流程同样未在本专项验证。
- 本次新增产品修复只有桌面 CORS 暴露 `Retry-After`。其 Python 最终回归 286 项：285 通过、1 Windows 符号链接权限跳过、0 失败；命令、Ruff、生产类型检查及日志见 [CORS 回归报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-02-cors-report.md`）。既有前端 29 项、TypeScript 和生产构建已通过，本次前端未改变。
- 测试子 agent 在最终 PageDown 成功产物保存后因额度中断。用户要求继续后，主 agent 读取原始通过结果并核对；子 agent 随后只补充核心命令和资源查询，没有重跑通过用例。第 2 票的 7 条验收条件已核对完成。
