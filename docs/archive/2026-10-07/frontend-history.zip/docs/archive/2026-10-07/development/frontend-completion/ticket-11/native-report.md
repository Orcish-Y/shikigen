> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 11 票原生与 Python 辅助验证报告

- 执行模型：`gpt-6-luna / max`
- 工作目录：`C:\code\shikigen-agent`
- Tauri 夹具：复用已有 `frontend/src-tauri/target/debug/examples/backend_window.exe`；未构建或改动 Rust。
- 静态服务：5173 上已有 PID 23344 的 `python -m http.server` 服务持续提供 `frontend/dist`。启动和定稿后 native runner 都通过 `ReconstructionAcceptance.setUpClass` 核对 index 与引用资源逐字节匹配；服务按要求保留。
- 隔离端口：Tauri 检查使用 9238、45200、45201；每次 runner 结束后均检查为未监听。最终没有遗留 `backend_window` 进程。
- 命令环境：Python 3.12 `.venv/Scripts/python.exe -X utf8`；`PYTHONPATH=C:\code\shikigen-agent\tests;C:\code\shikigen-agent\frontend\src-tauri\tests;C:\code\shikigen-agent\packages\harness`。

## 原生运行结果

| 运行 | 命令 | UTC 起止 | 结果 |
| --- | --- | --- | --- |
| 完整原生批次 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-11/native-runner.py all` | 2026-10-05 14:04:44.158Z – 14:09:11.499Z | 24 项：22 通过、2 失败、0 error、0 skip；exit 1。包含新11专项1项、第10票4项及03–09旧项19项 |
| 11专项，增长错误夹具后 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-11/failure-final.py` | 2026-10-05 14:17:08.012Z – 14:17:26.938Z | 1 通过、0 失败、0 error、0 skip；exit 0。仅验证更新后的错误正文，尚不包含稍后增加的 badge 颜色断言 |
| 旧04 IME 隔离诊断 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-11/ime-diagnostic.py` | 2026-10-05 14:19:15.010Z – 14:19:33.431Z | 原旧04用例加只读事件监听，1 通过、0 失败、0 error、0 skip；exit 0。此隔离通过不抵消完整批次中的正式失败 |
| 11专项，失败颜色定稿后 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-11/failure-final.py native-style-final` | 2026-10-05 14:22:39.144Z – 14:22:58.855Z | 1 通过、0 失败、0 error、0 skip；exit 0。使用最新 build，检查实际失败颜色 `rgb(185, 28, 28)` |

前三项与最后一项使用上述同一 repo cwd 和 `PYTHONPATH`。完整命令、cwd、executable、参数、环境、UTC 时间、退出码与 stdout/stderr 路径均记录在各自 meta JSON。

## 初次完整批次的两项失败

1. **第11票长错误纵向滚动断言。** 原 fixture 的错误内容只有三行，主要内容在一条超长行里。原生截图显示水平滚动内容；垂直 `scrollHeight` 与 `clientHeight` 相等，因此 `frontend/src-tauri/tests/failure_partial_acceptance.py` 的纵向滚动断言失败。主 agent 把错误 fixture 改成120条编号明细，保留原断言，没有放宽检查。更新夹具后的 `native-new-final` 单项通过；样式修正后的最终 `native-style-final` 也通过。

2. **继承旧04 IME 输入用例。** `message_drafts_acceptance.py:105` 等待用户消息的30秒超时。首轮现场中 textarea 有焦点且原文草稿仍在，`__sends=[]`、公开历史为空；没有发送 POST，不能归为后端拒收。首轮没有事件 trace，不能判定具体拦截条件。单独原样重跑该旧用例时通过：`Input.insertText` 后观测到 `compositionend`（`trusted=false`，事件时间戳89.899ms）；可信 Enter keydown 时间戳178.700ms、`isComposing=false`、`keyCode=13`、`repeat=false`，距 compositionend约88.8ms，大于50ms保护窗口。按下时 textarea 仍聚焦、草稿非空、发送按钮未禁用，随后公开消息和重启恢复断言通过。隔离通过不改写首轮22/24的结果；首轮失败与隔离通过的差异仍未解释。

   事件详情与 `needs-triage` 跟踪见[IME问题记录](../../../../../issues/composition-enter-no-post.md)、[首轮 failure evidence](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/native/04-message-drafts/test_original_enter_composition_and_draft_survive_native_restart/failure-evidence.json`）、[隔离事件记录](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/ime-diagnostic/04-ime/test_original_enter_composition_and_draft_survive_native_restart/ime-events.json`）及[隔离成功记录](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/ime-diagnostic/04-ime/test_original_enter_composition_and_draft_survive_native_restart/result.json`）。未改动输入产品代码、原用例或断言。

## 日志与证据

- 完整批次：[stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/logs/native-all.stderr.log`）、[meta](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/logs/native-all.meta.json`）
- 初始第11票失败现场：[failure evidence（原始产物已删除）](../../../README.md#已删除的材料)、[DOM（原始产物已删除）](../../../README.md#已删除的材料)、[截图（原始产物已删除）](../../../README.md#已删除的材料)
- 旧04首轮失败现场：[failure evidence](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/native/04-message-drafts/test_original_enter_composition_and_draft_survive_native_restart/failure-evidence.json`）、[DOM](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/native/04-message-drafts/test_original_enter_composition_and_draft_survive_native_restart/failure-dom.html`）、[截图](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/native/04-message-drafts/test_original_enter_composition_and_draft_survive_native_restart/window.png`）
- fixture 更新后的第11票：[stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[meta（原始产物已删除）](../../../README.md#已删除的材料)、[持久记录（原始产物已删除）](../../../README.md#已删除的材料)
- IME 隔离诊断：[stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/logs/native-ime-diagnostic.stderr.log`）、[meta（原始产物已删除）](../../../README.md#已删除的材料)、[事件 JSON](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/ime-diagnostic/04-ime/test_original_enter_composition_and_draft_survive_native_restart/ime-events.json`）
- 失败标记颜色定稿后的第11票：[stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[meta（原始产物已删除）](../../../README.md#已删除的材料)、[持久记录（原始产物已删除）](../../../README.md#已删除的材料)

原生第11票记录确认：同一 Run 先只有用户消息；失败后保存全部已接入正文且 `generation_status=error`，Run 状态为 `error`、code 为 `execution_failed`；真实原因含120行明细，支持滚动、复制与完整查看；保留下一条草稿；宿主退出并重新启动后，相同历史、错误原因和草稿仍可读取。失败 badge 的计算颜色断言也在最新原生单项通过。

## Python 静态检查

对本票四个 Python 辅助文件运行 `.venv/Scripts/ruff.exe`，repo cwd，均 exit 0：

- `ruff check tests/desktop_failure_fixtures.py frontend/src-tauri/tests/failure_partial_acceptance.py .scratch/frontend-completion/ticket-11/failure-final.py .scratch/frontend-completion/ticket-11/ime-diagnostic.py`：All checks passed。
- `ruff format --check` 对同四个文件：4 files already formatted。
- [Ruff check stdout/meta（原始产物已删除）](../../../README.md#已删除的材料)、[format stdout/meta（原始产物已删除）](../../../README.md#已删除的材料)。

## 覆盖边界

- 本轮原生独特用例集合为24项，完整顺序批次实际结果是22通过、2失败；后续只重跑了第11票和发生诊断的旧04，不把这些单项隔离结果合并宣称为24项全通过。
- 旧04在首轮失败、一次隔离诊断通过，根因与稳定性未确认；物理键盘和 Windows 系统 IME 候选面板不在此次 CDP 诊断覆盖内。
- 本票没有 Rust 产品变更，因此没有重复 Rust 编译或测试。后端完整回归由主 agent 在本原生 GUI 完全退出后串行执行。
