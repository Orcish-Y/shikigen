> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 17 票 Spec Review

固定点：编辑前备份 `.scratch/frontend-completion/ticket-17/baseline`；审查完整差异 `.scratch/frontend-completion/ticket-17/review.diff` 与候选文件清单。规格依据：第 17 票实施规格、PRD §16–17、`005-run-details.contract.md`。

## (a) 缺失或部分实现

无遗留 Spec finding。已复核修正：新 GET 观察在首帧前同步发布 pending 状态（`conversation-state.ts` 的 `createFrameReceiver`）；取消 pending/stale 用量时协调至多一次串行新快照，并防止取消前 GET 冒充取消后核实（`conversation-state.ts` 的 `snapshotRequest`；新增 `run-cancel.test.mjs` 覆盖）；UTC 复制保留服务端微秒（`RunDetails.tsx`）。

## (b) 范围外行为

未发现。后续第 18 票的运行事件 HTTP 查询／历史呈现和第 19 票的 5 秒、最多 12 次结算轮询不属于本票；它们未实现不记为缺失。

## (c) 表面实现但行为错误

无遗留项。真实累计用量、缺值与零区分、审批继续阶段重置结算确认、同 `updated_at` 晚到用量、取消终态及生命周期错误来源均与本票边界相符。

## 原生验收夹具静态核对

未见夹具掩盖产品错误或削弱原有验收。首次 GET 被 hold 时仍要求显示“正在读取用量”而非“暂无用量数据”；放行后仍断言未知用量、仍在结算及尚未结束。抽屉检查仍严格断言 400 CSS px，并记录 rect 与 DPR。Markdown 焦点检查断言 `2px solid var(--accent)` 与 3px offset 声明、计算颜色、`:focus-visible` 和焦点有效，并保留内容、关闭按钮、恢复焦点三组 computed-style 完整相等。仅去掉 DPI 量化下 computed width 必须字面等于 `2px` 的脆弱断言，设计声明与样式一致性仍受检；新增失败前记录样式便于诊断。

## 验证边界

本次静态 Spec review 未运行测试、构建或原生程序，不代表原生验收通过。截至收到的主 agent 进度，多模型、取消晚到用量、失败与旧工具、未知用量用例已实机通过；仅 Markdown 焦点用例仍在单项复验，不能计作通过，最终以指定测试子 agent 的证据报告为准。

结果：Spec 遗留 finding 0；范围外行为 0；错误实现 0。
