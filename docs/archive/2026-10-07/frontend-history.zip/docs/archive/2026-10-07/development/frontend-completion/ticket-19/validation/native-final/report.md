> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 19 最终原生取证报告

## 执行结果

- 模型：`gpt-6-luna`，推理强度 `max`。
- 工作目录：`C:\code\shikigen-agent`。
- 命令：

  ```powershell
  .venv/Scripts/python.exe .scratch/frontend-completion/ticket-19/native_runner.py --batch native-evidence-final-4 --tests test_twelve_real_time_reads_pause_and_manual_continue_in_summary_and_details test_recoverable_failures_stop_after_three_retries_and_manual_read_recovers
  ```

- UTC：2026-10-06 11:42:20.152 开始，11:43:54.797 结束，耗时 94.645 秒；runner 退出码 `0`。
- unittest 摘要：2 通过、0 失败、0 跳过；两项测试本身耗时 91.236 秒。
- runner 复用了既有 dist server，并报告 index 396 bytes、2 个 asset；未运行 `--regression`。

## 场景核对

### 12 次真实定时轮询、暂停与人工继续

`result.json` 有 2 个启动读取、12 个预算内自动读取，预算内 12 个相邻间隔为 **5012.4–5027.9ms**，均不小于 4800ms。结果还保存了暂停后打开详情和点击“继续核实”的各一次读取；测试断言手动继续只新增 1 GET。12 个定时读取的采集记录均带 `isPendingInjected=true`，其原始 `actualSnapshot.usage_pending` 均为 `false`，没有被注入标记污染。

实际后台最终快照为 `completed`、`usage_pending=false`，输入 15、输出 12、总计 27 tokens、2 次模型调用。测试通过了摘要暂停文案、详情结算文案与 14px 字号、手动继续后保存状态，以及关闭详情后的摘要状态断言。Tauri WebView CDP 的 `page_target` 为 `http://127.0.0.1:5173/`。

证据：`native/native-evidence-final-4/UsageSettlementAcceptance/test_twelve_real_time_reads_pause_and_manual_continue_in_summary_and_details/` 下的 `result.json`、`paused-summary.png`、`window.png`、`host-0.log`。

### 503 重试、暂停与人工恢复

采集到 4 个 503，三段自动重试间隔分别为 **1015.7ms、2016.4ms、5007.3ms**，对应 1/2/5 秒节奏。随后人工恢复恰好新增 1 GET。后台最终快照仍为 `completed`、`usage_pending=false`，输入 15、输出 12、总计 27 tokens、2 次模型调用；UI 显示已保存。Tauri WebView CDP 的 `page_target` 同为 `http://127.0.0.1:5173/`。

证据：`native/native-evidence-final-4/UsageSettlementAcceptance/test_recoverable_failures_stop_after_three_retries_and_manual_read_recovers/` 下的 `result.json`、`window.png`、`host-0.log`。

## 日志、历史失败与清理

stdout、stderr 和准确起止时间分别保存在本目录的 `native-evidence-final-4.stdout.log`、`native-evidence-final-4.stderr.log`、`start-time.txt`、`end-time.txt`；机器可读摘要为 [command-results.json（原始产物已删除）](../../../../../README.md#已删除的材料)。两个 `host-0.log` 在 WebView 关闭时各有一条 Chromium `Failed to unregister class Chrome_WidgetWin_0, Error=1412` 诊断；两个 host 均以 0 退出，runner 与两项断言均成功。

更早的 `native-evidence-final-2`（2 次尝试、19.934 秒）CDP 连接关闭，`native-evidence-final-3`（2 次尝试、66.472 秒）未找到目标 endpoint；这两批未产生通过证据，仍作为历史失败保留，不计入 final-4 的 2/2 通过，也没有在本报告覆盖或改算。

执行前 9238/45200 无监听；结束后这两个端口均无监听，`backend_window.exe` 已退出。5173 的既有 Python dist server（PID 23344）仍在运行，因为 runner 明确以 `SHARED_DIST_SERVER_MODE=reused` 复用它；本 agent 没有停止该共享进程。未运行完整测试套件、取消/events 场景、TypeScript/Vite、后端或 Ruff；这些不属于本次两个场景的复验范围。

