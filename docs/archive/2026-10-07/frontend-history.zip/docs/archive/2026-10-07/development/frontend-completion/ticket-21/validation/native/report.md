> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 21 原生验收报告（final-1 / final-2 / final-3）

## 最新结论：final-3 原生验收通过

测试子 agent 使用 GPT-6-Luna、推理强度 max。final-3 在真实装饰式 Windows Tauri 窗口中运行四项新用例：4 passed / 0 failed / 0 errors / 0 skipped，耗时 50.629s，进程退出码 0。此前 final-1 / final-2 失败记录和证据均保留。验收 agent 未修改产品代码、断言或测试，也未运行 Git 命令；本报告记录验证证据，不更新票据状态。

原生 stdout：validation/native/final-3-stdout.log；退出码：validation/native/final-3-exit-code.txt。auto-review 批准了本机原生运行。runner 校验 5173 返回的 index（396 bytes）和两个直接引用资源与本次 dist 完全一致。

final-3 cwd 为仓库根目录，使用临时 UV cache；未传 --tests，因此执行 runner 明确选择的全部四项：

      $env:UV_CACHE_DIR = Join-Path $env:TEMP 'ticket21-uv-cache'; uv run python .scratch/frontend-completion/ticket-21/native_runner.py --batch final-3 2>&1 | Tee-Object -FilePath .scratch/frontend-completion/ticket-21/validation/native/final-3-stdout.log; $nativeExitCode = $LASTEXITCODE; Set-Content -LiteralPath .scratch/frontend-completion/ticket-21/validation/native/final-3-exit-code.txt -Value $nativeExitCode; exit $nativeExitCode

final-4 前端最终检查由主 agent 核对原始日志和 meta：Node 255 pass / 0 fail / 0 skip/cancel（43.124s）；TypeScript 检查退出码 0，无诊断（237.938s）；Vite build 退出码 0（48.749s）。构建的 JS bundle 为 index-DGVwYAxd.js，635.70 kB，仍有 Vite 500 kB 提示；CSS 为 index-DRI4AevL.css。final-3 没有重跑 Node、tsc 或 build，直接验收主 agent 已验证的 dist。

Ruff check 与 format check 退出码均为 0，日志分别保存在 validation/native/final-3-ruff-check.log、final-3-ruff-format-check.log、final-3-ruff-prepare-review-check.log 和 final-3-ruff-prepare-review-format-check.log。前三文件检查了 responsive_navigation_acceptance.py、native_runner.py、window_acceptance.py；另按主 agent 指定补查 prepare_review.py。

## 七项验收条件覆盖

| 验收条件 | final-3 实际证据 |
| --- | --- |
| 1. 原稿视觉、颜色／字体层级、展开／收起比例与主按钮 hover | 对照查看 design/pic/展开.png、收起.png 与 Tauri 原生 1440 展开和 1440 折叠截图；稳定几何为展开 rail 256px、折叠 rail 64px、history 256px、应用栏 40px。白画布、Slate 面板、Indigo 选中／主操作；测量 Geist、角色 15px/22px、正文 14px/24px、头像 28px、间隔 12px。通过 CDP 鼠标移动检查主按钮 hover 色为 #4338CA。 |
| 2. 四档断点、尺寸与互斥侧栏 | 真实窗口 CSS 内容区 1440×900、1280×800、1024×768、390×844 全部精确达到；断点分别为 wide-desktop、compact-desktop、tablet、phone。导航为 256、64、64、无固定栏；history 为 256、256、被覆盖、被合并。平板与手机通过同一 dialog 切换导航／会话视图。 |
| 3. 菜单、桌面偏好、列表与焦点 | 首次默认和 resize 不写桌面偏好；桌面主动展开仅写 false，切换窄屏菜单无新增写入；Tauri 宿主真正重启后仍恢复偏好与含首尾空白的草稿。41 条 seed、筛选后 39 条会话；session list scrollTop=240 跨视图和回桌面后保留；阅读锚点 id/offset/scrollTop 不变，底部导航可滚动且头尾入口可达。测试还覆盖四个禁用项说明、Tab dialog 焦点约束、同一单前景和菜单替换为命令面板。 |
| 4. 消息主轴与排版规格 | 四档均记录 40px app bar、840px 消息主轴上限、28px 头像、12px gap、角色 15/22、正文 14/24；Tauri 外窗、client rect 与 DPI 都已记录。桌面主区白底、侧栏 Slate，原稿比例截图可复核。 |
| 5. 输入、长内容、完整查看及触控尺寸 | 四档初始 draft 为 48px；30 行草稿限制 180px 且内部滚动。窗口变窄时相同字符串使高度 48→96→48 并完整保留。本批实测长代码320px内部滚动；JSON复用相同`.content-block pre`规则，未额外运行全部JSON／工具分支。桌面 full-content 抽屉宽 400px，phone 为 390×675.20px（844px 高度的 80dvh），每次只开一个 dialog；tablet／phone 主操作触控高度 44px。 |
| 6. 状态、滚动、菜单和运行中行为 | 布局切换不额外 GET messages／POST stream／cancel；运行中 SSE、草稿和阅读锚点保留；取消确认打开时唯一 dialog 与初始焦点有效，关闭后没有 cancel 请求。切换菜单保留 filter、已加载页、scroll、草稿和阅读位置；命令面板替换菜单前景。真实托盘警告与公开 history HTTP 500 都占据布局，详情和侧栏 y 与 workspace 顶部同步，必要操作仍可达。 |
| 7. 原生窗口、DPI、演示交互与原稿对照 | 4 档均运行实际 backend_window.exe 和独立 SQLite fixture；每档保存工作区／长内容截图与 geometry JSON，并保存 1440 折叠、native-restart、menu-restored、tablet-short-navigation 和 history-500 截图。跑过 session 浏览、输入、完整内容、长代码／提示，以及运行中布局切换。外窗与 client rect 证明保留 OS 装饰，40px app bar 从 WebView client 内容区起算。截图通过 CSS 尺寸归一后与原稿展开／收起 PNG 核对。 |

### 四档原生尺寸与 DPI

| CSS 内容区 | 断点 | navigation / history | DPR / DPI | Win32 外窗 rect / client rect（物理 px） |
| --- | --- | --- | --- | --- |
| 1440×900 | wide-desktop | 256 / 256 | 2 / 192 | (0,49,2906,1920) / (0,0,2880,1800) |
| 1280×800 | compact-desktop | 64 / 256 | 2 / 192 | (0,49,2586,1720) / (0,0,2560,1600) |
| 1024×768 | tablet | 64 / overlay | 2 / 192 | (0,49,2074,1656) / (0,0,2048,1536) |
| 390×844 | phone | hidden / merged menu | 2 / 192 | (0,49,806,1808) / (0,0,780,1688) |

另加短窗口 1024×600：DPR 2 / DPI 192，外窗 rect (0,49,2074,1320)，client rect (0,0,2048,1200)。navigation scrollHeight=273、clientHeight=118、scrollTop=155、overflow-y=auto；头部 y=192.80、底部 footer bottom=599，命令按钮可见。截图证明长导航仍能滚动且头尾可达。

桌面详情抽屉实测：1440×900 为 400×860；1280×800 为 400×760；1024×768 为 400×728。手机完整查看为 390×675.20，满足 80dvh。四档工作区、完整查看和尺寸数据文件都在各 case 子目录。

### 原稿截图对照与逐项证据

我查看了 design/pic/展开.png、收起.png，以及 final-3 的 1440-workspace.png、1440-collapsed.png、1280-workspace.png、1024-workspace.png 和 390-full-content.png。原稿 PNG 使用约 1.5 倍像素尺寸；final-3 WebView 截图为 DPR 2。按 CSS 内容区归一后，展开／折叠导航 256／64px、history 256px、40px app bar、840px 消息中轴以及 Slate／白色／Indigo 系统符合设计稿与 frontend/design.md 的目标。测试中的真实会话文本替代原稿示例文字；WebView 截图不包含原生标题栏，但外窗和 client rect 均取自实际装饰窗口。

可核对的主要证据：

- final-3-stdout.log 与 final-3-exit-code.txt：四项完整原生输出及进程退出码。
- final-3-ruff-check.log、final-3-ruff-format-check.log、final-3-ruff-prepare-review-check.log、final-3-ruff-prepare-review-format-check.log：Ruff 输出。
- native/final-3/test_four_native_sizes_original_proportions_input_long_content_and_drawers/：1440、1280、1024、390 工作区／完整查看 PNG 与 JSON，1440-collapsed、result.json。
- native/final-3/test_only_desktop_choice_persists_through_native_restart_and_narrow_menus/native-restart.png 与 result.json：宿主重启证据。
- native/final-3/test_menu_preserves_filter_pages_scroll_reading_and_single_foreground_focus/menu-restored.png 与 result.json：列表、阅读位置、请求数量和视图返回证据。
- native/final-3/test_active_stream_layout_does_not_reconnect_cancel_or_hide_required_controls/tablet-short-navigation.png、active-and-read-failure.png 与 result.json：短导航、运行中 SSE、托盘警告和 500 提示证据。

运行后复查 9238、45200、5173 均无监听，backend_window.exe 无遗留进程；runner 清理了本批拥有的宿主和服务。四个 final-3 case 都保存 result.json，无 failure.json。

尚未由这四项自动用例验证：物理键盘／IME 候选行为、真实 OS clipboard 读写，以及原生标题栏外观细节；后续联合流程仍可覆盖。以上是证据边界，不改变票据状态。

## 旧批次记录

下面保留 final-1 和 final-2 的运行历史。它们在修正环境／测量／seed 夹具前执行，不代表 final-3 的结果。

## 构建与运行记录

- 构建 cwd：frontend
- 构建命令：

      node node_modules/vite/bin/vite.js build

- 构建退出码：0；Vite 7.3.6，4889 modules；frontend/dist/assets/index-TRMi8t4T.js 635.52 kB，仍有大于 500 kB 的提示。
- 构建日志：validation/native/final-2-build.log
- 构建退出码文件：validation/native/final-2-build-exit-code.txt

final-1 原生命令（cwd：仓库根目录）：

      $env:UV_CACHE_DIR = Join-Path $env:TEMP 'ticket21-uv-cache'; uv run python .scratch/frontend-completion/ticket-21/native_runner.py --batch final-1

结果：Ran 4 tests in 134.863s；4 项均在等待 CDP /json/list page endpoint 时超时。四个 case 目录都有 host-0.log（0 bytes），无已连接的 WebSocket，因此 EvidenceResult 没有创建 failure.json/window.png/result.json。运行前 9238、45200、5173 均空闲，backend_window.exe 存在；runner 后来复用与当前 dist 逐字节匹配的 5173 服务。stdout 未通过 Tee 捕获；validation/native/final-1-stdout.log 是依据每个工具返回 chunk 整理的完整输出，非原始字节流。未重复覆盖该 batch。

final-2 原生命令（cwd：仓库根目录；经 auto-review 批准的本机执行）：

      $env:UV_CACHE_DIR = Join-Path $env:TEMP 'ticket21-uv-cache'; uv run python .scratch/frontend-completion/ticket-21/native_runner.py --batch final-2

stdout 通过 Tee-Object 保存至 validation/native/final-2-stdout.log；进程退出码 1 保存至 validation/native/final-2-exit-code.txt。runner 显示 SHARED_DIST_SERVER_MODE=reused，并核对 index 396 bytes、2 个引用资源与当前 dist 完全相同。

## final-2 结果（历史）

| 原生用例 | 结果 | 实际范围与失败点 |
| --- | --- | --- |
| test_four_native_sizes_original_proportions_input_long_content_and_drawers | FAIL | 1440×900 的首档布局、字体、长输入、代码区和 400px 桌面完整查看抽屉均先通过。切到 1280×800 时，rail 读到 69.9609375px，断言 64px 失败；1024、390 未到达。 |
| test_only_desktop_choice_persists_through_native_restart_and_narrow_menus | FAIL | 桌面主动选择写入 false、窄屏菜单切换不追加写入、单前景 dialog 与关闭后焦点检查均已走过。返回桌面时读到 rail 244.140625px，断言 256px 失败；宿主重启后的偏好／草稿恢复未执行。 |
| test_menu_preserves_filter_pages_scroll_reading_and_single_foreground_focus | FAIL | 初始化阶段等待空数据库文案超时，目标菜单保留流程没有执行。已有 41 条 seed 会话使宿主自动选中会话，不符合旧 start_empty 对空数据库文案的假设；主 agent 已更新夹具等待真实列表后显式新建。 |
| test_active_stream_layout_does_not_reconnect_cancel_or_hide_required_controls | PASS | 实际 running SSE 下切换 1024／390／1440，手机与平板切换菜单视图，检查草稿、阅读锚点、运行取消确认和请求基线；触发真实 missing-tray-icon 宿主警告和公开历史 HTTP 500；提示占位、窄屏无横溢、长草稿及主要操作可达均通过。 |

前两项的宽度失败是动画取样时序：断点状态更新后测试仅等待约 100ms，而 frontend/design.md 第 9 节记录 Grid 过渡为 160ms。69.96px 和 244.14px 是中间帧。主 agent 正将窗口测量改为等待动画完成，并保留精确的 64／256px 断言。

## final-2 几何与截图（历史）

1440×900 原生内容区报告 devicePixelRatio=2、native_dpi=192。首档快照记录：应用栏 40px；navigation/history 各 256px；chat 区 928px；消息与 composer 中轴最大 840px；头像 28px；message gap 12px；角色 15px/22px；正文 14px/24px；草稿初始 48px。首档 400px 桌面抽屉和长输入断言通过。

可核对证据：

- native/final-2/test_four_native_sizes_original_proportions_input_long_content_and_drawers/1440-workspace.json
- native/final-2/test_four_native_sizes_original_proportions_input_long_content_and_drawers/1440-workspace.png
- native/final-2/test_four_native_sizes_original_proportions_input_long_content_and_drawers/1440-full-content.json
- native/final-2/test_four_native_sizes_original_proportions_input_long_content_and_drawers/1440-full-content.png
- native/final-2/test_four_native_sizes_original_proportions_input_long_content_and_drawers/failure.json
- native/final-2/test_four_native_sizes_original_proportions_input_long_content_and_drawers/window.png

我对照查看了 design/pic/展开.png 和 design/pic/收起.png。1440 展开态实际快照的 256 + 256 + 840 CSS px 比例及 40px 应用栏符合设计基准；当前 batch 未产生稳定的 64px 折叠态截图。

active-stream PASS 的截图显示手机 390×844、DPR 2：workspace.y=106.59，其间包含 40px 应用栏和真实托盘故障提示；通知高度 180px（内容 scrollHeight 217px），draft 高 180px（scrollHeight 720px），主要按钮 44px 且 bottom=775px，document width=390px。证据为：

- native/final-2/test_active_stream_layout_does_not_reconnect_cancel_or_hide_required_controls/result.json
- native/final-2/test_active_stream_layout_does_not_reconnect_cancel_or_hide_required_controls/active-and-read-failure.png
- native/final-2/test_active_stream_layout_does_not_reconnect_cancel_or_hide_required_controls/window.png

失败项截图和页面正文捕获位于各自 case 子目录的 failure.json 与 window.png；运行日志 host-0.log 为空属于该 Tauri 示例宿主的现状，不作为失败原因证据。

## final-2 当时未完成的覆盖

- 稳定测量 1280 下 64px rail、1024 互斥覆盖、390 单菜单及 1440 折叠态。
- 修正 seed 会话后的分页、过滤、列表滚动位置、阅读锚点与命令替换流程。
- native restart 后桌面偏好和消息草稿恢复。
- phone 80dvh 完整查看抽屉及折叠主导航截图。
- 物理键盘 IME、OS clipboard 和原生标题栏外观未由这四项自动用例覆盖；完整联合流程仍由后续综合验收负责。
- final-2 的 254 项 Node、TypeScript 与完整构建结果没有在此重新执行；主 agent 交接时报告已有 254 pass / 0 fail / 0 skip/cancel，tsc 与 build 已通过，本报告另记录了 CSS 调整后的 Vite build 通过。

final-1、final-2、final-3 三个 batch 与证据目录均保留；没有执行或修改票据状态。
