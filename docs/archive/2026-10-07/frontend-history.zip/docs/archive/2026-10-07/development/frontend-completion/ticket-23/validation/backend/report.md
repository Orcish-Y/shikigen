> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第23票后端回归验证报告

- 模型：`gpt-6-luna`，推理强度 `max`
- 环境：Windows PowerShell，工作目录 `C:\code\shikigen-agent`，Python 3.12.13、Ruff 0.16.0、ty 0.0.83
- 验证范围：仓库完整后端 `unittest`、全仓 Python Ruff check/format 检查、项目既有产品类型检查
- 职责边界：未运行 Git 命令，未修改产品代码、测试或断言；验证材料仅写入 `.scratch/frontend-completion/ticket-23/validation/`

## 后端完整回归

命令：

```powershell
.venv/Scripts/python.exe -m unittest discover -s tests -v
```

- 退出码：`0`
- unittest：334 项，333 通过、0 失败、0错误、1跳过；耗时 543.229 秒
- 命令实测总时长：557.248 秒
- 唯一跳过：`RuntimeDataTests.test_symlink_data_and_parent_are_rejected`，Windows 未提供符号链接权限
- 审批恢复3秒结算正式用例 `test_waits_for_previous_cleanup_and_survives_caller_cancellation` 与空环境退出正式用例 `test_environment_loaded_before_config_without_overriding_host` 本次均为 `ok`。两个历史问题仍为 `needs-triage`；本次通过不证明根因已解决，也不覆盖历史失败。
- 原生 IME 间歇问题不在本次 Python 后端套件范围内，未验证。

日志与机器可读命令结果：[`unittest.stderr.txt`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`unittest.result.json`（原始产物已删除）](../../../../../README.md#已删除的材料)。

## Ruff 全仓扫描

使用当前仓库 Ruff 配置执行以下两条命令：

```powershell
.venv/Scripts/python.exe -m ruff check .
.venv/Scripts/python.exe -m ruff format --check .
```

- `ruff check .`：退出码 `1`，379 项诊断，57 项可由 `--fix` 修复；其中 `.scratch/` 365 项、`frontend/` 11 项、`packages/` 3 项，分布在70个文件。未应用修复。
- `ruff format --check .`：退出码 `1`，753个 Python 文件中64个需格式化、689个已格式化。未改写文件。
- 这两项是启动本报告验证时的全仓快照，扫描到正在编写的第23票 runner 文件。主 agent 后续修改了这些文件，因此该快照不代表最终源码状态；不会把它宣称为当前最终全仓基线，也未为通过检查而修改文件。

原始输出和结果：[`ruff-check.stdout.txt`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`ruff-check.result.json`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`ruff-format.stdout.txt`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`ruff-format.result.json`（原始产物已删除）](../../../../../README.md#已删除的材料)。

### 当前票据文件专项 Ruff

主 agent 完成格式化及窗口激活辅助函数更新后，对当前票据相关的13个 Python 文件执行：

```powershell
.venv/Scripts/python.exe -m ruff check .scratch/frontend-completion/ticket-23/prepare_review.py .scratch/frontend-completion/ticket-23/native_runner.py .scratch/frontend-completion/ticket-23/live_runner.py .scratch/frontend-completion/ticket-23/production_runner.py frontend/src-tauri/tests/native_workflow_acceptance.py frontend/src-tauri/tests/native_acceptance.py frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/pagination_acceptance.py frontend/src-tauri/tests/workspace_file_open_acceptance.py frontend/src-tauri/tests/run_details_acceptance.py frontend/src-tauri/tests/conversation_export_acceptance.py frontend/src-tauri/tests/stream_recovery_acceptance.py frontend/src-tauri/tests/window_acceptance.py
.venv/Scripts/python.exe -m ruff format --check .scratch/frontend-completion/ticket-23/prepare_review.py .scratch/frontend-completion/ticket-23/native_runner.py .scratch/frontend-completion/ticket-23/live_runner.py .scratch/frontend-completion/ticket-23/production_runner.py frontend/src-tauri/tests/native_workflow_acceptance.py frontend/src-tauri/tests/native_acceptance.py frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/pagination_acceptance.py frontend/src-tauri/tests/workspace_file_open_acceptance.py frontend/src-tauri/tests/run_details_acceptance.py frontend/src-tauri/tests/conversation_export_acceptance.py frontend/src-tauri/tests/stream_recovery_acceptance.py frontend/src-tauri/tests/window_acceptance.py
```

- 两条命令均退出码 `0`，分别耗时 `0.286` 秒和 `0.189` 秒。
- 主 agent 随后更新了 `production_runner.py` 的托盘窗口恢复验收。对此最新文件另补 Ruff check 与 format --check，均退出码 `0`，分别耗时 `0.206` 秒与 `0.223` 秒。
- 这证明当前列出的13个文件及最新 `production_runner.py` 通过专项 Ruff；没有重新扫描全仓，也不覆盖其他 Python 文件。
- 13文件日志和结果：[`ruff-check.stdout.txt`（原始产物已删除）（原始产物已删除）](../../../../../README.md#已删除的材料)。
## 类型检查与 CLI 静态导入

- 产品源码类型检查：`.venv/Scripts/python.exe -m ty check app packages/harness/shikigen`，退出码 `0`，耗时 2.487 秒。范围遵循既有第18票标准，不包含全量测试目录。
- Runner 清单：`.venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch validation-preflight --list`，退出码 `0`，列出105个唯一用例；没有启动原生程序。
- 在线 runner 帮助：`.venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/live_runner.py --help`，退出码 `0`；仅完成模块导入和帮助输出，没有启动原生程序或模型任务。

类型与 CLI 输出、命令结果见 [`ty-check.stdout.txt`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`ty-check.result.json`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`native-list.stdout.txt`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`native-list.result.json`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`live-help.stdout.txt`（原始产物已删除）](../../../../../README.md#已删除的材料)、[`live-help.result.json`（原始产物已删除）](../../../../../README.md#已删除的材料)。

工具版本记录见 [`toolchain.txt`（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 后续检查

主 agent 后续修正了 runner 和若干验收入口；全仓 Ruff 快照因此保留为早期记录。当前13个票据相关文件及最新 production_runner.py 已专项通过 Ruff；全仓最终扫描未执行。
