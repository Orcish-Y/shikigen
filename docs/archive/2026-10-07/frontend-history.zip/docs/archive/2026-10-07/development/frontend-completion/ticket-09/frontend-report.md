> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 09 前端 / Rust 验证报告

- 执行模型：`gpt-6-luna`，推理强度 `max`
- 日期：2026-10-05
- 仓库基点：`eceb02064c0c77d18ac68e651e3dc84ffe21797d`
- 范围：按 A 分工完成前端单测、TypeScript 检查、前端构建、Tauri Rust 测试、格式检查和 `backend_window` 示例构建。

## 结果

| 命令 | 工作目录 | 结果 |
| --- | --- | --- |
| `pnpm.exe test` | `frontend` | 121 通过，0 失败，0 跳过；exit 0 |
| `node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json` | `frontend` | exit 0；无诊断输出 |
| `pnpm.exe build` | `frontend` | exit 0；Vite 生成 `frontend/dist` |
| `cargo test` | `frontend/src-tauri` | 25 通过，0 失败，0 ignored；exit 0 |
| `cargo fmt --check` | `frontend/src-tauri` | exit 0 |
| `cargo build --example backend_window` | `frontend/src-tauri` | exit 0 |

未发现失败命令。`cargo test` 报告中包含 0-test 二进制/doc-test 目标；汇总计数按所有目标相加为 25 passed、0 failed、0 ignored。

## 构建产物

- [frontend-ready.json（原始产物已删除）](../../../README.md#已删除的材料) 列出 `frontend/dist` 的 38 个文件及各自大小、SHA-256，并记录 `index.html` 直接引用资源与 `backend_window.exe` 的构建结果和 SHA-256。
- `backend_window.exe`：`frontend/src-tauri/target/debug/examples/backend_window.exe`，16,075,776 bytes，SHA-256 `fed92aa9da7c6e46c34fdc3e59db59e8fe5735acc0aecfca50272285338a95ca`。

## 警告

- Vite 提示单个压缩前 JS chunk 大于 500 kB；本次生成的 `index-KXbcsP2Z.js` 为 540.94 kB。构建仍成功。
- Rust MSVC linker 输出创建 import library/object 的消息，并由 `shikigen-desktop` 报出一个 `linker_messages` warning；测试与示例构建均成功。

## 日志与退出码

每条命令的 stdout、stderr、exit 和运行元数据均保存在 [logs（原始产物已删除）](../../../README.md#已删除的材料)：

| 命令 | stdout | stderr | exit |
| --- | --- | --- | --- |
| `pnpm.exe test` | [stdout（原始产物已删除）](../../../README.md#已删除的材料) | [stderr（原始产物已删除）](../../../README.md#已删除的材料) | [exit（原始产物已删除）](../../../README.md#已删除的材料) |
| TypeScript 检查 | [stdout（原始产物已删除）](../../../README.md#已删除的材料) | [stderr（原始产物已删除）](../../../README.md#已删除的材料) | [exit（原始产物已删除）](../../../README.md#已删除的材料) |
| `pnpm.exe build` | [stdout（原始产物已删除）](../../../README.md#已删除的材料) | [stderr（原始产物已删除）](../../../README.md#已删除的材料) | [exit（原始产物已删除）](../../../README.md#已删除的材料) |
| `cargo test` | [stdout（原始产物已删除）](../../../README.md#已删除的材料) | [stderr（原始产物已删除）](../../../README.md#已删除的材料) | [exit（原始产物已删除）](../../../README.md#已删除的材料) |
| `cargo fmt --check` | [stdout（原始产物已删除）](../../../README.md#已删除的材料) | [stderr（原始产物已删除）](../../../README.md#已删除的材料) | [exit（原始产物已删除）](../../../README.md#已删除的材料) |
| `cargo build --example backend_window` | [stdout（原始产物已删除）](../../../README.md#已删除的材料) | [stderr（原始产物已删除）](../../../README.md#已删除的材料) | [exit（原始产物已删除）](../../../README.md#已删除的材料) |

## 覆盖范围

首轮前端／Rust分工没有运行原生 WebView 验收或 Python 后端回归；其他分工的实际结果分别见原生与后端报告。原生验证方收到 `frontend-ready.json` 后按清单校验产物。本分工不包含物理键盘、系统 IME 或软键盘实机检查。
## sameFact 修正增量复核（2026-10-05）

主 agent 修正了事实比较：chat reading content 改用 RunProjection.sameFact 比较只读事实结构，避免 JSON.stringify 将对象键顺序变化误判为新内容。第五项 chat-reading-position 测试先 RED（true != false），修复后本轮 GREEN。

- 定向 Node 测试：52 通过，0 失败，0 跳过；exit 0。实际运行四个文件：chat-reading-position、message-drafts、tool-records、run-reconstruction。
- tests/run-projection.test.mjs 不存在；rg --files frontend/tests 找到 run-reconstruction.test.mjs。该文件通过 ConversationStore 回放覆盖 RunProjection 路径，因此用作指定 projection 覆盖的现有替代项。
- TypeScript 检查 exit 0；pnpm.exe build exit 0。没有重复运行初批全套 121 项，也没有重跑 Rust 25 项。
- 本轮增量是 52 项定向重叠测试；报告为“初批全套 121 + 本轮定向 52”，不将其合并声称为全套 122 项。
- frontend-ready.json 已更新为本次 dist 的精确 38 文件大小/SHA-256；frontend-ready.initial.json 保留同票首轮构建清单。
- Vite 仍提示一个 minified JS chunk 大于 500 kB。原生 agent 收到新清单后可重跑 09 专项以及主 agent指定的受影响 07/08 回归。

日志前缀为 frontend-incremental-，包括 Node 测试、TypeScript、pnpm build 各自的 stdout、stderr、exit 和 meta 文件。
## 最终 sameFact 增量复核（2026-10-05）

根因修正后新增第六项 chat-reading-position 测试。本轮按要求没有重跑 121 项全套或 25 项 Rust 测试。

- 定向 Node 命令运行 chat-reading-position、message-drafts、tool-records、run-reconstruction 四个文件：53 通过，0 失败，0 跳过；exit 0。
- TypeScript 检查 exit 0；pnpm.exe build exit 0。四个文件中没有 run-projection.test.mjs；使用 rg 找到的 run-reconstruction.test.mjs 作为现有 RunProjection 回放覆盖。
- 当前报告保留首轮全套 121/121，并分别记录之前的定向 52/52 和本轮定向 53/53；重叠选择测试不相加冒称新的完整套件数。
- frontend-ready.json 已刷新为本次 build 的 38 个 dist 文件与 index 引用资源大小/SHA-256；frontend-ready.previous.json 保留 build 前快照。
- Vite 仍提示 minified JS chunk 大于 500 kB。完整 stdout、stderr、exit 和 meta 文件使用 frontend-final-* 前缀。

## 最终 history-gate 增量复核（2026-10-05）

根因复核发现缺锚点 fallback 需要等待历史重建真正结束。应用当前在 history ready、verified 且 observation idle/closed 时才将缺失目标视为失效；等待期间已有锚点仍可定位。第七项回归先因缺少导出失败，再经主 agent 修复通过。

- 定向 Node 测试运行四个指定文件：54 通过，0 失败，0 跳过；exit 0。
- TypeScript 检查 exit 0；pnpm.exe build exit 0。
- 未重跑完整 121 项、之前的 52/53 项、Rust 25 项或后端 291 项。报告保留各批实际数量，不把重叠定向测试相加为全套数量。
- frontend-ready.json 已刷新为本次构建的 38 项 dist 和 index 引用资源大小/SHA-256；frontend-ready.pre-history-gate.json 保存变更前清单。
- Vite 仍提示 minified JS chunk 大于 500 kB。全部命令日志使用 frontend-history-gate-* 前缀。

## 布局竞态修复增量复核（2026-10-05）

主 agent 针对 ResizeObserver 与浏览器 scroll clamp 的先后竞态修正了 layout-change 与滚动意图判别。当前构建对应该修正，前端定向验证结果为：

- Node 定向测试：55 通过，0 失败，0 跳过；运行 chat-reading-position、message-drafts、tool-records、run-reconstruction 四文件。
- TypeScript 检查 exit 0；pnpm.exe build exit 0。
- 未重跑 121 项全套、52/53/54 既有重叠批次、Rust 25 项或后端291项。计数按实际批次独立报告，不相加。
- frontend-ready.json 已刷新为本次 build 的 38 个 dist 文件及 index 引用资源精确大小/SHA-256；frontend-ready.pre-layout.json 保存 build 前清单。
- Vite 保留单个 minified JS chunk 大于 500 kB 的 warning。日志前缀 frontend-layout-final-*。

## 最终冻结构建增量复核（2026-10-05）

主 agent 最终冻结了布局更新门槛与手势资格修正，并增强原生代码块滚动夹具。本轮使用冻结后的前端产物：

- 定向 Node 测试 55 通过、0 失败、0 跳过；tsc 与 pnpm.exe build 均 exit 0。
- 只运行四个定向文件；没有重复首轮完整 121 项、Rust 25 项或 Python 后端 291 项。
- ready 清单更新为本轮 dist，38 个文件及 index 引用资源均带大小和 SHA-256；frontend-ready.pre-final-freeze.json 保留本轮构建前清单。
- 日志使用 frontend-final-freeze-* 前缀。Vite 的 >500 kB chunk warning 仍存在，未影响构建。

## controls-fix 定向增量复核（2026-10-05）

主 agent 修正了“回到底部”意图与阅读条显隐引起的自身视口变化之间的识别。最终 build 对应该修正：

- 指定四个前端测试文件 55 通过、0 失败、0 跳过；tsc 与 pnpm.exe build 均 exit 0。
- 没有重复完整 121 项、之前的 52/53/54/55 定向批次、Rust 或后端套件。
- frontend-ready.json 更新为最终构建的 dist/index SHA-256；frontend-ready.pre-controls-fix.json 保留冻结前快照。
- stdout、stderr、exit、meta 使用 frontend-controls-fix-* 前缀；Vite >500 kB chunk warning 仍在。


## 最终 late-scroll 冻结增量复核（2026-10-05）

针对最终冻结代码，只重跑第 09 票涉及的四个 Node 测试文件、TypeScript 检查和前端构建；本批最终证据如下：

| 检查 | 实际命令 / 工作目录 | 结果 |
| --- | --- | --- |
| Node 定向测试 | `node --import tsx --test tests/chat-reading-position.test.mjs tests/message-drafts.test.mjs tests/tool-records.test.mjs tests/run-reconstruction.test.mjs`；`frontend` | 56 通过、0 失败、0 跳过；exit 0，约 15.7 秒 |
| TypeScript | `node node_modules/typescript/bin/tsc --noEmit -p tsconfig.json`；`frontend` | exit 0，无诊断输出 |
| Vite 构建 | `pnpm.exe build`；`frontend` | exit 0，生成 `frontend/dist` |

完整日志分别为 Node 的 [stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[exit（原始产物已删除）](../../../README.md#已删除的材料)，TypeScript 的 [stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[exit（原始产物已删除）](../../../README.md#已删除的材料)，构建的 [stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[exit（原始产物已删除）](../../../README.md#已删除的材料)。准确时间和命令见各自 `frontend-late-scroll-*.meta.txt`。

最终 [frontend-ready.json（原始产物已删除）](../../../README.md#已删除的材料) 于 17:15:48 生成，记录 38 个 dist 文件的大小与 SHA-256，前端构建 exit 0；原生最终预检又核对本地 dist 与 5173 服务 HTTP 响应 38/38 匹配。TypeScript 与定向 Node 检查先于该构建完成。Vite 仍提示单个 minified JS chunk 大于 500 kB，构建成功。此次未重跑完整 121 项前端套件、Rust 25 项或后端 291 项；Rust／后端没有本票最后一轮产品改动。
