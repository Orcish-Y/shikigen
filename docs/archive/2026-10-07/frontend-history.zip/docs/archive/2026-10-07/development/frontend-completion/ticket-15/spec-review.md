> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Spec 轴复审

> 主 agent 收尾补充：以下“待执行／待复验”描述是源码复审时的状态。后续轻量测试 agent 已完成最新Node15项及当前构建分批11个唯一原生用例，均有通过日志；审查本身仍是静态结论，不冒充测试执行。详见[最终实施与验证报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/report.md`）。

## 初审记录与关闭状态

1. **已关闭（源码）**：原确认仅按路径关联消息。当前 `App.tsx:83-86, 104-120, 416-420` 以会话／消息／内容块身份和原引用核对准备、观察及确认；图片与完整详情贯穿同一身份。依据“确认时核对原会话、消息和引用仍是当前目标”([契约:185](../../../../../wayfinder/frontend-completion/tickets/004-message-tools-export.contract.md#L185))。新增原消息替换原生验收待执行。
2. **已关闭（源码）**：`Overlay.tsx:27-35` 在 DOM 更新后恢复仍有效焦点，否则聚焦 `.chat-workspace` 或可聚焦的 `.backend-screen`，且不抢新模态。新真实后端失败焦点验收待执行。依据原句“关闭后返回有效入口或稳定工作区”([契约:188](../../../../../wayfinder/frontend-completion/tickets/004-message-tools-export.contract.md#L188))。
3. **已关闭（源码；新断言待复验）**：共享 `WorkspaceFileButton`（`WorkspaceFileOpen.tsx:28-34`）对尾斜线目录显示“目录引用暂不支持打开（只读）”，覆盖普通链接、Markdown 图片和完整图片详情。无尾斜线但实际为目录时，准备错误态且无 intent 显示“本次准备未打开文件，当前引用只读。”；同时保留实际 HTTP 错误与原引用复制，错误态无“确认打开”按钮，只能关闭或手动重新准备。依据“未知协议与目录打开保持只读说明”([票据:23](../../../../../wayfinder/frontend-completion/implementation/15-workspace-file-open.md#L23))和“目录引用提示暂不支持文件打开”([契约:149](../../../../../wayfinder/frontend-completion/tickets/004-message-tools-export.contract.md#L149))。重新准备只是再次核实；若磁盘目标已变成普通文件，仍进入新确认，不会静默打开。无残余目录 UX 或安全缺口。

## 派发与关闭边界

`workspace_file_open.rs:319-340` 在 ledger 锁内完成租约、代次、有效期及目标版本末次核验，随后释放锁再调用可能等待 UI 主线程的 Tauri／OS callback。这样隐藏或关闭可独立失效其他意图，不会因 `is_visible()` 主线程往返和 ledger 互锁。若关闭发生在末次授权之前会拒绝派发；末次授权后 callback 已进入派发阶段，关闭不能承诺撤销 OS 请求。这是与一次性意图及“发出打开后防重复”一致的窄并发界限，记为已说明风险，不列硬规格缺口。若产品要求关闭在 opener 实际调用前任何时刻都能撤销，则需另定不阻塞主线程的派发取消协议。

## 范围与验证界限

未见与 ticket 15 无关的 scope creep；未知协议保持只读，Agent 明确链接／图片才可走受控入口，文件权限仍限定于主窗口、当前工作目录和一次性确认。源码审查未发现硬规格缺口。Rust 当前专项 10 项、check、fmt 已由主 agent 报告通过；本次只读文案改动后的前端 Node 15 项、TSC、build 和两项原生 smoke 仍待轻量 agent 验证，当前 native final-2 也仍在运行，均不计通过。此前 Node 21/TSC 与基于旧 dist 的原生 11 项（9 通过、2 失败）是旧源码／旧构建证据；本审查未运行测试。
