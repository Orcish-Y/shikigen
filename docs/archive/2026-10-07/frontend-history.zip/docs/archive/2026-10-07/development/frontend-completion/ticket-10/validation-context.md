> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 10 票验证交接

## 最终冻结补充

收尾状态：第 10 票已验收，全部 8 条核心条件关闭。最终显式 `gpt-6-luna / max` 验证结果为后端专项 10 通过、串行完整 301 项（300 通过、0 失败／错误、1 Windows 符号链接环境跳过）、前端 Node 134 通过、原生 Tauri 单个 runner 串行 4＋19＝23 个唯一用例通过；最终 TypeScript／构建／Ruff 11 文件／产品和测试范围 ty 通过。原始日志、截图与最新范围见 [report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-10/report.md`）。下面各段记录开发及派发当时状态；较早全套与隔离二的审批超时保留 needs-triage，不能用最终通过覆盖历史失败。

2026-10-05 最终增量：Spec 审查发现取消发生在首事件之前时尚未创建预览 state；已统一先创建同 Run state 并持锁取消。第 10 个公开竞态用例修复前红、修复后绿，后端专项 10/10。最新完整回归 final5 共 301 项，299 通过、1 错误、1 Windows 符号链接权限跳过；错误为已记录的审批恢复结算测试在第 258 行等待 3 秒超时，尚未确认根因，不能记为全套通过。原生全部结束后再隔离复现、串行完整回归。

原生第一次 23 项为 14 通过、8 失败、1 错误；第二次为 19 通过、4 失败。修复测试注入时机、真实 stream 事件入口、完整内容块断言和按钮启用等待，未删除或放宽行为断言。第 6 票请求计数改为精确 Thread messages 与 Run messages 各一次。第二次旧 03–08 共 16 项通过；第 9 票三个 Home 操作用例仍失败，新增第 10 票首项在发送入口出现 Failed to fetch，未进入取消阶段。

主 agent 已修复原生 Home 被应用回写打断的问题：chat-reading-position.ts 的同一布局比较容忍 0.5 CSS px 内的锚点抖动；useChatReading.ts 不写近似相等的 scrollTop。新增 1/64 px 抖动及真实 1 px 位移 Node 回归，修复前失败。测试子 agent 在修复后完成前端全套 134/134；最终 tsc/build 和全 23 项原生等待结果。新增改动文件还包括两个阅读位置源文件、Node 测试，以及两个既有原生测试文件。最终 Ruff 范围共 11 个 Python 文件；原生端口与后端完整回归按串行顺序执行。

追加验证（产品代码不变）：后端专项新增第 9 项 `test_completion_barrier_seals_before_queued_delta_can_mutate_facts`，正常完成结算事务持锁期间排队 delta，提交后不得新增消息事实。测试 agent 将跑 9 专项及最终 300 项完整单测（预计 1 Windows 符号链接环境跳过），final4 证据独立保留；此前 299 项结果仍为真实历史结果。Standards 独立审查无硬违规，1 项终态集合重复的维护启发式；Spec 与原生结果待核对。

后端正文缓冲改为按 `(thread_id, run_id)` 持有，暂停 invocation 回收及结算回滚不丢正文；正常结算也在同一预览锁内提交，终态后封口，成功回收时释放已封口状态。新增暂停后取消回滚重试、取消事务屏障与迟到 delta/快照两个专项，总计 8 项。开发检查新增两项通过，但模拟旧库的 sqlite 连接未关闭导致一项 teardown 失败；已用 closing 修复并分割长 SQL，须由最终测试确认。测试字段 self.run 已改 self.run_id，避免覆盖 unittest.TestCase.run。产品类型检查的仓库既有有效范围为 `ty check app packages/harness`；默认根目录检查曾失败 474 个诊断，主要扫描历史 scratch 脚本，原日志保留，不能称全仓类型通过。

前端最终新增 components/ContentViewer.tsx、MessageBody.tsx 改动：保留 preview 身份与复制当前片段的语义，单独用 generating=false 停止终态生成光标，提示尚未读取保存事实，避免读失败时把预览当作已提交记录。测试子 agent 已在这些最终前端源代码上完成 Node 全套 133 通过、tsc 与 build 通过。原生 4+19 项等待最终冻结后执行；已有窗口/服务必须按原限制保留。

主 agent 实现、测试子 agent 显式使用 gpt-6-luna / max。仓库 C:/code/shikigen-agent；PowerShell；基准 d7862fb50a7c5654661ca6d8967195d863c2d80e；开始工作区干净。不得操作 git、修改 AGENTS.md、旧票证据或产品代码，失败报告主 agent 修复。

目标：docs/wayfinder/frontend-completion/implementation/10-cancel-partial-message.md 全部八条验收；完整规格 .scratch/frontend-completion/PRD.md 第 10–11 节；frontend/design.md 取消确认沿用既有 dialog、危险色和焦点。1–9 已完成，11 的执行失败正文保存和 12 的正式审批 UI 待实施。

实现：AIContent 默认 complete，新事实显式 generation_status；幂等比较旧缺省 complete。RunEventIngestor 在预览锁内冻结正文；RunTransitions.cancel_run 在一个持久事务保存原身份/预留 seq 的所有非空正文、必要审批 invalidated 和 cancelled 生命周期/状态。提交后封口、广播、协作停止；回滚保留缓冲和运行句柄，迟到根快照不覆盖封存正文或在下一 Run 重归属。正常消息先提交保留 complete。

前端：BackendSession.cancel/runMessages；ConversationStore 共享同 Run 写 pending，取消目标含会话、Run 与地址租约，有效终态立即结束 pending，失败/协议问题只 GET 有限恢复（1/2/5秒，最多3次恢复，遵守 Retry-After）和手动核实。确认终态时一次 Run messages 补读，重复通知去重，失败保留预览/终态，可手动读取。运行中底部取消；审批卡片取消。Overlay 默认聚焦继续运行，Esc/关闭/遮罩零 POST；切换/隐藏/失效关闭，确认瞬间重核。正文外因取消中止标记；终态预览停止生成光标；现有导出排除预览。

改动范围：packages/harness/shikigen/contracts/messages.py；persistence/chat_store.py、event_store.py；runtime/run_events.py、run_execution.py、runs.py；frontend/src/backend-client.ts、run-protocol.ts、run-projection.ts、conversation-state.ts、useConversations.ts、App.tsx、components/Overlay.tsx、Conversation.tsx、styles.css；tests/test_cancel_partial_message.py；frontend/tests/run-cancel.test.mjs。原生测试和夹具待主 agent 添加。无 Rust 产品代码、依赖改动。

开发检查：首条后端测试红（取消未保存正文），实现后绿；首条前端测试红（缺少 cancelTarget），实现后绿。后端首次5项通过；新增断开请求测试尚未执行。前端专项7项通过、tsc通过。不能替代最终子 agent 验证。

后端命令（cwd 仓库）：.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_cancel_partial_message.py -v；完整 .venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v；.venv/Scripts/ruff.exe check <上述Python改动>；ruff format --check 同范围；.venv/Scripts/ty.exe check。完整通常约4–5分钟。Windows符号链接权限跳过按事实记录，旧审批结算/空宿主环境退出超时 needs-triage 保留。测试不得使用真实供应商网络。

新增原生：tests/desktop_cancel_fixtures.py 是真实 create_agent/模型节点/工具/middleware/checkpoint 的离线可控流；frontend/src-tauri/tests/cancel_partial_acceptance.py 自己声明4项：确认默认焦点/四种放弃零POST后真实取消重开；真实取消响应被隐藏后只GET核实；interrupted 取消审批失效且零工具副作用、完整消息保留complete；隐藏和自然完成关闭确认零POST。夹具在每个隔离工作目录使用 allow-cancel-model 文件门控，cancel-text-ready 表示流已输出但仍需等UI末段显示。python main只跑此类自己声明的方法，不能把继承父类旧测试在新夹具下重复执行。

前端命令（cwd frontend）：node --import tsx --test tests/run-cancel.test.mjs；pnpm test（全套一次）；pnpm exec tsc --noEmit；pnpm build。原生需先dist最新、backend_window.exe 可用；真实窗口和端口共享必须串行，backend单测可并行。原生9238、后端45200需空闲；5173原静态服务可按 ReconstructionAcceptance 的逐字节校验复用，禁止杀用户进程。运行环境 PYTHONPATH=C:/code/shikigen-agent/tests;C:/code/shikigen-agent/frontend/src-tauri/tests;C:/code/shikigen-agent/packages/harness；GUI受沙箱限制时按工具申请升级。原生执行（cwd仓库）：.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/cancel_partial_acceptance.py。建议测试runner针对异常捕获截图/HTML/API请求/后台状态，使用原第9票runner为参考但不能修改旧证据。新4项 + 受影响既有03–09共19项（用类 __dict__ 选自己定义test方法，不能加上继承的用例）串行执行；artifact_root 一律覆盖到 ticket-10/native/<票号>，不会覆盖旧票。

证据写到本目录各自子目录（backend/、logs/、native/）。报告包含实际模型、cwd/命令、实际通过失败跳过、所有历史失败日志、复现与根因判断、剩余覆盖缺口。主 agent 核对原始日志/截图后更新票据并按 implement 提交当前分支，子 agent 不提交。
