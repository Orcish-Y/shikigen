> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 14 票交接

目标：实现并验证 docs/wayfinder/frontend-completion/implementation/14-workspace-image-preview.md 全部七条条件；规格 .scratch/frontend-completion/PRD.md §13，docs/wayfinder/frontend-completion/tickets/004-message-tools-export.contract.md §本地资源，frontend/design.md 本地图片。先读 AGENTS.md。

模型显式 gpt-6-luna / max。主 agent 写产品与修复；验证 agent 只执行验证、诊断、写本票报告和原始证据。不得删断言、放宽规格或将未执行算通过。用户禁止 Git 操作，本轮所有 agent 不运行任何 Git 命令，不暂存/提交/切分支。

## 方案与改动

- 新 packages/harness/shikigen/runtime/workspace_resources.py：装配时绝对根及目录身份；opaque workspace_id；资源身份绑定原引用规范路径、实际目标、stat 版本、Runtime 生命周期。根/逐级链接必须在目录内；Windows junction 同样核实，禁止设备与 ADS 路径。普通文件，完整真实元数据（额外 version），MIME 内容签名，SVG 二进制只由 img 使用；20MiB；读前/后 fstat/路径/根核实。Windows 3.12 stat 与 fstat 的 ctime 定义不兼容，Windows 版本用 dev/ino/size/mtime，其他系统另含 ctime。
- 新 app/routes/workspace.py + server.py：GET workspace / resources/resolve?path= / resources/{id}/image，全程 no-store，图片正确 MIME/nosniff。纯读线程池，不调用 Run/Graph/tools。非法422、越界/不可读403、缺文件/资源身份404、变化409、大图413、不支持415。
- composition.py：open_runtime 先绑定资源根，再将绝对根传给真实文件工具与 Agent；Runtime.resources 共享已装配资源。assemble_runtime 外部装配同样固定根。
- backend-client.ts：BackendSession workspace/resolveResource/resourceImage，no-store、租约取消、读取后过滤迟到响应、结构/MIME/大小检查。
- 新 workspace-images.ts：可见会话内引用/资源去重、资源共享 Blob URL、最后读者释放/abort、scope dispose 与 session 失效清理；错误仅局部，显式 retry 重新 resolve。
- 新 components/WorkspaceImage.tsx + MessageBody/ContentViewer/App/styles.css：Agent 明确本地 Markdown 图片自动读，其他角色/代码/JSON/网页图片不读；约320px保持比例；原引用/当前磁盘说明/实际文件核对复制；单前景图片完整查看。Provider 每次 session/thread/visible 更换释放旧 scope。隐藏关闭图片详情；切会话原有逻辑关闭详情。
- MessageBody 的 RenderBoundary 改为稳定 identity（内容改变时重置失败）避免 delta 每次重挂载资源；Markdown paragraph 用消息身份+源偏移作为阅读锚点，保持同一条长消息中图片增高后的可见正文位置。
- 无 Rust/依赖/写 API/数据库 schema 改动。文件系统打开归第15票。

## 开发检查

HTTP 第一条确实 red404 后 green；边界 red 暴露 Windows ctime 和目录分类，修复后8项公开HTTP通过，涵盖真实junction越界/变更、目录替换、旧服务身份、文件替换、URI/CWD、格式/大图、owned Runtime真实工具同根。
Node 新7项 + 旧正文5项=12项通过，覆盖共享Blob、最后释放、隐藏/切换中断、旧租约、迟到响应、五种读取错误重试、协议/MIME/大小以及单读者解除。
TypeScript开发检查 exit0；Python 5文件 Ruff通过，产品3文件 ty通过。这些不代替最终验证。

## 环境、命令与范围

cwd C:/code/shikigen-agent，Windows PowerShell，无权限提升。已有 .venv/Scripts/python.exe、ruff.exe、ty.exe；frontend/node_modules 已装。不要联网安装，不改 AGENTS。

后端验证 agent：

1. `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_workspace_resources.py -v`
2. `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v` 唯一完整回归一次；所有历史失败原样保存，复现要先报告根因证据。完成后通知主 agent 释放原生验收排他时段。
3. `.venv/Scripts/ruff.exe check app/server.py app/routes/workspace.py packages/harness/shikigen/runtime/composition.py packages/harness/shikigen/runtime/workspace_resources.py tests/test_workspace_resources.py`，同范围 `format --check`。
4. `.venv/Scripts/ty.exe check app/routes/workspace.py packages/harness/shikigen/runtime/workspace_resources.py packages/harness/shikigen/runtime/composition.py tests/test_workspace_resources.py`，诊断分别区分产品/测试。

前端/实机验证 agent：

frontend cwd：`node --import tsx --test tests/workspace-images.test.mjs tests/message-content.test.mjs tests/chat-reading-position.test.mjs`（先核对准确名字）；完整一次 `node --import tsx --test tests/*.mjs`；`node node_modules/typescript/bin/tsc --noEmit`；`node node_modules/vite/bin/vite.js build`。Node/静态/构建可与后端并行。

原生必须等主 agent 通知后端完整回归结束后开始，避免端口/数据库/进程争用；frontend/dist 已构建，已有 frontend/src-tauri/target/debug/examples/backend_window.exe；无 Rust变更无需重复构建。端口9238/45200必须空闲，5173若预置服务存在，逐字节核对当前dist才复用，不关闭不属于自己的进程。实际Tauri隔离临时工作区、真实Graph/HTTP/SSE/文件。主 agent 将提供本票 native_runner.py，选择新图片专项与旧正文/阅读原断言，串行执行；不能用浏览器SSR代替真实Tauri。

## 证据与报告

各自写 backend-report.md / frontend-report.md；原始证据写 validation/backend 或 validation/frontend 分目录，独占写入。每条命令含cwd/开始结束/exit/count，保留stdout/stderr/meta。报告模型、范围、通过/失败/跳过、复现、截图/日志和覆盖缺口。不要提前改票据 done。主 agent 检查证据后更新票据。
