> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 默认下载第 7 轮最终复验

日期：2026-10-07（Asia/Shanghai）  
验证模型：<code>gpt-6-luna / max</code>  
工作目录：<code>C:\code\shikigen-agent</code>

## 结果

命令：

    .venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch default-download-7-final --tests NativeSaveCancelExportAcceptance.test_default_download_retains_actual_complete_markdown_without_override

结果：**1 selected / 1 executed / 1 passed / 0 failed / 0 error / 0 skip，runner exit 0**。权威计数在 [runner-result.json（原始产物已删除）](../../../../../README.md#已删除的材料)；其 <code>runner_pid</code> 为 29148。

测试只观察实际默认 WebView 下载。本例隔离 profile 的 Preferences 只含 <code>default_directory</code> 和 <code>directory_upgrade</code>，<code>prompt_for_download</code> 不存在；未调用 <code>Browser.setDownloadBehavior</code>。单一下载 GUID <code>b1e424d0-fabd-44b5-9356-5b52b9c9a41d</code> 共观察 8 个 Page 事件（1 个 <code>downloadWillBegin</code>、7 个 <code>downloadProgress</code>），同 GUID 终态为 <code>completed</code>，接收和总字节均为 69,777。Tauri 宿主退出后源文件仍在工作区，大小 69,777 bytes、SHA-256 <code>5a9c4e3dfb61c92bdeb246d517e452b2b4859fc81fed66622ac47e943650d270</code>；观察副本大小和哈希相同。测试断言后端历史与未提交草稿未变。没有运行付费模型。

证据：[完整调用和运行前哈希（原始产物已删除）](../../../../../README.md#已删除的材料)、[静态预检与精确 list（原始产物已删除）](../../../../../README.md#已删除的材料)、[隔离 profile 实际偏好（原始产物已删除）](../../../../../README.md#已删除的材料)、[终态/GUID/下载文件校验（原始产物已删除）](../../../../../README.md#已删除的材料)、[事件（原始产物已删除）](../../../../../README.md#已删除的材料)、[用例结果（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner stderr（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 静态检查与来源

四个相关 Python 文件的 Ruff check 与 <code>ruff format --check</code> 均 exit 0；原始 runner 精确列出 1 项。38 个 <code>frontend/dist</code> 文件的名称、大小和 SHA-256 与 <code>final-4/vite-build.json</code> 清单一致：共 1,049,454 bytes，manifest 记录哈希 <code>fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f</code>。

运行前的 10 个源哈希见 [source-hashes-before-run.json（原始产物已删除）](../../../../../README.md#已删除的材料)。本批没有即时 post-hash；[后续观察（原始产物已删除）](../../../../../README.md#已删除的材料)是在批次结束和平台源释放后采集，不可当作即时 post-hash。后续观察中下载用例源 <code>conversation_export_acceptance.py</code> 与运行前哈希相同；平台验收源已在释放后由主 agent 修改。

既有 [download-final-evidence.json（原始产物已删除）](../../../../../README.md#已删除的材料) 的 <code>runner_exit_code</code> 字段误填为 runner PID 29148。该字段不正确；[更正说明（原始产物已删除）](../../../../../README.md#已删除的材料)以 <code>runner-result.json</code> 中的真实 exit 0 为准。未改写原 JSON。

## 清理缺口

测试创建的隔离 TemporaryDirectory <code>C:\Users\Orcs0\AppData\Local\Temp\shikigen native acceptance hcx83pmj</code> 在运行后仍存在。runner 活跃期间观察到该目录下 Preferences，且隔离 profile 的默认下载路径指向本例 artifact。复核显示该目录位于系统 Temp 下、目标自身不是 reparse point，runner PID 29148、Tauri PID 9516、fixture PID 23744/5692 均已退出。下载源文件另存于工作区 <code>.scratch</code>，不在这个 Temp 目录中。

两次精确 <code>Remove-Item -LiteralPath $resolvedPath -Recurse -Force</code> 尝试均在 <code>functions.exec</code> 调用 <code>exec_command</code> 的进程启动/CreateProcess 层被拒，观察到的工具错误原文为 <code>blocked by policy</code>。PowerShell 没有启动，没有 PowerShell stdout/stderr，也不是 automatic approval review；没有文件变更。按父 agent 指示不再重试，Temp 残留作为清理缺口保留。完整解析路径、所有权、reparse 与进程证据见 [temp-fixture-cleanup.json](../../../../../native-acceptance-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/default-download-7-final/temp-fixture-cleanup.json`）。

这是本例隔离默认偏好下的一次真实下载通过，不证明 Save As 取消或人工保存交互。
