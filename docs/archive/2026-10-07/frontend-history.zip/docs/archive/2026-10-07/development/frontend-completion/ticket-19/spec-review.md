> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 19 Spec 轴审查

范围：只读复核最新差异和规格；未运行测试、构建或 Git 命令。

## (a) 缺失／部分实现

未发现剩余硬性 Spec 缺口。此前 EOF 补读与 pending=false 竞争会吞掉补读的问题已修复：同阶段且已有边界补读标记时，自动请求停止后排队一次独立快照；继续前核对 session、线程、Run、执行阶段、窗口可见和未暂停（[conversation-state.ts:1009](../../../../../../frontend/src/conversation-state.ts#L1009)、[conversation-state.ts:1014](../../../../../../frontend/src/conversation-state.ts#L1014)）。旧请求被撤销 owner，只有当前 owner 可完成结算协调（[conversation-state.ts:1010](../../../../../../frontend/src/conversation-state.ts#L1010)、[conversation-state.ts:1148](../../../../../../frontend/src/conversation-state.ts#L1148)）。这符合“同一观察代次正常结束于 interrupted 或终态时，补读一次只读 Run 快照”及“查询得到适用于当前阶段的 usage_pending=false 时立即停止”（[005-run-details.contract.md:94](../../../../../wayfinder/frontend-completion/tickets/005-run-details.contract.md#L94)、[005-run-details.contract.md:103](../../../../../wayfinder/frontend-completion/tickets/005-run-details.contract.md#L103)）。

## (b) 范围外行为

未发现明确超出本票范围的产品行为。验收夹具把 `actualSnapshot` 深拷贝于 fetch 注入前（[usage_settlement_acceptance.py:33](../../../../../../frontend/src-tauri/tests/usage_settlement_acceptance.py#L33)），随后只改页面收到的 envelope（[usage_settlement_acceptance.py:35](../../../../../../frontend/src-tauri/tests/usage_settlement_acceptance.py#L35)）；独立 Python HTTP 查询读取后端 Run 快照（[run_details_acceptance.py:58](../../../../../../frontend/src-tauri/tests/run_details_acceptance.py#L58)），核对真实 `usage_pending=false` 与 27 tokens（[usage_settlement_acceptance.py:117](../../../../../../frontend/src-tauri/tests/usage_settlement_acceptance.py#L117)）。本次连接夹具委托既有握手（[usage_settlement_acceptance.py:11](../../../../../../frontend/src-tauri/tests/usage_settlement_acceptance.py#L11)）：过滤到 `127.0.0.1:5173` 页面（[pagination_acceptance.py:43](../../../../../../frontend/src-tauri/tests/pagination_acceptance.py#L43)），连续三次稳定后才连接（[pagination_acceptance.py:54](../../../../../../frontend/src-tauri/tests/pagination_acceptance.py#L54)），并等待页面完整加载和 Tauri bridge（[pagination_acceptance.py:61](../../../../../../frontend/src-tauri/tests/pagination_acceptance.py#L61)）。错误继续由等待／CDP 操作向上报告；`page_target` 随用量证据保存（[usage_settlement_acceptance.py:59](../../../../../../frontend/src-tauri/tests/usage_settlement_acceptance.py#L59)）。两次夹具修正不改产品行为或验收断言。

## (c) 看似实现但行为不符

未发现剩余硬性错误。新阶段不沿用旧边界补读；旧 owner 的 finally 不会清理或计费新 owner。边界补读使用普通快照入口，保持与自动轮询分开。
