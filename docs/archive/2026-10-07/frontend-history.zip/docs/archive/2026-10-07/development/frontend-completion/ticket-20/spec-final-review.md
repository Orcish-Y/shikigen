> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 20 票 Spec 最终静态复核

- 复核模型：GPT-6-Luna，max（按派发要求）。
- 复核基线：`.scratch/frontend-completion/ticket-20/before/` 对应的固定点，以及 `review.diff`、`changed-files.txt` 中列出的第 20 票改动。
- 对照规格：第 20 票六项 AC、`.scratch/frontend-completion/PRD.md` §7/§8、交互验收契约 §4/§5/§8 与 `frontend/design.md`。
- 本轮只做源码与已有记录的静态审查；没有执行 Git、测试、类型检查或构建，也没有修改产品代码或测试。

## 结论

在第 20 票范围内，六项 AC 均与当前实现及现有验收记录相符。**未发现需要修复的 Spec 偏差；严重度发现为 0。**标题缓存故障与消息草稿／审批存储故障现已正确隔离，静态核对通过。

## 六项验收条件

1. **标题来源与核对：符合。**[conversation-titles.ts](../../../../../../frontend/src/conversation-titles.ts#L18) 只从首条非预览 human 消息提取明确文本，忽略未知块，不改消息；标题限为 48 个 grapheme 后加省略号。缓存按 thread ID 持久化来源身份，完整历史通过 `reconcileHistory` 核对；SSE／单 Run 的部分消息读取不会清除既有来源。[conversation-state.ts](../../../../../../frontend/src/conversation-state.ts#L864) 仅在当前打开／核对的会话读取历史，并在读取后重核标题；标题派生不调用写回接口。正式 title 与空值回退分别由 [displayConversationTitle](../../../../../../frontend/src/conversation-titles.ts#L13) 实现。

2. **共用显示标题、可查完整标题、缓存错误提示：符合。**[useConversations.ts](../../../../../../frontend/src/useConversations.ts#L33) 将同一个显示标题用于会话行与活动工具栏会话；[Sidebar.tsx](../../../../../../frontend/src/components/Sidebar.tsx#L183) 本地过滤匹配该标题，并提供完整标题／时间入口；[ConversationIdentity.tsx](../../../../../../frontend/src/components/ConversationIdentity.tsx#L4) 展示完整标题、ID、时区与 UTC 并提供复制控件。标题错误状态由 `titleStorageIssue` 独立维护：[conversation-state.ts](../../../../../../frontend/src/conversation-state.ts#L157) 在每次视图发布时刷新缓存和告警状态，[App.tsx](../../../../../../frontend/src/App.tsx#L364) 单独显示标题缓存告警，而 [Composer](../../../../../../frontend/src/components/Conversation.tsx#L251) 仍只根据草稿存储状态提示草稿持久性。最终 native 报告中的 title-only quota 场景也确认：标题告警出现、草稿仍持久化，Composer 不误报草稿仅保存在内存。

3. **真实时间排序、日历分组、相对时间与完整时间：符合。**[conversation-state.ts](../../../../../../frontend/src/conversation-state.ts#L341) 按真实 `updated_at` 降序并以 ID 作稳定次序；[useConversations.ts](../../../../../../frontend/src/useConversations.ts#L33) 只计算显示分组，不以文案重排。[conversation-time.ts](../../../../../../frontend/src/conversation-time.ts#L30) 按用户时区分别计算本地日历日与实际经过时长，覆盖昨天边界、七天阈值、未来和不可解析时间；身份抽屉展示本地日期／时间／时区、服务端原值和可复制 UTC。[frontend/design.md](../../../../../../frontend/design.md#L87) 要求长标题完整入口及时间辅助文字层级，现有组件沿用这些语法。

4. **可见分钟刷新、未来和未知时间：符合。**[useConversationTime.ts](../../../../../../frontend/src/useConversationTime.ts#L5) 在可见时对齐分钟边界刷新，重新可见时立即更新；该 hook 只更新时间状态，不发 HTTP。未来时间显示绝对本地时间；未来日期和未知时间进入“日期待确认”，无效时间显示“时间未知”。final-5 原生报告记录页面虚拟时钟跨分钟／跨日刷新没有新增请求，并核对真实隐藏与托盘恢复路径。

5. **加载／失败／空态与示例草稿行为：符合。**[App.tsx](../../../../../../frontend/src/App.tsx#L406) 按列表或历史读取状态传递 `readState`；[Conversation.tsx](../../../../../../frontend/src/components/Conversation.tsx#L87) 只在 `ready` 且确无消息时渲染空态，读取中和失败各自显示状态。真实空列表有新建入口，空会话有三条已确认示例。[appendTaskExample](../../../../../../frontend/src/conversation-titles.ts#L95) 只在空字符串时填入，否则保留原文并以空行追加；[useConversations.ts](../../../../../../frontend/src/useConversations.ts#L94) 校验当前会话和历史已就绪后才写入草稿；[App.tsx](../../../../../../frontend/src/App.tsx#L409) 仅由示例点击同步聚焦，且模态打开时不执行。迟到历史没有安排焦点动作或发送动作。

6. **持久缓存、标题覆盖、时间边界、示例原文及实机草稿保留：有证据。**源码及现有 Node 用例覆盖缓存重启／完整历史核对、正式标题优先与 null 回退、部分消息不清缓存、存储失败隔离、时间阈值与时区边界、示例原文追加。现有 [frontend 验证报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/validation/frontend/report.md`） 记载 Final-3 全量 Node 246/246、TypeScript 与 Vite build 通过；[native 验证报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/validation/native/report.md`） 记载最新 Final-5 使用当前 dist 原生 4/4 通过，覆盖标题过滤与完整身份入口、重启／缓存核对／失败读取／存储告警、示例与迟到读取焦点竞态，以及时间刷新／隐藏恢复。此处只核对报告和源码，本复核没有重跑上述命令。

## 严重度发现与覆盖边界

- P0：0；P1：0；P2：0；P3：0。
- Final-5 使用 CDP 键盘输入、页面 clipboard stub 和页面虚拟时钟；不等于物理键盘／输入法候选、OS 原生剪贴板或系统窗口尺寸验收。这些边界已在 native 报告中明示，不据此将第 21／22／23 票范围误判为第 20 票遗漏。
- Final-4 的 CDP 初始化阻塞记录继续保留；它未进入产品断言，不作失败或通过证据。最新完整产品断言证据以 Final-5 为准。

**Spec 结论：通过；待主 agent 按项目流程关闭第 20 票。**
