> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 09 原生验收记录

- 执行模型：`gpt-6-luna`，推理强度 `max`
- 最终结果：第09原生三项、第07两项及第08四项受影响回归全部通过，分别exit0；共19个唯一原生案例分批覆盖，详见末节。以下保留早期失败及逐轮修复记录，历史失败不改算通过。

## Build 与宿主预检

- frontend 定向测试 54/54 通过，tsc 与 `pnpm.exe build` exit 0；未重复首轮 121 项全套或 Rust 25 项。对应 stdout/stderr/exit/meta 使用 `logs/frontend-history-gate-*` 前缀。
- `frontend-ready.json` 记录 38 个 dist 文件及 index 直接引用资源的字节数和 SHA-256；静态服务 `http://127.0.0.1:5173` 逐文件返回 38/38 项字节与哈希匹配，结果见 [preflight-final.json（原始产物已删除）](../../../README.md#已删除的材料)。静态服务进程命令行见 [static-server-process.json（原始产物已删除）](../../../README.md#已删除的材料)。
- 9238 与 45200 原生端口在 runner 前均可成功 bind；预检结果同上。没有停止或更改已有 5173 服务。
- 两次早期只读预检脚本尝试分别因子进程未加载 HttpClient assembly、随后未识别 Get-FileHash cmdlet 而 exit 1；stderr 分别保存在 `logs/native-preflight-final.stderr.log` 与 `logs/native-preflight-history-gate.stderr.log`。改用 WebClient 与 .NET SHA-256 后预检成功，相关成功日志为 `logs/native-preflight-history-gate-verified.*`、`logs/native-preflight-final-freeze.*` 和 `logs/native-preflight-controls-fix.*`。这些是预检脚本环境问题，不是产品测试失败。

## 第 09 原生批次（首次 history-gate build）

 runner 是 [native-final-runner.py（原始产物已删除）](../../../README.md#已删除的材料)，由 `native-recheck-runner.py` 复制，只将 `ARTIFACT_ROOT` 改为 `native/09-final`。命令为 `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-09/native-final-runner.py`，工作目录为仓库根目录；进程级 `PYTHONPATH` 为 `tests;frontend/src-tauri/tests;packages/harness`。

| 唯一用例 | 结果 |
| --- | --- |
| `test_switch_hide_host_reentry_and_restart_preserve_reading_intent` | 通过 |
| `test_accepted_send_stream_replacement_layout_and_internal_scroll` | **失败**：`_callTestMethod` 内 `assert_anchor` 等待超时 |
| `test_only_active_approval_action_locates_and_focuses_timeline_card` | 通过 |

批次 exit 1，2 通过、1 失败。完整输出、错误、退出码与命令元数据见 `logs/native-09-final.{stdout,stderr,exit,meta}`。

失败证据：[`failure-evidence.json`（原始产物已删除）](../../../README.md#已删除的材料)，截图为同目录 `window.png`。期望锚点是当前 run 最后一条消息 seq 11、offset `-16.046875`、scrollTop `9917`；实际仍定位到相同消息，但 offset 变为 `-328.453125`、scrollTop `10677`，滚动区总高度从捕获时 `10775` 增至 `11223`。`following=false`、`newContent=false`。页面请求仪表记录两次 POST send；history 包含新 run seq 8–11；最后可见 timeline scroll top 依次为 9917、9918、10077、10364.5、10677。完整正文、读取事件、请求、历史和窗口截图均保存在上述证据目录。

该失败在 history-gate build 仍可重现布局/滚动时序问题。09 的两个其他用例已通过。旧失败保存在 `native/09` 与 `native/09-recheck`，未覆盖。本报告建立时没有重跑 03–06，也没有运行 07/08 回归；07 两项与 08 四项待修复后的 09 批次通过再执行。物理键盘、系统 IME 和软键盘实机检查仍属于第 23 票。

## 第 09 原生批次（最终冻结布局修复）

最终前端冻结版的定向测试为 55/55、tsc 与 build exit 0；`frontend-ready.json` 已更新。测试前 HTTP 预检确认 5173 服务按字节/hash 提供 dist 中 38/38 个文件，9238 与 45200 均可 bind。完整预检日志为 `logs/native-preflight-final-freeze.*`，结果见 [preflight-final.json（原始产物已删除）](../../../README.md#已删除的材料)。

runner 为 [native-layout-final-runner.py（原始产物已删除）](../../../README.md#已删除的材料)，仍只运行 09 的三个明确用例，artifact root 为 `native/09-layout-final`。批次运行 112.4 秒后 exit 1，0 通过、3 失败。三个失败都在测试方法调用 `home()` 的等待中断言未满足；不是放宽或改写的断言：

| 唯一用例 | 结果与当前几何 |
| --- | --- |
| `test_switch_hide_host_reentry_and_restart_preserve_reading_intent` | `home()` 超时；scrollTop 5207.5、总高度 5793、锚点 seq 5 offset -682.27、following false |
| `test_accepted_send_stream_replacement_layout_and_internal_scroll` | `home()` 超时；scrollTop 5207.5、总高度 5793、锚点 seq 5 offset -682.27、following false |
| `test_only_active_approval_action_locates_and_focuses_timeline_card` | `home()` 超时；scrollTop 3205、总高度 3790、锚点 seq 3 offset -3027.80、following false |

每项最后记录的滚动目标均为主 timeline。各项 failure-evidence.json、完整 body/history/request/事件数据和 window.png 分别保存在 `native/09-layout-final/<case>/`；完整 runner stdout、stderr、exit 和 meta 为 `logs/native-09-layout-final.*`。本轮没有运行 07/08 回归；因 09 未通过，需等主 agent修复后重新跑 09，再按要求重跑 07 两项与 08 四项。旧 `native/09`、`native/09-recheck`、`native/09-final` 证据全部保留。

## 第 09 原生批次（controls-fix build）

controls-fix 前端增量测试 55/55，tsc/build exit 0。`logs/native-preflight-controls-fix.*` 显示当前静态服务的 38/38 dist 文件逐字节/hash 匹配，9238 与 45200 均可 bind。runner 为 [native-controls-final-runner.py（原始产物已删除）](../../../README.md#已删除的材料)，artifact root `native/09-controls-final`；三个用例串行执行，批次 1 通过、2 失败、exit 1：

| 唯一用例 | 结果与证据 |
| --- | --- |
| `test_switch_hide_host_reentry_and_restart_preserve_reading_intent` | `assert_anchor` 失败：expected seq 5 / top 4541 / offset -15.773；actual seq 2 / top 0 / offset 18；总高度同为 5793。见 [failure-evidence.json（原始产物已删除）](../../../README.md#已删除的材料) 与同目录 `window.png`。 |
| `test_accepted_send_stream_replacement_layout_and_internal_scroll` | 末尾代码块命中检查失败：`elementFromPoint(621.5, 717.453)` 未命中 `pre`，断言发生在滚轮事件前；此前回到最新状态为 top 10976、height 585、total 11561、following true。见 [failure-evidence.json（原始产物已删除）](../../../README.md#已删除的材料) 与同目录 `window.png`。 |
| `test_only_active_approval_action_locates_and_focuses_timeline_card` | 通过。 |

完整 stdout、stderr、exit 与 meta 为 `logs/native-09-controls-final.*`。因 09 仍未全部通过，没有运行 07 两项或 08 四项回归；03–06 没有重跑。此前 09 的全部历史结果仍保存在各自目录，未被覆盖。

## 最终冻结构建后的原生验收与受影响回归（2026-10-05）

最终闭环按 `09 → 07 → 08` 串行执行。实际模型为 `gpt-6-luna / max`，工作目录均为 `C:\code\shikigen-agent`；每条 Python 命令的进程级 `PYTHONPATH` 为 `C:/code/shikigen-agent/tests;C:/code/shikigen-agent/frontend/src-tauri/tests;C:/code/shikigen-agent/packages/harness`。每批的实际命令、PID、开始／结束时间、stdout、stderr 和 exit 文件都单独保留；unittest verbose 输出在 stderr，stdout 文件为空。

### 冻结产物与原生宿主预检

- 最新 `frontend-ready.json` 生成于 2026-10-05 17:15:48，记录 `frontend/dist` 的 38 个文件大小和 SHA-256。复核本地清单为 38/38 一致；新建的 [09 原生预检（原始产物已删除）](../../../README.md#已删除的材料) 对现有 `http://127.0.0.1:5173` 逐文件 GET，38/38 字节数与 SHA-256 匹配，9238 与 45200 均可 bind，`ready=true`。完整脚本输出见 [预检 stdout（原始产物已删除）](../../../README.md#已删除的材料)，脚本见 [preflight-09-scroll-final.ps1（原始产物已删除）](../../../README.md#已删除的材料)。
- 5173 当前仍由 PID 23344 监听。保留的进程命令行证据显示它服务 `frontend/dist`；本轮没有停止或改动它。原生用例结束后 9238 与 45200 均无监听者。

### 最终 09 与 07／08 定向回归

| 批次 | Python 进程 / 时间 | 结果 | 命令、日志与退出码 |
| --- | --- | --- | --- |
| 09 原生专项 | PID 23512；17:37:57.391–17:38:30.152；unittest 32.222 秒 | 3 通过、0 失败、0 跳过；exit 0 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-09/native-scroll-final-runner.py`；[命令（原始产物已删除）](../../../README.md#已删除的材料)、[started（原始产物已删除）](../../../README.md#已删除的材料)、[ended（原始产物已删除）](../../../README.md#已删除的材料)、[stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[exit（原始产物已删除）](../../../README.md#已删除的材料) |
| 07 Markdown 回归 | PID 32344；18:03:28.865–18:03:47.423；unittest 15.501 秒 | 2 通过、0 失败、0 跳过；exit 0 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-09/native-07-final-runner.py`；[命令（原始产物已删除）](../../../README.md#已删除的材料)、[started（原始产物已删除）](../../../README.md#已删除的材料)、[ended（原始产物已删除）](../../../README.md#已删除的材料)、[stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[exit（原始产物已删除）](../../../README.md#已删除的材料) |
| 08 工具记录回归 | PID 5208；18:03:47.535–18:04:20.479；unittest 30.035 秒 | 4 通过、0 失败、0 跳过；exit 0 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-09/native-08-final-runner.py`；[命令（原始产物已删除）](../../../README.md#已删除的材料)、[started（原始产物已删除）](../../../README.md#已删除的材料)、[ended（原始产物已删除）](../../../README.md#已删除的材料)、[stdout（原始产物已删除）](../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../README.md#已删除的材料)、[exit（原始产物已删除）](../../../README.md#已删除的材料) |

09 的三项是 `test_switch_hide_host_reentry_and_restart_preserve_reading_intent`、`test_accepted_send_stream_replacement_layout_and_internal_scroll`、`test_only_active_approval_action_locates_and_focuses_timeline_card`；07 的两项是 `test_real_messages_full_copy_drawer_and_single_foreground`、`test_native_rejects_unsafe_urls_and_frontend_reports_open_failure`；08 的四项为 `ToolRecordsAcceptance` 本类定义的四个用例，不包含继承测试。三个批次实际逐项通过。

窗口证据均保留：09 的 [切换／隐藏／宿主重入／重启截图（原始产物已删除）](../../../README.md#已删除的材料)、[流式／布局／内部滚动截图（原始产物已删除）](../../../README.md#已删除的材料)、[审批定位截图（原始产物已删除）](../../../README.md#已删除的材料)，对应目录各有 `result.json` 与宿主日志。07 的截图位于 [Markdown 完整呈现用例（原始产物已删除）](../../../README.md#已删除的材料) 和 [安全 URL 用例（原始产物已删除）](../../../README.md#已删除的材料)。08 的四张 `window.png` 分别位于 `native/08-final/test_true_status_pairing_full_records_empty_values_and_complete_copy/`、`test_manual_collapse_survives_replay_selection_and_native_restart_resets/`、`test_parameters_artifacts_and_independent_result_full_view_and_copy/`、`test_failure_arrival_respects_manual_collapse_of_waiting_card/`。额外的内容截图也保留在对应目录。

最终唯一原生覆盖为旧第 03–06 票 10 项＋第 07 票 2 项＋第 08 票 4 项＋第 09 票 3 项，共 19 个唯一案例。03–06 的十项来自本票较早的 `native-full-pre-fix.stderr.log`，分别 3／4／2／1 项通过；该早期批次另有 07／08 六项通过、09 三项失败，不能将整个早期批次算作通过。最后冻结构建后只执行 09→07→08，没有重复 03–06。07／08 是受影响回归，09 曾多次重试；重复执行不累计计数，也不称为一轮 19 项全通过。此前 09 的 history-gate、layout、controls-fix 等失败批次及诊断目录仍完整保留在上文路径；最终冻结构建的 09 三项本批全部通过。

### 环境记录与覆盖缺口

- 旧版预检遇到 HttpClient 程序集未加载、后续 Get-FileHash 在子进程中不可用，已在本报告前文和各自 stderr 中保留；采用 WebClient 与 .NET SHA-256 的最终预检成功。本轮另一次 CIM 命令行读取返回“拒绝访问”，没有影响运行，也没有尝试终止任何进程；使用已保存的 `native/static-server-process-final.json` 与当前 netstat 监听 PID 核对现有服务。一次本地清单诊断最初把 `bytes` 当作字段名（manifest 实际字段为 `size_bytes`），临时显示 38 项不匹配；按正确 schema 复算为 0 项不匹配，独立 HTTP 预检随后确认 38/38。
- 本轮原生用例使用真实 Windows Tauri/WebView、临时后端和受控公开请求；其 390 视口属于浏览器设备视口模拟。没有验收 14 票本地图片资源，也没有声称物理键盘、系统 IME、软键盘或四档真实窗口尺寸联合通过；这些仍留给对应后续票据，尤其第 23 票实机验收。
