> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Standards Review — Ticket 04

## 做得好

- `MessageDrafts` 集中维护持久化草稿、提交快照与版本匹配清理；`ConversationStore` 继续管理运行事实。用户用语符合 `CONTEXT.md` 的“消息草稿／发送结果待确认”，原文保留也符合 `frontend/design.md:171`。
- 输入法与 Enter 规则隔离在 `composer-keyboard.ts`，普通 Enter 也没有复用为审批或取消操作。

## 需要修

- **硬违规（1）**：`frontend/design.md:278` 要求状态变化使用适量 `aria-live`。`App.tsx:250` 在提交状态变成 `unknown` 时挂载 `SendRecovery`，但 `SendRecovery.tsx:23-24` 的核对区和“发送结果待确认”标题没有 live/status 语义。HTTP 200 空流结束时可进入该状态而不更新已有 `role="status"` 通知，因此读屏用户可能不会获知这项关键状态。给状态文案增加适当的实时播报。

## 值得讨论

- **Heuristic — Duplicated Code**：`conversation-state.ts:79-86` 在构造初始化和 `publishInputs()` 中重复草稿记录到文本映射；可集中为一个投影方法。
- **Heuristic — Repeated Switches**：`Conversation.tsx:193-194` 与 `:206` 分别按同一 `runStatus` 选择操作按钮和说明文案；可先派生 composer 模式，避免状态与文案分叉。
- **Heuristic — Mysterious Name**：`message-drafts.ts:77` 的 `unknown()` 没有说明它把提交状态改为未知；`markSubmissionUnknown()` 会更清楚。

计数：硬违规 1；heuristic 3。未发现其他文档标准硬违规。

## 复核（主 agent 修复后）

- 原硬违规已修：`Conversation.tsx:208-211` 的常驻 composer 文案现有 `role="status" aria-live="polite" aria-atomic="true"`，并通过 `sendUnknown` 覆盖待核实状态。
- 两项 heuristic 已修：`conversation-state.ts:79-87` 抽出 `inputState()` 统一投影；`message-drafts.ts:79` 改为 `markSubmissionUnknown()`。
- **仍有 1 项 heuristic — Repeated Switches**：`Conversation.tsx:195-196` 的 CTA 与 `:210` 的 footer 说明仍分别判断同一个 `runStatus`。可派生一次 composer mode，再共同决定操作和文案。

复核计数：硬违规 0；heuristic 1。复核仅读代码，未运行前端检查。
