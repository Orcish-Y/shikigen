> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 1440 桌面交互矩阵回归

日期：2026-10-07  
模型：gpt-6-luna / max  
工作目录：C:\code\shikigen-agent

## 结果

只运行一次 1440×900 fresh batch，结果 **1 selected / 1 executed / 0 passed / 1 failed / 0 error / 0 skip**，runner exit 1。

    .venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch interaction-matrix-2 --tests NativePlatformAcceptance.test_1440_native_send_approve_cancel_and_reconnect

Ruff check 与 ruff format --check 对 platform 和 runner 均 exit 0；精确 --list 选中一项。frontend/dist 38/38 文件、1,049,454 bytes 与 final-4 清单逐文件匹配，manifest SHA-256 fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f。运行前后源码 hash 相同：platform 839f88333b08cee883b2d0077264fc2be94deadd43ce24d4943205a5f7d31a69；runner 4f802c6f4bd38c18190d99c774e134cc3effc03d0be6c804d8322b607e4f756d。

## 交互阶段与失败

真实桌面窗口出现缺托盘图标 TrayNotice。首个 reading_agent Run 79e079a80db4448ba61e98903794f26c 经真实窗口鼠标审批并完成；workflow JSON 保存了 approval 阶段及 history。随后真实鼠标发送长草稿，第二个 Run 86aff34d2cc4400fb35618e8c70dd4d0 进入 running，history 保存了 30 行正文。故障配置后，界面出现“自动恢复已停止”；手动真实鼠标点击“重新连接”后“观察已建立”，阅读锚点、草稿和 window.__sends == 2 断言通过。

用例随后在全局流请求 method 序列断言失败。原始序列为 POST、GET、GET、POST、GET、GET、GET、GET；测试预期 POST、POST、GET、GET、GET、GET。raw API path 按 Run ID 统计发现：首个 Run 有 2 次 GET /runs/{firstRunId}/stream，第二个 Run 有 4 次 GET /runs/{secondRunId}/stream，正符合第二个 Run 的 3 次失败恢复 GET 加手动重连 GET 预算。故失败来自全局数组包含首个 Run 的两个自动恢复 GET；没有放宽恢复预算。API snapshot 共 24 条 path/method 记录，含 2 个全局 POST /stream 和首个 Run 的 1 个 /approval-decisions POST。

failure snapshot 同时记录了真实可信鼠标事件：处理审批、批准、提交决策、发送、重新连接，各自的 pointer/click 目标和坐标均在 nativeControlEvents 中。workflow 文件只写到 approval 与 send 阶段；reconnect stage 写入发生在失败断言之后。取消确认操作未执行。raw API 观察只记录 path/method，不含响应状态；因此不单独声称 snapshot 证明三次状态码为 503。

此宽屏原型未启动屏幕键盘；不作为 Story 114 的 OSK 并存验收。虽然 TrayNotice、审批、发送和重连路径到达，整项仍为失败，且取消阶段缺失；不能合并成四操作全通过。

用例在 15.407 秒结束（cases.json）；unittest stdout 报 20.565 秒。无模型调用。没有修改产品代码、断言、系统设置、剪贴板或 Git，也没有重跑失败批次。

## 证据与清理

- [预检（原始产物已删除）](../../../../../README.md#已删除的材料)、[命令记录（原始产物已删除）](../../../../../README.md#已删除的材料)、[事件/path 分析与 post-hash（原始产物已删除）](../../../../../README.md#已删除的材料)、[Win32 HWND 清理复核（原始产物已删除）](../../../../../README.md#已删除的材料)
- [stdout（原始产物已删除）](../../../../../README.md#已删除的材料)、[stderr（原始产物已删除）](../../../../../README.md#已删除的材料)、[summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases（原始产物已删除）](../../../../../README.md#已删除的材料)
- [失败快照（原始产物已删除）](../../../../../README.md#已删除的材料)、[审批/发送 workflow 阶段（原始产物已删除）](../../../../../README.md#已删除的材料)、[失败截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[审批阶段截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[发送阶段截图（原始产物已删除）](../../../../../README.md#已删除的材料)

清理后本例 Tauri HWND 10879944 已失效，owner PID 3528 已退出；没有 OSK 或 native backend/application 进程残留。9238/45200 无监听；5173 PID 23344、预存 TabTip PID 14204 保持。按 invocation 开始时间的 UTC 检查没有发现本批新建/更新的 shikigen native acceptance 临时目录；没有删除目录。

此结果仅代表 1440 原型的一次验证，不更新票据状态。
