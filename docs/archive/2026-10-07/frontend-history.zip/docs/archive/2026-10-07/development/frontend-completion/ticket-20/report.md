> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第20票：会话标题、日期时间与空态引导

日期：2026-10-06。来源：[实施票据](../../../../../wayfinder/frontend-completion/implementation/20-conversation-titles-time-empty-state.md)、[统一规格 §7/8](../PRD.md)、[交互契约 §4/5](../../../../../wayfinder/frontend-completion/tickets/006-interaction-acceptance.contract.md)、[前端设计规范](../../../../../../frontend/design.md)。

当前：第20票已验收，产品实现、最终完整前端回归、原生四场景复验及双轴静态审查完成，主agent核对六条验收证据后关闭票据。下一票为第21票“原稿风格的响应式导航与桌面偏好”，尚未开始。用户明确要求本轮不操作 Git；固定点为实施前文件备份 [before/（临时产物已清理）](../../../README.md#已清理的临时产物)，使用 [prepare_review.py（原始产物已删除）](../../../README.md#已删除的材料) 生成 [review.diff（原始产物已删除）](../../../README.md#已删除的材料)，未调用 Git。

## 实现与职责

- `frontend/src/conversation-titles.ts`：独立的显示缓存。服务端非空标题优先，首条已提交 human 消息的字符串／明确 type=text 文本块派生临时标题，不猜未知对象、不取草稿或预览。临时标题按原顺序提取文本并整理为一行，最多48个完整 grapheme，超长另加省略号；原始消息不变。缓存记录会话、Run、seq、message_id与派生名，跨重启保留。完整历史重新核对来源，部分读取不能擦除或替换较早来源。失败保留内存并提示。
- `conversation-state.ts`：复用既有选中会话历史、已提交 SSE、运行保存内容及事件读取；不为标题批量读其他历史，不 PATCH，不以缓存证明执行或发送接受。标题存储故障通过独立 `titleStorageIssue` 传递到 App，不混入消息／审批 `storageIssue`，避免将已持久保存的草稿误报为仅内存保留。
- `conversation-time.ts`、`useConversationTime.ts`：独立本地展示时钟，按墙钟分钟对齐，隐藏停止、重新显示立即重算。依据真实 updated_at 显示“今天／昨天／更早／日期待确认”、相对时间和七天起日期；未来时间绝对显示，未知时间说明，完整本地时区及 UTC 可复制。UTC原值保留服务端微秒；非零偏移另转为 UTC，仍展示完整服务端原值。不改事实或排序，不触发额外 HTTP。
- `useConversations.ts`：列表、工具栏、本地过滤与导出共享显示标题；第22票后续命令检索消费同一会话展示数据。
- `Sidebar.tsx`、`ConversationIdentity.tsx`、`App.tsx`：列表行独立的完整标题／时间入口与工具栏入口，复用已有单前景抽屉、复制与焦点返回。采用原稿 Slate／Indigo、256px侧栏、紧凑文字与轻边框；触控入口44px。
- `Conversation.tsx`及草稿动作：区分未读／读取失败／真实空列表／空会话；无会话提供新建。三个任务示例只填入空草稿或在已有原文后加空行追加，保留所有空白、聚焦而不发送。动作核对当前会话；没有迟到读取的异步聚焦任务。
- 命名复核将本票新增布尔属性 `creating` 改为 `isCreating`。本票没有后端／Rust产品、数据库结构或依赖变更。

## 验证分工与证据

最终测试和审查均显式使用 **GPT-6-Luna / max**，主 agent 负责产品实现、修复和结果核对。前端与原生隔离；原生等待 dist 构建结束，独占9238／45200并逐字节校验复用5173静态服务，不停止外部进程。

- [前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/validation/frontend/report.md`）最新 `final-3`：完整 Node 回归 **246通过，0失败／跳过／取消**；TypeScript exit 0、无诊断；Vite生产构建 exit 0。此批覆盖完整本地时间复制、`isCreating` 命名和最后标题存储错误隔离修正，dist构建结束于21:33:04。较早245项完整回归、46项专项保留，不与最终246相加。
- [原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/validation/native/report.md`）最新 `final-5`：真实 Windows Tauri／WebView2 四项 **4通过，0失败／错误／跳过**，38.118秒、exit 0；5173的索引与两个引用资源经字节匹配，使用最新dist。默认权限批次卡于CDP连接，自动审批获准以 `require_escalated` 启动隔离主机和loopback服务后，实际完成本批产品验收。
- Python三个文件最终 `ruff check`、`ruff format --check` 各exit 0。检查范围为新增原生验收、`native_runner.py`、`prepare_review.py`；未改后端／Rust产品，不重复无关全套。
- Standards初审的1项布尔命名问题已修；[最终 Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/standards-final-review.md`）硬性违规0、判断性建议0、剩余问题0。[最终 Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/spec-final-review.md`）六项AC符合，严重度发现0；较早[Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/spec-review.md`）产品偏差0及其当时的实机证据待办作为历史保留。

### 最终执行命令

前端工作目录 `C:\code\shikigen-agent\frontend`：

```text
node --import tsx --test tests/*.mjs
node node_modules/typescript/bin/tsc --noEmit
node node_modules/vite/bin/vite.js build
```

原生与Python检查工作目录 `C:\code\shikigen-agent`，设置进程内 `UV_CACHE_DIR` 为临时目录，避免默认uv缓存访问限制：

```powershell
$env:UV_CACHE_DIR = Join-Path $env:TEMP 'ticket20-uv-cache'
uv run python .scratch/frontend-completion/ticket-20/native_runner.py --batch final-5
uv run ruff check frontend/src-tauri/tests/conversation_presentation_acceptance.py .scratch/frontend-completion/ticket-20/native_runner.py .scratch/frontend-completion/ticket-20/prepare_review.py
uv run ruff format --check frontend/src-tauri/tests/conversation_presentation_acceptance.py .scratch/frontend-completion/ticket-20/native_runner.py .scratch/frontend-completion/ticket-20/prepare_review.py
```

前端每条命令有独立时间／退出码记录；原生stdout见 [final-5.stdout.log（原始产物已删除）](../../../README.md#已删除的材料)，结果及截图见 [final-5/（临时产物已清理）](../../../README.md#已清理的临时产物)。主agent已读实际退出记录、完整Node汇总及构建输出，核对原生四个result.json、四张window.png和identity.png。

## 六条验收条件与证据

| 条件 | 最终证据 |
| --- | --- |
| 首条已提交明确用户文本、服务端优先、持久核对、限制读取 | Node专项覆盖原文／内容块／未知块／预览／grapheme／partial读取；原生标题用例核对真实提交历史、正式标题覆盖及null回退、只读取当前会话合法历史或已知Run消息且无PATCH。 |
| 列表／工具栏／过滤一致、完整查看、缓存故障 | 原生标题用例核对正式标题过滤和键盘打开完整只读抽屉；重启用例核对缓存纠正、读取500保留标题和标题存储故障独立提示。44px触控入口静态核对，物理触控联合检查在第23票。 |
| 真实更新时间、本地日历、七天阈值、完整时间复制 | Node覆盖全部阈值、微秒UTC、时区／DST／跨年；原生Asia/Shanghai分组与真实字段身份核对。UTC复制等于公开updated_at，本地时间复制等于完整页面值。 |
| 分钟／重新显示／跨日刷新、未来和未知、不增加HTTP | Node覆盖未来绝对、无效与缺失时间、未来日期待确认；原生虚拟分钟／午夜不发请求。真实WM_CLOSE隐藏及托盘重新显示通过，仅沿用一次列表和一次所选历史GET。 |
| 真空态、示例仅填入／追加、原文／焦点保留 | 原生三个示例逐字追加原有缩进和尾部空白，空草稿直接填入；无stream POST。迟到历史不抢模态或另一会话输入，切回原草稿保留。列表未读／失败及无会话新建分支静态核对。 |
| 公开读取、本地缓存、真实Tauri场景与草稿保护 | 最终Node246全套及原生final-5四项单批通过；真实native退出／重启、隔离SQLite公开历史读取、fetch记录、result.json和截图可核对。 |

新增前端展示专项共14项，包含最后标题错误与草稿持久状态隔离回归；它们已包含在246项全套中，不另累计。

## Standards

[最终报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/standards-final-review.md`）：硬性违规0、判断性smell建议0、剩余问题0。实体／布尔命名、标题存储独立语义及已有前端设计规则符合仓库约定；初审的布尔属性问题已改为 `isCreating`。静态审查未执行测试、构建或Git。

## Spec

[最终报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-20/spec-final-review.md`）：第20票六项AC均与当前实现和已有证据相符，P0／P1／P2／P3各0。标题来源、完整／部分历史缓存核对、共用显示标题、时间边界与显示时钟、空态及草稿焦点保护没有遗留偏差；特别核对最后 `titleStorageIssue` 独立发布。审查引用最终前端与原生证据，未重复执行测试。第21／22／23票的后续范围仍保留。

## 历史失败与修订

1. 主 agent 开发定向首次12通过／1失败，原因是夹具把默认GET的省略method视为错误；修正为显式默认GET。第二次12通过／1失败，原因是误用threads[0]核对a会话，而真实列表按id倒序让b位于首项；改为按真实会话id查找。原断言语义保留，最终开发专项13通过。
2. 主 agent 两次早期类型检查并行等待无输出，主动停止自己的进程；未取得退出码，不算通过。最终类型检查交轻量子 agent，取得exit 0。
3. 原生 `final-1` 的键盘入口未触发dialog，失败发生在复制之前；保留未完成验收。夹具补Page.bringToFront及CDP Enter字符以触发完整keypress，不以程序click替代键盘。
4. 原生缓存写失败警告等待超时；同页面重复注入全局const发生冲突。将新增注入包IIFE，不改产品或断言。
5. 原生焦点用例CDP返回“Object reference chain is too long”，表达式末尾返回DOM对象；改为只返回布尔值。保留焦点断言。
6. 最初Ruff发现6处E501、后来新增import发现I001，主 agent修正行长和导入排序。中间失败不算最终通过。
7. 前端验证发现完整本地时间没有复制入口，主 agent补CopyContent；Standards发现新增creating命名不符，主 agent改isCreating。修正后交轻量子 agent再查类型／构建及定向实机复制。
8. `final-2` 四项2通过／2失败，53.450秒、exit 1；两个失败均为测试按可见文字寻找无文字、只有aria-label的关闭按钮。主agent改用准确可访问标签定位并等待关闭，保留焦点和尾部断言。其已通过的部分不能使该历史批次变成4／4。
9. 原生核对发现只标题写入失败时，产品共用storageIssue误报草稿仅内存。主agent先新增公开store回归取得RED（1失败），然后分离titleStorageIssue，完整246项和最终原生缓存场景验证修正。草稿保存仍实际写入本地，不放宽原断言。
10. 最后夹具路径约束允许当前同一会话的完整历史及真实最后Run已保存消息两种公开读取；此前只允许全历史会误禁正常终态补读。仍禁止其他会话／Run及标题PATCH，不扩大产品请求范围。
11. `final-4` 四项0通过／4失败，137.751秒、exit 1，全部止于CDP endpoint初始化，尚未执行产品断言，只有空host日志，无截图或result.json。获准权限执行后的新目录final-5完整通过；不覆盖旧失败。final-3原生批次未执行，不计入数量。
12. 本轮默认uv缓存访问拒绝；临时缓存下新增两处E501，主agent修整后最终check和format各通过。全部原生失败批次、夹具原因、命令和局限见原生报告，不删除失败来取得通过。

## 实机证据范围

截图为真实 Tauri WebView 内容；CDP键盘／输入和公开剪贴板stub不等同物理键盘／OS剪贴板。时间阈值使用公开页面虚拟墙钟与纯函数边界验证，不声称等待了真实一分钟；真实隐藏／托盘显示已在final-5通过。原生边框、物理输入／系统IME、OS剪贴板及四档多尺寸联合检查继续归第23票，本票不将这些未执行检查算通过。Vite主chunk631.72kB大于500kB的非致命提示保留。

本票不更改后端／Rust产品、数据库结构、依赖或API；最终回归范围是完整前端、本票真实原生场景及新增Python检查。历史后端超时的needs-triage记录继续保留于实施索引，不以本票结果证明完整仓库全部测试通过。
