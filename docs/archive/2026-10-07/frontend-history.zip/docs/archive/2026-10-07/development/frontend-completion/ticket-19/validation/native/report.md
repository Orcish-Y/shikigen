> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 19 补充检查记录

验证模型：`gpt-6-luna`，推理强度 `max`
工作目录：`C:\code\shikigen-agent`

## 已完成的补充检查

| 检查 | 命令 | 结果 |
| --- | --- | --- |
| Ruff lint | `.venv/Scripts/python.exe -m ruff check frontend/src-tauri/tests/usage_settlement_acceptance.py .scratch/frontend-completion/ticket-19/native_runner.py .scratch/frontend-completion/ticket-19/prepare_review.py` | 通过，退出码 0 |
| Ruff 格式 | `.venv/Scripts/python.exe -m ruff format --check frontend/src-tauri/tests/usage_settlement_acceptance.py .scratch/frontend-completion/ticket-19/native_runner.py .scratch/frontend-completion/ticket-19/prepare_review.py` | 3 个文件均已格式化，退出码 0 |
| 后端用量专项 | `.venv/Scripts/python.exe -m unittest discover -s tests -p test_run_usage.py -v` | 9 项通过，0 失败，退出码 0 |

后端输出包含 LangChain 实验性流协议警告和“Subagent bash unavailable tools”诊断；对应测试均报告 `ok`，整组结果为 `OK`。完整 stdout/stderr 与逐命令 JSON 见同目录日志文件。

## 原生验收状态

**最终范围更新：**以下列出的 final-2／final-3 缺口已由新建的 `gpt-6-luna / max` agent 在 `native-evidence-final-4` 完成复验，**2／2 通过，91.236 秒、退出 0**。原始快照、注入标记和真实 Tauri 目标已独立记录；最终范围以[最新取证报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-19/validation/native-final/report.md`）及机器结果为准。四个唯一原生场景均有最终通过证据，两批重叠不累计为六项。历史失败仍保留，执行环境原因没有确认为特定权限根因。

默认沙箱批次 `native-final-1 --regression` 执行 **4 项，0 通过、2 失败、2 错误，退出码 1**；四项均在 CDP endpoint／WebSocket 阶段失败，未进入产品断言。`stderr` 含 `WinError 10054`。日志 `native-final-1.stdout.log`／`native-final-1.stderr.log`，耗时 90.785 秒；失败 artifact 保留在 `../../native/native-final-1/`，没有有效窗口截图。

第一次升权调用 `native-final-2 --regression` 在父 agent 中断停滞回合后，工具返回 aborted，耗时 971.3 秒，无 session id、退出码或 artifact。第二次调用 `native-final-1-escalated --regression` 同样被父 agent 中断等待，耗时 274.3 秒，没有 session id、退出码或 artifact。两次都不计作测试结果。

获批 runner 前缀后，批次 `native-final-1-escalated --regression` **4／4 通过，退出码 0，耗时 117.573 秒**。四项真实 Tauri/WebView 测试均留下 `result.json` 和截图，主结果位于 `../../native/native-final-1-escalated/`：

| 场景 | 实际证据 |
| --- | --- |
| 12 次真实间隔核实，摘要／详情暂停与主动继续 | 12 个后续请求的完成至下次启动间隔约 5.008–5.019 秒；暂停和继续后的真实快照是 `completed`、`usage_pending=false`、27 tokens。截图：`UsageSettlementAcceptance/test_twelve_real_time_reads_pause_and_manual_continue_in_summary_and_details/paused-summary.png` 与 `window.png`。 |
| 503 重试与手动恢复 | 四个 503 请求后按约 1／2／5 秒重试，暂停后手动 GET 成功；真实快照保留 27 tokens。截图：`UsageSettlementAcceptance/test_recoverable_failures_stop_after_three_retries_and_manual_read_recovers/window.png`。 |
| 取消后详情关闭仍读取晚量 | 真实取消与晚到快照均为 `cancelled`，`updated_at` 相同（`2026-10-06T19:29:13.519932+08:00`）；晚到快照 `usage_pending=false`、0 tokens。截图：`CancelUsageSettlementAcceptance/test_actual_cancel_late_usage_is_verified_with_details_closed/window.png`。 |
| 既有审批／事件／完整 JSON／阅读位置回归 | 通过；完整事件子视图返回保持位置 250，随后设置位置 180，EOF 补读前后仍保持 180。截图：`RunEventsAcceptance/test_required_complete_json_actual_decisions_eof_and_reading_position/window.png` 与 `required.png`。 |

**取证字段限制：**前两项通过批次的原生断言和 UI 行为通过，但测试记录里的 `actualSnapshot` 是响应对象的别名；随后将响应 `usage_pending` 注入为 `true` 时，它也被改写。因此该字段不能代表注入前的后端值。主 agent 用 `structuredClone` 修复了取证代码，产品 UI 和断言未改。新进程批次 `native-evidence-final-2` 只重跑这两项，但均在握手阶段收到 CDP `WinError 10054`，2 项、0 通过、2 错误、退出码 1，19.934 秒；未到传输注入断言，没有截图或 `result.json`。随后批次 `native-evidence-final-3` 复用稳定连接 helper，两项仍在等待 CDP endpoint 时超时，2 项、0 通过、2 失败、退出码 1，66.472 秒；host 日志为空，没有截图或 `result.json`，同样未到注入断言。因此，两个用例的成功 UI/重试行为保留在首次 4／4 通过批次中，但修复后脚本记录的注入前 `usage_pending` 独立原始快照字段仍未实机确认。

最终六文件 Node 定向回归 82／82、TypeScript、Vite build 均通过；三个 Python 文件最新 Ruff lint／format 均退出 0。取证 helper 最后两次修改仅用于连接和保存原始响应，未改产品 UI、断言或 dist。构建与前端测试记录见 `../frontend/report.md` 和同目录 `command-results.json`。后端 `test_run_usage.py` 9／9 通过。本次未重跑完整 Node suite、后端全量或 Rust 测试。

取证脚本格式检查的中间失败也保留：一次因单行 LF/CRLF 不一致，一次因连接说明注释超过 Ruff 行宽；主 agent 修正后，最终三文件 `ruff check` 与 `ruff format --check` 均退出 0。主 agent 已要求停止后续原生启动；final-2／final-3 的连接问题未被归因为产品或特定权限根因，也没有继续盲目重试。
