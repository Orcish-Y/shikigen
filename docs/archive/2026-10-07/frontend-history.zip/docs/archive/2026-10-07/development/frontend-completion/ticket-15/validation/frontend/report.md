> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 15 前端／原生最终验证报告

> 主 agent 收尾补充：本报告记录原验证 agent 的执行范围与早期原生失败。随后当前桌面环境的独立 `gpt-6-luna / max` 子 agent 完成原生探针1项、剩余7项专项＋3项回归10项，均通过；原始失败仍保留。当前原生结论见[独立报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/validation/native-current-environment/report.md`），总体验收见[第15票报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-15/report.md`）。

- 验证执行者：gpt-6-luna / max（按主 agent 委派设置）
- 日期：2026-10-06（Asia/Shanghai）
- 工作目录：C:\code\shikigen-agent
- 测试子 agent 未修改产品代码、测试断言或 Git 状态；只生成验证日志、诊断 JSON 和本报告。pnpm build 按要求刷新了 frontend/dist。

## 结论

最新源码的前端定向 Node 用例 15/15 通过；tsc --noEmit、Vite build、Ruff check 和 Ruff format check 均退出码 0。构建仅报告现有的单个 JS chunk 超过 500 kB 警告。

原生 GUI 尚不能判为通过。final-1 的 11 项有 9 项通过、2 项失败；其中一项是旧 dist 上的消息身份用例，另一项暴露了 no-default chooser 证据采集缺口。final-2 的 11 项全部在连接 Tauri/CDP endpoint 9238 时超时，未进入功能断言；这属于原生运行环境阻塞，不能算作功能测试通过，也不能算作 11 个功能缺陷。主 agent 已将后续原生环境诊断交给独立 agent；本验证 agent 未再启动 GUI 或占用端口。

## 前端与静态检查

| 检查 | 命令与工作目录 | 结果 |
|---|---|---|
| 初始完整 Node suite | pnpm test，cwd frontend | 179 通过，0 失败，0 跳过；187.553 秒，exit 0。属于早期基线。 |
| 21 项定向 Node | pnpm exec node --import tsx --test tests/workspace-file-open.test.mjs tests/message-content.test.mjs tests/workspace-images.test.mjs，cwd frontend | 21 通过，0 失败，0 跳过；112.352 秒，exit 0。 |
| 最新 15 项定向 Node | pnpm exec node --import tsx --test tests/workspace-file-open.test.mjs tests/message-content.test.mjs，cwd frontend | 15 通过，0 失败，0 跳过；33.752 秒，exit 0。覆盖目录只读、准备失败后的只读说明、原消息和内容块身份及消息正文。 |
| TypeScript | pnpm exec tsc --noEmit，cwd frontend | 最新源码 exit 0。 |
| Vite build | pnpm build，cwd frontend | 最新源码 exit 0；只有 Some chunks are larger than 500 kB after minification 警告。dist/index.html 为 396 字节，最后更新时间 13:40:36。 |
| Native Python Ruff | .venv/Scripts/python.exe -m ruff check frontend/src-tauri/tests/workspace_file_open_acceptance.py .scratch/frontend-completion/ticket-15/native_runner.py，cwd repo root | 最新源码 All checks passed，exit 0。 |
| Native Python 格式 | .venv/Scripts/python.exe -m ruff format --check frontend/src-tauri/tests/workspace_file_open_acceptance.py .scratch/frontend-completion/ticket-15/native_runner.py，cwd repo root | 2 files already formatted，exit 0。 |
| Tauri host 示例 | cargo build --locked --example backend_window，cwd frontend/src-tauri | exit 0；仅有链接器输出警告。该构建在最后纯命名变更前完成；主 agent确认随后 Rust 变更只改测试实体名、产品代码未变。 |

最新 Node、tsc、build 和 Ruff 原始日志及 exit-code 文件均在本目录。完整 Node 179 项、21 项早期定向记录保留为历史基线，不替代最新的 15 项结果。

## 原生批次与证据

### final-1

执行命令（cwd repo root）：

~~~powershell
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-15/native_runner.py --batch final-1 --regression
~~~

运行器选择 11 项，9 通过、2 失败、0 跳过；118.564 秒，exit 1。共享 5173 服务被复用；运行器报告 dist index 为 396 字节、2 个 asset。没有终止或重启共享服务。

通过项包括取消/焦点、文件变化后重新准备、命令拒绝越界、会话/租约切换、图片入口确认、真实默认程序打开一次，以及 3 个既有 Markdown/图片回归。

失败项：

1. test_source_message_identity_and_real_backend_failure_revoke_and_restore_focus：等待把消息身份改成 replacement-message 后的探针超时。该批次使用旧 dist，发生在当前消息身份修复之前。
2. test_unassociated_file_uses_actual_os_result_and_never_reuses_confirmation：OS 调用返回 true，但旧夹具只收集可见标题，未取得 chooser 证据，断言 chooser_windows 失败。之后对 Windows 的只读提升权限探针发现本轮新建 OpenWith.exe（PID 26016，2026-10-06 13:16:47.267，命令行 OpenWith.exe -Embedding），并观察到 HWND 0x5b0b1e、类名 Open With Dummy Window Class For Interim Dialog。同一 PID 的创建时间对应测试时段；它不是打开文件内容或可见 Picker 的证据。探针时它不是前景窗口，也没有子控件文本。既有 ApplicationFrameHost.exe（PID 16600）创建于 2026-09-30，不能归因于本次测试。没有关闭这些进程或任何用户窗口。

Windows 证据保存在 windows-after-final-1-elevated.json。探针以 IsWindowVisible 过滤候选窗口，因此记录的是 Win32 可见样式结果；它不证明 Picker 当时处于前景或显示了文件。原失败快照及截图位于 native/final-1/WorkspaceFileOpenAcceptance/ 对应测试目录。

### final-2

执行命令（cwd repo root）：

~~~powershell
.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-15/native_runner.py --batch final-2 --regression
~~~

运行器选择 11 项，11 项都在 WindowAcceptance.connect 的 endpoint 等待中失败；总计 359.947 秒，exit 1。测试启动阶段反复无法连接 9238，未进入产品功能断言；测试目录只有空的 host 日志。共享 5173 仍被复用（index 396 字节、2 个 asset）。本验证 agent 没有手动启动、关闭或杀死任何端口进程。45200 未由本 agent 单独诊断。

失败原始日志为 native-final-2.stderr.log，完整命令输出和退出码在 native-final-2.stdout.log、native-final-2.exit-code.txt。native artifacts 保留在 native/final-2/。

## 已确认的边界与未覆盖项

- Node bridge 测试中的公开 bridge 响应是模拟调用；它们不等同于真实 BackendManager 进程重启。
- final-1 的身份/恢复用例因旧 dist 探针超时而失败；final-2 未连接 endpoint。因此真实 Tauri host 重启后的消息身份、租约更新和焦点恢复目前没有成功的 GUI 验收证据。
- final-1 的默认程序用例验证系统接受并打开一次测试报告窗口；它不能证明默认应用完成读取文件。
- final-1 的 no-default 调用返回 true，后续确有本轮 OpenWith.exe 进程证据，但无 Picker 子文本/截图，不能把它报告为默认程序成功或文件已显示。
- 最新 no-default 夹具和最新 dist 尚未在成功建立 Tauri/CDP endpoint 的批次中验收。当前阻塞是原生运行环境/endpoint；主 agent已安排独立 agent 诊断，之后需按该 agent 的恢复结论运行受控 native 验收。
- 未运行全仓库测试，也未把未执行的 native 验收标作通过。

## 主要日志与证据

以下相对路径均从 repo root 解析：

- .scratch/frontend-completion/ticket-15/validation/frontend/pnpm-test.stdout.log
- .scratch/frontend-completion/ticket-15/validation/frontend/node-final-targeted.stdout.log
- .scratch/frontend-completion/ticket-15/validation/frontend/node-final-latest.stdout.log
- .scratch/frontend-completion/ticket-15/validation/frontend/tsc-final-latest.exit-code.txt
- .scratch/frontend-completion/ticket-15/validation/frontend/pnpm-build-final-latest.stderr.log
- .scratch/frontend-completion/ticket-15/validation/frontend/ruff-check-final-latest.stdout.log
- .scratch/frontend-completion/ticket-15/validation/frontend/ruff-format-final-latest.stdout.log
- .scratch/frontend-completion/ticket-15/validation/frontend/cargo-build-example-final.stderr.log
- .scratch/frontend-completion/ticket-15/validation/frontend/native-final-1.stderr.log
- .scratch/frontend-completion/ticket-15/validation/frontend/native-final-2.stderr.log
- .scratch/frontend-completion/ticket-15/validation/frontend/windows-after-final-1-elevated.json
