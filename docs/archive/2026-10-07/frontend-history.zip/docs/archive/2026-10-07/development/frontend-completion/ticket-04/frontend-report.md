> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 04 票前端最终验证报告

日期：2026-10-05（工作区本地时间）

## 执行者与范围

- 实际模型：`gpt-6-luna`；推理强度：`max`。
- 范围：第 04 票前端 Node 单测、TypeScript、生产构建、Ruff，以及真实 Tauri/WebView 的票 04 四项与票 03 三项串行验收。
- 未改产品代码或正式用例；验证产物、日志和本报告写入 `.scratch/frontend-completion/ticket-04/`。
- 本报告是前端验证结果，不代表全仓后端回归结果；后端测试由主 agent 另行汇总。

## 最终检查

| 检查 | 命令与工作目录 | 结果 | 日志 |
| --- | --- | --- | --- |
| 定向 Node | `node --experimental-strip-types --test tests/message-drafts.test.mjs tests/conversation-state.test.mjs tests/run-reconstruction.test.mjs`（`frontend/`） | exit 0；49 pass、0 fail、0 skip | `node-targeted-final.log` |
| TypeScript | `node frontend/node_modules/typescript/bin/tsc --noEmit -p frontend/tsconfig.json`（仓库根目录） | exit 0 | `direct-tsc-final.log` |
| 生产构建 | `pnpm.exe build`（`frontend/`） | exit 0；24.98 秒；产物 `index-BfBYdbL-.js`、`index-CSJzwBNI.css` | `build-final.log` |
| Ruff lint | `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/message_drafts_acceptance.py tests/test_server.py`（仓库根目录） | exit 0；All checks passed | `ruff-check-final.log` |
| Ruff 格式 | `.venv/Scripts/ruff.exe format --check frontend/src-tauri/tests/message_drafts_acceptance.py tests/test_server.py`（仓库根目录） | exit 0；2 files already formatted | `ruff-format-final.log` |
| 票 04 原生验收 | `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/message_drafts_acceptance.py`（仓库根目录） | exit 0；4 pass、0 fail、0 skip；32.051 秒 | `native.log` |
| 票 03 原生回归 | `.venv/Scripts/python.exe -X utf8 frontend/src-tauri/tests/run_reconstruction_acceptance.py`（仓库根目录） | exit 0；3 pass、0 fail、0 skip；20.642 秒 | `ticket03-regression-final.log` |

另有一次实现改动后的全量 Node 基线：`node --experimental-strip-types --test tests/*.test.mjs`（`frontend/`）exit 0，69 pass、0 fail、0 skip，日志 `node-suite.log`。该结果早于最后的辅助状态播报、缺失存储 API 提示与 Run 404 错误文案细化；这些最后改动由上表定向 49 项 Node、tsc 和构建覆盖。

## 原生验收证据

- 原文与组合输入、重启恢复：公开 POST 与持久 HumanMessage 正文逐字符相同，内容为 `  中文原文\n    缩进  \n`（包含首尾空格、缩进和末尾换行）。WebView 合成输入期间 Enter 未触发发送；真实 Tauri 窗口退出再启动后，下一条草稿 `下一条草稿\n  重启保留` 仍在。
- 迟到接受与未知结果：接受响应延迟期间编辑的新草稿没有被旧提交清掉。模拟传输层在服务器已接受后返回 500，历史仍有对应消息；页面显示待核对，用户查询和明确确认后没有自动重发。
- 显式新任务：确认后确实新增第二条 POST，原提交正文一致；期间写入的 `另写的新草稿` 保留。确认弹窗截图记录潜在重复执行说明。
- 运行期间编辑：运行中 textarea 仍可编辑；普通 Enter 没有产生第二次发送或触发底部运行操作；刷新后草稿仍保留。
- 票 03 的三项真实窗口回归均通过：页面读取已保存消息后仅在显式点击时发送、interrupted GET replay 不发 POST、旧暂停快照不覆盖当前已恢复运行状态。

票 04 结果 JSON：

- `.scratch/frontend-completion/ticket-04/native/test_original_enter_composition_and_draft_survive_native_restart/result.json`
- `.scratch/frontend-completion/ticket-04/native/test_late_acceptance_and_unknown_send_manual_confirmation/result.json`
- `.scratch/frontend-completion/ticket-04/native/test_explicit_new_task_is_a_new_post_and_preserves_newer_draft/result.json`
- `.scratch/frontend-completion/ticket-04/native/test_running_draft_stays_editable_and_enter_cannot_invoke_run_action/result.json`

关键截图：

- 迟到接受后待核对状态：`.scratch/frontend-completion/ticket-04/native/test_late_acceptance_and_unknown_send_manual_confirmation/unknown-send.png`
- 主动新任务确认弹窗：`.scratch/frontend-completion/ticket-04/native/test_explicit_new_task_is_a_new_post_and_preserves_newer_draft/confirm-new-task.png`
- 原文发送与重启后草稿：`.scratch/frontend-completion/ticket-04/native/test_original_enter_composition_and_draft_survive_native_restart/window.png`
- 其余两项 `window.png` 与全部 JSON 在相同的测试名子目录中；票 03 三项的 JSON 和截图位于 `.scratch/frontend-completion/ticket-03/native/` 下对应测试目录。

已目视检查 unknown-send、confirm-new-task 和重启恢复截图，页面与弹窗内容可读，视觉沿用现有工作台样式。

## 首轮原生失败与修复后结果

首次运行的 4 项原生测试全失败，命令 exit 1；完整输出保存在 `native-first.log`。首项已成功 POST 且服务端历史含原文，但 `window.__sends[0]` 为空；其余三项因拦截器未观察到 POST，分别超时等待迟到响应钩子、待核对界面和运行期发送计数。定位原因是 App 构造 `BackendClient` 时已绑定原始 `window.fetch`，原测试在页面加载后替换 `window.fetch`，因此没有拦截到请求。

主 agent 将正式验收夹具改为在 `Page.reload` 前用 `Page.addScriptToEvaluateOnNewDocument` 注入传输包装；断言未删除或放宽。最新脚本在最新 dist 上重跑后 4/4 通过。首轮日志保留供复核。

## 原生服务、资产与剩余覆盖

- 原生夹具在启动前校验 5173 返回的 index HTML 字节，以及 HTML 中声明的脚本／样式资源，与当前 `frontend/dist` 对应文件逐字节相同；最新 4 项和票 03 回归均通过此前置校验。当前主产物 SHA-256：
  - `frontend/dist/index.html`：`72C3A7780F77A12018DCB0B07078083C0BE68FA923322BAA408CF074985932A4`
  - `frontend/dist/assets/index-BfBYdbL-.js`：`EDB76CD4807F301A88937291B155066CFA43F1C02A9185E9AC24669B94004F73`
  - `frontend/dist/assets/index-CSJzwBNI.css`：`CE8B862FFC23677AE961CC94B149D3C6D87C2B00E7817CA69F48DBC862655EEE`
- PID 23344 是 `python -m http.server 5173 --bind 127.0.0.1 --directory C:\code\shikigen-agent\frontend\dist`。它在首次端口探测后出现，创建归属不能确定；按主 agent 指示保留并只读复用，没有停止。最终检查 5173 仍可连接，9238 与 45200 已释放。Tauri/backend 窗口由夹具退出清理。
- 输入法限制：原生脚本以 CDP `Input.imeSetComposition` 与 composition 键盘事件验证 WebView 组合输入保护；这不等于 Windows 系统中文 IME 候选面板、物理键盘或所有输入法的实机验证。系统 IME、多尺寸/边框/窄屏和触控联合验收仍是剩余覆盖。
- Python 后端单测与类型检查不属于本次前端验证范围；`tests/test_server.py` 本次只运行了 Ruff。
