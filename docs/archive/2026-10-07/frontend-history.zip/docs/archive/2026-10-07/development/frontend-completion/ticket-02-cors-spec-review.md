> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 02 CORS Spec 审查

基准：`f61190b44f099101cae37f976a2033eaaef49703`；范围仅本轮 CORS 修复及其回归，不审此前 `-X utf8` 改动。

## 做得好的

- `app/desktop.py:88-92` 仅在桌面托管 API 暴露 `Retry-After`；两个既有允许 Origin 与普通 HTTP／CLI 策略保持原样，符合“桌面 WebView 可读取分页重试等待时长”的需求。
- `tests/test_desktop.py:127-151` 通过隔离桌面进程实测开发和生产 Origin 的允许／暴露头，并检查未允许 Origin 不获 ACAO，回归覆盖了 CORS 范围。

## 需要修

- **已确认的实现偏差：0。** AC6 要求“Retry-After …可用”（`docs/wayfinder/frontend-completion/implementation/02-paginated-conversation-list.md:24`）；桌面 CORS 暴露该响应头，客户端再用 `response.headers.get("Retry-After")` 读取（`frontend/src/backend-client.ts:106-109`），实现方向与规格一致。
- 未发现超出规格的行为（scope creep）。

## 值得讨论

- **覆盖缺口，不是已确认的产品缺陷：**新增回归只请求返回 200 的 `/api/threads` 并检查 `Access-Control-Expose-Headers`（`tests/test_desktop.py:131-144`），未验证真实 503 响应含 `Retry-After` 且 WebView 能读取其值。规格还要求 GET 503 遵守 `Retry-After`（`.scratch/frontend-completion/PRD.md:404`）。真实 503／浏览器补证尚未完成；不能把本项回归视为该场景已通过。

**结论：**本次 CORS 改动无 Spec 代码 finding；有 1 项真实 503 浏览器路径的验收覆盖待补。

## 审查后的补证

2026-10-04，`gpt-6-luna`（max）已在隔离 Tauri 应用补齐上述路径。真实 FastAPI 会话游标查询返回 503、`Retry-After: 1` 与对应 CORS 头；同一 WebView 的跨端口 `fetch` 返回 `type=cors`，能读取 `Retry-After=1`。应用由可信 CDP 滚轮事件触发实际分页请求后，界面显示“1 秒后可重试”、禁用按钮并保留 20 行；0.5 秒观察窗内未产生自动重试。

主 agent 核对的结构化证据：[真实 503 与浏览器读取（原始产物已删除）](../../README.md#已删除的材料)；[执行日志（原始产物已删除）](../../README.md#已删除的材料)。该 CORS 覆盖缺口已补齐；这里的输入证据为真实 WebView 中的 CDP 事件，不代表物理 Windows 输入验收。
