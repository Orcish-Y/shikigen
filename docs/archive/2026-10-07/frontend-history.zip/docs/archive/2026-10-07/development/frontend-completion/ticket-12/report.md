> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 12 票：逐项审批并继续同一运行

日期：2026-10-06（Asia/Shanghai）。起始固定点：`a35232d461b38bdb48a8cbdad4ed6a59561dba0c`。

## 实现范围

- 新增真实审批卡片：按事件 seq、Interrupt 与动作原顺序展示；每项默认未选择，全部选完统一提交，未支持或无法解析的请求整组只读。
- 参数默认折叠，长 JSON 区块滚动、完整查看和复制复用既有内容组件；拒绝原因可选，切到批准时保留本地文字但提交批准不携带原因。
- 复用 `POST /api/threads/{thread_id}/runs/{run_id}/approval-decisions`，body 仍只有 `responses`；checkpoint 仅用于完整请求身份保护。首次发送暂停后自动 GET 核实，审批后继续同一 Run。
- 提交与取消互斥；只有本次 POST 的有效 metadata 结束 pending，后续 SSE 继续观察。失败先 GET 核实，不自动重发。历史只读真实 resolved／invalidated；Run 终态立即锁定旧卡片。
- 保持现有 Tauri 外壳、聊天时间线、只读抽屉和取消确认样式；底部“处理审批”定位卡片。旧 Run 参数详情按自己的 Run 状态标为历史，不随新 Run 改变。
- 命名整理包括审批模型 helper、`receiveFrame`／`createFrameReceiver`、`publishState`／`updateView`、`ConversationActions` 和测试辅助函数；未修改后端产品、Rust、公开协议或依赖。

跨重启审批草稿及完整未知提交恢复仍由第 13 票实施；本票选择仅在当前应用内保存。

## 验证分工与结果

主 agent 负责实现和修复；最终后端、前端及原生验证由显式 `gpt-6-luna / max` 子 agent 执行。HTTP/runtime 与原生测试串行，Node 和静态检查并行。专项和全量有重叠，不相加。

| 检查 | 结果 | 证据 |
| --- | --- | --- |
| 完整后端回归 | 321 项：320 通过、0 失败／错误、1 Windows 符号链接权限跳过 | [backend-report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-12/backend-report.md`）、[完整日志（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终真实 HTTP／Graph 审批专项 | 1 通过；2 Interrupt × 2 动作，批准工具执行、拒绝工具不执行，同 run_id 完成，重复提交拒绝 | [最终专项日志（原始产物已删除）](../../../README.md#已删除的材料) |
| 既有后端审批／取消／消息事务专项 | 33 通过 | [专项日志（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终完整 Node 回归 | 152 通过，失败／取消／跳过均 0；包含审批 12 项及重建／取消／草稿路径 | [frontend-report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-12/frontend-report.md`）、[最终全量日志（原始产物已删除）](../../../README.md#已删除的材料)、[元数据（原始产物已删除）](../../../README.md#已删除的材料) |
| 较早 Node 全量／受影响四文件 | 148／59 通过；最终全量已覆盖后续窄修复，结果有重叠不相加 | [frontend-report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-12/frontend-report.md`） |
| TypeScript／Vite | 通过；Vite 保留大于 500 kB chunk 的非致命提示 | [frontend-report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-12/frontend-report.md`） |
| 产品 ty／新增三文件 Ruff | 通过 | [backend-report.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-12/backend-report.md`） |
| 新增测试 ty | **未通过：2 条 LangGraph TypedDictLike 上界诊断**，没有 ignore／cast | [类型诊断（原始产物已删除）](../../../README.md#已删除的材料) |
| Tauri 原生串行验收首轮 | 12 项：0 通过、2 失败、10 错误、0 跳过；均止于 WebView／CDP 连接阶段，未进入业务断言 | [runner（原始产物已删除）](../../../README.md#已删除的材料)、[首轮原始日志（原始产物已删除）](../../../README.md#已删除的材料)、[元数据（原始产物已删除）](../../../README.md#已删除的材料) |
| 原生启动隔离诊断 | 受审查的本地实机执行后同一新用例 1 通过，13.20 秒；包含完整业务断言，普通沙箱失败保留 | [诊断日志（原始产物已删除）](../../../README.md#已删除的材料)、[元数据（原始产物已删除）](../../../README.md#已删除的材料) |
| 其余 11 项实机业务验收 | 9 通过、2 失败、0 错误／跳过；两个问题修复后另做定向回归 | [原始日志（原始产物已删除）](../../../README.md#已删除的材料)、[元数据（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终实机定向回归 | **7／7 通过，0 失败／错误／跳过**；4 项新增审批与 3 项既有取消／定位／GET 恢复，70.450 秒 | [最终日志（原始产物已删除）](../../../README.md#已删除的材料)、[元数据（原始产物已删除）](../../../README.md#已删除的材料)、[runner（原始产物已删除）](../../../README.md#已删除的材料) |

最终实机命令为 `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-12/native_final_recheck_runner.py`，根目录执行，2026-10-06 03:15:02–03:16:15（UTC+08:00）。本轮分批覆盖 12 个唯一原生用例；最终 7 项是修复后的回归，不能将之前的失败批次改算为全通过。复用已有 5173 静态服务前，逐字节校验本次构建的 index 和全部引用资源；9238／45200 在启动前空闲。本票没有 Rust 产品改动，未重复 Rust 构建或完整测试。

## 八条验收对应证据

| 条件 | 核对结果与证据 |
| --- | --- |
| 1．真实请求与原顺序 | 审批模型保留 seq、Interrupt／动作顺序及原始 namespace；[多动作实机记录（原始产物已删除）](../../../README.md#已删除的材料) 直接比较 GET required 与显示内容。 |
| 2．默认未选／不支持只读 | Node 审批专项核对默认 0／4、全部选择资格和整组只读；[不支持动作实机记录（原始产物已删除）](../../../README.md#已删除的材料) 核对零审批 POST，仍可确认取消。 |
| 3．完整只读参数／原文原因 | 实机比较复制与详情的完整参数，断言区块内滚动、切换选择保留拒绝原文且批准不携带原因；[参数抽屉截图（原始产物已删除）](../../../README.md#已删除的材料)。 |
| 4．完整 responses／checkpoint 保护 | [真实 HTTP 专项（原始产物已删除）](../../../README.md#已删除的材料) 与最终原生记录核对 2 Interrupt × 2 动作、responses 顺序及只有 responses 的 POST body；Node 核对完整身份变化。 |
| 5．pending 与来源隔离 | Node 覆盖错误 Run、GET／旧 POST metadata、隐藏切换、503 Retry-After；实机延迟 POST metadata，核对编辑／提交／取消禁用，并在 SSE 结束前解除 pending；[pending 截图（原始产物已删除）](../../../README.md#已删除的材料)。 |
| 6．真实处理事实／终态 | Node 核对 resolved／invalidated 与迟到 running；实机先核对取消快照不生成失效历史，再手动 GET 读取真实事件；[旧 Run 缺处理记录及历史详情（原始产物已删除）](../../../README.md#已删除的材料)。 |
| 7．底部定位／恢复入口 | [定位实机记录（原始产物已删除）](../../../README.md#已删除的材料)、[取消实机记录（原始产物已删除）](../../../README.md#已删除的材料) 与 Node 覆盖缺卡片、观察恢复、取消互斥。 |
| 8．公开接口与实机闭环 | 最终 4 个新原生用例全部通过，覆盖批准／拒绝、422 后保留选择并 GET 核实、同 Run 恢复、实际工具副作用、未支持决策和旧运行详情；HTTP 专项同时核对重复提交拒绝及真实持久记录。 |

主 agent 已核对最终原始日志、元数据、请求 JSON 与原生截图，两份独立审查无剩余硬问题，八条条件已满足；票据标记 done。类型工具限制和历史失败保留如下。

## 已修复问题与保留证据

- 未知提交经完整 GET 已核实后，补充 JSON 快照读取失败曾撤销审批资格；修复后 Node“未知提交经正常全量 GET 已核实，后续快照失败不撤销这次审批资格”覆盖此边界。
- Spec 审查发现旧终态审批参数在新 Run 中重开时漏标历史；已改为按详情目标 run_id 查询状态，新增原生回归。
- 实机取消后只有运行快照、尚未读取审批失效事实时，旧卡片已经只读，但缺少读取处理记录入口；现仅当前 Run 的卡片提供“读取审批记录”，复用有限 GET 恢复并禁止写请求在途时调用。第 12 项 Node 测试先红后绿，不把终态快照当审批事实。
- 历史参数实机脚本曾在空草稿时等待发送按钮可用；现先填入新草稿，再保留发送资格及抽屉历史断言，并明确断言旧卡片尚未读取 resolution。第一次失败日志保持原样。
- 尝试将测试状态改为 BaseModel 消除了 ty 诊断，却改变了 LangGraph v3 的 values 类型，不符合 Harness 的 dict 合同；HTTP 专项真实失败，随后恢复 TypedDict，最终 HTTP 专项通过。该失败及恢复证据保留在后端报告。
- 最小 [schema_diagnosis.py（原始产物已删除）](../../../README.md#已删除的材料) 使用官方 `MessagesState`／`AgentState` 也复现相同 ty 上界诊断；这是当前工具兼容限制，测试 ty 仍记未通过。
- 原生首次启动的 runner 缺少根 `tests/` 导入路径，执行 0/12，原日志保留；只修正验证运行配置后重跑。
- 普通沙箱中的 12 项均未连接成功 WebView／CDP；受审查的本地执行使同一首例通过，支持环境限制是共因，未认定具体被拦的 API。随后串行验证其余用例，避免重复已通过的路径。
- 首轮连接失败曾在旧票路径写入 8 个空宿主日志；已归档至 [bootstrap-old-paths/manifest.json（原始产物已删除）](../../../README.md#已删除的材料)，6 个旧票已跟踪日志按 HEAD 原始字节恢复。最终本票证据单独保存，旧历史没有被空日志覆盖。
- 主 agent 已查看实际 [pending 卡片截图（原始产物已删除）](../../../README.md#已删除的材料) 和 [参数抽屉截图（原始产物已删除）](../../../README.md#已删除的材料)：沿用既有浅色外壳、卡片边框和只读抽屉；参数长内容可滚动，审批选择仍在聊天卡片。
- 最终回归后再次核对[不支持动作取消截图（原始产物已删除）](../../../README.md#已删除的材料)与[新运行下旧参数截图（原始产物已删除）](../../../README.md#已删除的材料)；旧详情明确标为历史，当前新 Run 仍等待审批。

## 双轴审查

### Standards

独立对照 AGENTS.md、领域约定与 design.md，见 [standards-review.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-12/standards-review.md`）。命名发现已修正，最终复核无剩余硬标准违规；品牌身份类型及选择地址封装仅列为启发式建议。

### Spec

独立对照本票及审批取消契约，见 [spec-review.md](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-12/spec-review.md`）。参数历史标记与手动读取事实入口已复核；身份未区分会话的早期怀疑已撤回，完整请求身份含经协议校验的 checkpoint.thread_id。后端持久化 invalidated 不等于前端已读取该事实，原生回归明确覆盖这个差别。

## 剩余范围

第 13 票：审批草稿跨重启与进一步未知提交恢复。第 23 票：物理键盘、系统 IME、窗口边框及多尺寸联合验收。既有审批结算超时、空宿主退出超时、IME Enter 未 POST 的 needs-triage 记录继续保留；本票的单次通过不代表旧问题已找到根因。
