> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第15票最终验证交接

## 最新收尾补充（2026-10-06；覆盖下方初始执行计划的数量／状态）

- 全量基线：Node179、Rust34、Python资源HTTP8通过。Rust纯命名修正后专项9/check/fmt再次通过；后续不得把基线误写为最后产品变更后的全量结果。
- Spec复审修正：`messageIdentity` 绑定原会话／消息／内容块，prepare/confirm/MutationObserver核对同一路径与身份；另一消息同路径不可保活。图片详情带同身份。Overlay延后到DOM提交后恢复焦点，并回退可聚焦backend-screen、不抢新modal；已知尾斜线目录（含图片）只读可复制。Node增加两项，正文专项7+打开专项7=14。
- 原生新专项现在8项，加原图片2/Markdown1共11。`final-1` 用旧dist跑11：9通过、2失败，0跳过，118.564秒，保留原始日志。身份新用例按预期在旧dist失败；无关联用例OS接受true但缺chooser窗口证据，不计通过。
- 无关联观测修正：实际诊断捕获该轮创建的 `OpenWith.exe` 隐藏dummy宿主。使用真实 `AssocQueryStringW` 先核实新扩展无默认程序（hresult<0且executable空），不改注册表。prepare前记录全部窗口；只识别新hwnd的明确扩展名，或真实OpenWith.exe路径与dummy类；真OS返回前和接受后均观察，最多等10秒。仍要求实际系统派发证据，保存system-windows.json和is_visible，只清理本轮明确新宿主。隐藏宿主不代表选择器可见或文件已显示；Windows返回accepted不等于有默认程序。修正PyHANDLE不支持context manager的问题，显式try/finally.Close。
- Rust新增第10项公共边界用例：OS callback阻塞时宿主invalidate必须独立完成。开发红灯0通过/1失败/9过滤保留red-dispatch-lock.log；原实现末尾持ledger锁调用Tauri可跨主线程等待的OS回调，而main隐藏/关闭也需要锁，已在最终授权后drop ledger再派发，文件guard仍持有。派发开始前取消仍作废；派发开始后不承诺撤销OS。需最终专项10/check/fmt及重建example，不重复全34。
- 最新差异生成器覆盖18个候选文件，index尚未收尾时17个非空差异；完成后索引也将进入差异。未执行Git。

主 agent 已实现代码，测试子 agent 固定 `gpt-6-luna / max`。主 agent 修复产品和测试代码；测试子 agent 只运行、定位并记录，禁止调整代码/断言，禁止所有 Git 命令。根目录 C:/code/shikigen-agent，PowerShell；Python3.12 .venv/Scripts/python.exe，pnpm 已安装，Cargo/Rustup 在 scoop。workspace-write，网络受限；GUI 或沙箱拒绝必须用 require_escalated 申请，不可绕过。已有依赖无需更新或联网。先读 AGENTS.md。

## 规格与目标

- docs/wayfinder/frontend-completion/implementation/15-workspace-file-open.md：六条验收，完整实施规格 .scratch/frontend-completion/PRD.md 第14节；样式 frontend/design.md；领域 CONTEXT.md。
- Agent Markdown 明确本地文件链接、图片“用系统打开”：每次先准备并确认；系统默认程序打开同一核实目标；不影响 Run、SSE 或审批。
- 宿主只接受 startupId/path，读自管 BackendManager 地址；资源服务提供根与普通文件元数据。返回一次性 request_id、租约/工作目录身份/完整元数据。准备零打开。确认只传 requestId，无调用者 baseUrl/root/任意路径权限。
- main窗口绑定、300秒精确过期、先消费 token 再查询、重验工作目录和完整元数据/版本、原生 canonical containment；Windows 文件 guard 禁止写入/替换至派发结束。
- 取消/遮罩/Esc/关闭作废；隐藏/退出/租约变化宿主 invalidate。前端会话/隐藏/租约切换 dispose，迟到prepare token丢弃作废，晚open响应不重开。读取期间关闭也阻止尚未派发的打开。新 prepare 替换旧意图。
- 单前景、默认取消、焦点返回；目标变化/失败显示真实原因，只能手动重新准备并确认；成功只宣称系统接受，绝不自动重复。

## 改动与现有结果

- 新 Rust frontend/src-tauri/src/workspace_file_open.rs：WorkspaceFileOpens、get lease callback、只读 HTTP、原生文件范围校验、一用/过期/消费/取消。新 commands lib.rs prepare/open/discard；desktop.rs hide/close/exit invalidation，backend state publish同步失效。
- 新前端 src/workspace-file-open.ts（公开native IPC controller）；components/WorkspaceFileOpen.tsx（provider/hook/button/确认内容）。App.tsx串联同Overlay、切换/引用MutationObserver、单前景。MessageBody/WorkspaceImage/ContentViewer增加受控按钮；styles.css沿用小圆角、白色、Slate、靛蓝。
- 无 Python 产品、依赖/lock、数据库 schema 改动。
- 新tests/workspace_file_open.rs：9项真实本地 HTTP/磁盘 + 时间/OS边界回调；已有开发专项9通过。red-rust.log 首轮缺模块，green-rust-first.log 首轮 Windows verbatim路径断言失败，修复产品回调使用已核实普通路径后 green-rust-second.log 1通过，rust-targeted-development.log9通过。
- frontend/tests/workspace-file-open.test.mjs 7项，开发7通过。red-node.log 缺模块真实红灯；TypeScript开发通过。
- 新native workspace_file_open_acceptance.py 七个明确本地方法，继承夹具用于真实 Graph/HTTP/文件，不加载继承测试。实际默认程序test通过 Win32标题变化取得系统窗口证据，只清理明确新创建窗口，不关用户已有窗口；未注册扩展名使用真实 OS 返回或选择程序弹窗证据。
- .scratch/frontend-completion/ticket-15/native_runner.py --batch unique-name [--tests method...] [--regression]，默认7项，regression加旧图片2项和Markdown1项（10唯一）。复用 ticket12 dist校验器，不覆盖旧批次；失败抓body/calls/focus/dialogs/screenshot。
- 原生尚未运行，可能存在夹具问题，报告完整错误不掩盖。旧14票 auto-preview 测试包含“报告未自动读取”断言，应仍通过，点击前不会发 prepare。

## 验证分工与命令

Rust/后端 agent：新专项9必要重查 + cargo test --locked -- --test-threads=1（完整一次，含桌面进程测试，先询问/处理权限）；cargo check --locked；rustfmt --check --edition 2021 src/workspace_file_open.rs src/lib.rs src/desktop.rs tests/workspace_file_open.rs（cwd frontend/src-tauri），相关后台HTTP .venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_workspace_resources.py -v（cwd根）；不启动GUI/5173/9238/45200，不build examples。完成 Cargo 后及时通知主 agent，前端 agent 才build backend_window例子。

前端/原生 agent：cwd frontend：pnpm test（完整Node一次）、pnpm exec tsc --noEmit、pnpm build；根 Ruff check/format --check 新native/runner两个文件。等待主 agent 允许 Cargo 后，在 frontend/src-tauri cargo build --locked --example backend_window。用 require_escalated 执行真实 GUI：根 .venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-15/native_runner.py --batch final-1 --regression。5173已有共享服务必须校验当前dist逐字节，不占用杀掉；9238、45200独占串行。每个失败独立保存，若失败先报告定位；主 agent修复后只能追加新批次针对性回归。需具体声明模拟公开bridge ready-frame≠真实BackendManager重启；WebView CDP≠物理输入；实际默认程序成功/无默认程序分别区分真实/模拟。

## 最终记录

各agent独立目录 .scratch/frontend-completion/ticket-15/validation/rust-backend 或 frontend；报告包括实际模型、cwd/准确命令、每项退出码、通过/失败/跳过、实际时间、原始stdout/stderr日志、截图和错误复现、未覆盖范围。不添加永久约定，不修改票据状态，由主agent核对。已有历史审批结算/退出等待/IME超时 needs-triage 保留；不宣称全仓库全绿。
