> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 11 票：执行失败保存正文

实施进度：已验收。

票据：[执行失败后保存已生成的中止正文](../../../../../wayfinder/frontend-completion/implementation/11-failure-partial-message.md)。基线 `e0ea6aef1947dbb4b4a080ca993cfa05ddb99b6f`，本轮起初工作区干净。`implement` 授权实施、验证、审查并在当前分支提交。

## 改动

1. RunEventIngestor 使用同 Run 接入锁冻结所有非空未提交正文，原 message_id、预留 seq、拼接顺序和空白不变；取消与失败共用提取逻辑，失败写 `generation_status=error`，不猜 tool_calls。
2. RunTransitions 将失败正文、Run error、实际 error/code、生命周期与用量放入同一事务。事务提交后才发布与封口；已有 complete、工具和首个终态不改，下一 Run 根快照沿用第 10 票封存身份保护。
3. 保存失败时原执行任务持有正文和失败 outcome，以 1/2/4/8/10 秒（后续 10 秒）重试事务。等待时释放协调锁，取消仍能竞争；不重跑 Graph。启动失败交给有强引用的后台结算任务，首次尝试后返回原启动异常，shutdown 可停止所有者。
4. 正文外独立标“因失败中止”，按 design.md 使用 #B91C1C/#FEF2F2 错误语义色；取消继续中性。真实错误代码和原因复用既有 ContentBlock、ContentViewer 和复制，区内滚动与原稿样式保持一致。前端沿用终态一次补读、去重、失败手动读取和预览不导出路径。

## 验证进展

最终验证由显式 `gpt-6-luna / max` 测试子 agent 执行；主 agent 仅做开发定向检查、修复、证据核对和交付。专项与全套有重叠，不相加。

| 范围 | 当前真实结果 | 证据 |
| --- | --- | --- |
| 新后端专项 | 最终 12 通过，根重放夹具签名调整后该项另 1 通过 | [后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/backend-report.md`） |
| 相关旧后端专项 | 首轮 73 通过，启动路径修复后受影响 40 通过 | [后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/backend-report.md`） |
| 前端专项 / 全套 | 全套 140 通过；最后仅颜色／class 变化后受影响 6 通过，未重复全套 | [前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/frontend-report.md`） |
| TypeScript / 前端构建 | 最终 pnpm build（包含 tsc）exit 0；Vite chunk >500 kB 提示保留 | [最终构建（原始产物已删除）](../../../README.md#已删除的材料) |
| 产品和新增测试 ty / 9 个唯一 Python 文件 Ruff | 修复后通过；后端检查 7 文件、原生辅助检查 4 文件，其中 2 文件重叠；首轮失败保留 | [后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/backend-report.md`）、[原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/native-report.md`） |
| 原生首轮单 runner | 24 项＝22 通过、2 失败、0 错误／跳过，exit 1 | [日志](../../../unresolved-issues-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/logs/native-all.stderr.log`） |
| 原生后续定向检查 | 本票最终 1 通过，旧 04 原样隔离诊断 1 通过；本轮覆盖 24 个唯一用例，未再执行完整批次，首轮仍为 22 通过、2 失败 | [原生报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/native-report.md`） |
| 后端完整回归 | GUI 全部结束后单次 313 项：312 通过、0 失败／错误、1 Windows 符号链接权限跳过；exit 0 | [原始日志（原始产物已删除）](../../../README.md#已删除的材料)、[命令元数据（原始产物已删除）](../../../README.md#已删除的材料) |
| Standards / Spec | 均 0 剩余硬问题；Standards 2 项非阻塞讨论建议 | [Standards](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/standards-review.md`）、[Spec](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/spec-review.md`） |

## 首轮失败与修复记录

- 开发 TDD 第一次失败：只有用户消息，缺两条已接入正文；加入同事务保存后通过。回滚专项第一次失败：原任务已结束，无法重试结算；改为原任务持有失败结果后通过。开发工具结果记录见[交接](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/validation-context.md`），未伪造独立原始日志。
- 首轮新增测试 ty 3 个诊断，第二轮 1 个 replay 赋值签名诊断；改为非空 task 的显式断言、Graph 夹具的根快照重放模式，最终通过。首轮 Ruff 9 个诊断（闭包 except 变量、未用导入、导入排序、长行）；主 agent 修正后通过，原日志保留。
- 主 agent 自审启动失败发现同步持续重试可能阻塞 Lifecycle.shutdown 等待已接收操作；改为后台结算所有者并增加第 12 个专项，无 Graph 执行、回滚不宣称终态、关闭能完成。
- 原生新专项首轮卡在 `scrollHeight > clientHeight`。当时错误夹具只有三行，中间是没有换行的重复长文本，截图显示横向滚动，不能据此认定纵向未约束。保留原断言并增强夹具为 120 条真实换行明细，新专项 1 通过；不是将失败改算通过。
- Standards 首轮指出失败 marker 误用了取消中性色，违反 design.md:197。主 agent 修正样式并加强 Node class／原生 computed RGB 断言，受影响 Node 6、最终构建和本票原生 1 通过。审查复核已关闭该硬问题。
- 旧第 04 票合成 IME 后 Enter 等待用户消息超时。失败时输入框有焦点和原文，零 POST、空历史；未捕获当时完整事件。原样隔离诊断 1 通过，记录 compositionend 和普通 Enter 间隔约 88.8ms、按下时可发送。根因仍未确认，不称作已修或与本票无关，见[独立 needs-triage 问题](../../../../../issues/composition-enter-no-post.md)。

主 agent 已亲读原始日志／元数据及实机截图：[完整失败原因（原始产物已删除）](../../../README.md#已删除的材料)、[主工作台（原始产物已删除）](../../../README.md#已删除的材料)。最新原生 UTC 14:22:39.144–14:22:58.855，1/1 通过，exit 0；后续 9238/45200/45201 无监听、无 backend_window host，原 5173 PID 23344 保留。

后端唯一完整回归 UTC 14:24:42.343–14:33:04.745，unittest 用时 491.468 秒，wrapper 用时约 502.402 秒。主 agent 已核对原始 summary、退出码和跳过原因；最终 313 项包含新增 12 项，不能再加上专项数量。历史审批恢复／空宿主环境用例本轮未报错，这不确认历史根因或清除问题。

## 边界

完整保存只承诺停止接入前已经收到的非空正文；强杀前的内存片段不承诺跨进程恢复。持续存储失败期间 Run 保持原已提交状态，失败结果所有者只存在于当前进程，GET 不补写或重跑；shutdown 不伪造取消／失败终态。工具错误、连接错误、资源显示错误与 interrupted 仍使用各自状态。

本票无 Rust 产品／依赖修改，未重复 Rust 构建或测试。物理系统 IME、窗口边框及多尺寸联合验收仍归第 23 票。完整导出格式归第 16 票。

历史[审批结算超时](../../../../../issues/approval-resume-settlement-timeout.md)和[空宿主环境退出超时](../../../../../issues/empty-host-environment-startup-exit.md)保持 needs-triage，原始失败不改算通过。前者根因及与结算互斥变更的关系未知。

## Standards

依据 AGENTS.md、design.md 和项目静态检查配置审阅。失败标记颜色问题已修并经 Node／实机复核，当前 0 项硬问题；保留“失败结算异常分类”和“测试辅助代码重复”两项非阻塞讨论建议。完整记录见 [Standards 审查](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/standards-review.md`）。

## Spec

核对本票六条验收条件与 PRD 第 11 节，未发现确认的规格缺失或越界。静态审查不替代执行证据，详见 [Spec 审查](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/spec-review.md`）。

| 验收条件 | 实现与执行证据 |
| --- | --- |
| 全部已接入正文、身份／seq／空白、独立标记，已完成记录不改 | 后端原文、多消息、完整／工具记录专项；Node marker 专项；原生历史、RGB 和重开核对 |
| 原子提交、提交后发布、回滚可重试，无 GET 补写或 Graph 重跑 | SQLite 故障触发器、广播观测、GET 前后事件计数、原执行 owner／启动 owner 专项 |
| 首终态、晚到结算／用量、下一 Run 根重放 | 取消先赢／失败先赢、事务屏障、迟到用量、封存身份重放专项 |
| 非 Run 故障与 interrupted 区分，未知标记可读 | 后端工具／连接／interrupted 专项，Node 协议问题与非运行错误专项 |
| 终态补读、未确认预览不导出、完整原因 | Node 保存确认与手动恢复专项，原生 120 行原因的滚动／复制／完整查看 |
| 公开执行与持久查询边界、实机重读 | Runtime＋HTTP／SSE 临时 SQLite 专项，真实 Tauri 退出重开后的正文／原因／草稿记录 |

## 交付核对

票据已标 done，六条验收条件均有上述执行证据；索引推进到第 12 票。最终文档链接、改动范围与原始证据核对见[交付审阅](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-11/delivery-audit.md`）。源码与作者文档的 Git whitespace 检查无问题；完整检查有三处原始失败 DOM 中的输入空白，按保留原文要求不改动证据，不宣称完整 whitespace 检查通过。
