> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 18 规格审查

## 审查结论

- **缺失／部分实现：0 项。** 首轮发现的坏事件原文缺失已修复。规格要求未通过协议校验的记录仅以只读原文呈现（[AC 4](../../../../../wayfinder/frontend-completion/implementation/18-run-events-history.md#L22)、[005 契约 §7](../../../../../wayfinder/frontend-completion/tickets/005-run-details.contract.md#L148)）。当前 [run.py](../../../../../../app/routes/run.py#L48) 先读取并逐条校验；遇到不兼容事件时不返回部分列表，而以 `no-store` HTTP 500 返回完整原始行（[错误分支](../../../../../../app/routes/run.py#L61)）。[backend-client.ts](../../../../../../frontend/src/backend-client.ts#L267) 只把该结构化诊断转为不可重试的协议读取问题；普通 HTTP 错误保持原分类。失败响应未合并进共享投影，因此不会成为事件、消息或审批事实。
- **范围外扩：0 项。** JSON／SSE 查询、客户端读取协调及新增验收证据均对应 AC 7；用量轮询与历史 Run 选择器仍未纳入本票。
- **看似实现但行为错误：0 项。** 最终字号层级符合两份规范：事件标题／正文是 14px（[styles.css](../../../../../../frontend/src/styles.css#L898)）；普通次要操作、返回、toolbar 和筛选控件是 12px（[design.md §88](../../../../../../frontend/design.md#L88)、[styles.css](../../../../../../frontend/src/styles.css#L890)）；时间／seq 等辅助信息 11px；JSON 是 12px/20px（[design.md §90](../../../../../../frontend/design.md#L90)、[styles.css](../../../../../../frontend/src/styles.css#L905)）。窄屏事件操作、筛选与展开目标至少 44px（[005 契约 §9](../../../../../wayfinder/frontend-completion/tickets/005-run-details.contract.md#L182)、[styles.css](../../../../../../frontend/src/styles.css#L906)）。因此 §9 的“重要文字≥14px”不把设计规范明确标作“普通次要操作”的控件也统一提升到 14px。完整视图返回使用 `focus({preventScroll:true})`（[RunDetails.tsx](../../../../../../frontend/src/components/RunDetails.tsx#L88)）；最新 native acceptance 的 `scrollIntoView` 与截图在阅读位置断言后，只补视觉证据，不改产品行为或断言。

## 剩余限制

本审查只做静态复核，未运行测试或 Git 命令。四档视口的完整视觉验收按后续 native workflow 计划执行，不构成 Ticket 18 的剩余规格缺口。
