> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 08 票 Spec review

**模型：** gpt-6-luna / max

**范围：** 基线 `0c52c18060158ebe23151a66fcba88feb4273ccd` 后的 diff 与本票新增源文件；对照第 08 票验收条件、消息契约 §2/§4/§5/§6、`frontend/design.md` §3/§7。

## Missing / partial

无 Spec 偏差。`tool-records.ts:19–49` 按会话、Run、ID 唯一关联并维持调用顺序；`ToolCard.tsx:27–62` 用真实结果状态、Run 状态与 seq 展示原记录，附加数据区分 null/省略并复用完整内容组件；`tool-card-preferences.ts:6–40` 保留手动折叠并仅首次失败自动展开。对应第 08 票六项验收和契约 §6。

## Scope creep

无。`run-projection.ts:28–33` 的 `runStatuses` 仅补充工具卡片解释所属历史 Run 终态；独立工具演示在第 08 票要求范围内。

## Looks wrong

无。真实 Tauri 桌面和 390×780 WebView 截图中，默认折叠、失败红色文字与图标、局部长内容滚动符合 design §3/§7 与契约 §5/§6。物理窗口和系统 IME 保留给第 23 票。

**结论：** 本票实现与 Spec 一致；未发现缺漏、越界或明显视觉偏差。

## 增量复核

新增原生方法经 oracle 修正后通过：参数和非 null artifact 的复制/完整查看，以及 orphan 工具结果的原文复制/完整查看均与 HTTP 事实一致；同时确认 history 不变且无额外 POST。实现未变，本次增量复核无新 Spec finding，结论仍为 **0 项**。
