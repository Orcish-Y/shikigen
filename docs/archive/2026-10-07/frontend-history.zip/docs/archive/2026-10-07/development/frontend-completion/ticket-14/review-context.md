> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第14票双轴审查上下文

用户授权 implement 下一票但禁止 Git 操作。依用户要求，本轮不运行任何 Git 命令。审查固定点改用实施前实际文件副本 baseline/（本轮代码编辑前复制）及新增文件空基准；review.diff 由 prepare_review.py 用 difflib 生成，包含完整16文件差异。上一票已提交固定点 ea1b0cf 仅作上下文，不读取索引/分支。当前代码、规范、基准副本可自行读。没有本轮提交列表。

实施规格：docs/wayfinder/frontend-completion/implementation/14-workspace-image-preview.md，.scratch/frontend-completion/PRD.md §13，docs/wayfinder/frontend-completion/tickets/004-message-tools-export.contract.md 本地资源，frontend/design.md §本地图片。方案/开发/验证边界见 validation-context.md；code review 不是用绿灯代替规格核查。第15票系统程序打开文件不在本票。新增版本字段属于票据要求的实际版本元数据。

标准来源：实际 AGENTS.md（命名实体名词、布尔判断、函数明确动宾/后缀、业务词优先、架构先讲、实现/验证分工）；CONTEXT.md 领域词汇；frontend/design.md 当前设计；pyproject.toml 配置由工具负责不重复lint问题。报告遵用户先做得好、再需修、最后讨论，最后各轴统计。gpt-6-luna/max 显式执行审查；主 agent 负责任何产品修复。不要操作 Git、改产品或删/弱化测试，可写本票 spec-review.md / standards-review.md。

Standards smell baseline（均是判断性 heuristic，仓库规范优先，跳过工具已强制规则）：

- Mysterious Name：名字无法说明作用/持有事实；用清楚名称，若仍不能命名重新考虑设计。
- Duplicated Code：多个hunk重复同逻辑形状；抽共同逻辑。
- Feature Envy：方法大量操作别人持有的事实；将逻辑放到持有方。
- Data Clumps：同几个字段/参数总一起出现；以领域类型组合。
- Primitive Obsession：原始值代替应独立的领域概念；提供小型领域类型。
- Repeated Switches：同类型反复switch/if级联；共享一处类型处理或多态。
- Shotgun Surgery：一个逻辑改动要求散布许多文件；聚集共同变化。
- Divergent Change：一个模块因多个无关原因变化；按职责拆分。
- Speculative Generality：规格未要求的抽象/参数/hook；删除或内联到真实需要出现。
- Message Chains：调用方不该理解的深层导航；由目标模块隐藏。
- Middle Man：仅代理转发无价值类/函数；直接使用真实目标。
- Refused Bequest：子类忽略大多继承行为；优先组合。

Standards轴：逐file/hunk报告违反文档标准（引用file+rule）和判断性smell（名称+相关hunk），明确硬违反与建议；400词以内。

Spec轴：独立核查缺失/部分需求、未要求行为、看似实现但行为错误，每项引用规格条文；400词以内。特别核实根同文件工具、路径/file URI/链接边界、普通文件、状态码/MIME/20MiB、版本/租约、纯GET、仅Agent明确引用、SVG仅img、共享Blob取消/释放、长单消息图片锚点、手动重试与只读完整查看。
