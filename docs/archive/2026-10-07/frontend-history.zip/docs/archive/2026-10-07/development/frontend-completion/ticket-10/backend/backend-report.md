> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 10 票后端验证报告（P2 首事件窗口修复）

## 范围

- 执行模型：gpt-6-luna / max（按派发指定）
- 工作目录：`C:\code\shikigen-agent`
- 基准：`d7862fb50a7c5654661ca6d8967195d863c2d80e`
- 依据：第 10 票实施规格、PRD 第 10–11 节及最终冻结验证交接。
- 验证子任务未修改源码或测试；主 agent 添加 P2 回归用例、修复产品代码并格式化测试。之前所有日志均保留。

## 当前最终验证结果（serial-final）

执行模型：gpt-6-luna / max。工作目录：C:\code\shikigen-agent。完整回归在本机串行、无 GUI 运行。

| 检查 | 最新结果 | 计数／细节 | 日志 |
|---|---|---|---|
| Ticket10 后端专项 | 通过 | 10 passed，0 failed，0 skipped；Ran 10 in 30.220s | specialized-final5.log |
| 完整 Python unittest | 通过 | 301 tests；300 passed，0 failure，0 error，1 skipped；UTC 2026-10-05T12:55:43.3148414Z–13:01:53.5525934Z；unittest 359.477s，墙钟 370.238s，exit 0 | full-unittest-serial-final.log |
| Ruff check | 通过 | 11 个 Python 文件；All checks passed | ruff-check-all11-final9.log |
| Ruff format --check | 通过 | 11 files already formatted | ruff-format-all11-final9.log |
| 产品范围 ty | 通过 | ty check app packages/harness；产品源自 final5 后未变化，复用既有结果 | ty-product-scope-final5.log |
| 测试／fixture／native acceptance ty | 通过 | 5 个 Python 文件；All checks passed | ty-changed-tests-all5-final8.log |

唯一跳过项是 test_runtime_data.RuntimeDataTests.test_symlink_data_and_parent_are_rejected，原因是 Windows symlink 权限不可用（Windows symlink privilege is unavailable）。本次完整日志中 10 个 Ticket10 专项均为 ok；审批恢复结算用例本轮全量执行也为 ok。

## 历史回归与未决审批超时

final5 的完整回归历史结果保留：301 tests，299 passed、1 error、1 skipped，Ran 721.361s；错误发生于 test_approval_resume.ApprovalResumeTests.test_waits_for_previous_cleanup_and_survives_caller_cancellation 的 tests/test_approval_resume.py:258，settled.wait() 等待 3 秒超时，日志为 full-unittest-final5.log。

final10 的同一正式隔离命令连续执行两次，结果为 1 pass、1 error；第二次在同一行 TimeoutError，详见后文的时间与独立日志。随后 native 最终验证结束后，本次完整 serial-final 回归中该测试通过。不同运行结果说明该超时仍呈间歇性；根因尚未确认。相关状态表述为：已记录的审批恢复结算超时，尚未确认与本票改动的关系。不得推断为资源争用，也不得断言与本票改动无关。

## P2：首事件窗口红绿证据

- 修复前单项：`test_cancel_before_first_event_seals_delta_and_complete_ingestion` 失败，1 test / 1 failure。消息数应为 1，实际为 2；说明此前 `_previews` 没有 state 时取消直接提交，随后首个 delta 与完整消息仍能写入。日志：`before-first-fix-red.log`。
- 主 agent 修复 `RunEventIngestor.cancel`：无论预览是否已创建，都先按 `(thread_id, run_id)` 获取/创建 state 并持锁，再提交取消事务。
- 修复后全套专项 10/10 通过；新增首事件窗口用例验证排队 delta 与完整消息在事务期间阻塞、取消后不发出消息预览或持久化事实。日志：`specialized-final5.log`。

## 静态检查与格式历史

- final5 首次 Ruff format check 曾失败：仅 `tests/test_cancel_partial_message.py` 有两行需格式化；日志 `ruff-format-all9-final5.log` 保留。
- 主 agent 随后执行格式化（本票测试与 native acceptance）；没有改变断言或行为。final6 对全部 9 个 Python 改动文件重新跑 Ruff check 与 format check 均通过。日志分别为 `ruff-check-all9-final6.log`、`ruff-format-all9-final6.log`。
- 产品范围 `ty check app packages/harness` 与最终测试／夹具 `ty` 均通过；旧全仓默认 ty 474 诊断日志 `ty-check.log` 保留，但不作为本票产品范围门槛。

## 最终命令与工作目录

工作目录：C:\code\shikigen-agent。执行模型：gpt-6-luna / max。最终完整 unittest 命令为 .venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v；无 GUI 串行执行，UTC 起止时间、exit code 与完整逐项结果见 full-unittest-serial-final.log。

Ruff check 与 format --check 均对同一组 11 个 Python 文件执行，命令、文件清单及结果在 commands.txt 与下列 final9 日志中：
- .venv/Scripts/ruff.exe check packages/harness/shikigen/contracts/messages.py packages/harness/shikigen/persistence/chat_store.py packages/harness/shikigen/persistence/event_store.py packages/harness/shikigen/runtime/run_events.py packages/harness/shikigen/runtime/run_execution.py packages/harness/shikigen/runtime/runs.py tests/test_cancel_partial_message.py tests/desktop_cancel_fixtures.py frontend/src-tauri/tests/cancel_partial_acceptance.py frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/visibility_polling_acceptance.py
- .venv/Scripts/ruff.exe format --check packages/harness/shikigen/contracts/messages.py packages/harness/shikigen/persistence/chat_store.py packages/harness/shikigen/persistence/event_store.py packages/harness/shikigen/runtime/run_events.py packages/harness/shikigen/runtime/run_execution.py packages/harness/shikigen/runtime/runs.py tests/test_cancel_partial_message.py tests/desktop_cancel_fixtures.py frontend/src-tauri/tests/cancel_partial_acceptance.py frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/visibility_polling_acceptance.py

测试范围 ty 命令（5 个 tests/fixture/native acceptance 文件）：
.venv/Scripts/ty.exe check --extra-search-path tests --extra-search-path frontend/src-tauri/tests tests/test_cancel_partial_message.py tests/desktop_cancel_fixtures.py frontend/src-tauri/tests/cancel_partial_acceptance.py frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/visibility_polling_acceptance.py --output-format concise
产品范围 ty check app packages/harness 自 final5 后产品源未变，本轮复用 ty-product-scope-final5.log，未重复执行。

审批恢复结算用例隔离复测使用原命令两次，无修改 3 秒超时或断言：
.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_approval_resume.py -k test_waits_for_previous_cleanup_and_survives_caller_cancellation -v
两次各自日志与 UTC 元数据见 approval-timeout-isolated-1.log 和 approval-timeout-isolated-2.log。早期 TDD red、10 项专项及历次完整回归命令也完整保存在 commands.txt。

## 当前覆盖状态

10 项后端专项在 final5 独立运行通过，最终 301 项串行全量也包含并通过这 10 项。新首事件窗口测试覆盖 cancel 在首条 delta 前创建 Run state 并持锁提交时，排队的首个 delta 与 Graph 完整消息均被封口屏障阻止；其他专项覆盖回滚缓冲、原序号、完成/取消竞争、晚到用量与事实、审批失效等边界。

完整回归的最新结果为 serial-final 通过，唯一 skip 是 Windows symlink 权限限制。审批恢复结算超时在两次隔离复测中一过一错，而最终完整回归通过；该既有 needs-triage 问题仍未查明根因，也未确认与本票改动的关系。

## 本轮日志索引

- before-first-fix-red.log
- specialized-final2.log、specialized-final4.log、specialized-final5.log
- full-unittest-final2.log、full-unittest-final4.log、full-unittest-final5.log
- full-unittest-serial-final.log（最新 301 项串行全量，exit 0）
- approval-timeout-isolated-1.log、approval-timeout-isolated-2.log
- ruff-check-all9-final5.log、ruff-format-all9-final5.log（历史失败记录）
- ruff-check-all9-final6.log、ruff-format-all9-final6.log
- ruff-check-all11-final7.log、ruff-format-all11-final7.log
- ruff-check-all11-final8.log、ruff-format-all11-final8.log（E501／格式失败，保留）
- ruff-check-all11-final9.log、ruff-format-all11-final9.log（最新通过）
- ty-product-scope-final5.log
- ty-changed-tests-final5.log、ty-changed-tests-final6.log
- ty-changed-tests-all5-final7.log、ty-changed-tests-all5-final8.log（5 个文件通过）
- ty-check.log（默认全仓扫描 474 诊断，历史环境范围结果，不作为产品范围门槛）

## 最终静态检查补充（final7）

本轮执行模型：gpt-6-luna / max。工作目录：C:\code\shikigen-agent。仅运行 Ruff 与 ty 静态检查；本轮没有启动功能测试、原生验收、GUI、端口或数据库。

| 检查 | 范围与结果 | 证据 |
|---|---|---|
| Ruff check | 11 个 Python 文件通过，0 项诊断 | ruff-check-all11-final7.log |
| Ruff format --check | 11 个 Python 文件均已格式化 | ruff-format-all11-final7.log |
| ty 测试范围 | 5 个测试/fixture/原生验收脚本通过，0 项诊断 | ty-changed-tests-all5-final7.log |
| ty 产品范围 | 本轮未重复运行；final5 后产品源未改，沿用 ty-product-scope-final5.log 的 ty check app packages/harness 通过结果 | ty-product-scope-final5.log |

Ruff 的 11 文件范围为：harness 的 messages、chat_store、event_store、run_events、run_execution、runs；tests/test_cancel_partial_message.py、tests/desktop_cancel_fixtures.py；以及原生验收的 cancel、client、visibility_polling 三个 Python 脚本。ty 测试范围对新增的 client 与 visibility_polling 脚本及既有三个测试/fixture 一起检查，均无诊断。

历史 final5 完整 unittest 为 301 项：299 passed、1 error、1 skipped。唯一 error 是 approval-resume 测试在 tests/test_approval_resume.py:258 等待 3 秒超时；同一 needs-triage issue 及隔离复测记录均保留。其后 final10 隔离复测一过一错，最新 serial-final 全套则为 301 项通过（1 项 Windows symlink skip）；详情见报告顶部和隔离复测章节。根因仍未确认，也未确认与本票改动的关系。

## 最新脚本增量的静态复查（final8）

主 agent 增加了 cancel acceptance 中所属会话文案与 h1 的断言后，我按最新文件重跑了 11 文件 Ruff 与 5 文件 ty。ty 通过；Ruff check 和 format --check 均失败，问题限于 frontend/src-tauri/tests/cancel_partial_acceptance.py:77：E501，93 字符（上限 88），且该文件需 Ruff format 换行。其他 10 个 Ruff 范围文件已格式化。按职责未修改文件；失败原始日志保留在 ruff-check-all11-final8.log 与 ruff-format-all11-final8.log。final7 是该增量之前的通过快照，不能代表最新文件状态。等待主 agent 修复后再做静态复查。

## 修复后的 Ruff 复查（final9）

主 agent 仅对 cancel_partial_acceptance.py 的新断言换行格式化后，我按同一 11 文件范围重跑 Ruff：check 通过，format --check 显示 11 files already formatted。final8 的 E501/格式失败日志保留为真实历史记录；最新静态状态由 final9 日志表示。本轮未重跑 ty，也未启动动态测试。

## Approval-resume 间歇性隔离复测（final10）

执行模型：gpt-6-luna / max。工作目录：C:\code\shikigen-agent。严格按原正式命令串行运行两次；未修改测试、3 秒等待或断言。

命令：.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_approval_resume.py -k test_waits_for_previous_cleanup_and_survives_caller_cancellation -v

| 尝试 | UTC 时间 | unittest 结果 | 墙钟时间 | 日志 |
|---|---|---|---:|---|
| 1 | 2026-10-05 12:53:26.151–12:53:43.451 | 1 passed，0 error，0 skipped；测试耗时 12.430 秒；exit 0 | 17.300 秒 | approval-timeout-isolated-1.log |
| 2 | 2026-10-05 12:53:58.922–12:54:10.800 | 0 passed，1 error，0 skipped；测试耗时 6.557 秒；在 tests/test_approval_resume.py:258 等待 settled.wait() 3 秒后 TimeoutError；exit 1 | 11.878 秒 | approval-timeout-isolated-2.log |

第二次失败后没有自动重试；当时依停止条件先停止动态验证。主 agent 随后授权唯一一轮串行完整 unittest：301 tests，300 passed、0 error、1 Windows symlink skip，Ran 359.477s，墙钟 370.238s，exit 0；日志 full-unittest-serial-final.log。完整回归中该 approval-resume 测试为 ok。隔离 1 pass / 1 error 与该全量通过共同表明结果有波动，needs-triage 根因未确认；没有证据将失败归于资源争用或断言与本票改动无关。
