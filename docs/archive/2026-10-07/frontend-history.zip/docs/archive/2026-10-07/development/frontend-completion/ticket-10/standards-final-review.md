> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 10 Standards 最终增量审查

审查基准：`d7862fb50a7c5654661ca6d8967195d863c2d80e`。模型：`gpt-6-luna / max`。审查命令：`git diff d7862fb50a7c5654661ca6d8967195d863c2d80e --`，并用 `rg -n` 与定点文件读取核对以下增量。未运行功能测试或 GUI。

## 做得好的

- `frontend/src/chat-reading-position.ts:17-25` 将共享容差定为 `0.5` CSS px，锚点布局比较两侧使用同一边界；`frontend/src/useChatReading.ts:42-44` 也只在差值 `> 0.5` 时写 `scrollTop`。这符合 `frontend/design.md:280` 的“用户上翻阅读后不抢夺滚动”，并避免亚像素测量噪声打断浏览器滚动。
- `frontend/tests/chat-reading-position.test.mjs:109-116` 同时断言 `1/64` px 抖动仍可识别滚动意图、真实 `1` px 锚点位移会改变布局判定，没有放宽原断言。
- `frontend/src-tauri/tests/client_acceptance.py:20-35` 最多等待 10 秒直到按钮可用，随后保留原有断言和点击；`visibility_polling_acceptance.py:97-110` 将宽泛的 `/messages` 计数拆为历史与运行消息两个精确路径断言，检查更明确。

## 需要修

未发现文档硬性标准违规或测试断言弱化。

## 值得讨论

- **启发式：可能的 Repeated Switches，沿用原报告，非硬性违规。** `frontend/src/components/Conversation.tsx:90,95` 与 `frontend/src/App.tsx:428`、`frontend/src/backend-client.ts:209` 重复列出终态；共享谓词 `frontend/src/run-projection.ts:18` 已存在。原报告建议统一终态判断，保留该建议供后续维护时考虑。
- **覆盖观察，非标准违规：** 新单测直接覆盖纯几何比较；`useChatReading.ts:42-44` 的 DOM 写入阈值未由该单测直接断言。可由本票原生 trace 验证这条路径，避免把几何单测当作 Home 原生滚动完整复现的证据。

本报告不是整体验收结论。主 agent 当前汇总为后端 301 项中 299 pass、1 error、1 skip；已知 3 秒超时仍未解决，因此当前批次不能标为全绿。
