> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 历史诊断代码

`default_download_probe.py.txt` 是 `default-download-6-default-pref` 单变量对照实际使用的原始 wrapper，按原字节归档。它依赖修正前夹具强制 `prompt_for_download=true`，不适用于现在的夹具，也不作为当前可执行测试入口。

原始对照移除该键后下载完成且退出后文件仍存在；原始文件的 Ruff I001 诊断保留在该批预检中。当前默认下载的回归入口为 `native_runner.py` 的原用例，不使用 wrapper。归档改用 `.txt`，避免将历史诊断代码误作为当前测试执行或静态检查对象。
