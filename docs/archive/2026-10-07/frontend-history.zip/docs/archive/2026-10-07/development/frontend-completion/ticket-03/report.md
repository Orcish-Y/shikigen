> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 3 票实施与验证记录

开始：2026-10-04；收尾：2026-10-05。票据：[全量重建消息与当前运行事实](../../../../../wayfinder/frontend-completion/implementation/03-run-fact-reconstruction.md)。本票全部验收完成，Status: done；索引 frontier 为第 4 票，本轮未启动第 4 票。

## 实现

- [run-protocol.ts](../../../../../../frontend/src/run-protocol.ts) 校验公开消息、Run 身份和四类 SSE；非法结构、JSON 截断和错误身份不接入事实，保留只读原文。
- [run-projection.ts](../../../../../../frontend/src/run-projection.ts) 将完整消息、当前观察的预览、各 Run 元数据与持久事件放入一份会话投影。完整事实按 seq 合并，重复不增加一行；delta 按到达顺序追加。历史缺项不删已知事实。
- [ConversationStore](../../../../../../frontend/src/conversation-state.ts) 绑定后端租约、选择 controller、观察对象和 Run。新 GET 的第一帧有效 metadata 才重置目标 Run 预览；切换只停止观察。新 Run 不继承旧错误、用量和完成时间，稀疏旧查询不能退回旧 Run。
- metadata 决定有效观察的当前状态；同 Run 终态不回退，历史 lifecycle 只作历史。正常 GET EOF 补读一次快照；查询旧空值不清除已确认失败和完成字段，usage=null 仍表示未知。
- 审批根据本次 GET required／resolved／invalidated 按 seq 重建，只在 interrupted 正常 EOF 后核实。处理 ID 必须完整覆盖对应 Interrupt；已处理或失效的 checkpoint 不能被更高 seq 的 required 重新开放。快照不创建审批资格。
- 页面复用现有徽标、提示和折叠原文，增加未保存预览、审批核实进度和协议问题只读原文。本票提供审批身份输入，提交交互仍归第 12 票。

后端产品、Rust 宿主与 CSS 未修改。Git stage／commit／分支和 AGENTS.md 未修改。审查固定点为本轮开始前工作副本；[文件范围（原始产物已删除）](../../../README.md#已删除的材料)与[完整差异（原始产物已删除）](../../../README.md#已删除的材料)保留本轮记录。

## 最终验证分工

所有最终执行使用 `gpt-6-luna / max`。主 agent 负责架构、产品与正式回归用例、失败判断和修复，测试子 agent 不修改产品或正式测试。因团队线程数量上限，完成 Standards 审查的同模型子 agent 接手前端验证，完整交接与执行证据仍独立留档。工作目录／命令／退出码详见[后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-03/backend-report.md`）、[前端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-03/frontend-report.md`）与[交接](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-03/validation-context.md`）。

| 批次 | 实际结果 | 证据 |
| --- | --- | --- |
| Python 6 个专项模块 | 60 通过，0 失败／跳过 | [后端报告](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-03/backend-report.md`） |
| Python 完整回归，一次 | 290 项：289 通过、1 环境跳过、0 失败 | [原始输出（原始产物已删除）](../../../README.md#已删除的材料)、[exitcode=0（原始产物已删除）](../../../README.md#已删除的材料) |
| Python production ty | 通过 | [原始输出（原始产物已删除）](../../../README.md#已删除的材料)、[exitcode=0（原始产物已删除）](../../../README.md#已删除的材料) |
| 公开 GET 真实审批／损坏 checkpoint 探针 | 两场景通过，无工具执行、无自动 start／resume | [探针（原始产物已删除）](../../../README.md#已删除的材料)、[输出（原始产物已删除）](../../../README.md#已删除的材料) |
| 前端首轮全套 | 42 项：41 通过、1 旧工具 fixture 缺字段失败 | [原始失败（原始产物已删除）](../../../README.md#已删除的材料) |
| 修复 fixture／EOF／审批集合后的前端全套 | 48 通过，0 失败／跳过 | [原始输出（原始产物已删除）](../../../README.md#已删除的材料)、[exitcode=0（原始产物已删除）](../../../README.md#已删除的材料) |
| 最后 checkpoint 防复活补修后的相关前端回归 | 42 通过，0 失败／跳过；另 9 项无关验证沿用上批 | [原始输出（原始产物已删除）](../../../README.md#已删除的材料)、[exitcode=0（原始产物已删除）](../../../README.md#已删除的材料) |
| 最终 tsc／Vite build | 通过，JS `index-BLDl1oVD.js` | [tsc（原始产物已删除）](../../../README.md#已删除的材料)、[最终构建（原始产物已删除）](../../../README.md#已删除的材料) |
| 唯一新增原生 Python 用例 Ruff／format --check | 通过，原连接器复原后再核对通过 | [Ruff（原始产物已删除）](../../../README.md#已删除的材料)、[format（原始产物已删除）](../../../README.md#已删除的材料) |
| 最新构建的 Tauri 3 项 | 3 通过，0 失败／跳过，21.411 秒，exitcode=0 | [成功输出（原始产物已删除）](../../../README.md#已删除的材料)、[exitcode（原始产物已删除）](../../../README.md#已删除的材料)、[首轮失败（原始产物已删除）](../../../README.md#已删除的材料) |

完整前端 48 项执行在最后 checkpoint guard 前；最终 guard 后只补相关三文件回归 42 项和类型／构建，不将其描述成最新代码另跑完整 51 项。Python 产品在前端补修期间没有变化，完整回归仍适用。唯一 Python 跳过是 Windows symlink privilege unavailable，不计通过。所有早期失败日志保留。

## Standards

**做得好**：投影集中维护消息与事件，双向校验 seq 和身份；页面原文只读并限高。**需要修**：硬性文档违规 0；重复 metadata 校验已修。**讨论**：泛谓词名称和 TS 排版差异为 2 项非阻塞建议。详见[原审查](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-03/standards-review.md`）。

## Spec

**做得好**：事实与预览分离；metadata 保持状态权威和终态保护；审批只由当前 interrupted GET 正常完整回放核实。**需要修**：seq 双向冲突、正常 GET EOF 单次快照、审批完整 ID 集合与 checkpoint 不复活三类问题已修。遗留缺项／范围外改动／未修实现错误均为 0。**讨论**：无。详见[最终复核](../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-03/spec-review.md`）。

两个轴分别记录；Standards 硬违规 0、非阻塞讨论 2，Spec 遗留问题 0，无各轴阻塞问题。

## 证据范围

后端正式用例已有 checkpoint 和同 Run 恢复覆盖；公开 GET interrupted 正常 EOF、重复回放与损坏 checkpoint 的精确组合由本轮 scratch HTTP 探针补证。未声称探针已经沉淀成正式后端测试。前端新正式 SSE／Store 回归已保存为 `frontend/tests/run-reconstruction.test.mjs`。

Tauri 专项使用确定性 Agent 和隔离临时数据，不访问供应商服务。复用逐字节匹配的既有 5173 静态服务，禁止终止未知归属服务；宿主及其数据库由本次夹具创建和清理。物理键盘、IME、触控、原生标题栏和多尺寸联合检查仍归第 23 票。

测试子 agent 最后核实 9238／45200 空闲，5173 未操作且 index／JS／CSS 与最新 dist 匹配；各宿主退出断言通过。WebView2 清理日志的 `Chrome_WidgetWin_0 (1412)` 诊断未导致用例失败或端口残留，保留原始 host 日志。

## 实机证据与首次失败

默认沙箱下第一次 3 项都在共享 `WindowAcceptance.connect` 失败：1 次 CDP WebSocket reset、2 次没有取得调试页面；尚未执行业务断言。原始日志保留，未计为通过。测试子 agent 经自动审批允许的原生窗口权限运行同一脚本后，3 项全部通过。主 agent 曾准备等待导航稳定的连接覆盖方法，在成功结果返回后撤回，最终正式脚本保留已通过的原共享连接器；业务断言未修改。

- 真实页面读取保存消息，并由用户点击显式发送；新正文只保存一次：[JSON（原始产物已删除）](../../../README.md#已删除的材料)、[截图（原始产物已删除）](../../../README.md#已删除的材料)。
- 刷新 interrupted 会话：全部页面请求为 GET，只有一次不带查询参数的既有 Run stream，随后一次快照；提示“审批请求已核实”，同一用户正文只一份：[JSON（原始产物已删除）](../../../README.md#已删除的材料)、[截图（原始产物已删除）](../../../README.md#已删除的材料)。
- 同 Run 已审批继续后，旧 interrupted 事件没有覆盖当前 running，最终实际完成：[JSON（原始产物已删除）](../../../README.md#已删除的材料)。

主 agent 已核对成功原始日志／退出码、三份 JSON，并查看前两张 WebView 截图。截图不包含原生边框，不用它宣称第 23 票视觉联合验收完成。
