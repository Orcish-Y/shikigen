> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# OS 输入与默认下载复验报告

日期：2026-10-07 08:52 Asia/Shanghai  
验证模型：`gpt-6-luna / max`  
工作目录：`C:\code\shikigen-agent`

## 总结果

本轮串行执行 3 个真实 Windows/Tauri 单例：**1 通过、2 失败、0 error、0 skip**。两项输入验收都未通过其核心动作断言；默认下载对照通过。没有修改产品代码、测试代码、断言或既有报告，也没有运行在线模型任务。

复用前完整核对了 `frontend/dist` 的 38 个文件名、长度和 SHA-256，与 `frontend-rust/final-4/vite-build.json` 中的清单逐项一致：38 文件、1,049,454 bytes，manifest SHA-256 `fdc6b6b595a5531ae8553c6bdb037f621dce64fbc3f169e305bc06737d81c83f`。原生 runner 每次还核对了共享 5173 服务的 index 和 2 个引用资产。环境快照见 [dist-manifest-check（原始产物已删除）](../../../../../README.md#已删除的材料) 和 [environment（原始产物已删除）](../../../../../README.md#已删除的材料)。

## 单例结果

### Windows 屏幕键盘：失败

命令：

```powershell
.venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch os-keyboard-4 --tests NativePlatformAcceptance.test_actual_windows_on_screen_keyboard_with_long_draft
```

结果为 **1 selected / 1 executed / 0 passed / 1 failed / 0 error / 0 skip**，runner exit 1。用例新建本次专用 OSK（PID 26304；非预存用户键盘），采集到 `OSKMainClass` 及 `DirectUIHWND`，且屏幕坐标命中 OSK 根窗口的断言已通过。实际鼠标点击后，长草稿没有追加预期的 `a`，在等待草稿更新处失败。用例因此没有到达 trusted `a` key 检查、发送按钮 `WindowFromPoint` 遮挡检查或后端消息为空断言；不能声称这些已通过。

证据： [命令与源哈希（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner 输出（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner 错误（原始产物已删除）](../../../../../README.md#已删除的材料)、[结果计数（原始产物已删除）](../../../../../README.md#已删除的材料)、[summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases（原始产物已删除）](../../../../../README.md#已删除的材料)、[failure snapshot（原始产物已删除）](../../../../../README.md#已删除的材料)、[OSK UIA 控件（原始产物已删除）](../../../../../README.md#已删除的材料)、[OSK 截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[应用截图（原始产物已删除）](../../../../../README.md#已删除的材料)。

复现步骤：运行上面的单例命令；OSK 显示后测试会将鼠标移到记录布局的 `a` 键坐标并点击，等待输入框内容成为原长草稿加 `a`。本次在这一步超时。unittest 清理已关闭新建 OSK；没有对预存 TabTip 或其他 OSK 执行关闭操作。清理证据见 [post-cleanup state（原始产物已删除）](../../../../../README.md#已删除的材料)。

### 中文 IME Space 选词及 Enter 发送：失败

命令：

```powershell
.venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch os-ime-space-1 --tests NativePlatformAcceptance.test_real_system_ime_space_selects_chinese_then_explicit_enter_sends_once
```

结果为 **1 selected / 1 executed / 0 passed / 1 failed / 0 error / 0 skip**，runner exit 1。真实按键路径在 Space 后没有把草稿变为 `你好`，失败于中文选词等待。failure snapshot 显示草稿仍为 `nihao`。测试未继续到普通 Windows Enter、运行 completed、后端恰好一条 human 消息的断言。该失败用例在断言前没有写事件 trace，因此本批没有 composition/key event 证据；不据此推断候选 UI 是否出现，也不覆盖此前单独通过的 `os-ime-enter-2`。

证据： [命令与源哈希（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner 输出（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner 错误（原始产物已删除）](../../../../../README.md#已删除的材料)、[结果计数（原始产物已删除）](../../../../../README.md#已删除的材料)、[summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases（原始产物已删除）](../../../../../README.md#已删除的材料)、[failure snapshot（原始产物已删除）](../../../../../README.md#已删除的材料)、[Tauri 截图（原始产物已删除）](../../../../../README.md#已删除的材料)、[清理状态（原始产物已删除）](../../../../../README.md#已删除的材料)。

复现步骤：运行上面的单例命令；测试向目标 Tauri textarea 输入拼音并注入真实 Windows Space，等待 IME 选词结果变为 `你好`。本次超时，随后 runner 清理宿主。需要后续补充失败前 composition/key event 观察，再判断输入法路径；不能把本次列为 IME 选词或 Enter 发送通过。

### 默认下载偏好对照：通过

命令：

```powershell
.venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/default_download_probe.py --batch default-download-6-default-pref --tests NativeSaveCancelExportAcceptance.test_default_download_retains_actual_complete_markdown_without_override
```

结果为 **1 selected / 1 executed / 1 passed / 0 failed / 0 error / 0 skip**，runner exit 0，`cases.json` 用时 15.750 秒。该对照只针对本例隔离 WebView profile：夹具原本写入 `prompt_for_download=true`，wrapper 在启动宿主前只移除该键；保留本例隔离的 `default_directory` 与 `directory_upgrade`。没有调用 `Browser.setDownloadBehavior` / Page 下载策略，不改产品、用户 profile 或系统安全配置。

下载 GUID `7372f11d-cb2c-4ddc-8480-b15d7a74f9b7` 的 8 条 Page 事件中，1 条 `Page.downloadWillBegin`、7 条 `Page.downloadProgress`，终态为 `completed`，`receivedBytes=totalBytes=69,777`。宿主退出后隔离目录中的文件仍存在；实际文件和观察副本均为 69,777 bytes、SHA-256 `4aea9d255dc01005208e4762fa7c9bf8c88b235b8811183e83a43b45bb37c60a`。这证明本例在移除强制询问偏好后默认 WebView 下载路径能完成并留存；不证明默认 Save As 对话框取消或人工用户交互。

证据： [命令与源哈希（原始产物已删除）](../../../../../README.md#已删除的材料)、[静态预检（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner 输出（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner 错误（原始产物已删除）](../../../../../README.md#已删除的材料)、[runner summary/cases（原始产物已删除）](../../../../../README.md#已删除的材料)、[完整事件与 GUID/哈希核对（原始产物已删除）](../../../../../README.md#已删除的材料)、[profile 对照（原始产物已删除）](../../../../../README.md#已删除的材料)、[原始下载事件（原始产物已删除）](../../../../../README.md#已删除的材料)、[用例结果（原始产物已删除）](../../../../../README.md#已删除的材料)、[summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases（原始产物已删除）](../../../../../README.md#已删除的材料)、[post-source hashes（原始产物已删除）](../../../../../README.md#已删除的材料)、[post-cleanup state（原始产物已删除）](../../../../../README.md#已删除的材料)。

额外诊断：用例能确认 WebView History 文件存在，但用例内只读 SQLite 查询返回 `database is locked`；没有据此声称 History 数据库记录已核对。实际终态事件、实际下载文件与用例保留副本分别核对通过。

## 静态预检与来源完整性

- 两项 OS 输入用例共用的四个 Python 文件（`native_platform_acceptance.py`、`native_workflow_acceptance.py`、`conversation_export_acceptance.py`、`native_touch_acceptance.py`）Ruff check 与 `ruff format --check` 均 exit 0；两个 `native_runner.py --list` 命令各精确列出 1 项。详情见 [静态预检（原始产物已删除）](../../../../../README.md#已删除的材料) 及 stdout/stderr 日志。
- 下载 wrapper 的 `ruff format --check` 与精确 `--list` exit 0。Ruff check **失败 1 项 I001**：`default_download_probe.py` 导入块排序。没有运行 `ruff --fix`、没有编辑 wrapper；该源哈希及运行前后对照均保留。它是静态风格失败，不是行为用例失败。
- 三个批次的 `command.json` 均保存 `gpt-6-luna / max`、实际命令、工作目录、来源 SHA-256 和 manifest。download-6 的 9 个被记录源文件在运行前后 SHA-256 全部相同，见 [post-source-hashes（原始产物已删除）](../../../../../README.md#已删除的材料)。
- download-6 曾有一次本地 PowerShell 端口守卫因数组展平产生误判，在启动任何 runner/宿主前退出。独立端口快照确认测试端口空闲、5173 属于 PID 23344；修正守卫后才执行上述单例命令，未与其他窗口测试重叠。

## 清理与未覆盖范围

每批结束后 9238 与 45200 均无监听，用户预置 5173 服务 PID 23344 保持运行，预存 TabTip PID 14204 保持运行；没有可见 OSK，也没有本轮新增的 Python/Shikigen 进程。OSK 新建窗口已由该用例关闭，IME 与下载宿主由 runner 清理。三份批次快照分别见各目录的 `post-cleanup-state.json`。

本轮没有证明 OSK 按键插入、IMEs Space 选词或该中文消息通过 Enter 只发送一次。下载偏好对照不替代人工 Save As／取消验收；失败的中文用例也没有复验候选窗口可见性。上述缺口继续按失败或待验证记录，不合并此前已有的其他批次计数。此报告只新增本轮验证证据，不更新票据或关闭第 23 票。

## 后续追加：Windows 输入与原生并存验收

上方“总结果”只计算最初三项。后续另执行六个 Tauri 单例：默认下载-7 1 pass；IME paced 1 fail；full-preedit 两项 2 pass；osk-coexistence-1 与 osk-coexistence-2 各 1 fail。合计九项为 **4 pass / 5 fail / 0 error / 0 skip**。独立 Win32 输入控制程序是环境诊断，不计为产品测试。各批原状态和证据均保留。

### 默认下载最终验收：通过

命令：

    .venv/Scripts/python.exe .scratch/frontend-completion/ticket-23/native_runner.py --batch default-download-7-final --tests NativeSaveCancelExportAcceptance.test_default_download_retains_actual_complete_markdown_without_override

结果 1/1 pass。真实 Page 下载事件中同一 GUID 进入 completed，接收完整 69,777 bytes；宿主退出后源文件仍存在，观察副本 SHA-256 一致。隔离 profile 中 prompt_for_download 缺省，未修改 Browser 下载策略。具体 GUID、事件和文件 hash 见 [download-7 结果报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/default-download-7-final-report.md`）。旧 default-download-6 单变量对照也保留；本结论仅支持这两个隔离 profile 观察到的默认下载路径。

### IME paced 比较：失败；完整预编辑回归：通过

IME paced 的真实 Space 已发送，但等待中文“你好”失败，草稿仍为 nihao，后续 Enter/history 未执行。失败前事件显示第一个 n 作为普通键，后面的 ihao 才处于同一 composition；保留原失败批次 [snapshot 与事件（原始产物已删除）](../../../../../README.md#已删除的材料)。

父 agent 后续要求 composition 最终预编辑必须完整 NIHAO 后，再独立运行 Space 选词+Enter 发送和普通 Enter 结束组合两个用例。该新批 2/2 pass：Space 选择你好，随后普通 Windows Enter 完成且只有一条 human 消息；普通 Enter case 仅结束拼音组合，不创建 run。旧 paced 失败不改写。证据见 [full-preedit summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[cases](../../../../../native-acceptance-evidence.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/native/os-ime-full-preedit-1/cases.json`） 及每个用例目录的 result.json / IME trace。

### OSK 与 Tauri 并存的取消可达性：仍失败

osk-coexistence-1 在原生托盘提示等待处失败。修正后的 osk-coexistence-2 已实际到达 TrayNotice，并通过 390×600、长草稿、阅读锚点、OSK 并存、取消按钮 WindowFromPoint、真实鼠标打开取消确认、Windows Esc 关闭以及草稿/锚点/运行中状态断言。它仍以 1 failure 结束：释放阅读流后 self.complete() 要求 at_latest()，但本例保留 paused reading anchor，wait 超时；用例未到达后续 no-tray WM_CLOSE 与 host wait 断言，故不计 pass。该 case 仅测取消，没有覆盖 Story 114 的发送、审批、重连。证据见 [osk-coexistence-1 原 summary（原始产物已删除）](../../../../../README.md#已删除的材料)、[osk-coexistence-2 报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/osk-coexistence-2-report.md`）、[osk-coexistence-2 summary/cases（原始产物已删除）](../../../../../README.md#已删除的材料)。

失败与通过批次均未重跑。预存 5173/PID 23344 与 TabTip/PID 14204 在这些单例期间保持运行；osk-coexistence-2 专用 OSK PID 24696 已退出且 HWND 33491382 已失效。清理快照、源哈希和命令日志在各自 validation/native 批次目录。
## 后续追加：1440 桌面四操作原型

新增的 interaction-matrix-1 原型在提交审批后等待“已完成”超时，结果 1 failure；snapshot 仍是等待审批，raw artifacts 不含 Network/后端审批事件，因此无法确认 POST 是否送出。后续发送、断流重连、取消没有运行；此原型没有启动 OSK，不能作为 Story 114 的 OSK 并存验收。用例耗时记录存在差异：unittest stdout 39.571 秒，cases.json 34.484 秒。完整命令、源 hash、失败截图和清理观察见 [interaction-matrix-1 报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/interaction-matrix-1-report.md`）。

截至此批，原报告范围累计十项 Tauri 单例：4 pass / 6 fail / 0 error / 0 skip。后续补测必须保留本次失败历史，不覆写、不重跑此batch。
## 后续追加：interaction-matrix-2

修正后的 1440 单例实际完成首 Run 审批、长草稿发送及手动重连，第二 Run 的流 GET 恰为 4；失败发生在未按 Run ID 分隔的全局方法序列断言，其中额外 2 个 GET 属于首 Run 的自动恢复。真实可信鼠标目标、API paths 和前两阶段 workflow 均保存。取消阶段未执行；本原型没有打开 OSK，不能据此关闭四档或 Story 114 验收。详情见 [interaction-matrix-2 报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/interaction-matrix-2-report.md`）。

截至此批，本报告范围为 11 个 Tauri 单例：4 pass / 7 fail / 0 error / 0 skip。保留两个 interaction-matrix 失败批次，不覆盖、不重复运行。

## 后续追加：interaction matrix 定向补验

`interaction-matrix-3` 的 1440×900 原型完成四阶段，1/1 pass。`interaction-matrix-final-1` 共 4 项：1280×800 四操作通过；OSK 并存 case 在 Home/阅读位置断言失败；1024 与 390 两档旧初始发送夹具依赖窄屏不挂载的 `.session[aria-current]`，未产生准备消息 POST。各原始 case 结果保留在对应 `native/interaction-matrix-3` 与 `native/interaction-matrix-final-1` 目录。

`interaction-matrix-final-2` 共 3 项：1024×768 四操作 1 pass；OSK 390×600 与托盘提示并存项、390×844 四操作项 2 fail。OSK 本批已实际触发可信“重新连接”点击，第二 Run stream GET 恰为 4；完整 DOM 含“观察已建立”，但等待 body 可见文本超时，未执行取消阶段。390×844 在批准动作前 WindowFromPoint 返回任务栏 HWND，守卫拒绝继续点击；失败结束后只读查得该 HWND 为 explorer 的 `Shell_TrayWnd`，不能回推点击时状态。详细证据见 [interaction-matrix-final-2 报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/interaction-matrix-final-2-report.md`）。

截至此批，本报告范围累计 **19 个 Tauri 单例：7 pass / 12 fail / 0 error / 0 skip**。该计数不包含独立 Win32 输入诊断。所有失败历史保留；未把断言未走到的操作计为通过，也未重跑已通过批次。

## 后续追加：窄屏四操作与 OSK 截图复验

`interaction-matrix-final-3` 两项均以 runner pass 结束：390×844 四操作及 OSK/长内容/TrayNotice 390×600 四阶段。事后视觉检查发现该批 `osk-coexistence-native.png` 实际是无关浏览器内容，不能作为 OSK 可见性证据；应用窗口截图确有 TrayNotice 和草稿，但不替代键盘截图。该批原始 pass 保留，同时将该图标记为无效证据。完整记录见 [final-3 报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/interaction-matrix-final-3-report.md`）。

随后 `interaction-matrix-final-4` 专为截图证据疑点重跑 OSK 联合项：1/1 pass。新 `osk-coexistence-native.png` 经本地图片查看实际显示 Windows 屏幕键盘完整键区；应用另有窗口截图。DPI-aware work area、Tauri窗体bounds、阶段请求数、可信点击和终态都留证。该 case 不涉及 OSK 键击注入或实体输入设备。完整记录见 [final-4 报告](../../../../../frontend-history.zip)（包内：`docs/archive/2026-10-07/development/frontend-completion/ticket-23/validation/native/interaction-matrix-final-4-report.md`）。

截至 final-4，本报告范围共有 **22 次 Tauri 单例执行：10 pass / 12 fail / 0 error / 0 skip**。其中 final-3 与 final-4 是同一 OSK case 的两次独立执行，分别计数；final-2 及更早失败历史仍保留。未计独立 Win32 输入诊断，也未将截图错误或尚未运行的动作记作通过。
