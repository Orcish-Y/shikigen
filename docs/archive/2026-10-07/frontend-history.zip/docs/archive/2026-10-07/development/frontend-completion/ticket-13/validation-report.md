> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 13 最终验证报告

- **验证模型**：gpt-6-luna，推理强度 max。
- **工作目录**：`C:\code\shikigen-agent`；前端命令的工作目录见下表。
- **验证结论**：前端 Node 检查、TypeScript 检查、最终 Vite 构建、HTTP smoke、6 个 Python 文件 Ruff 检查/格式检查均通过。7 个唯一原生用例最终都有通过证据，但分散在多个批次中；早期失败批次保留，不能把它们描述为单次 7/7 成功。
- **Git**：未执行 Git 修改操作。验证器没有修改产品代码或测试断言。
- **原始证据**：每条命令的实际 argv、cwd、开始/结束时间、退出码、计数及独立 stdout/stderr 均保存在 [`validation/`（原始产物已删除）](../../../README.md#已删除的材料)；下表时间使用 `Asia/Shanghai (UTC+08:00)`。

## 命令与结果

| # | 命令 | cwd | 时段 | 结果 | 原始记录 |
|---|---|---|---|---|---|
| 01 | `node --import tsx --test tests/approval-draft-recovery.test.mjs tests/approval-decisions.test.mjs tests/run-cancel.test.mjs tests/message-drafts.test.mjs tests/visibility-polling.test.mjs` | `frontend` | 09:21:30–09:21:31 | exit 0；61/61 pass | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 02 | `node --import tsx --test tests/*.mjs`（唯一一次完整前端 Node suite） | `frontend` | 09:22:21–09:24:00 | exit 0；164/164 pass，0 skip/fail | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 03 | `node --import tsx --test tests/approval-draft-recovery.test.mjs` | `frontend` | 09:24:31–09:24:31 | exit 0；12/12 pass（中间版本） | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 04 | `node --import tsx --test tests/approval-draft-recovery.test.mjs tests/approval-decisions.test.mjs tests/run-reconstruction.test.mjs tests/run-cancel.test.mjs tests/conversation-state.test.mjs tests/message-drafts.test.mjs tests/visibility-polling.test.mjs` | `frontend` | 09:26:10–09:26:10 | exit 0；91/91 pass，0 skip/fail | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 05 | `node node_modules/typescript/bin/tsc --noEmit` | `frontend` | 09:26:32–09:26:40 | exit 0；0 TypeScript errors | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 06 | `node node_modules/vite/bin/vite.js build` | `frontend` | 09:26:54–09:27:19 | exit 0；36 assets，1 warning；此构建在 App 文案改动期间生成，已由 #07 覆盖 | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 07 | `node node_modules/vite/bin/vite.js build` | `frontend` | 09:27:54–09:28:06 | exit 0；最终 36 assets，1 warning | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 08 | `.venv/Scripts/ruff.exe check frontend/src-tauri/tests/approval_draft_recovery_acceptance.py .scratch/frontend-completion/ticket-13/native_runner.py` | repo 根目录 | 09:28:29–09:28:29 | exit 0；2 files，0 diagnostics（初轮范围） | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 09 | `.venv/Scripts/ruff.exe format --check frontend/src-tauri/tests/approval_draft_recovery_acceptance.py .scratch/frontend-completion/ticket-13/native_runner.py` | repo 根目录 | 09:28:43–09:28:43 | exit 0；2 files，0 would reformat（初轮范围） | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 10 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-13/native_runner.py` | repo 根目录 | 09:29:29–09:31:42 | exit 1；7 项中 4 pass、3 fail | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 11 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-13/native_recovery_retry_runner.py` | repo 根目录 | 09:33:26–09:35:27 | exit 1；3 项均 fail | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 12 | `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p test_frontend_approval_flow.py -v` | repo 根目录 | 09:36:42–09:36:47 | exit 0；1/1 pass | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 13 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-13/native_recovery_diagnostic_runner.py` | repo 根目录 | 09:37:10–09:37:55 | exit 1；1 项 fail | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 14 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-13/native_recovery_sqlite_runner.py` | repo 根目录 | 09:39:45–09:40:45 | exit 1；3 项中 1 pass、1 fail、1 error | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 15 | `.venv/Scripts/python.exe -X utf8 .scratch/frontend-completion/ticket-13/native_recovery_final_runner.py` | repo 根目录 | 09:42:42–09:43:02 | exit 0；2/2 pass，0 skip/fail/error | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 16 | `.venv/Scripts/ruff.exe check` 对本票 6 个 Python 文件（完整参数见 meta） | repo 根目录 | 09:43:37–09:43:37 | exit 0；6 files，0 diagnostics | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 17 | `.venv/Scripts/ruff.exe format --check` 对本票 6 个 Python 文件（完整参数见 meta） | repo 根目录 | 09:43:55–09:43:55 | exit 0；6/6 already formatted，0 would reformat | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |
| 18 | `.venv/Scripts/python.exe -X utf8 -c <all-file HTTP byte-compare script>`，比对 `127.0.0.1:5173` 与 `frontend/dist` | repo 根目录 | 09:45:40–09:45:41 | exit 0；38/38 files 字节一致，0 mismatch | [meta（原始产物已删除）](../../../README.md#已删除的材料) · [stdout（原始产物已删除）](../../../README.md#已删除的材料) · [stderr（原始产物已删除）](../../../README.md#已删除的材料) |

## 原生验收覆盖与失败说明

本票 7 个唯一原生用例的最终通过证据来自串行拆分批次，不是单次全绿运行：初始 7 项批次中的 4 个既有审批用例通过；pending 重启用例在 SQLite fixture 批次通过；重开后选择/原文恢复与历史 404 保留两个用例在最终批次通过。7 项如下：

1. `test_choices_and_raw_reason_survive_native_restart_then_full_get` — 最终批次通过。
2. `test_pending_restart_verifies_before_manual_same_run_resubmission` — SQLite 批次通过。
3. `test_history_404_keeps_copyable_local_choices_then_get_recovers` — 最终批次通过。
4. `test_multi_interrupt_action_order_parameters_pending_and_same_run_resume` — 初始批次通过。
5. `test_422_preserves_choices_and_only_get_then_manual_resubmit` — 初始批次通过。
6. `test_unsupported_group_read_only_and_confirmed_cancel_without_tools` — 初始批次通过。
7. `test_old_terminal_parameters_keep_history_label_after_new_run` — 初始批次通过。

失败批次和诊断保留如下：

- #10 初始批次的三个新增恢复用例都卡在 `window.__approvalRequests` wrapper 就绪等待；四个旧用例已通过。后续夹具在新文档加载流程中启用 Page，再进行重试。
- #11 重试进入恢复路径后，重开期间未观察到预期 GET/未知状态或历史 404 文案。#13 的现场诊断显示后端在进程重开后无法恢复 memory checkpointer 中的审批 checkpoint；fixture 改为本票隔离 SQLite checkpoint，不涉及后端产品代码。
- #14 SQLite 批次中 pending 重启通过；选择/原文用例因 fixture 查询不存在的 `/events` JSON API 而 `KeyError: 'data'`；历史 404 用例断言了旧文案。fixture 改为读取已存在的 `/stream` SSE 并检查无 `resolved` 事实，同时更新为当前 UI 文案后，#15 两个重跑用例均通过。所有历史失败日志和 diagnostic 文件均保留。

最终截图和结果：

- [重开后选择与原文恢复截图（原始产物已删除）](../../../README.md#已删除的材料)；[result.json（原始产物已删除）](../../../README.md#已删除的材料)
- [历史 404 截图（原始产物已删除）](../../../README.md#已删除的材料)；[result.json（原始产物已删除）](../../../README.md#已删除的材料)
- [pending 重启截图（原始产物已删除）](../../../README.md#已删除的材料)；[result.json（原始产物已删除）](../../../README.md#已删除的材料)
- #13 原生现场文件位于 [`native/recovery-diagnostic-1/`（临时产物已清理）](../../../README.md#已清理的临时产物)；初始批次 4 个既有用例截图位于 [`native/batch-1/`（临时产物已清理）](../../../README.md#已清理的临时产物)。

成功恢复用例目录中的 `diagnostic-error.txt` 写有 `no close frame received or sent`。检查了调用顺序：各用例先完成主断言、截图及 `result.json` 写入，再退出原生 host；注册的额外诊断 cleanup 随后尝试复用已经关闭的 CDP 连接并记录该错误。因此它属于 teardown 后的补充诊断失败，不影响已写出的主结果、窗口截图或测试断言；文件保留原样。

## 运行环境与范围

- 原生 runner 串行执行。未知 5173 服务未被终止：runner 复用前校验了 `index.html` 和 2 个直接引用资源；额外的 #18 对当前 `frontend/dist` 共 38 个文件逐字节比较，全部一致。未杀 PID 23344。9238 与 45200 在预检时空闲。
- #07 是包含最终 App 文案的构建。唯一完整前端 Node suite #02 为 164/164；之后身份匹配清理逻辑和 13 项恢复测试更新由 #04 的 91/91 定向覆盖。完整 Node suite 未重复执行。TSC #05 早于纯 UI 文案更改；之后未改 TS 分支，最终构建已重新执行。
- Vite 构建有一条 chunk size 提示：`index` JS chunk 575.48 kB，超过 500 kB 提示阈值；构建 exit 0。详见 #07 stderr。
- 后端完整 321 项回归来自上一票，本票未重跑；本票只运行真实 HTTP `test_frontend_approval_flow.py`（1/1）。物理输入、系统 IME 和多尺寸验收属于第 23 票，不在本票验证范围。
