> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第 11 票后端验证报告

## 首轮结果（实现修复前）

- 模型：`gpt-6-luna / max`
- 工作目录：`C:\code\shikigen-agent`
- 基线：`e0ea6aef1947dbb4b4a080ca993cfa05ddb99b6f`
- 时间：2026-10-05 13:56–14:02 UTC
- 本节记录首轮结果（实现修复前）。当时主 agent 正在修复启动失败结算路径，完整 discover 仍待 GUI 退出，修复后的定向回归也待定稿后执行；两项后续结果已分别补记在本文下方。

## 专项测试

新增 `tests/test_failure_partial_message.py` 实际有 11 项（交接写 10 项是笔误），11/11 通过。七个相关旧专项共 73/73 通过。总计 **84 通过、0 失败、0 跳过**。

新专项 stderr 中三次 `sqlite3.IntegrityError`（rollback/retry、cancel race、shutdown）由测试设置的 SQLite trigger 注入，测试随后均通过；它们是预期故障路径证据，不是测试失败。

| 覆盖范围 | 实际结果 | UTC | 原始日志 |
| --- | ---: | --- | --- |
| `test_failure_partial_message.py` | 11 通过 | 13:56:04.387–13:56:26.456 | `logs/backend-new-special.*` |
| `test_cancel_partial_message.py` | 10 通过 | 13:56:51.505–13:57:10.401 | `logs/backend-old-cancel-partial.*` |
| `test_execution.py` | 9 通过 | 13:57:16.790–13:57:20.259 | `logs/backend-old-execution.*` |
| `test_run_events.py` | 6 通过 | 13:57:27.263–13:57:55.048 | `logs/backend-old-run-events.*` |
| `test_runtime.py` | 20 通过 | 13:58:01.802–13:58:32.275 | `logs/backend-old-runtime.*` |
| `test_run_cancel.py` | 8 通过 | 13:58:41.192–13:59:02.609 | `logs/backend-old-run-cancel.*` |
| `test_run_usage.py` | 9 通过 | 13:59:09.295–13:59:24.838 | `logs/backend-old-run-usage.*` |
| `test_approval_resume.py` | 11 通过 | 13:59:32.911–14:00:16.864 | `logs/backend-old-approval-resume.*` |

所有专项使用工作目录 `C:\code\shikigen-agent` 和 `.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p <文件名> -v`，由 `run-command.ps1` 分别保存 stdout、stderr 和 UTC 元数据。逐条的完整命令与退出码见各自 `.meta.json`。

## 静态检查

| 检查 | 命令 | 结果 | UTC / 日志 |
| --- | --- | --- | --- |
| 产品 ty | `.venv\Scripts\ty.exe check app packages/harness` | 通过，exit 0 | 14:01:04.117–14:01:04.897，`logs/backend-ty-product.*` |
| 新增测试 ty | `.venv\Scripts\ty.exe check --extra-search-path tests --extra-search-path frontend/src-tauri/tests tests/test_failure_partial_message.py tests/desktop_failure_fixtures.py frontend/src-tauri/tests/failure_partial_acceptance.py` | 失败，3 个诊断 | 14:01:12.971–14:01:13.416，`logs/backend-ty-tests.*` |
| Ruff check | `.venv\Scripts\ruff.exe check packages/harness/shikigen/runtime/run_events.py packages/harness/shikigen/runtime/run_execution.py packages/harness/shikigen/runtime/runs.py tests/test_failure_partial_message.py tests/desktop_failure_fixtures.py frontend/src-tauri/tests/failure_partial_acceptance.py .scratch/frontend-completion/ticket-11/native-runner.py` | 失败，9 个诊断 | 14:01:47.808–14:01:47.913，`logs/backend-ruff-check.*` |
| Ruff format | 同一文件列表，参数为 `format --check` | 7 个文件已格式化，exit 0 | 14:02:03.782–14:02:03.880，`logs/backend-ruff-format.*` |

新增测试 ty 的诊断：`test_failure_partial_message.py:164,454` 中 `execution.task` 是 `Task[None] | None`，调用 `.done()`／`.cancelled()` 前需要处理 None；`:423` 的 `replay` 函数签名与 `astream_events` 不兼容。

Ruff check 的 9 个诊断：`run_execution.py:130` 一个 F821（未定义 `error`，出现在主 agent 正在修复的 startup 失败路径）；`native-runner.py` 一个未用 `Path` 导入；`failure_partial_acceptance.py` 四个 E501；`test_failure_partial_message.py` 一个 import 排序及两处 E501。未改写或清理这些失败日志；修复后的检查需重新执行。

## 命令、重现与边界

专项可使用上表文件名替换下列模式参数重现：

```powershell
Set-Location C:\code\shikigen-agent
.\.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_failure_partial_message.py -v
```

Ty/Ruff 可直接重跑上表的完整命令。实际 wrapper 命令、参数、UTC、cwd、环境、stdout/stderr 路径、退出码都在 `logs/*.meta.json`，原始 stdout/stderr 保留在同名 `.log` 文件中。全部首轮命令未额外设置环境变量。

- 首轮报告撰写时尚未执行后端完整 `unittest discover -s tests -v`；GUI 完成后已按交接要求只执行一次，最终结果见下文。
- 这次 `test_approval_resume.py` 的 11 项通过。交接记录的历史审批 cleanup 超时仍保留在 `.scratch/approval-cleanup-test-timeout/issues/01-approval-resume-settlement-timeout.md`；其根因和与本次结算改动的关系未知，不能据本次通过宣称无关或已解决。
- 前端构建、Node 专项、原生 GUI 验收由其他验证任务处理，本报告不将其计为后端验证结果。

## 最终定向回归（startup 修复后）

主 agent 增加 startup 失败事务回滚的结算 owner 与 shutdown 覆盖，并修正静态检查诊断后，我按要求重跑了受影响专项。新专项现为 12 项；最终定向批次 **52/52 通过、0 失败、0 跳过**：新专项 12、`test_execution.py` 9、`test_runtime.py` 20、`test_approval_resume.py` 11。另单独重跑 late-ingestion/根快照重放用例 1/1 通过，该用例已计入新专项 12 项，不重复计数。

| 覆盖范围 | 结果 | UTC | 原始日志 |
| --- | ---: | --- | --- |
| 新增专项，包括启动回滚/shutdown | 12 通过 | 14:03:50.945–14:04:15.419 | `logs/final-backend-new-special.*` |
| `test_execution.py` | 9 通过 | 14:04:21.869–14:04:26.548 | `logs/final-backend-execution.*` |
| `test_runtime.py` | 20 通过 | 14:04:34.128–14:04:58.225 | `logs/final-backend-runtime.*` |
| `test_approval_resume.py` | 11 通过 | 14:05:05.705–14:05:34.871 | `logs/final-backend-approval-resume.*` |
| late-ingestion 单例重跑 | 1 通过（已包含在上方） | 14:07:23.237–14:07:26.639 | `logs/final-backend-late-facts-case.*` |
| 产品 ty | 通过 | 14:05:45.173–14:05:45.610 | `logs/final-backend-ty-product.*` |
| 新增测试 ty | 通过 | 14:07:33.922–14:07:34.329 | `logs/final2-backend-ty-tests.*` |
| Ruff check | 通过 | 14:07:41.774–14:07:41.856 | `logs/final2-backend-ruff-check.*` |
| Ruff format --check | 7 个文件均已格式化 | 14:07:49.506–14:07:49.577 | `logs/final2-backend-ruff-format.*` |

回归命令均以 `C:\code\shikigen-agent` 为 cwd，由 `run-command.ps1` 执行并保存完整元数据。新增专项使用 `.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_failure_partial_message.py -v`；三个旧专项分别将 `-p` 文件名替换为 `test_execution.py`、`test_runtime.py` 和 `test_approval_resume.py`。单例命令为：

```powershell
Set-Location C:\code\shikigen-agent
$env:PYTHONPATH = 'tests;packages/harness'
.\.venv\Scripts\python.exe -X utf8 -m unittest test_failure_partial_message.FailurePartialMessageTests.test_failure_barrier_seals_late_ingestion_and_next_run_replay -v
```

最终测试 ty 命令同上表静态检查项。最终 Ruff 命令为首轮表格中的完整七文件命令。首轮 `final-backend-ty-tests` 的一个 replay 动态赋值类型诊断保留在日志中；主 agent 改为 fixture replay 模式后，`final2-backend-ty-tests` 通过。startup 调整后的完整产品 ty 通过，最新测试/Ruff 文件状态的 ty、Ruff check 与 format 均通过。

首轮七个旧专项共 73 项结果保留在上文；startup 修复后额外回归了本节列出的三个受影响旧专项。历史审批 cleanup 超时根因仍未知，完整回归成功不证明该历史问题已修复或与本票无关。

## 完整后端最终回归（GUI结束后）

- 模型：`gpt-6-luna / max`
- 工作目录：`C:\code\shikigen-agent`
- 命令：`.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -v`
- unittest 结果：`Ran 313 tests in 491.468s`；**312 通过、0 失败、0 错误、1 跳过**，摘要为 `OK (skipped=1)`，进程 exit 0。
- 唯一跳过：`test_runtime_data.RuntimeDataTests.test_symlink_data_and_parent_are_rejected`，原因 `Windows symlink privilege is unavailable`，该项未计为通过。
- run-command UTC：2026-10-05 14:24:42.3437563–14:33:04.7452861；端到端历时 502.402 秒。完整逐项 stderr、stdout 和元数据见 `logs/final-full-backend-discover.stderr.log`、`logs/final-full-backend-discover.stdout.log`、`logs/final-full-backend-discover.meta.json`。unittest 测试明细写在 stderr；stdout 为空。
- 启动前已收到前端验证 agent 通知：最后 native-style-final 于 14:22:58.855 UTC exit 0，GUI host 已退出。运行期间本地 listener 核查仅见保留的 `127.0.0.1:5173` 静态服务（PID 23344），9238、45200、45201 无 listener。测试进程以 4 threads、354 handles 运行并自行退出；未中断或重复执行。
- 该轮 ty 最新测试命令 `.venv\Scripts\ty.exe check --extra-search-path tests --extra-search-path frontend/src-tauri/tests tests/test_failure_partial_message.py tests/desktop_failure_fixtures.py frontend/src-tauri/tests/failure_partial_acceptance.py` 于 14:24:42.358–14:24:42.813 UTC exit 0；日志为 `logs/final3-backend-ty-tests.*`。它与完整 discover 并行，检查文件与该轮使用的测试文件一致。
- 最新 Ruff check 与 `format --check` 已在 14:07 的 `final2-backend-ruff-*` 记录中通过；按主 agent 指示复用该结果，不重复执行。产品 Python 在该次通过后未再更改。

历史完整套件耗时参考：ticket 09 为 264.383 秒，ticket 05 为 358.668 秒，ticket 06 为 340.563 秒，ticket 07 为 384.388 秒，ticket 03 为 318.939 秒；ticket 10 一次失败耗时 721.361 秒、最终成功耗时 359.477 秒。本次端到端 502.402 秒虽比 ticket 10 最终成功运行长，仍处于历史完整套件记录范围内。此次完整回归 313 项中 312 通过、1 跳过；未据此对既往 approval cleanup 超时的根因或其与本次的关联作结论，独立问题仍保持 `needs-triage`。
