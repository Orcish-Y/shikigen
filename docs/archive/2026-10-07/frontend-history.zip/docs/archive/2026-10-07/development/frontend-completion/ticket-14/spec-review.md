> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第14票 Spec 复审

### 做得好的

- 只读资源 API、工作目录与文件工具共用根、路径边界／文件版本核验、支持格式及 20 MiB 限制均与规格一致；图片仅经 Blob URL 放入 `<img>`。局部错误、原引用复制、手动重试、实际路径核对及长消息阅读锚点均有实现。
- 自动读取仅由 Agent Markdown 图片触发；用户／工具正文、代码／JSON 和网页图片不读取本地资源。第15票系统文件打开仍未混入本票。

### 曾发现／修复

- 初审发现 ready→ready 租约更换时，图片详情可能继续引用已撤销 URL。**红灯证据：**[`native-lease-red-1.stderr.log`（原始产物已删除）](../../../README.md#已删除的材料) 为 1 项失败，详情关闭等待超时；对应 [`failure.json`（原始产物已删除）](../../../README.md#已删除的材料) 显示旧 Blob 已撤销、时间线新图已加载而图片详情仍开着。违反 004 契约 §7：“后端或工作目录更换后旧资源身份失效，重新解析消息中的原始引用”（第138行）。
- 当前 [`App.tsx`](../../../../../../frontend/src/App.tsx#L95) 在 session 或可见状态变化时关闭图片详情；新增原生回归 [`workspace_image_acceptance.py`](../../../../../../frontend/src-tauri/tests/workspace_image_acceptance.py#L272) 覆盖同 Run 的 ready→ready 桥接帧。**绿灯证据：**[`lease-final-2 stderr`（原始产物已删除）](../../../README.md#已删除的材料) 为 1/1 通过；[`result.json`（原始产物已删除）](../../../README.md#已删除的材料) 记录 dialog 关闭、旧 URL 全撤销、新图片重新请求且 run_id 不变。测试通过公开 Tauri 桥接注入状态帧，明确不是实际 BackendManager 进程重启。

### 复审结论与验证边界

- 复查当前源码和刷新后的差异后，未发现其他缺失／部分需求、错误实现或本票 scope creep；**当前未解决 Spec 发现：0 项**。本结论只针对 Spec 轴。
- 更早的原生图片三项首轮因 SVG 图标识别与 tray_left 夹具失败；修正夹具后 `native/recheck-1` 为 3/3 通过，旧四项在另批次通过；这些批次不合并宣称 7/7 同批全绿。完整 Node 回归在 overlay 修复后为 172/172，TypeScript 和 Vite build exit 0；最终租约专项以 `lease-final-2` 记录为准。

**统计：当前 Spec 发现 0 项；历史缺陷 1 项，已修复并由最终租约专项绿灯覆盖。**
