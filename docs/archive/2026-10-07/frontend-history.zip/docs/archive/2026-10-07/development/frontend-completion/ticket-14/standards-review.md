> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 14 — Standards 审查

## 做得好的

- frontend/src/components/WorkspaceImage.tsx 与 frontend/src/styles.css 遵循 frontend/design.md「本地图片与文件确认」：保留比例、正文宽度内显示、图片最高 320px；引用、读取错误和重试入口就近保留。
- 新增 App effect 在后端租约或可见性变化时收起图片详情；原生验收用例的注释明确说明 ready→ready 帧来自公开 Tauri 桥测试注入，不声称实际 BackendManager 重启。
- 资源查询、图像读取和 UI 生命周期各有明确模块边界，名称大多使用工作目录、资源、图片等领域词。

## 需要修

最终 review.diff 中无未解决的文档标准硬违反。审查中发现并已修复：

- frontend/src/workspace-images.ts：shared 实体改为名词 imageResource；回调、Blob URL 工厂以及订阅、装载、状态发布和释放函数改用 receiveState、createObjectUrl、retryImageLoad 等动宾名。
- frontend/src/components/WorkspaceImage.tsx：布尔标志改为 isVisible、areCoordinatesVisible。
- frontend/src-tauri/tests/workspace_image_acceptance.py：测试夹具 URL 回调同步采用 createObjectUrl / revokeObjectUrl。
- 本轮新增 frontend/src/App.tsx 的 updater 参数起初叫 current，已改为 currentOverlay。
- 上述修复遵循 AGENTS.md「命名规范与语义严谨」中的实体名词、显式布尔判断和 callable 命名规则。

## 值得讨论

两项判断性 smell 均已处理：app/routes/workspace.py:get_workspace 的 coordinates 改为领域名 workspace_identity（Mysterious Name）；ResourceBinding.metadata 没有读取者，已从 packages/harness/shikigen/runtime/workspace_resources.py 删除（Speculative Generality）。

Standards 轴：未解决硬违反 0；未解决 smell 0。按本轮要求只读核对，未运行测试或 Git 命令。

