> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Ticket 15 · Standards review（复审）

固定点：`.scratch/frontend-completion/ticket-15/baseline/`；按当前源码及 `review.diff` 静态审查（17 个非空文件差异；18 个候选含未变的 index）。标准来源：`AGENTS.md §5 命名规范与语义严谨`；`frontend/design.md` 无相关冲突。未运行 Git 或测试。

## 做得好

- 上轮 **7 组硬命名问题均已关闭**：Rust `create_file_error`、`read_current_lease`；`lease_handle`→`backend_app`；布尔量改 `is_server_held`/`is_server_stopping`；fixture/test 名改为 `start_resource_server`、`read_backend_snapshot`、`startup_snapshot`、`clock_state`、`open_invocation` 等名词/动宾；`failureMessage`→`readFailureMessage`；Promise→`invocationPromise`；native acceptance 改为 `invoke_native_command`、`read_file_invocations`、`read_message_history`、`read_window_titles`、`read_open_outcome`。`native_command=True` 是现有方法参数，非命名违规。
- 上轮 **Mysterious Name**（`C:\Users\Orcs0\.codex\skills\code-review\SKILL.md §3`）中的 `operation` 已改 `operationGeneration`。`request` 已改 `request_id`。`ReadLease`/`ReadClock` 本身是“动词+对象”，符合显式动宾规则；改为 `ReadLeaseFn`/`ReadClockFn` 是清晰度增强，撤回原硬违规判断。
- 本轮复核指出的 `other`（HTML/DOM 实体）、`invalid`（元数据 patch）与布尔量 `image` 均已分别改为 `otherMessageMarkup`、`invalidMetadata`、`isImage`；Rust 测试局部 ID 改为 `request_id`。追加复核的内嵌 JS 克隆节点也已从 `other` 改为 `otherReferenceElement`，对应 clone、属性赋值和 append 引用一致。上述均按当前源码核对，无行为/API变化。
- 并发职责静态看合理：最终 ledger 校验及文件复验后先 `drop(ledger)`，再进入可能等待 UI/OS 的 `perform_open`；文件 guard 跨派发。未见回调持 ledger 的死锁路径。锁内 lease/文件复验可能延长失效操作等待，属于性能权衡，未据此报硬问题。

## 值得讨论：1 项启发式异味

- **可能的 Data Clumps**（判断，非硬违规；`C:\Users\Orcs0\.codex\skills\code-review\SKILL.md §3`）：`reference` 与 `messageIdentity` 在 `App`、`WorkspaceFileOpen`、`WorkspaceImage`、`ContentViewer` 间反复同行传递；若后续扩展来源元数据，可考虑小型来源身份类型。另 `ContentViewer` 与 `WorkspaceFileOpen` 互相导入，提取 `CopyContent` 到叶模块可消除循环；这是结构观察，不计标准违规。

其余固定异味基线未见充分证据。最新 `review.diff` 已刷新（17 个非空差异文件）；当前计数：**硬问题 0，启发式异味 1**。锁结论为静态审查，非实测结论。
