> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 第13票规格审查

## 做得好的

- [approval-drafts.ts](../../../../../../frontend/src/approval-drafts.ts#L55) 持久保存 submission ID、草稿版本和原 responses；重开把 pending 改为 unknown，接受后保留锁定记录（第121行）。[conversation-state.ts](../../../../../../frontend/src/conversation-state.ts#L625) 仅在当前身份、Run interrupted 且审批经核实后开放操作；符合票13第20–23行及交互契约§5–7。

## 需要修的（初审记录，已修复）

- 初审发现清理只比 checkpoint，会在处理事件缺少对应 required 时误删本地草稿：契约要求按匹配身份清理（[003 §5，第78行](../../../../../wayfinder/frontend-completion/tickets/003-approval-cancel.contract.md#L78)），而投影明确允许没有 required 的处理事件（[run-projection.ts:94](../../../../../../frontend/src/run-projection.ts#L94)）。当前树已修：用 `collectApprovalRecords` 得到有真实 resolution 的完整 identity 后才清理（[conversation-state.ts:168](../../../../../../frontend/src/conversation-state.ts#L168)）；新增缺少 required 的回归用例（[approval-draft-recovery.test.mjs:317](../../../../../../frontend/tests/approval-draft-recovery.test.mjs#L317)）。我未执行测试。

## 值得讨论

- 初审建议调整 [App.tsx:287](../../../../../../frontend/src/App.tsx#L287) 的 409 文案，避免自动 GET 已停止后仍暗示“正在重建”。已采纳为“审批已变化，请核实同一运行；以当前请求和实际处理记录为准”。未发现越界行为。

## 最终结论

当前树无未解决的 Spec 硬问题（0 项）。初审问题与文案建议均已修复；本审查未执行测试。
