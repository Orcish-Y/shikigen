> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 会话页长由前端传入

用户追加要求（2026-10-04）：`get_thread` 当前只有 cursor，`list_threads` 的条目限制应由前端传递，store 不写死。

## 实现范围与验收

- `GET /api/threads?limit=20&cursor=...`：limit 是必填正整数，cursor 可选；保留 `{data, next_cursor}`、摘要状态、排序及既有游标语义。
- HTTP → ThreadService → ChatStore → ThreadStore 都明确接收并传递 limit，无默认 20。store 使用参数绑定的 SQL LIMIT，读取 limit+1 条、返回最多 limit 条，额外记录决定下一页。跨页可以改变 limit。
- 前端 ConversationStore 统一配置页长 20，每次首次、刷新、重载、下一页和重试都显式传递。BackendSession 校验正整数及响应条数，结束判断使用前端同一配置。
- 缺少／非法 limit、重复或未知查询参数返回 422 和 no-store；已有非法 cursor、503 Retry-After、500 路径保留。
- 补验 1／7／20／25 条页长的空页、整页、余页，3→25→50 跨页变更，Python 公共调用、参数验证、客户端编码和响应上限；保留列表去重、状态优先级、独立分页请求和聊天隔离回归。
- SQLite 的整数绑定有限范围。预读条数以十进制文本绑定并 CAST 成数据库整数，避免极大正整数 limit 引发 500；这只处理存储表示范围，返回页长仍由调用方 limit 决定。边界回归覆盖 2^63−1、2^63、10^100 的 HTTP 与 Python 查询。[SQLite CAST 语义](https://www.sqlite.org/lang_expr.html#castexpr)规定超出范围的正整数转换到最大可表示值。
- 本次不启动第 3 票。UI 风格及前端每页 20 条保持已有要求。

## 验证与审查边界

主 agent 实现与修复，最终验证委派 gpt-6-luna / max（fork_turns=none），前后端可并行。测试子 agent 不修改产品代码，不操作 Git，不重跑与本次无关的原生视觉／物理键盘验收。

变更前固定点为本次修改前工作副本快照 `before/`；文件清单 `files.txt`，审查差异 `change.diff`。不使用整仓库 staged 改动作为本次审查范围，不进行 Git 写操作。
