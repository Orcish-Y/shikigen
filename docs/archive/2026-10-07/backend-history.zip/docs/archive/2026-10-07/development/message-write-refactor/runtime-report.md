> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 统一消息写入重构：运行验证报告

## 模型与环境

- 实际模型：gpt-6-luna，推理强度 max。
- 工作目录：C:\code\shikigen-agent。
- Python：.venv/Scripts/python.exe，未调用供应商或外部模型。
- 所有逐文件专项使用命令格式：.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p <文件名> -v。
- 完整 stdout/stderr、准确命令、cwd、UTC 起止时间、退出码与计数保存在 .scratch/message-write-refactor/logs/ 对应日志和 meta 文件中。首轮失败日志未覆盖。

## 首轮专项：修复前结果

先按交接顺序逐文件运行：

| 测试文件 | 结果 | 证据 |
| --- | --- | --- |
| test_message_write_transaction.py | 7 项，OK | logs/test_message_write_transaction.log |
| test_failure_partial_message.py | 12 项，OK | logs/test_failure_partial_message.log |
| test_cancel_partial_message.py | 10 项，OK | logs/test_cancel_partial_message.log |
| test_execution.py | 9 项，OK | logs/test_execution.log |
| test_runtime.py | Ran 20，FAILED（failures=1, errors=2） | logs/test_runtime.log |

首轮前四个文件 Ran 38，全部 OK。第五个文件只有 TransactionTests.test_creation_failure_and_cancellation_roll_back_all_facts 失败：旧故障注入 patch 了 RunEventIngestor.write_in_transaction，并预期该方法第二次调用时抛错；当前入口 human 消息改由 EventStore.write_message_in_transaction 写入，所以注入点没有执行。失败后留下活动 Run，使该父测试的后续 CancelledError 子测与最终创建触发 ThreadBusy。failure/error 汇总来自同一个父测试中的子测试与父级错误，不能把 20 减去 3 当作独立通过用例数。首轮原始日志和 meta 保留在上表路径。

主 agent 修复了测试故障注入点：patch 入口消息实际使用的事务内写入方法，在完成真实 INSERT 后注入 OSError 或 CancelledError，从而验证整笔事务回滚及原有断言。

## 修复后的专项结果

十二个相关文件已在当前版本通过。首轮四个 OK 文件未重复执行；修复后的 test_runtime 与剩余七项使用独立的 r2 日志。

| 测试文件 | 结果 |
| --- | --- |
| test_message_write_transaction.py | 7/7 通过 |
| test_failure_partial_message.py | 12/12 通过 |
| test_cancel_partial_message.py | 10/10 通过 |
| test_execution.py | 9/9 通过 |
| test_runtime.py（修复后 r2） | 20/20 通过 |
| test_run_cancel.py | 8/8 通过 |
| test_run_events.py | 6/6 通过 |
| test_run_usage.py | 9/9 通过 |
| test_approval_resume.py | 11/11 通过 |
| test_server.py | 17/17 通过 |
| test_message_contract.py | 7/7 通过 |
| test_storage_contracts.py | 10/10 通过 |

当前版本专项累计 Ran 126，126 通过、0 失败、0 错误、0 跳过。修复后的结果日志为 logs/test_runtime-r2.log、logs/test_run_cancel-r2.log、logs/test_run_events-r2.log、logs/test_run_usage-r2.log、logs/test_approval_resume-r2.log、logs/test_server-r2.log、logs/test_message_contract-r2.log、logs/test_storage_contracts-r2.log；各自对应 .meta.json 保留命令和时间。

## 唯一一次完整后端验证

实际命令：

.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v

工作目录：C:\code\shikigen-agent。

- UTC 开始：2026-10-05T17:12:11.6475539+00:00
- UTC 结束：2026-10-05T17:21:08.9776970+00:00
- 退出码：0
- unittest 输出：Ran 320 tests in 528.496s；OK (skipped=1)
- 结果：319 通过、0 失败、0 错误、1 跳过。
- 唯一跳过：test_runtime_data.RuntimeDataTests.test_symlink_data_and_parent_are_rejected；原因是 Windows symlink privilege is unavailable。
- 完整日志：logs/unittest-discover-final.log；命令、模型、计数与 UTC 时间：logs/unittest-discover-final.meta.json。

完整命令只执行了一次，没有重复启动。完整套件经过包含此重构的所有已发现 Python 测试；GUI 手动实机验收与真实系统 IME 未运行。

## 历史问题与覆盖边界

approval cleanup 的 3 秒超时、Windows 空环境宿主退出超时、真实系统 IME Enter 超时等历史条目继续保留待查。本次完整 suite 中 test_missing_environment_reports_name_and_exits 通过，不据此关闭空宿主历史问题；Windows symlink 用例仍因权限不足被跳过，也不视为通过。GUI 与真实系统 IME 未覆盖，不对其行为作结论。
