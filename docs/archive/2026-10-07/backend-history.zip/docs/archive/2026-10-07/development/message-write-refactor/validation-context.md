> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 统一消息写入与结算事务重构：验证交接

## 授权与环境

用户要求移除 partial_messages，并授权按前一轮方案修改；最新消息明确要求重新读取 AGENTS.md 后实施。主 agent 已重读。全程中文，主 agent 实现／修复，最终项目验证必须显式使用 gpt-6-luna / max 子 agent。测试子 agent 不修改产品、不放宽或删除断言、不操作 Git 暂存／提交。

工作目录 C:/code/shikigen-agent；Windows PowerShell，Python 3.12 .venv/Scripts/python.exe，Ruff/ty 都在 .venv/Scripts。危险全访问，approval never，不能传 sandbox_permissions。无依赖变更，不调用供应商或外部模型；现有测试使用离线真实 Graph／HTTP／SQLite 临时库。

本轮开始 HEAD 为 e0ea6ae，已有 236 个 staged 条目（第 11 票代码／文档／证据），3 个 unstaged runtime 文件含失败保存与命名修改。全部保留，禁止 staging/reset/commit。原始 .git/index SHA256 保存于 index-before.json。四个产品文件与七个被调整的旧测试的本轮前版本保存于 before/，用于区分这次重构与已有改动。

## 目标与验收

1. RunTransitions.settle_execution、cancel_run 及对应事务内方法／RunSettlement 协议不再接收消息正文；产品源码移除 partial_messages。
2. EventStore.write_message_in_transaction 统一普通 complete、cancelled、error 的规范化消息写入；身份、metadata 冲突、原 seq／正文／工具记录、严格 JSON 校验沿用既有规则。普通自动事务包装入口仍可用。
3. RunEventIngestor 冻结缓冲、自己开启共享事务。仅仍 running 的失败或仍非终态的取消将缓冲转为普通 AI 消息；正常完整记录不覆盖。消息写入与 Run 原因／状态／用量／生命周期同事务；数据库提交后才清空缓冲、封口和广播。
4. 消息实际插入与广播都在 Run 生命周期事实之前，id 游标单调性／预留 seq 不变。事务内方法不自行提交、不重入锁、不发布。
5. 回滚保留缓冲和失败结算 owner；取消失败不请求 abort。首终态、迟到 usage、interrupted 与根快照重放保护保留；已有启动失败后台 owner／shutdown 协议保留，重试不执行 Graph。
6. 用户暂存区及其他改动保留，HTTP／SSE／数据库／前端契约不变。

规格背景：docs/wayfinder/frontend-completion/implementation/10-cancel-partial-message.md、11-failure-partial-message.md、.scratch/frontend-completion/PRD.md 第 11 节。当前仅内部重构，不推进第 12 票或更改已验收票据状态。

## 实现与改动范围

- packages/harness/shikigen/persistence/event_store.py：自动提交入口的消息分支调用 write_message_in_transaction；共同内部事件 writer 保留幂等、序号、metadata、冲突和 JSON 校验；事务内 writer 不加锁／提交。
- runtime/runs.py：独立事务 wrapper 保留；新增 settle_execution_in_transaction 与 cancel_run_in_transaction，仅负责状态／生命周期／usage，不接收正文。入口 human 消息也复用统一 writer。
- runtime/run_events.py：settle/cancel 持原 Run 接入锁，在一个 ChatStore.transaction 中先暂写 buffered AI 消息，再调用事务内结算函数。事务内先读 Run 状态；后续 invocation／usage／approval 校验若失败，全部暂写统一回滚。提交后清理封口。_partial_messages 删除，committed 集合改为 committed_message_ids，取消回调名改为 cancel_fn。
- runtime/run_execution.py：有 ingestor 时绑定事务内方法，独立执行 fake／无 ingestor 仍调用原独立方法。重试／启动后台 owner／cleanup 逻辑不改。
- 旧测试：test_runtime.py、test_server.py、test_approval_resume.py、test_run_cancel.py 的暂停提交前／后 barrier 移到 ingestor.settle，保持原提交时机，避免在新事务内 barrier 阻塞读。存储故障注入改为事务内 transition；cancel callback 接受 transaction 位置参数。test_run_events.py、test_run_usage.py、test_cancel_partial_message.py 相应同步注入方法名。原断言不删除／放宽。
- tests/test_execution.py：ControlledSettlement 补齐两个事务内 protocol 方法，假模块仍不声称 SQLite 验证。
- tests/test_message_write_transaction.py：新 7 项，验证两个终态共享事务的完整回滚、统一 writer 的 seq／metadata／冲突／幂等、正常写入复用、状态接口无消息 payload，以及失败 Runtime 的共同 writer／广播顺序／第二条消息失败时首条也回滚并由原 owner 重试。只复用 FailureGraph，不继承或导入其 TestCase，避免重复发现旧用例。

## 已做检查与计划

主 agent 仅格式化这 13 个 Python 文件，未运行本轮功能测试；没有声称本轮通过。第 11 票历史后端 313 总／312 通过／1 Windows symlink skip，仅为基线记录，不能代替本轮。

运行验证 agent 先按文件逐项执行新专项与相关旧专项，记录每条命令/cwd/实际模型/UTC/退出码/完整 stdout stderr/数量，不汇总重复计数。建议先 test_message_write_transaction.py、test_failure_partial_message.py、test_cancel_partial_message.py，再 test_execution.py、test_runtime.py、test_run_cancel.py、test_run_events.py、test_run_usage.py、test_approval_resume.py、test_server.py、test_message_contract.py、test_storage_contracts.py。发现失败立即报告，不继续反复重跑到绿，不自行修。

精确专项命令（repo cwd）：.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -p <文件名> -v。

最后在主 agent 确认静态／专项修复完毕后仅执行一次完整后端：.venv/Scripts/python.exe -X utf8 -m unittest discover -s tests -v。预计 320 项，以实际结果为准；GUI 不运行，其他子 agent 仅只读静态检查，可并行。保留旧审批 3 秒 cleanup 超时、Windows 空宿主退出超时、Windows symlink 跳过的真实结果，不归为无关或环境修复。

独立静态验证 agent：.venv/Scripts/ty.exe check app packages/harness；再对本轮九个测试文件用 --extra-search-path tests 检查；.venv/Scripts/ruff.exe check 与 format --check 对上述四个产品＋九个测试。可并行类型与 Ruff；不运行功能测试或 GUI，独立审阅事务所有权、锁顺序、首终态／回滚／广播、规范命名及旧断言保留，报告真实诊断给主 agent 修复。

日志与报告全部放 .scratch/message-write-refactor/，可复用 ticket-11/run-command.ps1 的内容作为本目录 wrapper，不修改旧文件。raw log／历史失败／截图不能删除或改写。禁止 kill 不归属进程，无需启动原生窗口／前端构建；本轮仅后端内部接口，真实系统 IME 与旧原生偶发超时不在此次覆盖。

## 已有风险与未解决问题

持续写失败仍只持有进程内 owner，不保证强杀未提交内存可恢复；GET 不补写。既有失败 settlement 捕获所有 Exception 并重试的异常分类建议仍保留，不借重构改变策略。

.scratch/approval-cleanup-test-timeout/issues/01-approval-resume-settlement-timeout.md、.scratch/desktop-environment-exit-timeout/issues/01-empty-host-environment-startup-exit.md、.scratch/native-ime-enter-timeout/issues/01-composition-enter-no-post.md 仍 needs-triage。本轮通过不抵消历史失败，未执行 GUI 或物理系统 IME 不算通过。

## 首轮验证发现与修正

- 新专项 7 项、失败正文 12 项、取消正文 10 项、执行 9 项首先通过。Runtime 首轮故障注入未迁移：原测试在 RunEventIngestor 的第二次调用后抛异常，但入口 human 消息已改走公共 writer。主 agent 改为拦截同一存储上的 write_message_in_transaction，在实际消息 INSERT 后抛 OSError／CancelledError，保留 Run、全部消息回滚和重试可创建的原断言。首错日志保留；修后使用独立 r2 记录。
- 静态检查发现 union callback 类型、一个旧 append 闭包的错误 args 转发、新 get_run 可空值下标及新 ingestor hook 的可空访问，主 agent 已分别用明确分支、恢复 kwargs 转发和 nonnull 断言修正；新测试 import 已排序。原 9 测试合并 ty 报 159 项，须分清既有测试类型债和本轮诊断，不能把检查说成全通过。
- Git binary index hash 的变化无法证明暂存内容被改；已按 path／blob／stage 清单核对，两边 2412 条，差异 0。后续只读核对 staged-manifest.txt；本轮没有 staging 或 commit 命令。
