> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Dev port fallback native CLI validation

- Date: 2026-10-07
- Model: `gpt-6-luna`, reasoning `max` (assigned validation model)
- Shell / OS: PowerShell on Windows
- CLI working directory: `C:\code\shikigen-agent\frontend`
- Scope: real Vite listener fallback and real Tauri CLI config/runner dispatch. No product or test files were edited. Temporary probe sources, binaries, and capture logs are in this directory.

## Results

**8 checks passed, 0 failed, 1 skipped.** The skipped check is launching the actual Shikigen WebView window and observing an in-window HMR refresh. The Tauri CLI was run for real, but `--runner` pointed at a temporary capture process so the application executable and its database were never started.

### Passed checks

1. **Vite fallback across two occupied ports.** Before starting anything, ports 5173 and 5174 were free. An owned HTTP blocker (PID 15288 in the first run) then listened on both ports. From `frontend`, `pnpm dev` logged attempts on 5173 and 5174 and selected `http://127.0.0.1:5175/`. GET `/` and `/@vite/client` both returned 200. The blocker returned its own 200 response on both occupied ports throughout the check.
2. **Dev help does not start Vite.** `pnpm tauri dev --help` returned 0. In the final-code run, port 5175 remained free and blockers remained on 5173/5174.
3. **Build help does not start Vite.** `pnpm tauri build --help` returned 0. In the final-code run, port 5175 remained free.
4. **Real Tauri CLI success path and runtime override.** `pnpm tauri dev --no-watch --runner <scratch capture-runner.exe>` returned 0 and reached Tauri's `Running DevCommand`. The runner captured:
   - `TAURI_CONFIG={"build":{"devUrl":"http://127.0.0.1:5175/","beforeDevCommand":null}}`
   - actual runner arguments: `run --no-default-features --color always --`
   - GET of the captured `devUrl`: `HTTP/1.1 200 OK`; response HTML included the Vite client.

   This check passed before and after the final lazy import change. The CLI reached the runner while 5173/5174 were blocked; no second strict-port Vite start occurred. Final-code capture: [runner-final-success.txt（原始产物已删除）](../../../../README.md#已删除的材料).
5. **Runner failure propagates and releases Vite.** In the pre-lazy-import run, the capture runner was set to exit 23. Tauri CLI returned 23, and port 5175 was free immediately afterward. Evidence: [runner-failure.txt（原始产物已删除）](../../../../README.md#已删除的材料).
6. **Invalid CLI arguments release Vite.** In the pre-lazy-import run, `pnpm tauri dev --no-such-option` returned 2, and port 5175 was free immediately afterward.
7. **Ctrl-C releases owned runtime processes.** This was repeated on the final code. While the wait runner was active, the wrapper's Vite listener on 5175 returned 200 for both `/` and `/@vite/client`; the runner captured the same runtime config with `devUrl` 5175 and `beforeDevCommand:null`. Ctrl-C ended the CLI session with exit code 1; wrapper PID 26856 and runner PID 30924 were gone, and 5175 was free. Evidence: [runner-cancel.txt（原始产物已删除）](../../../../README.md#已删除的材料) and the final-code [runner-final-cancel.txt（原始产物已删除）](../../../../README.md#已删除的材料).
8. **Process and port cleanup.** The owned blocker was stopped after all checks. Final state: ports 5173, 5174, and 5175 free; final blocker PID 12468 gone; no probe runner or Tauri wrapper remained.


## Invocation provenance

Exact commands, flags, working directories, probe-owned environment values, exit codes, and before/during/after port and PID observations are in [invocations.json（原始产物已删除）](../../../../README.md#已删除的材料). The capture-runner files are persisted evidence. CLI/Vite stdout was visible in tool results but was not separately saved as a raw-output file; the report and JSON summarize those observations and do not claim to be raw logs.

### Version boundary

The root agent made one final behavior-preserving change after the first integration pass: `@tauri-apps/cli` moved from a top-level import into a lazily loaded callback. The runner-failure and invalid-argument checks above were run before that change and were not repeated, per the root agent's instruction. The final code was rechecked for both help paths, successful CLI/config dispatch, and Ctrl-C cancellation. The successful final capture proves `TAURI_CONFIG` still carries the selected port and disables `beforeDevCommand`.

### Commands and exit codes

| Command | Result |
|---|---|
| `pnpm dev` (5173/5174 occupied) | Selected 5175; `/` 200; `/@vite/client` 200. Intentionally stopped with Ctrl-C (session code 1). |
| `pnpm tauri dev --help` | 0; no Vite listener on 5175. |
| `pnpm tauri build --help` | 0; no Vite listener on 5175. |
| `pnpm tauri dev --no-watch --runner .scratch/.../capture-runner.exe` | 0; actual CLI runtime config captured; runner GET 200. |
| Same command with runner forced to exit 23 | CLI returned 23; Vite listener released. |
| `pnpm tauri dev --no-such-option` | CLI returned 2; Vite listener released. |
| `pnpm tauri dev --no-watch --runner .scratch/.../wait-runner.exe`, then Ctrl-C | Session code 1; wrapper, runner, and port 5175 released. Repeated after final code change. |

The full `pnpm test` and `pnpm build` suites were not run here; another validation agent owns them. No actual app window, user database, LLM, MCP, POST request, or persistent config was used.