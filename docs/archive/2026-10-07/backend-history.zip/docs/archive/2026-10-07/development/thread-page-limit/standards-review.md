> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Standards 审查

## 做得好的

- `ThreadService`、`ChatStore` 与 `ThreadStore` 使用必填关键字参数传递页长；store 将 `limit + 1` 作为 SQL 参数，并以同一 limit 截取结果、判断下一页，符合 [docs/project.md](../../../../project.md) 中的接口约定。
- 前端在 `conversation-state.ts` 集中定义页长，并用 `URLSearchParams` 编码请求；后端仅为该列表端点的参数验证错误补 `no-store`。

## 需要修的

- 文档标准硬违规：**0**。
- Fowler 判断性 smells：**0**。参数沿 HTTP、Runtime、ChatStore、ThreadStore 传递是本次接口契约要求，也符合项目现有模块边界；不把必要的跨层调用更新当作 Shotgun Surgery。

## 值得讨论

- 无新增标准层面的讨论项。此次前端仍使用 20 条页长，与 PRD 和项目文档一致。

## 增量复核：大 limit 的 SQLite 绑定

- `ThreadStore` 将 `limit + 1` 转为十进制文本并绑定到 `LIMIT CAST(? AS INTEGER)`；相邻注释说明这是为避免 SQLite 参数绑定溢出。该改动局部、可读，没有新增重复逻辑或抽象。
- 本增量的文档标准硬违规：**0**；新增 Fowler smell：**0**。
- 未运行测试，未修改产品代码或 Git。
