> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Final Tauri CLI origin inheritance validation

- Date: 2026-10-07
- Model: gpt-6-luna, reasoning max
- Frontend working directory: C:\code\shikigen-agent\frontend
- Source hashes, exact commands, environment fields, exit codes, port/PID observations, and process cleanup: [invocations.json（原始产物已删除）](../../../../README.md#已删除的材料)

## Result

The final pnpm tauri dev --no-watch --runner command returned **0**. Its real Tauri CLI runner captured:

- TAURI_CONFIG.build.devUrl = http://127.0.0.1:5175/
- SHIKIGEN_DESKTOP_DEV_ORIGIN = http://127.0.0.1:5175 (same origin, no trailing slash)
- GET / and /@vite/client: both HTTP/1.1 200 OK

With owned blockers on 5173 and 5174, blocker PID 18768 continued returning 200 throughout the success and error-path probes. The runner-forced exit 23 propagated as CLI exit 23; an invalid option returned CLI exit 2. Both error paths released the Vite port. After stopping the owned blocker, ports 5173–5175 were unavailable and all observed owned PIDs had exited.

## Scope and limits

This validates environment propagation through the real Tauri CLI runner boundary. It does not launch the application executable or managed Python backend, so it does not directly observe the later app-to-Python inheritance or exercise a WebView. No raw CLI/Vite stdout file was saved; the manifest distinguishes tool output from the persisted runner captures.

The earlier Ctrl-C cleanup result is referenced in the manifest and predates this origin-environment change. It was not rerun per instruction. Runner-failure and invalid-argument cleanup were run against this final source. Full Node and Python suites are being handled by the other validation agents.