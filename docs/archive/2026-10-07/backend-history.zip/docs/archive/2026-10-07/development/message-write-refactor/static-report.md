> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 统一消息写入与结算事务重构：静态验证报告

## 范围与结论

- 仓库：`C:\code\shikigen-agent`；所有命令均以该目录为工作目录，PowerShell 7.6.6。
- 验证模型：`gpt-6-luna`，推理强度 `max`。
- 覆盖：4 个产品文件与 9 个相关测试文件的 ty/Ruff 静态检查；事务所有权、锁顺序、提交与发布时序、缓冲回滚、首终态、消息身份/序号、生命周期发布、旧断言和命名审阅。
- 本审阅没有运行功能测试、GUI 或前端构建。功能专项由另一验证 agent 执行。
- 修复后结果：产品 ty 通过；新增事务测试独立 ty 通过；13 文件 Ruff check 与 format check 通过。全 9 个测试文件的 ty 仍报告 152 项旧测试代码类型诊断，见下表；没有一项诊断定位在快照对照所得的本轮修改行内。该定位结果没有通过对完整修改前代码包重新运行 ty 来证明严格基线，因此不能断言所有 152 项在修改前就已经存在。

产品文件：

- `packages/harness/shikigen/persistence/event_store.py`
- `packages/harness/shikigen/runtime/runs.py`
- `packages/harness/shikigen/runtime/run_events.py`
- `packages/harness/shikigen/runtime/run_execution.py`

13 文件 Ruff / 9 文件 ty 的测试文件：

- `tests/test_approval_resume.py`
- `tests/test_cancel_partial_message.py`
- `tests/test_execution.py`
- `tests/test_message_write_transaction.py`
- `tests/test_run_cancel.py`
- `tests/test_run_events.py`
- `tests/test_run_usage.py`
- `tests/test_runtime.py`
- `tests/test_server.py`

## 命令与结果

下列日志元数据均记录命令、cwd、UTC 开始/结束、退出码、模型及 stdout/stderr。首轮失败日志保留，修后复核使用 `r2`、`r3` 后缀。

| 轮次 | 命令 | UTC 时间 | 退出码 | 结果 |
|---|---|---|---:|---|
| r1 | `.venv/Scripts/ty.exe check app packages/harness` | 2026-10-05 17:00:25–17:00:28 | 1 | 2 项产品诊断，首轮后修复 |
| r1 | `.venv/Scripts/ty.exe check --extra-search-path tests tests/test_approval_resume.py tests/test_cancel_partial_message.py tests/test_execution.py tests/test_message_write_transaction.py tests/test_run_cancel.py tests/test_run_events.py tests/test_run_usage.py tests/test_runtime.py tests/test_server.py` | 2026-10-05 17:00:25–17:00:28 | 1 | 159 项诊断；首轮后修复其中落在新改行的诊断 |
| r1 | `.venv/Scripts/ruff.exe check` + 上述 13 个文件 | 2026-10-05 17:00:25 | 1 | `test_approval_resume.py:406` F821、`test_message_write_transaction.py:3` I001；首轮后修复 |
| r1 | `.venv/Scripts/ruff.exe format --check` + 上述 13 个文件 | 2026-10-05 17:00:25 | 0 | 13 files already formatted |
| r2 | `.venv/Scripts/ty.exe check app packages/harness` | 2026-10-05 17:07:10 | 0 | 通过 |
| r2 | `.venv/Scripts/ty.exe check --extra-search-path tests tests/test_message_write_transaction.py` | 2026-10-05 17:07:10–17:07:11 | 0 | 新增事务测试无诊断 |
| r2 | `.venv/Scripts/ruff.exe check` + 上述 13 个文件 | 2026-10-05 17:07:10 | 0 | All checks passed |
| r2 | `.venv/Scripts/ruff.exe format --check` + 上述 13 个文件 | 2026-10-05 17:07:10 | 0 | 13 files already formatted |
| r2 | `.venv/Scripts/ty.exe check --extra-search-path tests` + 上述 9 个测试文件 | 2026-10-05 17:07:31 | 1 | 152 项旧测试代码类型诊断；修改行定位方法及限制见下节 |
| r3 | `.venv/Scripts/ty.exe check app packages/harness` | 2026-10-05 17:11:29–17:11:32 | 0 | 重命名后产品检查通过 |
| r3 | `.venv/Scripts/ruff.exe check packages/harness/shikigen/runtime/runs.py` | 2026-10-05 17:11:29 | 0 | 通过 |
| r3 | `.venv/Scripts/ruff.exe format --check packages/harness/shikigen/runtime/runs.py` | 2026-10-05 17:11:29 | 0 | 通过 |

13 文件 Ruff 命令的完整 argv 如下（工作目录 `C:\code\shikigen-agent`）：

```powershell
.venv/Scripts/ruff.exe check packages/harness/shikigen/persistence/event_store.py packages/harness/shikigen/runtime/runs.py packages/harness/shikigen/runtime/run_events.py packages/harness/shikigen/runtime/run_execution.py tests/test_approval_resume.py tests/test_cancel_partial_message.py tests/test_execution.py tests/test_message_write_transaction.py tests/test_run_cancel.py tests/test_run_events.py tests/test_run_usage.py tests/test_runtime.py tests/test_server.py
.venv/Scripts/ruff.exe format --check packages/harness/shikigen/persistence/event_store.py packages/harness/shikigen/runtime/runs.py packages/harness/shikigen/runtime/run_events.py packages/harness/shikigen/runtime/run_execution.py tests/test_approval_resume.py tests/test_cancel_partial_message.py tests/test_execution.py tests/test_message_write_transaction.py tests/test_run_cancel.py tests/test_run_events.py tests/test_run_usage.py tests/test_runtime.py tests/test_server.py
```

对应原始命令及 stdout/stderr 位于 `logs/`，各命令的 `*.meta.json` 记录精确 argv 和 UTC 时间。

关键日志：

- 首轮：`logs/ty-product.stdout.log`、`logs/ty-tests.stdout.log`、`logs/ruff-check.stdout.log`、`logs/ruff-format.stdout.log`
- 修后 r2：`logs/ty-product-r2.stdout.log`、`logs/ty-new-test-r2.stdout.log`、`logs/ty-tests-r2.stdout.log`、`logs/ruff-check-r2.stdout.log`、`logs/ruff-format-r2.stdout.log`
- 最终 r3：`logs/ty-product-r3.stdout.log`、`logs/ruff-check-runs-r3.stdout.log`、`logs/ruff-format-runs-r3.stdout.log`

## 静态审阅

### 做得好

- 独立事务入口继续存在；`settle_execution_in_transaction` 和 `cancel_run_in_transaction` 只接收状态/结算参数与事务，不接收消息正文。事务包装入口把提交责任留在 `ChatStore.transaction()`，事务内方法不自行提交、加锁或广播。
- `EventStore.write_message_in_transaction` 先规范化消息并派生身份，再复用共享事件 writer。共享 writer 保留运行存在性检查、预留消息 seq、单调分配、幂等返回、正文/metadata 冲突检测，以及 `allow_nan=False` 的严格 JSON 序列化。普通自动事务消息入口也委托到该 writer。
- `RunEventIngestor.settle` / `cancel` 持每 Run 接入锁并打开一个共享数据库事务；仅在运行仍符合失败/取消条件时写缓冲 AI 消息，之后调用事务内状态转移。事件结果把新消息放在审批/生命周期结算事件之前；协调器在事务提交和 ingestor 返回后按该顺序发布。
- 数据库事务异常会先回滚，异常路径不会运行成功后的封口/清缓冲代码；失败执行仍由原 owner 持有 outcome 重试事务，不重新运行 Graph。取消只有在事务成功返回取消状态后才调用 `request_cancel()`。
- `partial_messages` / `_partial_messages` 在 `packages/harness/shikigen` 与 `tests` 中无命中。原有 7 个测试快照的修改限于注入点、回调参数和故障注入目标；没有删除或放宽旧断言。`test_runtime.py` 的创建回滚测试现在在消息 writer 已真实执行后再注入 `OSError` / `CancelledError`，仍保留运行与消息均回滚的断言。
- `runs.py` 结算逻辑中的事件实体已按审阅修正为 `running_event`；最终 ty 和该文件 Ruff 复核通过。

### 需要修

- 当前范围内没有剩余静态检查诊断落在新增测试或本轮修改行上。首轮发现的 transaction callback 类型 union、未定义 `args`、新测试对可空 `get_run()` 的下标访问、可空 `_ingestor` 使用，以及 Ruff import 顺序均已由主 agent修复并由 r2/r3 检查复核。
- 全 9 个测试文件的 ty 命令仍失败，不能记为通过。r2 输出共 152 项，类型分类为：`unresolved-attribute` 87、`invalid-argument-type` 44、`not-subscriptable` 14、`invalid-assignment` 6、`no-matching-overload` 1。按文件计数：

| 文件 | 诊断数 |
|---|---:|
| `tests/test_approval_resume.py` | 17 |
| `tests/test_execution.py` | 3 |
| `tests/test_run_cancel.py` | 76 |
| `tests/test_run_events.py` | 19 |
| `tests/test_run_usage.py` | 22 |
| `tests/test_runtime.py` | 7 |
| `tests/test_server.py` | 8 |
| **合计** | **152** |

### 值得讨论

- 上述 152 项逐条与修改前快照的 `git diff --no-index --unified=0` 新行范围比对；7 个有 before 快照的旧测试中，0 项落在修改行。`test_execution.py` 的 3 项位于 `git diff HEAD` 新增 fake 协议方法 hunk 之外；新增 `test_message_write_transaction.py` 单独 ty 检查为 0 项。该方法只定位本轮新增/改动行，不是完整修改前包的 ty 基线执行；旧行上的错误仍需保持为未解决的测试静态类型问题，不据此宣称基线严格相同。
- 本静态审阅不替代另一 agent 的功能测试；测试通过数、功能错误路径和竞态覆盖应以其报告为准。本轮 GUI、原生 IME、前端构建均未执行。

## 暂存区审计记录

- 原始 `.git/index` SHA256 见 `index-before.json`；仅该二进制 hash 的差异不能证明暂存条目内容改变。
- 保存的 stage manifest 有 2412 条。稍后只读 `git ls-files --stage` 比较在 2412 条时曾为零差异；最终一次比较为 2457 条，较保存清单新增 50 条、缺少 5 条。变化来源未确定；本验证 agent未执行 Git 暂存或提交命令，也不声称暂存区从头到尾未变。
- 该次新增的 50 项中，45 项是本轮审计/并行运行的 `.scratch/message-write-refactor/` 记录与 wrapper；另 5 个 staged test blob 更新为：`tests/test_approval_resume.py` `6996758c0dbed5be78c23375a052fe129e94244c`、`tests/test_message_write_transaction.py` `5f5da9821b97746689ed4f717280be6550355e69`、`tests/test_run_cancel.py` `c8053a78a6e1da7210ca720aa6e73bf04fa3a853`、`tests/test_runtime.py` `eb99b19c2b142e0b2d0ffc094dbc23998f9a9a7a`、`tests/test_server.py` `76372e32c826ea8682dd90698f2280f48fa40867`。移除的是同五路径的旧 staged blob；完整 50/5 路径与 hash 见 `logs/staged-manifest-delta-final.json`。这组差异中没有产品源文件 blob。


