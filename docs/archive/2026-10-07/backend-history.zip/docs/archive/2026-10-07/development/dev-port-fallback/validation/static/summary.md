> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# 端口回退修复：静态与 Node 验证

日期：2026-10-07  
验证模型：gpt-6-luna / max  
工作目录：`C:\code\shikigen-agent\frontend`

## 最终通过项

| 命令 | 结果 | 原始日志与退出码 |
| --- | --- | --- |
| `node --import tsx --test tests/tauri-command.test.mjs` | 8/8 通过；退出码 0；1.81 秒 | `13-final-focused-node.log` / `.exitcode` |
| `pnpm test` | 277/277 通过；失败 0、跳过 0；23.21 秒；退出码 0 | `14-final-pnpm-test.log` / `.exitcode` |
| `pnpm build` | `tsc --noEmit` 成功；Vite 转换 4,893 个模块；退出码 0 | `09-pnpm-build.log` / `.exitcode` |
| `node --check scripts/tauri.mjs` | 通过；退出码 0 | `15-final-node-check-tauri.log` / `.exitcode` |
| `node --check scripts/tauri-command.mjs` | 通过；退出码 0 | `16-final-node-check-tauri-command.log` / `.exitcode` |

构建有一条既有 bundle 大小警告：压缩前 JS chunk 为 642.19 kB，超过 500 kB 提示阈值；构建仍成功。`NODE_OPTIONS` 未设置（长度 0），未检测到 `--require`、`--import` 或 `--test` 注入项；详情见 `node-options-summary.json`。

## 挂起诊断记录

最初几轮专项测试的 8 条用例都打印通过，但 Node runner 没有退出汇总。进程快照定位到 Vite 的 `frontend/tsconfig.json` 文件 watcher：Vite 共创建 14 个 watcher，13 个发出 close，剩余一个 `FSEvent` 仍 `hasRef=true`。不带 `tsx` 的对比也复现了该资源。证据见 `active-resources-7636.json`、`unclosed-watchers-7636.json`、`06-no-tsx-hang-processes.txt`。

`watch: null` 在 Vite 配置合并后没有关闭这个 watcher。随后第一次 `watch.ignored` 断言错误地假设归一化结果仍是函数，专项以 7/8、退出码 1 结束；这属于测试 fixture 断言形状错误，不是产品启动失败，记录见 `12-focused-node-final.log`。主 agent 按 Vite 归一化后的数组形状修正断言，并验证同一忽略回调确实忽略 `tsconfig.json`。最终专项与完整 Node 回归均正常退出并通过。

早期挂起日志、退出码、PID 进程树与 watcher 快照均保留在本目录，包含 `02-pnpm-test.outcome.txt`、`02-pnpm-test-hang-processes.txt`、`05-diagnostic-tsx.outcome.txt`、`05-diagnostic-tsx-hang-processes.txt`、`11-diagnostic-after-watch-null-processes.txt`。挂起轮次没有计入通过数量；只终止了本 agent 启动且经 PID/父子链核对的测试进程，没有触碰另一 agent 的 blocker/Vite 进程。

## 覆盖范围

本次覆盖前端 Node 测试、TypeScript 类型检查、Vite production build 和两个 Tauri 脚本语法检查。另一 agent 使用 `.scratch` capture runner 验证了真实 CLI 调用、占用端口场景，以及该 runner 启动进程的清理。该验证没有实际启动 WebView 做 HMR 刷新，也没有运行 Cargo app 构建。未运行后端测试或真实供应商请求。
