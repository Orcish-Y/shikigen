> 归档于 2026-10-07；正文状态与命令属于原开发阶段。当前完成情况见 [开发交接](../../../../development-handoff.md)。相对路径链接已迁移；代码块中的旧 scratch 路径需按归档路径调整。

# Backend verification report — thread page limit

- Date: 2026-10-04
- Model: gpt-6-luna, max
- Working directory: `C:\code\shikigen-agent`
- Scope: backend list-limit propagation and regression checks for the working-copy snapshot described by `.scratch/thread-page-limit/change.diff`. This report does not treat unrelated staged changes as part of the implementation.
- Product code and formal tests were not edited during verification. No Git write operation was run. No Tauri app was started, and the reserved ports 5173, 9238, and 45200 were not used.

## Results

| Check | Result |
| --- | --- |
| Ruff on all specified paths | Exit 1; 11 diagnostics, all in `frontend/src-tauri/tests/pagination_acceptance.py` |
| Ruff on the same file in the `before/` snapshot | Exit 1; the same 11 pre-existing diagnostics |
| Ruff on the remaining 13 specified paths | Pass |
| `ty check app packages/harness` | Pass |
| Pagination unittest | 11 passed, 0 failed, 0 skipped |
| Full Python unittest discovery (pre-SQLite-fix snapshot) | 289 tests, 288 passed, 0 failed, 1 skipped; exit 0 |
| Large-limit HTTP probe (pre-fix) | Probe runner exit 0; requests at/above `2^63-1` returned HTTP 500 |

The initial Ruff diagnostics comprise one import-order finding and ten line-length findings. Their messages and source lines are already present in the before-snapshot file. The current file has small line-number shifts after added request calls. No Ruff finding was reported in the changed backend files or other formal test files.

The pre-fix full suite's one skip is `test_symlink_data_and_parent_are_rejected`, skipped because Windows symlink privilege is unavailable. Negative-path tests emit expected exception logs (for example malformed SQLite reads and recovery errors); their unittest cases all reported `ok`.

## Commands and evidence

Commands ran in PowerShell from `C:\code\shikigen-agent`.

```powershell
.venv\Scripts\ruff.exe check app/routes/thread.py app/server.py packages/harness/shikigen/persistence/thread_store.py packages/harness/shikigen/persistence/chat_store.py packages/harness/shikigen/runtime/threads.py tests/test_thread_pagination.py tests/test_conversation_queries.py tests/test_desktop.py tests/test_desktop_lifecycle.py tests/test_runtime.py tests/test_server.py tests/runtime_data_worker.py frontend/src-tauri/tests/client_acceptance.py frontend/src-tauri/tests/pagination_acceptance.py
.venv\Scripts\ruff.exe check .scratch/thread-page-limit/before/frontend/src-tauri/tests/pagination_acceptance.py
.venv\Scripts\ruff.exe check app/routes/thread.py app/server.py packages/harness/shikigen/persistence/thread_store.py packages/harness/shikigen/persistence/chat_store.py packages/harness/shikigen/runtime/threads.py tests/test_thread_pagination.py tests/test_conversation_queries.py tests/test_desktop.py tests/test_desktop_lifecycle.py tests/test_runtime.py tests/test_server.py tests/runtime_data_worker.py frontend/src-tauri/tests/client_acceptance.py
.venv\Scripts\ty.exe check app packages/harness
.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_thread_pagination.py -v
.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -v
.venv\Scripts\python.exe -X utf8 .scratch/thread-page-limit/backend-limit-probe.py
```

Log and exit-code files:

- `.scratch/thread-page-limit/backend-ruff.log`, `backend-ruff.exitcode`
- `.scratch/thread-page-limit/backend-ruff-before-pagination.log`, `backend-ruff-before-pagination.exitcode`
- `.scratch/thread-page-limit/backend-ruff-without-pagination-acceptance.log`, `backend-ruff-without-pagination-acceptance.exitcode`
- `.scratch/thread-page-limit/backend-ty.log`, `backend-ty.exitcode`
- `.scratch/thread-page-limit/backend-pagination.log`, `backend-pagination.exitcode`
- `.scratch/thread-page-limit/backend-full-suite.log`, `backend-full-suite.exitcode`
- `.scratch/thread-page-limit/backend-limit-probe.py`, `backend-limit-probe.log`, `backend-limit-probe.exitcode`

## Backend coverage checked

The pagination tests verify:

- Client-selected page sizes across 3 → 25 → 50 with one cursor chain, preserving row order.
- Empty, exact-page, and lookahead boundaries for page sizes 1, 7, 20, and 25, including tied timestamps and the legacy 0/20/21/40/41 counts.
- Required positive integer `limit`, OpenAPI required/integer schema, and uncached 422 for missing, zero, negative, empty, decimal, or non-integer values.
- 422/no-store for malformed cursors, unknown parameters, duplicate cursors, and duplicate limits.
- Public Python `ChatStore` and `ThreadService` callers choosing independent page sizes; store-level rejection of zero, negative, bool, float, and string values.
- Frozen cursor behavior after a boundary row moves or is deleted; rows moved across the boundary remain representable.
- Run-summary state precedence, transaction/rollback behavior, sort-time stability, and existing 503/`Retry-After` or 500 storage-failure handling.

## Boundary finding (pre-fix; revalidation below)

The positive-integer API does not currently define a maximum. The scratch ASGI/SQLite probe observed:

- `limit=1,000,000` and `limit=2^63-2`: HTTP 200 with `Cache-Control: no-store`.
- `limit=2^63-1`, `2^63`, and `10^100`: HTTP 500 with `Cache-Control: no-store`.

The failure log shows `OverflowError: Python int too large to convert to SQLite INTEGER` while binding `limit + 1`. Thus an unbounded positive integer can pass FastAPI validation but fail at the SQLite parameter boundary. The current successful upper boundary observed is `2^63-2`; this is not an ordinary page-size case, but it is a gap between the stated positive-integer contract and storage behavior. No product fix was made by this validation agent.

Reproduce with:

```powershell
.venv\Scripts\python.exe -X utf8 .scratch/thread-page-limit/backend-limit-probe.py
```

No screenshots apply. At the time of the pre-fix complete unittest run there were no failures; the later overflow red/green evidence is listed below. Frontend/Node tests and native Tauri interaction checks were not part of this backend validation scope.




## Follow-up verification after SQLite overflow fix

Date: 2026-10-04. The refreshed diff changes the lookahead binding in `ThreadStore` to `LIMIT CAST(? AS INTEGER)` and binds `str(limit + 1)`. This avoids Python's SQLite integer binding overflow while retaining SQL parameter binding, the existing requested-limit slice, and cursor lookahead behavior. The new formal public test seeds three ordered rows and checks limits `2^63-1`, `2^63`, and `10^100` over HTTP and `ChatStore`: status 200, `no-store`, all three IDs in order, and `next_cursor=null`.

### Follow-up results

| Check | Result |
| --- | --- |
| Ruff on the two changed Python files | Pass; exit 0 |
| `ty check app packages/harness` | Pass; exit 0 |
| Pagination suite | 12 tests passed, 0 failed, 0 skipped |
| Conversation query suite | 4 tests passed, 0 failed, 0 skipped |
| Server suite | 16 tests passed, 0 failed, 0 skipped |
| Follow-up HTTP probe | All 5 values returned 200/no-store, including `2^63-1`, `2^63`, and `10^100` |

The three focused unittest batches ran 32 methods total, with no failures or skips. The new formal large-limit test passed for both public HTTP and direct `ChatStore` calls. The corrected scratch probe uses an empty temporary database and verifies HTTP status/cache behavior for `1,000,000`, `2^63-2`, `2^63-1`, `2^63`, and `10^100`.

The previously reported SQLite overflow is **fixed and revalidated** on the refreshed snapshot. Pre-fix evidence remains available: `backend-overflow-red.log` (formal red test, exit 1) and `backend-limit-probe.log` (HTTP 500 behavior). Post-fix evidence is in `backend-overflow-pagination.log` and `backend-limit-probe-fixed.log`.

### Follow-up commands and logs

Commands ran from `C:\code\shikigen-agent`:

```powershell
.venv\Scripts\ruff.exe check packages/harness/shikigen/persistence/thread_store.py tests/test_thread_pagination.py
.venv\Scripts\ty.exe check app packages/harness
.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_thread_pagination.py -v
.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_conversation_queries.py -v
.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests -p test_server.py -v
.venv\Scripts\python.exe -X utf8 .scratch/thread-page-limit/backend-limit-probe.py
```

Each command's actual result and exit code is preserved in:

- `backend-overflow-ruff.log`, `backend-overflow-ruff.exitcode`
- `backend-overflow-ty.log`, `backend-overflow-ty.exitcode`
- `backend-overflow-pagination.log`, `backend-overflow-pagination.exitcode`
- `backend-overflow-conversation-queries.log`, `backend-overflow-conversation-queries.exitcode`
- `backend-overflow-server.log`, `backend-overflow-server.exitcode`
- `backend-limit-probe-fixed.log`, `backend-limit-probe-fixed.exitcode`

The earlier complete Python discovery result (289 tests, 288 passed, 1 Windows symlink-permission skip) was run **before** this SQLite fix. The full suite was intentionally not rerun after the fix; only the 32 focused methods above were executed on the refreshed backend. Frontend tests/build and five frontend probes were not repeated by this backend verification agent and remain supported by their prior frontend verification evidence. Native Tauri interaction checks remain outside this validation scope.




